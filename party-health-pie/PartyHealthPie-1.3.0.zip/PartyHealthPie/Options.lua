-- The addon menu, under Options > AddOns > Heal Pie (or /php).
local _, ns = ...

local RED, GOLD = "|cffff6060", "|cffffd100"
local refreshers = {}
local category

local function Changed()
	ns.ApplySettings()
end

local function AddRefresher(fn)
	refreshers[#refreshers + 1] = fn
end

function ns.RefreshOptions()
	for _, fn in ipairs(refreshers) do fn() end
end

local function Label(parent, text, x, y, template)
	local fs = parent:CreateFontString(nil, "ARTWORK", template or "GameFontHighlight")
	fs:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
	fs:SetText(text)
	return fs
end

local function Heading(parent, text, y)
	return Label(parent, GOLD .. text .. "|r", 16, y, "GameFontNormalLarge")
end

local function OpenPicker(get, set)
	local start = get()
	local function Current()
		local r, g, b = ColorPickerFrame:GetColorRGB()
		set({ r, g, b })
		Changed()
	end
	local function Cancel()
		set(start)
		Changed()
	end
	if ColorPickerFrame.SetupColorPickerAndShow then
		ColorPickerFrame:SetupColorPickerAndShow({
			r = start[1], g = start[2], b = start[3],
			swatchFunc = Current, cancelFunc = Cancel, hasOpacity = false,
		})
	else
		ColorPickerFrame.func, ColorPickerFrame.cancelFunc, ColorPickerFrame.hasOpacity = Current, Cancel, false
		ColorPickerFrame:SetColorRGB(start[1], start[2], start[3])
		ColorPickerFrame:Show()
	end
end

local function Swatch(parent, x, y, get, set)
	local button = CreateFrame("Button", nil, parent)
	button:SetSize(22, 22)
	button:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
	local edge = button:CreateTexture(nil, "BACKGROUND")
	edge:SetAllPoints()
	edge:SetColorTexture(0.75, 0.75, 0.75, 1)
	local fill = button:CreateTexture(nil, "ARTWORK")
	fill:SetPoint("TOPLEFT", 2, -2)
	fill:SetPoint("BOTTOMRIGHT", -2, 2)
	fill:SetColorTexture(1, 1, 1, 1)
	local function Show()
		local c = get()
		fill:SetVertexColor(c[1], c[2], c[3])
	end
	button:SetScript("OnClick", function()
		OpenPicker(get, function(c)
			set(c)
			Show()
		end)
	end)
	AddRefresher(Show)
	Show()
	return button
end

local function Check(parent, x, y, text, get, set)
	local box = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
	box:SetSize(26, 26)
	box:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
	if text then Label(parent, text, x + 30, y - 6) end
	box:SetScript("OnClick", function(self)
		set(self:GetChecked() and true or false)
		Changed()
	end)
	local function Show() box:SetChecked(get()) end
	AddRefresher(Show)
	Show()
	return box
end

local function Slider(parent, x, y, text, low, high, step, format, get, set)
	local title = Label(parent, text, x, y)
	local readout = Label(parent, "", x + 300, y)

	local bar = CreateFrame("Slider", nil, parent)
	bar:SetOrientation("HORIZONTAL")
	bar:SetSize(280, 16)
	bar:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)
	bar:SetMinMaxValues(low, high)
	bar:SetValueStep(step)
	bar:SetObeyStepOnDrag(true)
	local track = bar:CreateTexture(nil, "BACKGROUND")
	track:SetPoint("LEFT")
	track:SetPoint("RIGHT")
	track:SetHeight(6)
	track:SetColorTexture(0.25, 0.25, 0.25, 1)
	local thumb = bar:CreateTexture(nil, "ARTWORK")
	thumb:SetSize(12, 18)
	thumb:SetColorTexture(1, 0.82, 0, 1)
	bar:SetThumbTexture(thumb)

	local syncing = false
	local function ShowValue(value) readout:SetText(format(value)) end
	bar:SetScript("OnValueChanged", function(_, value)
		if syncing then return end
		set(value)
		ShowValue(value)
		Changed()
	end)
	local function Show()
		syncing = true
		bar:SetValue(get())
		syncing = false
		ShowValue(get())
	end
	AddRefresher(Show)
	Show()
end

local function Percent(v) return string.format("%d%%", math.floor(v * 100 + 0.5)) end
local function Pixels(v) return string.format("%d px", math.floor(v + 0.5)) end

local function ClassName(class)
	if LOCALIZED_CLASS_NAMES_MALE and LOCALIZED_CLASS_NAMES_MALE[class] then
		return LOCALIZED_CLASS_NAMES_MALE[class]
	end
	return class
end

local function MetalChooser(parent, y)
	local buttons = {}
	local x = 16
	for _, metal in ipairs(ns.METALS) do
		local button = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
		button:SetSize(74, 24)
		button:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
		button:SetText(metal.name)
		button:SetScript("OnClick", function()
			ns.db.metal = metal.key
			Changed()
			ns.RefreshOptions()
		end)
		buttons[metal.key] = button
		x = x + 80
	end
	AddRefresher(function()
		for key, button in pairs(buttons) do
			button:SetEnabled(key ~= ns.db.metal)
		end
	end)
end

local function Build(content)
	local y = -12
	Label(content, "Heal Pie", 16, y, "GameFontNormalHuge")
	y = y - 30
	Label(content, "Drag the circle to move it. |cffffffff/php demo|r previews a party, |cffffffff/php demo raid|r a raid.", 16, y)
	y = y - 26

	local preview = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
	preview:SetSize(150, 24)
	preview:SetPoint("TOPLEFT", content, "TOPLEFT", 16, y)
	preview:SetScript("OnClick", function()
		ns.SetDemo(not (ns.demo and not ns.demoRaid), false)
		ns.RefreshOptions()
	end)
	AddRefresher(function() preview:SetText((ns.IsDemo() and not ns.demoRaid) and "Stop Preview" or "Preview Party") end)

	local reset = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
	reset:SetSize(150, 24)
	reset:SetPoint("TOPLEFT", content, "TOPLEFT", 174, y)
	reset:SetText("Reset to Defaults")
	reset:SetScript("OnClick", function()
		ns.ResetDB()
		Changed()
		ns.RefreshOptions()
	end)
	y = y - 42
	local raidPreview = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
	raidPreview:SetSize(150, 24)
	raidPreview:SetPoint("TOPLEFT", content, "TOPLEFT", 16, y + 12)
	raidPreview:SetScript("OnClick", function()
		ns.SetDemo(not (ns.demo and ns.demoRaid), true)
		ns.RefreshOptions()
	end)
	AddRefresher(function() raidPreview:SetText((ns.IsDemo() and ns.demoRaid) and "Stop Preview" or "Preview Raid") end)
	y = y - 30

	Heading(content, "Size and Transparency", y)
	y = y - 28
	Slider(content, 16, y, "Size (party and group pies)", ns.SIZE_MIN, ns.SIZE_MAX, 2, Pixels,
		function() return ns.db.size end, function(v) ns.db.size = v end)
	y = y - 50
	Slider(content, 16, y, "Border opacity", 0, 1, 0.05, Percent,
		function() return ns.db.borderAlpha end, function(v) ns.db.borderAlpha = v end)
	y = y - 50
	Slider(content, 16, y, "Player color opacity", 0, 1, 0.05, Percent,
		function() return ns.db.playerAlpha end, function(v) ns.db.playerAlpha = v end)
	y = y - 56

	Heading(content, "Raids", y)
	y = y - 28
	Check(content, 16, y, "A pie for each raid group",
		function() return ns.db.raidLayout ~= "single" end,
		function(v) ns.db.raidLayout = v and "groups" or "single"; ns.RefreshOptions() end)
	y = y - 28
	Check(content, 16, y, "One big pie with a wedge for everyone in the raid",
		function() return ns.db.raidLayout == "single" end,
		function(v) ns.db.raidLayout = v and "single" or "groups"; ns.RefreshOptions() end)
	y = y - 30
	Check(content, 16, y, "Put your own group first",
		function() return ns.db.ownGroupFirst end, function(v) ns.db.ownGroupFirst = v end)
	y = y - 32
	Label(content, "Show groups", 16, y - 4)
	for g = 1, 8 do
		Check(content, 100 + (g - 1) * 52, y, tostring(g),
			function() return not ns.db.hiddenGroups[g] end,
			function(v) ns.db.hiddenGroups[g] = (not v) or nil end)
	end
	y = y - 34
	Slider(content, 16, y, "Group pies per row", 1, 8, 1, function(v) return tostring(math.floor(v + 0.5)) end,
		function() return ns.db.groupColumns end, function(v) ns.db.groupColumns = math.floor(v + 0.5) end)
	y = y - 50
	Slider(content, 16, y, "Big raid pie size", ns.RAID_SIZE_MIN, ns.RAID_SIZE_MAX, 2, Pixels,
		function() return ns.db.raidSize end, function(v) ns.db.raidSize = v end)
	y = y - 56

	Heading(content, "Border Metal", y)
	y = y - 30
	MetalChooser(content, y)
	y = y - 36
	Label(content, "Selected target outline", 46, y - 4)
	Swatch(content, 16, y, function() return ns.db.targetColor end, function(c) ns.db.targetColor = c end)
	y = y - 42

	Heading(content, "Role Symbols", y)
	y = y - 28
	Check(content, 16, y, "Show a tank, healer or DPS symbol on each wedge",
		function() return ns.db.roleIcons end, function(v) ns.db.roleIcons = v end)
	y = y - 30
	Check(content, 16, y, "Color and glow it, with a timer, for debuffs you can dispel",
		function() return ns.db.dispelGlow end, function(v) ns.db.dispelGlow = v end)
	y = y - 40

	Heading(content, "Mouseover Healing", y)
	y = y - 28
	Check(content, 16, y, "Hovering a wedge targets that player or pet (changes wait for combat to end)",
		function() return ns.db.mouseover end,
		function(v)
			ns.db.mouseover = v
			if v then ns.ApplyGameMouseover() end
		end)
	y = y - 30
	Check(content, 16, y, "Drag it in combat too (it moves when you let go; changes wait for combat to end)",
		function() return ns.db.moveInCombat end, function(v) ns.db.moveInCombat = v end)
	y = y - 30
	Check(content, 16, y, "Hovering a wedge lists what you can dispel and your heals over time on them",
		function() return ns.db.auraPopup end, function(v) ns.db.auraPopup = v; if not v then ns.HideAuraPopup() end end)
	y = y - 30
	Check(content, 16, y, "Gray out the wedges of members too far away to heal",
		function() return ns.db.rangeFade end, function(v) ns.db.rangeFade = v end)
	y = y - 40

	Heading(content, "Low Health", y)
	y = y - 28
	Check(content, 16, y, "Flash the outline at low health",
		function() return ns.db.flash end, function(v) ns.db.flash = v end)
	y = y - 34
	Label(content, "Low-health wedge color", 46, y - 4)
	Swatch(content, 16, y, function() return ns.db.lowFill end, function(c) ns.db.lowFill = c end)
	y = y - 30
	Label(content, "Outline flash, dark end", 46, y - 4)
	Swatch(content, 16, y, function() return ns.db.flashLow end, function(c) ns.db.flashLow = c end)
	y = y - 30
	Label(content, "Outline flash, bright end (used when flashing is off)", 46, y - 4)
	Swatch(content, 16, y, function() return ns.db.flashHigh end, function(c) ns.db.flashHigh = c end)
	y = y - 42

	Heading(content, "Shields and Incoming Heals", y)
	y = y - 28
	Label(content, "Shield color", 46, y - 4)
	Swatch(content, 16, y, function() return ns.db.shieldColor end, function(c) ns.db.shieldColor = c end)
	y = y - 30
	Label(content, "Incoming heal color", 46, y - 4)
	Swatch(content, 16, y, function() return ns.db.healColor end, function(c) ns.db.healColor = c end)
	y = y - 42

	Heading(content, "Classes", y)
	y = y - 28
	local COL_CLASS, COL_PET, COL_PET_ON, COL_RES_ON = 160, 240, 320, 410
	Label(content, "Class", 16, y, "GameFontNormal")
	Label(content, "Color", COL_CLASS - 6, y, "GameFontNormal")
	Label(content, "Pet Color", COL_PET - 14, y, "GameFontNormal")
	Label(content, "Pet Wedge", COL_PET_ON - 12, y, "GameFontNormal")
	Label(content, "Resource", COL_RES_ON - 10, y, "GameFontNormal")
	y = y - 24
	for _, class in ipairs(ns.ClassList()) do
		Label(content, ClassName(class), 16, y - 4)
		Swatch(content, COL_CLASS, y, function() return ns.ClassColor(class) end,
			function(c) ns.db.classColors[class] = c end)
		Swatch(content, COL_PET, y, function() return ns.PetColor(class) end,
			function(c) ns.db.petColors[class] = c end)
		Check(content, COL_PET_ON, y + 2, nil, function() return ns.PetEnabled(class) end,
			function(v) ns.db.petOff[class] = (not v) or nil end)
		Check(content, COL_RES_ON, y + 2, nil, function() return ns.ResourceEnabled(class) end,
			function(v) ns.db.resourceOff[class] = (not v) or nil end)
		y = y - 28
	end
	y = y - 14

	Heading(content, "Resource Colors", y)
	y = y - 28
	for _, entry in ipairs(ns.RESOURCES) do
		local token = entry[1]
		Label(content, entry[2], 46, y - 4)
		Swatch(content, 16, y, function() return ns.ResourceColor(token) end,
			function(c) ns.db.resourceColors[token] = c end)
		y = y - 28
	end
	return -y + 20
end

function ns.CreateOptions()
	local panel = CreateFrame("Frame")
	panel.name = "Heal Pie"

	-- About a hundred widgets most players never look at, so they are built the first time the panel opens.
	local function BuildOnce()
		panel:SetScript("OnShow", function() ns.RefreshOptions() end)
		local scroll = CreateFrame("ScrollFrame", nil, panel, "UIPanelScrollFrameTemplate")
		scroll:SetPoint("TOPLEFT", 4, -4)
		scroll:SetPoint("BOTTOMRIGHT", -28, 4)
		local content = CreateFrame("Frame", nil, scroll)
		content:SetSize(560, 1)
		scroll:SetScrollChild(content)
		content:SetHeight(Build(content))
		ns.RefreshOptions()
	end
	panel:SetScript("OnShow", BuildOnce)
	ns.BuildOptions = BuildOnce

	category = Settings.RegisterCanvasLayoutCategory(panel, panel.name)
	Settings.RegisterAddOnCategory(category)
end

function ns.OpenOptions()
	if not category then
		print(RED .. "Heal Pie:|r the options are not ready yet.")
		return
	end
	Settings.OpenToCategory(category:GetID())
end
