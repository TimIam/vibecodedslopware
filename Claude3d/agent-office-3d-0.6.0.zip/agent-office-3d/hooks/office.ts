// The agent office's evidence: this session's own supported hooks, the workers
// derived from them, and the small in-app pane that opens the 3D window.

import { atom, read, update } from 'claude-code'

import type { OfficeAgent, OfficePending, TurnReason } from '../types'
import { EXTERNAL_TOOL, approvalText, deriveWorkers, identityOf, questionText } from '../src/office'
import type { OfficeWorker } from '../src/office'
import { addReceipt, findNonce, noteTurnEnd, noteTurnStart } from '../src/records'
import { oneLine } from '../src/sanitize'
import type { Engine } from './shared'

// This module's $.state values (the contract is ../types; each module that reads or writes one declares it).
const agentReceiptsAtom = atom({ plugin: 'agent-office-3d', key: 'agentReceipts' } as const, [])
const agentsAtom = atom({ plugin: 'agent-office-3d', key: 'agents' } as const, [])
const retiredAtom = atom({ plugin: 'agent-office-3d', key: 'retiredAgents' } as const, [])
const framesAtom = atom({ plugin: 'agent-office-3d', key: 'frames' } as const, [])
const officeAutoOpenedAtom = atom({ plugin: 'agent-office-3d', key: 'officeAutoOpened' } as const, false)
const pendingAtom = atom({ plugin: 'agent-office-3d', key: 'pending' } as const, [])
const sendsAtom = atom({ plugin: 'agent-office-3d', key: 'sends' } as const, [])
const turnsAtom = atom({ plugin: 'agent-office-3d', key: 'turns' } as const, [])

export const OFFICE = 'agent-office'
export const OFFICE_TITLE = 'Agent Office'
const MAX_RETIRED = 8

// Calls in flight, to match a shown permission dialog to its call. A reload
// loses this map; a turn's end then clears whatever its calls left pending.
const inflight = new Map<string, { identity: string; tool: string }>()
let calls = 0

/** Mirrors $.agent.list(): a worker exists only while the engine lists the agent. */
export async function pollAgents($: Engine): Promise<void> {
  let listed
  try {
    listed = await $.agent.list()
  } catch {
    return
  }
  const agents: OfficeAgent[] = listed.map(a => ({
    id: a.id,
    name: a.name === undefined ? null : oneLine(a.name, 60),
    description: oneLine(a.description, 120),
    type: oneLine(a.type, 60),
    status: a.status,
    isTeammate: a.teammateId !== undefined,
    parentId: a.parentId ?? null,
  }))
  const before = await read($, agentsAtom)
  if (JSON.stringify(agents) === JSON.stringify(before)) return
  // An agent the list stops carrying keeps a bounded desk, with its last listed state;
  // one that comes back (resumed) is live again.
  const listedIds = new Set(agents.map(a => a.id))
  const dropped = before.filter(a => !listedIds.has(a.id))
  const retired = await read($, retiredAtom)
  if (dropped.length > 0 || retired.some(r => listedIds.has(r.id))) {
    const at = await $.clock.now()
    await update($, retiredAtom, list =>
      [...list.filter(r => !listedIds.has(r.id) && !dropped.some(d => d.id === r.id)), ...dropped.map(d => ({ ...d, retiredAt: at }))].slice(-MAX_RETIRED),
    )
  }
  await update($, agentsAtom, () => agents)
}

async function addPending($: Engine, item: OfficePending): Promise<void> {
  await update($, pendingAtom, list => [...list.filter(p => p.id !== item.id), item].slice(-50))
}

async function removePending($: Engine, id: string): Promise<void> {
  const gone = (p: OfficePending) => p.id === id || p.id === `${id}#approval`
  if ((await read($, pendingAtom)).some(gone)) await update($, pendingAtom, list => list.filter(p => !gone(p)))
}

/** tool.call, before the call runs: an AskUserQuestion is a pending question; WebFetch, WebSearch or an MCP tool is an external wait. */
export async function callStarted($: Engine, call: { tool: string; tool_use_id?: string; agentId?: string }, input: unknown): Promise<string> {
  calls += 1
  const id = call.tool_use_id ?? `call-${calls}`
  const identity = identityOf(call.agentId)
  const tool = String(call.tool)
  inflight.set(id, { identity, tool })
  const since = await $.clock.now()
  if (tool === 'AskUserQuestion') await addPending($, { id, identity, kind: 'question', tool, text: questionText(input), since })
  else if (EXTERNAL_TOOL(tool)) await addPending($, { id, identity, kind: 'external', tool: oneLine(tool, 60), text: oneLine(tool, 60), since })
  return id
}

/** tool.call, once the call resolved (answered, run, denied or failed): whatever it held is no longer pending. */
export async function callEnded($: Engine, id: string): Promise<void> {
  inflight.delete(id)
  await removePending($, id)
}

/**
 * classic.PermissionRequest: the engine showed a permission dialog. The office
 * only records it; the person answers in Claude Code's own prompt.
 */
export async function approvalShown($: Engine, agentId: string | undefined, tool: string, input: unknown): Promise<void> {
  const identity = identityOf(agentId)
  const since = await $.clock.now()
  const pending = await read($, pendingAtom)
  const match = [...inflight.entries()].reverse().find(([id, c]) => c.identity === identity && c.tool === tool && !pending.some(p => p.id === `${id}#approval`))
  const id = match === undefined ? `approval:${identity}:${since}` : `${match[0]}#approval`
  await addPending($, { id, identity, kind: 'approval', tool: oneLine(tool, 60), text: approvalText(tool, input), since })
}

async function sentTo($: Engine, agentId: string): Promise<Set<string>> {
  return new Set((await read($, sendsAtom)).filter(s => s.target.kind === 'agent' && s.target.agentId === agentId).map(s => s.nonce))
}

export async function turnStarted($: Engine, agentId: string | undefined, turnId: string, text: string): Promise<void> {
  const identity = identityOf(agentId)
  const at = await $.clock.now()
  await update($, turnsAtom, list => [
    ...list.filter(t => t.identity !== identity),
    { identity, isRunning: true, lastReason: list.find(t => t.identity === identity)?.lastReason ?? null, at },
  ])
  if (agentId === undefined) return
  const nonces = await sentTo($, agentId)
  if (nonces.size > 0) {
    await update($, agentReceiptsAtom, list => list.map(r => (nonces.has(r.nonce) ? noteTurnStart([r], { turnId, text, at })[0]! : r)))
  }
  await pollAgents($)
}

export async function turnEnded($: Engine, agentId: string | undefined, turnId: string, reason: TurnReason, answer: string): Promise<void> {
  const identity = identityOf(agentId)
  const at = await $.clock.now()
  await update($, turnsAtom, list => [...list.filter(t => t.identity !== identity), { identity, isRunning: false, lastReason: reason, at }])
  // The turn is over: nothing it held is waiting any more.
  if ((await read($, pendingAtom)).some(p => p.identity === identity)) await update($, pendingAtom, list => list.filter(p => p.identity !== identity))
  if (agentId === undefined) return
  await update($, agentReceiptsAtom, list => noteTurnEnd(list, { turnId, reason, answer, at }))
  await pollAgents($)
}

/** session.receive for one of this session's agents: arrival of a message this session sent it. */
export async function agentReceive($: Engine, agentId: string, text: string, originKind: string, claimedPlugin: string | null): Promise<void> {
  const nonce = findNonce(text)
  if (nonce === null || !(await sentTo($, agentId)).has(nonce)) return
  const at = await $.clock.now()
  await update($, agentReceiptsAtom, list => addReceipt(list, { nonce, at, originKind, claimedPlugin }))
}

export async function workersNow($: Engine): Promise<OfficeWorker[]> {
  const [turns, agents, retired, pending, peers] = await Promise.all([
    read($, turnsAtom),
    read($, agentsAtom),
    read($, retiredAtom),
    read($, pendingAtom),
    read($, framesAtom),
  ])
  return deriveWorkers({ now: await $.clock.now(), turns, agents, retired, pending, peers })
}

/** The office when asked: `/office`. */
export async function openOffice($: Engine): Promise<void> {
  await $.ui.open({ id: OFFICE, title: OFFICE_TITLE })
}

/**
 * The office once per session when it starts, never with focus. The mark lives
 * in $.state, so a hot reload or a later turn does not open it again, and a
 * pane the person closed stays closed until they run /office.
 */
export async function autoOpenOnce($: Engine, isEnabled: boolean): Promise<'opened' | 'already' | 'disabled'> {
  if (!isEnabled) return 'disabled'
  if (await read($, officeAutoOpenedAtom)) return 'already'
  await update($, officeAutoOpenedAtom, () => true)
  void $.ui.open({ id: OFFICE, title: OFFICE_TITLE }).catch(() => undefined)
  return 'opened'
}
