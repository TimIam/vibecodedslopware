// The Agent Arcade: games the person and agents play at tables in the
// fullscreen office. A seat is the person, or an agent (a model and how hard
// it thinks). A game runs while both seats are taken; an agent's move is one
// model completion with no history, given the position, the moves so far and
// every legal move, and only a legal move is ever played: an answer that is
// not one is sent back with the reason, three times at most, after which the
// game waits for the person (`stuck`). The person's moves go through the same
// rules. The rules of each game are a module (src/arcade/games.ts lists them);
// nothing here knows one game from another. Nothing here touches any conversation.

import { atom, read, update } from 'claude-code'

import { GAMES, gameOf, sideName } from '../src/arcade/games'
import type { GameRules } from '../src/arcade/rules'
import { inert, oneLine } from '../src/sanitize'
import type { ArcadeGame, ArcadeSeat, ArcadeSide, ArcadeState } from '../types'
import type { Engine } from './shared'
import { errorText } from './shared'

/** The models a seat may hold, by full id, with the name the window shows. */
export const ARCADE_MODELS: readonly { id: string; name: string }[] = [
  { id: 'claude-fable-5-1', name: 'Fable 5.1' },
  { id: 'claude-opus-5-5', name: 'Opus 5.5' },
  { id: 'claude-sonnet-5-5', name: 'Sonnet 5.5' },
  { id: 'claude-haiku-5-5', name: 'Haiku 5.5' },
]
export const ARCADE_EFFORTS = ['low', 'medium', 'high', 'xhigh', 'max'] as const
const MAX_ATTEMPTS = 3
const MOVE_TIMEOUT_MS = 180000
const REPLY_CHARS = 240
const MAX_MOVES = 400

export function freshGame(kind: string): ArcadeGame {
  const rules = gameOf(kind)
  return {
    kind,
    id: 0,
    seats: { a: null, b: null },
    moves: rules?.seedMove ? [rules.seedMove()] : [],
    history: [],
    turn: 'a',
    status: 'waiting',
    result: null,
    winner: null,
    thinking: null,
    lastReply: null,
    error: null,
    attempts: 0,
    updatedAt: 0,
  }
}

const freshAll = (): ArcadeState => Object.fromEntries(Object.keys(GAMES).map(kind => [kind, freshGame(kind)]))

// This module's $.state values (the contract is ../types; each module that reads or writes one declares it).
const arcadeAtom = atom({ plugin: 'agent-office-3d', key: 'arcade' } as const, freshAll())

export { sideName }

const bothSeated = (g: ArcadeGame): boolean => g.seats.a !== null && g.seats.b !== null

/** The game's position as its rules see it. */
const positionOf = (g: ArcadeGame): { rules: GameRules<unknown>; s: unknown } => {
  const rules = gameOf(g.kind)
  if (rules === undefined) throw new Error(`no such game: ${g.kind}`)
  return { rules, s: rules.replay(g.moves) }
}

/** The game's status fields from its moves: the side to move and whether, and how, it is over. */
function settle(game: ArcadeGame): ArcadeGame {
  const { rules, s } = positionOf(game)
  const st = rules.status(s)
  return {
    ...game,
    history: rules.history(s),
    turn: rules.turn(s),
    status: st.over ? 'over' : game.status === 'stuck' ? 'stuck' : bothSeated(game) ? 'playing' : 'waiting',
    result: st.over ? st.result : null,
    winner: st.over ? st.winner : null,
  }
}

// ─── Commands from the window (checked again here: they came from a page) ──
const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v)

function parseSeat(v: unknown): ArcadeSeat | null {
  if (!isRecord(v)) return null
  if (v.kind === 'human') return { kind: 'human' }
  if (v.kind !== 'agent') return null
  const model = ARCADE_MODELS.find(m => m.id === v.model)
  const effort = ARCADE_EFFORTS.find(e => e === v.effort)
  if (model === undefined || effort === undefined) return null
  return { kind: 'agent', model: model.id, effort, name: oneLine(typeof v.name === 'string' && v.name.trim() !== '' ? v.name : `${model.name} · ${effort}`, 40) }
}

async function setGame($: Engine, kind: string, fn: (g: ArcadeGame) => ArcadeGame): Promise<ArcadeGame> {
  const now = await $.clock.now()
  let out: ArcadeGame | null = null
  await update($, arcadeAtom, all => {
    const next = { ...settle(fn(all[kind] ?? freshGame(kind))), updatedAt: now }
    out = next
    return { ...all, [kind]: next }
  })
  return out!
}

/** One arcade command the window posted: `{ type: 'arcade', game, action, ... }`. Answers what to tell the person, if anything. */
export async function arcadeCommand($: Engine, cmd: Record<string, unknown>): Promise<string | null> {
  const kind = typeof cmd.game === 'string' && gameOf(cmd.game) !== undefined ? cmd.game : null
  if (kind === null) return null
  const rules = gameOf(kind)!
  const side: ArcadeSide | null = cmd.side === 'a' || cmd.side === 'b' ? cmd.side : null
  switch (cmd.action) {
    case 'seat': {
      const seat = parseSeat(cmd.seat)
      if (side === null || seat === null) return 'That seat request was not understood: nothing changed.'
      await setGame($, kind, g => ({ ...g, id: g.id + 1, seats: { ...g.seats, [side]: seat }, error: null, attempts: 0, thinking: null, status: g.status === 'stuck' ? 'playing' : g.status }))
      return null
    }
    case 'leave': {
      if (side === null) return null
      await setGame($, kind, g => ({ ...g, id: g.id + 1, seats: { ...g.seats, [side]: null }, thinking: null, attempts: 0 }))
      return null
    }
    case 'reset':
      await setGame($, kind, g => ({ ...freshGame(kind), id: g.id + 1, seats: g.seats }))
      return null
    case 'retry':
      await setGame($, kind, g => ({ ...g, id: g.id + 1, status: g.status === 'stuck' ? 'playing' : g.status, attempts: 0, error: null, thinking: null }))
      return null
    case 'move': {
      const text = typeof cmd.move === 'string' ? cmd.move.trim().slice(0, 24) : ''
      if (text === '') return null
      const game = (await read($, arcadeAtom))[kind] ?? freshGame(kind)
      const seat = game.seats[game.turn]
      if (game.status !== 'playing') return `The ${rules.title} game is not running.`
      if (seat === null || seat.kind !== 'human') return `It is not your move: ${rules.sides[game.turn]} is ${seat === null ? 'an empty seat' : seat.name}.`
      const result = humanMove(game, text)
      if (typeof result === 'string') {
        await setGame($, kind, g => ({ ...g, error: result }))
        return result
      }
      await setGame($, kind, g => ({ ...g, moves: result, error: null, lastReply: null }))
      return null
    }
    default:
      return null
  }
}

/** The person's move applied by the rules: the new move list, or why it was refused. */
function humanMove(game: ArcadeGame, text: string): string[] | string {
  if (game.moves.length >= MAX_MOVES) return 'This game has gone on long enough: start a new one.'
  const { rules, s } = positionOf(game)
  const move = rules.parse(s, text)
  if (move === null) {
    const legal = rules.legal(s)
    return `${inert(text, 24)} is not a legal move here. Legal: ${legal.slice(0, 40).join(' ')}${legal.length > 40 ? ' …' : ''}`
  }
  return [...game.moves, move]
}

// ─── An agent's move ───────────────────────────────────────────────────────
const inFlight = new Set<string>()

/** The legal move in a reply: the whole first line, then each token of the first two lines; the rest as its reason. */
function readReply(game: ArcadeGame, text: string): { move: string | null; reason: string; tried: string } {
  const { rules, s } = positionOf(game)
  const lines = text.trim().split('\n').map(l => l.trim()).filter(Boolean)
  const tokens = lines.slice(0, 2).join(' ').split(/[\s,.;()`"'*]+/).filter(Boolean)
  let move: string | null = null
  for (const candidate of [lines[0] ?? '', ...tokens]) {
    const m = candidate === '' ? null : rules.parse(s, candidate)
    if (m !== null) {
      move = m
      break
    }
  }
  const reason = inert(lines.slice(1).join(' ') || '', REPLY_CHARS)
  return { move, reason, tried: inert(lines[0] ?? text, 40) }
}

async function agentMove($: Engine, kind: string): Promise<void> {
  const start = (await read($, arcadeAtom))[kind]
  if (start === undefined) return
  const seat = start.seats[start.turn]
  if (seat === null || seat.kind !== 'agent') return
  const id = start.id
  const side = start.turn
  await setGame($, kind, g => ({ ...g, thinking: side, error: null }))
  let problem: string | null = null
  try {
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      const game = (await read($, arcadeAtom))[kind]
      if (game === undefined || game.id !== id || game.status !== 'playing' || game.turn !== side) return // changed under us: drop it
      const { rules, s } = positionOf(game)
      const ask = rules.prompt(s, side, problem)
      const r = await $.model.complete({ model: seat.model, effort: seat.effort, system: ask.system, prompt: ask.prompt, maxTokens: 200, timeoutMs: MOVE_TIMEOUT_MS })
      const after = (await read($, arcadeAtom))[kind]
      if (after === undefined || after.id !== id || after.status !== 'playing' || after.turn !== side) return
      if (!r.isAnswered) {
        problem = r.reason === 'api-error' ? `the request failed (${r.status})` : r.reason === 'aborted' ? 'the request timed out' : 'the reply was empty'
        await setGame($, kind, g => ({ ...g, attempts: attempt, error: `${seat.name}: ${problem}` }))
        continue
      }
      const { move, reason, tried } = readReply(after, r.text)
      if (move === null) {
        problem = `"${tried}" is not a legal move.`
        await setGame($, kind, g => ({ ...g, attempts: attempt, error: `${seat.name} answered "${tried}", which is not legal (try ${attempt} of ${MAX_ATTEMPTS}).` }))
        continue
      }
      await setGame($, kind, g => ({ ...g, moves: [...g.moves, move], lastReply: reason || null, error: null, attempts: 0, thinking: null }))
      return
    }
    await setGame($, kind, g => ({ ...g, status: 'stuck', thinking: null, error: `${seat.name} gave no legal move in ${MAX_ATTEMPTS} tries: ${problem ?? 'no answer'} Retry when ready.` }))
  } catch (err) {
    await setGame($, kind, g => ({ ...g, status: 'stuck', thinking: null, error: `${seat.name}: ${errorText(err)}` }))
  } finally {
    await setGame($, kind, g => (g.id === id && g.thinking === side ? { ...g, thinking: null } : g))
  }
}

/**
 * Starts an agent's move wherever one is due. From the window's timer it is
 * never awaited (a model call takes seconds); `wait` awaits it, for the command.
 */
export async function arcadeTick($: Engine, wait = false): Promise<void> {
  const all = await read($, arcadeAtom)
  const started: Promise<void>[] = []
  for (const kind of Object.keys(GAMES)) {
    const g = all[kind]
    if (g === undefined || g.status !== 'playing' || g.thinking !== null || inFlight.has(kind)) continue
    const seat = g.seats[g.turn]
    if (seat === null || seat.kind !== 'agent') continue
    inFlight.add(kind)
    started.push(agentMove($, kind).finally(() => inFlight.delete(kind)))
  }
  if (wait) await Promise.all(started)
}

/** The arcade as the window draws it: every game, each with its board as its rules give it. */
export async function arcadeOut($: Engine): Promise<Record<string, unknown>> {
  const all = await read($, arcadeAtom)
  const out: Record<string, unknown> = {}
  for (const [kind, rules] of Object.entries(GAMES)) {
    const g = all[kind] ?? freshGame(kind)
    const s = rules.replay(g.moves)
    out[kind] = {
      ...g,
      ...rules.out(s),
      title: rules.title,
      sides: rules.sides,
      models: ARCADE_MODELS,
      efforts: ARCADE_EFFORTS,
      legal: rules.legal(s),
      lastMove: g.moves.filter(m => !m.startsWith('seed:')).at(-1) ?? null,
    }
  }
  return out
}

/**
 * `/3d arcade <what>`: `status` (the games as JSON), `tick` (plays any
 * agent move that is due, and waits for it), or a command as JSON, as the
 * window would post it: {"game":"chess","action":"seat","side":"a","seat":{"kind":"human"}}.
 */
export async function arcadeCli($: Engine, args: string): Promise<string> {
  const what = args.trim()
  if (what === '' || what === 'status') return JSON.stringify(await arcadeOut($), null, 2)
  if (what === 'tick') {
    await arcadeTick($, true)
    return JSON.stringify(await arcadeOut($), null, 2)
  }
  let cmd: unknown
  try {
    cmd = JSON.parse(what)
  } catch {
    return `/3d arcade: status | tick | {"game":"${Object.keys(GAMES).join('"|"')}","action":"seat"|"leave"|"move"|"reset"|"retry",...}`
  }
  if (!isRecord(cmd)) return 'The arcade command must be a JSON object.'
  const text = await arcadeCommand($, cmd)
  return text ?? 'ok'
}
