// Agent Office fullscreen: `/3d full` launches game/server.mjs, which
// opens a fullscreen browser window running a three.js office (game/game.js),
// and keeps it linked to this session for as long as both live.
//
// The engine ends a child process with the dispatch that started it, and a
// command's dispatch ends when it answers. So the server runs detached
// (`server.mjs --launch` starts it and exits), and the link is files alone,
// kept by a timer: this module writes the office's state to `state.json`
// several times a second while it changes, and every few seconds regardless
// (a heartbeat: the server closes the window when writes stop), and reads the
// commands the window appended to `commands.jsonl`: `select` (the worker the
// person faces: its conversation is then included) and `send` (a message the
// person typed and confirmed). A send goes through the office's own checks
// (the worker's target, then sendTo). Nothing else the window says is acted on.
//
// The bridge is kept in $.state, so a reload of this module (session.start
// runs again) re-links to a window that is still open.

import { atom, read, update } from 'claude-code'

import type { OfficeWorker } from '../src/office'
import { buildSnapshot } from '../src/records'
import { oneLine } from '../src/sanitize'
import type { DesignContext, FullscreenBridge, MuseumFrame, MuseumLine } from '../types'
import { arcadeCommand, arcadeOut, arcadeTick } from './arcade'
import { designCommandFromWindow, designOut, designTick } from './design'
import { escapeCommandFromWindow, escapeOut, escapeTick } from './escape'
import { kanbanCommandFromWindow, kanbanOut, kanbanTick } from './kanban'
import { workersNow } from './office'
import type { Engine } from './shared'
import { errorText, flushPrompts, ownMessages, sendTo } from './shared'

/** The anchors the world editor may name, as the last state write saw them: the desks and the rooms of every session. */
let lastDesignContext: DesignContext = { desks: [], rooms: [] }

// This module's $.state values (the contract is ../types; each module that reads or writes one declares it).
const noticeAtom = atom({ plugin: 'agent-office-3d', key: 'office3dNotice' } as const, null)
const framesAtom = atom({ plugin: 'agent-office-3d', key: 'frames' } as const, [])
const bridgeAtom = atom({ plugin: 'agent-office-3d', key: 'fullscreenBridge' } as const, null)

const TICK_MS = 250
const HEARTBEAT_MS = 3000
const ALIVE_CHECK_MS = 1000
const INSPECT_MS = 2000
const LAUNCH_TIMEOUT_MS = 30000
const INSPECT_LINES = 40
const LINE_CHARS = 700
const MAX_CMDS_PER_TICK = 20

type Inspect = { key: string; note: string; lines: MuseumLine[]; at: number }

const KIND_LABEL: Record<OfficeWorker['kind'], string> = {
  main: 'this conversation',
  subagent: 'subagent of this session',
  teammate: 'teammate of this session',
  peer: 'enrolled peer session',
}

/** A worker's own conversation: this session's messages, one of its agents', or a peer's published snapshot. */
async function conversationOf($: Engine, worker: OfficeWorker, peers: readonly MuseumFrame[]): Promise<{ lines: MuseumLine[]; note: string }> {
  if (worker.kind === 'peer') {
    const peer = peers.find(p => `peer:${p.sessionId}` === worker.key)
    return { lines: peer?.snapshot ?? [], note: 'Its own snapshot, published by that session when it enrolled:' }
  }
  const agentId = worker.target?.kind === 'agent' ? worker.target.agentId : worker.key.startsWith('agent:') ? worker.key.slice('agent:'.length) : undefined
  try {
    const messages = await ownMessages($, agentId)
    if (!Array.isArray(messages)) return { lines: [], note: `Its conversation is not readable here: ${messages.deny}` }
    return { lines: buildSnapshot(messages), note: agentId === undefined ? 'This conversation ($.session.messages()):' : 'Its conversation ($.session.messages({ agentId })):' }
  } catch (err) {
    return { lines: [], note: `Its conversation could not be read: ${errorText(err)}` }
  }
}

/** A message typed in the window, to one worker: the office's own checks, then sendTo; the outcome is the window's notice. */
async function sendFromWindow($: Engine, key: string, text: string): Promise<void> {
  const worker = (await workersNow($)).find(w => w.key === key)
  let result: { isSent: boolean; text: string }
  if (worker === undefined) result = { isSent: false, text: 'That worker is gone: nothing was sent.' }
  else if (worker.target === null) result = { isSent: false, text: `${worker.noSendReason ?? 'The office offers no Send for this worker.'} Nothing was sent.` }
  else result = await sendTo($, worker.target, worker.name, text.trim())
  await update($, noticeAtom, () => ({ text: oneLine(result.text, 300), isError: !result.isSent, at: 0 }))
}

let timer: { cancel: () => void } | null = null
let selectedKey: string | null = null
let inspect: Inspect | null = null
let lastText = ''
let lastWriteAt = 0
let lastAliveAt = 0
let isTicking = false
let isLinked = false

/** One worker as the window draws it: the office's own words, nothing inferred. */
function workerOut(w: OfficeWorker) {
  return {
    key: w.key,
    name: oneLine(w.name, 60),
    kind: w.kind,
    kindLabel: KIND_LABEL[w.kind],
    detail: oneLine(w.detail, 160),
    state: w.state,
    stateLabel: oneLine(w.stateLabel, 40),
    light: w.light,
    evidence: oneLine(w.evidence, 200),
    hand: w.hand === null ? null : { kind: w.hand.kind, text: oneLine(w.hand.text, 300) },
    canSend: w.target !== null,
    noSendReason: w.noSendReason,
  }
}

/** A worker key the window makes for another session's agent: `peer:<sessionId>:<that session's agent key>`. */
const isPeerAgentKey = (key: string): boolean => key.startsWith('peer:') && key.indexOf(':agent:') > 0

/** The last part of a folder path, Windows or POSIX. */
const folderName = (path: string): string => path.split(/[\\/]/).filter(Boolean).at(-1) ?? 'project'

async function refreshInspect($: Engine, workers: readonly OfficeWorker[], now: number): Promise<void> {
  if (selectedKey !== null && isPeerAgentKey(selectedKey)) {
    inspect = { key: selectedKey, note: "Another session's agent: it publishes its state, not its conversation. Its own session's lead desk takes messages.", lines: [], at: now }
    return
  }
  const worker = selectedKey === null ? undefined : workers.find(w => w.key === selectedKey)
  if (worker === undefined) {
    inspect = null
    return
  }
  if (inspect !== null && inspect.key === worker.key && now - inspect.at < INSPECT_MS) return
  const peers = await read($, framesAtom)
  const { lines, note } = await conversationOf($, worker, peers)
  inspect = { key: worker.key, note, lines: lines.slice(-INSPECT_LINES).map(l => ({ role: l.role, text: l.text.slice(0, LINE_CHARS) })), at: now }
}

/** Writes the state file when it changed, or when the heartbeat is due. */
async function writeState($: Engine, bridge: FullscreenBridge, now: number, force: boolean): Promise<void> {
  const workers = await workersNow($)
  await refreshInspect($, workers, now)
  const notice = await read($, noticeAtom)
  // Sessions, for the rooms: this one (its lead and agents are the workers above), then each enrolled peer with
  // the agents it published. A peer's agents are workers too, shown but not messageable from here.
  const [sessionId, cwd, peers] = await Promise.all([$.session.id(), $.session.cwd(), read($, framesAtom)])
  const ownAgents = workers.filter(w => w.kind === 'subagent' || w.kind === 'teammate').map(w => w.key)
  const peerAgents = peers.flatMap(p =>
    p.agents.map(a => ({
      key: `peer:${p.sessionId}:${a.key}`,
      name: a.name,
      kind: 'subagent' as const,
      kindLabel: `agent of ${oneLine(p.label, 40)}`,
      detail: 'as its own session published it',
      state: a.state,
      stateLabel: a.stateLabel,
      light: a.light,
      evidence: p.isStale ? 'its session stopped refreshing its record' : "that session's own office record",
      hand: a.hand === null ? null : { kind: a.hand, text: 'Waiting on its own person, in that session.' },
      canSend: false,
      noSendReason: "An agent of another session: the office cannot reach it. Its session's lead desk takes messages.",
      desk: null,
    })),
  )
  const sessions = [
    { id: sessionId, project: folderName(cwd), label: 'This session', isSelf: true, lead: 'main', agents: ownAgents },
    ...peers.map(p => ({ id: p.sessionId, project: p.project, label: p.label, isSelf: false, lead: `peer:${p.sessionId}`, agents: p.agents.map(a => `peer:${p.sessionId}:${a.key}`) })),
  ]
  lastDesignContext = {
    desks: sessions.flatMap(s => [{ key: s.lead, label: 'Lead', session: s.id }, ...s.agents.map((key, i) => ({ key, label: `Agent ${i + 1}`, session: s.id }))]),
    rooms: [{ project: 'my-office', title: 'My Office (your own room)' }, ...[...new Set(sessions.map(s => s.project))].map(project => ({ project, title: project }))],
  }
  const body = {
    v: 1,
    mode: 'live',
    sessions,
    workers: [...workers.map(workerOut), ...peerAgents],
    inspect: inspect === null ? null : { key: inspect.key, note: inspect.note, lines: inspect.lines },
    notice: notice === null ? null : { text: notice.text, isError: notice.isError },
    arcade: await arcadeOut($),
    design: await designOut($, lastDesignContext),
    kanban: await kanbanOut($),
    escape: await escapeOut($),
  }
  const text = JSON.stringify(body)
  if (force || text !== lastText || now - lastWriteAt >= HEARTBEAT_MS) {
    // `at` changes every write, so the server sees the heartbeat even when nothing else did.
    await $.fs.write(bridge.stateFile, JSON.stringify({ ...body, at: now }))
    lastText = text
    lastWriteAt = now
  }
}

const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v)

/** One command line the window appended, checked again here: it came from a page. Answers whether the state should go out now. */
async function onCommand($: Engine, cmd: unknown): Promise<boolean> {
  if (!isRecord(cmd) || typeof cmd.type !== 'string') return false
  if (cmd.type === 'hello') return true
  if (cmd.type === 'arcade' || cmd.type === 'design' || cmd.type === 'kanban' || cmd.type === 'escape') {
    const text =
      cmd.type === 'arcade' ? await arcadeCommand($, cmd) : cmd.type === 'design' ? await designCommandFromWindow($, cmd) : cmd.type === 'kanban' ? await kanbanCommandFromWindow($, cmd) : await escapeCommandFromWindow($, cmd)
    if (text !== null) await update($, noticeAtom, () => ({ text: oneLine(text, 300), isError: true, at: 0 }))
    return true
  }
  if (typeof cmd.key !== 'string' || cmd.key === '' || cmd.key.length > 200) return false
  if (cmd.type === 'select') {
    selectedKey = cmd.key
    inspect = null
    return true
  }
  if (cmd.type === 'send' && typeof cmd.text === 'string' && cmd.text.trim() !== '') {
    await sendFromWindow($, cmd.key, cmd.text)
    return true
  }
  return false
}

/** The new lines of the command file, acted on in order; the count seen is kept in $.state. */
async function readCommands($: Engine, bridge: FullscreenBridge): Promise<boolean> {
  let text: string
  try {
    text = await $.fs.read(bridge.cmdFile)
  } catch {
    return false // none yet
  }
  const lines = text.split('\n').filter(l => l.trim() !== '')
  if (lines.length <= bridge.cmdSeen) return false
  const fresh = lines.slice(bridge.cmdSeen, bridge.cmdSeen + MAX_CMDS_PER_TICK)
  await update($, bridgeAtom, b => (b === null ? b : { ...b, cmdSeen: bridge.cmdSeen + fresh.length }))
  let isDue = false
  for (const line of fresh) {
    try {
      if (await onCommand($, JSON.parse(line))) isDue = true
    } catch {
      // A line that is not JSON is skipped.
    }
  }
  return isDue
}

/** Switches the link off (the session's timer stays, idle). */
function stopTimer(): void {
  isLinked = false
  inspect = null
  selectedKey = null
  lastText = ''
}

/** What the link has been doing, for /3d diag: where a tick is (so a stuck await shows), and the last error. */
const diag = { timerStarts: 0, ticks: 0, skipped: 0, writes: 0, stage: 'idle', lastError: '', lastErrorStage: '', ended: '' }

async function tick($: Engine): Promise<void> {
  diag.ticks += 1
  if (isTicking) {
    diag.skipped += 1
    return
  }
  isTicking = true
  try {
    diag.stage = 'read bridge'
    const bridge = await read($, bridgeAtom)
    if (bridge === null) {
      diag.ended = 'no bridge in $.state'
      stopTimer()
      return
    }
    diag.stage = 'clock'
    const now = await $.clock.now()
    // The server deletes its folder when the window closes: then the link is over (a write would make the folder again).
    if (now - lastAliveAt >= ALIVE_CHECK_MS) {
      diag.stage = 'fs.exists ready.json'
      if (!(await $.fs.exists(bridge.readyFile))) {
        diag.ended = 'ready.json is gone (the server closed)'
        await update($, bridgeAtom, () => null)
        stopTimer()
        return
      }
      lastAliveAt = now
    }
    diag.stage = 'read commands'
    const isDue = await readCommands($, bridge)
    // A send to this conversation from the window is submitted from here, a timer, which the engine accepts.
    await flushPrompts($)
    // An agent's arcade move starts from here too (a model call, never awaited by the tick).
    await arcadeTick($)
    // So does the escape room's teammate reply, and the kanban board's re-read of its file.
    await escapeTick($)
    await kanbanTick($)
    diag.stage = 'write state'
    const before = lastWriteAt
    await writeState($, bridge, now, isDue)
    // A queued world-editor request goes to the model with the anchors this write just saw (a model call, never awaited here).
    void designTick($, lastDesignContext)
    if (lastWriteAt !== before) diag.writes += 1
    diag.stage = 'idle'
  } catch (err) {
    const text = errorText(err)
    if (text !== diag.lastError) void $.ui.toast(`Fullscreen office link error (${diag.stage}): ${text}`)
    diag.lastError = text
    diag.lastErrorStage = diag.stage
    diag.stage = 'idle'
    $.ui.log(`fullscreen office: ${text}`, { to: 'debug' })
  } finally {
    isTicking = false
  }
}

export async function fullscreenDiag($: Engine): Promise<string> {
  const bridge = await read($, bridgeAtom)
  const now = await $.clock.now()
  const alive = bridge === null ? null : await $.fs.exists(bridge.readyFile).catch(err => `error: ${errorText(err)}`)
  return JSON.stringify(
    { sessionTimer: timer !== null, linked: isLinked, ...diag, msSinceLastWrite: lastWriteAt === 0 ? null : now - lastWriteAt, bridgeDir: bridge?.dir ?? null, readyFileExists: alive, cmdSeen: bridge?.cmdSeen ?? null },
    null,
    2,
  )
}

/** Switches the session's link timer on: it ticks while this is true. */
function startTimer(): void {
  if (isLinked) return
  lastAliveAt = 0
  diag.timerStarts += 1
  diag.ended = ''
  isLinked = true
}

/**
 * At session.start (and so after a reload): the link's timer, made here with
 * the session.start hook's `$`, which serves for the session's life. A
 * command's `$` stops serving once the command has answered, so the command
 * only switches the link on; this timer does the work. Then re-link to a
 * window still open.
 */
export async function resumeFullscreen($: Engine): Promise<void> {
  if (timer === null) {
    timer = $.clock.every(TICK_MS, () => {
      if (isLinked) void tick($)
    })
  }
  const bridge = await read($, bridgeAtom)
  if (bridge === null) return
  if (await $.fs.exists(bridge.readyFile).catch(() => false)) startTimer()
  else await update($, bridgeAtom, () => null)
}

/** Launches the detached server and its window, and starts the link. */
export async function startFullscreen($: Engine): Promise<string> {
  const open = await read($, bridgeAtom)
  if (open !== null && (await $.fs.exists(open.readyFile).catch(() => false))) {
    startTimer()
    return 'The fullscreen office is already open (Alt+Tab to it). /3d close closes it.'
  }
  let out: { exitCode: number; stdout: string; stderr: string }
  try {
    out = await $.process.run(['node', `${$.plugin.root}/game/server.mjs`, '--launch'], { timeoutMs: LAUNCH_TIMEOUT_MS })
  } catch (err) {
    return `The fullscreen office could not start: ${errorText(err)}. It needs Node.js on PATH.`
  }
  const line = out.stdout.split('\n').find(l => l.startsWith('READY '))
  let ready: unknown = null
  try {
    ready = line === undefined ? null : JSON.parse(line.slice('READY '.length))
  } catch {}
  if (
    !isRecord(ready) ||
    typeof ready.dir !== 'string' ||
    typeof ready.stateFile !== 'string' ||
    typeof ready.cmdFile !== 'string' ||
    typeof ready.readyFile !== 'string' ||
    typeof ready.url !== 'string'
  ) {
    const why = oneLine(`${out.stdout} ${out.stderr}`, 300) || `exit code ${out.exitCode}`
    return `The fullscreen office could not start: ${why}`
  }
  const bridge: FullscreenBridge = { dir: ready.dir, stateFile: ready.stateFile, cmdFile: ready.cmdFile, readyFile: ready.readyFile, cmdSeen: 0, url: ready.url }
  await update($, bridgeAtom, () => bridge)
  stopTimer()
  await writeState($, bridge, await $.clock.now(), true)
  startTimer()
  return ready.hasBrowser === false
    ? `No Edge or Chrome was found to open the window. Open this address in a browser yourself: ${bridge.url}`
    : 'The fullscreen Agent Office is opening in its own window. Click it to play; Esc pauses, Alt+F4 closes it.'
}

/** Asks the server to close its window, and ends the link. */
export async function stopFullscreen($: Engine): Promise<string> {
  const bridge = await read($, bridgeAtom)
  stopTimer()
  await update($, bridgeAtom, () => null)
  if (bridge === null || !(await $.fs.exists(bridge.readyFile).catch(() => false))) return 'The fullscreen office is not open.'
  await $.fs.write(bridge.stateFile, JSON.stringify({ v: 1, close: true }))
  return 'The fullscreen office was closed.'
}
