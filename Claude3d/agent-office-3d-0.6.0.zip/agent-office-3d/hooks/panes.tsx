// What the two panes draw: the office pane (the button into the 3D window, and
// whether this project is in the office) and the gallery of enrolled
// conversations (/museum).
//
// Everything a conversation or a store record supplies is drawn as plain Text
// (never Markdown or Link), and escaped inside SVG.

import { atom, read, update } from 'claude-code'
import type { RenderElement } from 'claude-code'

import type { MuseumLine, MuseumSend, SendTarget } from '../types'
import { MAX_TEXT, describeState } from '../src/delivery'
import { oneLine } from '../src/sanitize'
import { OVERVIEW, SLOTS, gallerySummary, renderGallerySvg } from '../src/scene'
import { startFullscreen } from './fullscreen'
import { enroll, isProjectHidden, leave, scan, selectSlot, sendToSelectedFrame, setProjectHidden, showOverview, stepFrame } from './museum'
import { workersNow } from './office'
import type { Engine } from './shared'

// This module's $.state values (the contract is ../types; each module that reads or writes one declares it).
const cameraAtom = atom({ plugin: 'agent-office-3d', key: 'camera' } as const, OVERVIEW)
const draftAtom = atom({ plugin: 'agent-office-3d', key: 'draft' } as const, '')
const framesAtom = atom({ plugin: 'agent-office-3d', key: 'frames' } as const, [])
const noticeAtom = atom({ plugin: 'agent-office-3d', key: 'notice' } as const, null)
const bridgeAtom = atom({ plugin: 'agent-office-3d', key: 'fullscreenBridge' } as const, null)
const officeNoticeAtom = atom({ plugin: 'agent-office-3d', key: 'officeNotice' } as const, null)
const scanAtom = atom({ plugin: 'agent-office-3d', key: 'scan' } as const, { at: 0, error: null, total: 0, staleCount: 0 })
const selectedAtom = atom({ plugin: 'agent-office-3d', key: 'selected' } as const, null)
const selfAtom = atom({ plugin: 'agent-office-3d', key: 'self' } as const, { sessionId: null, isEnrolled: false, label: null })
const sendsAtom = atom({ plugin: 'agent-office-3d', key: 'sends' } as const, [])
const viewAtom = atom({ plugin: 'agent-office-3d', key: 'view' } as const, 'overview')

type RenderEvent = Parameters<Engine['ui']['resolve']>[0]

const SHOWN_SENDS = 6

/** The exact identity a send is captured for: names collide and labels are cut, ids do not. */
function destinationOf(target: SendTarget): string {
  return target.kind === 'agent' ? `agent ${target.agentId}` : target.kind === 'main' ? 'this conversation (its own prompt queue)' : `session ${target.sessionId}`
}
const SHOWN_LINES = 10

const SEND_MARK: Record<MuseumSend['state'], string> = {
  sending: '…',
  failed: '✗',
  queued: '◷',
  arrived: '↘',
  'in-conversation': '▤',
  'turn-started': '▶',
  answered: '✓',
  'turn-failed': '✗',
  unverified: '?',
}

function sendLines($: Engine, e: RenderEvent, sends: readonly MuseumSend[]): RenderElement {
  const { Box, Text } = $.ui.resolve(e)
  return (
    <Box flexDirection="column">
      <Text dimColor>Sent from here (newest first):</Text>
      {sends
        .slice(-SHOWN_SENDS)
        .reverse()
        .map(s => (
          <Text color={s.state === 'failed' || s.state === 'turn-failed' ? 'error' : s.state === 'answered' ? 'success' : undefined}>
            {`${SEND_MARK[s.state]} ${s.targetLabel} [${destinationOf(s.target)}] ${s.nonce}: "${oneLine(s.text, 40)}": ${describeState(s)}`}
          </Text>
        ))}
    </Box>
  )
}

function transcriptLines($: Engine, e: RenderEvent, lines: readonly MuseumLine[]): RenderElement {
  const { Box, Text } = $.ui.resolve(e)
  return (
    <Box flexDirection="column">
      {lines.length === 0 && <Text dimColor>(no messages yet)</Text>}
      {lines.slice(-SHOWN_LINES).map(line => (
        <Text color={line.role === 'user' ? 'suggestion' : undefined}>{`${line.role === 'user' ? 'you   ' : 'claude'} │ ${line.text}`}</Text>
      ))}
    </Box>
  )
}

// ─── The office pane: the way into the 3D office ──────────────────────────

/** Opens the 3D office window; the outcome is the pane's notice. */
async function enterOffice($: Engine): Promise<void> {
  const text = await startFullscreen($)
  await update($, officeNoticeAtom, () => ({ text: oneLine(text, 300), isError: /not |fail|error|refused/i.test(text), at: 0 }))
}

/** The pane's other button: this project leaves the office, or comes back. */
async function toggleProject($: Engine): Promise<void> {
  const [isHidden, me] = await Promise.all([isProjectHidden($), read($, selfAtom)])
  const text = await setProjectHidden($, !isHidden && me.isEnrolled)
  await update($, officeNoticeAtom, () => ({ text: oneLine(text, 300), isError: false, at: 0 }))
}

export async function renderOfficePane($: Engine, e: RenderEvent): Promise<RenderElement> {
  const [workers, me, notice, bridge, isHidden] = await Promise.all([workersNow($), read($, selfAtom), read($, officeNoticeAtom), read($, bridgeAtom), isProjectHidden($)])
  const { Box, Text, Button } = $.ui.resolve(e)
  const hands = workers.filter(w => w.hand !== null).length
  const isOpen = bridge !== null
  const isIn = me.isEnrolled && !isHidden
  return (
    <Box flexDirection="column" gap={1}>
      <Text weight="semibold">Agent Office 3D</Text>
      <Text dimColor>{`${workers.length} worker${workers.length === 1 ? '' : 's'} in this session · ${hands} hand${hands === 1 ? '' : 's'} up${isOpen ? ' · the office window is open' : ''}`}</Text>
      <Button
        key="enter"
        hotkey="e"
        variant="primary"
        onPress={() => {
          void enterOffice($)
        }}
      >
        {isOpen ? 'Bring the 3D office window back' : 'Enter the 3D office'}
      </Button>
      <Text dimColor>
        {isHidden
          ? 'This project is out of the office: other sessions do not see it.'
          : isIn
            ? `This project is in the office as "${me.label ?? ''}": its room, its desks and its agents appear in every office window.`
            : 'This project is not in the office yet.'}
      </Text>
      <Button
        key="toggle"
        dimColor
        onPress={() => {
          void toggleProject($)
        }}
      >
        {isIn ? 'Remove this project from the office' : 'Add this project to the office'}
      </Button>
      {notice !== null && (
        <Text color={notice.isError ? 'error' : undefined} dimColor={!notice.isError}>
          {notice.text}
        </Text>
      )}
      <Text dimColor>In the window: W A S D and the mouse to walk, E to sit at a desk or a chair, G for the world editor, Esc to stand up. /3d opens it too.</Text>
    </Box>
  )
}

// ─── Gallery (optional) ────────────────────────────────────────────────────

export async function renderGalleryPane($: Engine, e: RenderEvent): Promise<RenderElement> {
  const [frames, selectedId, draft, camera, view, sends, me, info, notice] = await Promise.all([
    read($, framesAtom),
    read($, selectedAtom),
    read($, draftAtom),
    read($, cameraAtom),
    read($, viewAtom),
    read($, sendsAtom),
    read($, selfAtom),
    read($, scanAtom),
    read($, noticeAtom),
  ])
  const { Box, Text, Button } = $.ui.resolve(e)
  const shown = frames.slice(0, SLOTS.length)
  const target = frames.find(f => f.sessionId === selectedId)
  const caption = view === 'frame' && target !== undefined ? `Viewing ${target.label}` : `Overview · ${frames.length} enrolled`

  let gallery
  if (e.surface === 'desktop' || e.surface === 'vscode' || e.surface === 'mobile') {
    const { Svg } = $.ui.resolve(e)
    gallery = <Svg source={renderGallerySvg({ frames: shown, selectedId, camera, caption })} alt={gallerySummary(shown, selectedId)} />
  } else {
    gallery = (
      <Box flexDirection="column">
        {SLOTS.map((_, i) => {
          const f = shown[i]
          const mark = f !== undefined && f.sessionId === selectedId ? '▶' : ' '
          return (
            <Text dimColor={f === undefined}>
              {f === undefined ? ` ${mark} [${i + 1}] empty frame` : ` ${mark} [${i + 1}] ${f.label} · ${f.isStale ? 'stale' : f.status} · ${f.messageCount} messages`}
            </Text>
          )
        })}
      </Box>
    )
  }

  const frameButtons = SLOTS.map((_, i) => {
    const f = shown[i]
    const onPress = () => {
      void selectSlot($, i)
    }
    if (f === undefined) {
      return (
        <Button key={`frame-${i + 1}`} hotkey={`${i + 1}`} dimColor onPress={onPress}>
          {`${i + 1} · empty`}
        </Button>
      )
    }
    return (
      <Button key={`frame-${i + 1}`} hotkey={`${i + 1}`} variant={f.sessionId === selectedId ? 'primary' : 'secondary'} onPress={onPress}>
        {`${i + 1} · ${f.label} `}
        <Text dimColor>{f.isStale ? 'stale' : f.status}</Text>
      </Button>
    )
  })

  let composer
  if (e.surface === 'desktop' || e.surface === 'terminal' || e.surface === 'vscode') {
    const { Input } = $.ui.resolve(e)
    composer = (
      <Box flexDirection="column">
        <Input
          key="draft"
          label={target === undefined ? 'To (select a frame first):' : `To ${target.label}:`}
          placeholder="A message for the selected conversation only"
          value={draft}
          submitLabel="send"
          onInput={value => {
            void update($, draftAtom, () => value.slice(0, MAX_TEXT + 100))
          }}
          onSubmit={value => {
            void sendToSelectedFrame($, value)
          }}
        />
        <Box flexDirection="row" gap={1}>
          <Button
            key="send"
            variant="primary"
            label={target === undefined ? 'Send' : `Send to ${target.label}`}
            onPress={() => {
              void sendToSelectedFrame($, null)
            }}
          />
        </Box>
      </Box>
    )
  } else {
    composer = <Text dimColor>Sending needs the desktop app or the terminal.</Text>
  }

  const scanLine =
    `${info.total} enrolled conversation${info.total === 1 ? '' : 's'} besides this one` +
    (info.staleCount > 0 ? ` (${info.staleCount} stale)` : '') +
    (info.total > SLOTS.length ? `; showing the first ${SLOTS.length}` : '') +
    (info.error !== null ? `; store error: ${info.error}` : '')

  return (
    <Box flexDirection="column" gap={1}>
      {gallery}
      <Box flexDirection="column">{frameButtons}</Box>
      <Box flexDirection="row" gap={1}>
        <Button key="prev" onPress={() => void stepFrame($, -1)}>
          ◀ Prev
        </Button>
        <Button key="overview" hotkey="o" onPress={() => void showOverview($)}>
          Overview
        </Button>
        <Button key="next" onPress={() => void stepFrame($, 1)}>
          Next ▶
        </Button>
        <Button key="refresh" hotkey="r" dimColor onPress={() => void scan($)}>
          Refresh
        </Button>
      </Box>
      <Text dimColor>{scanLine}</Text>
      {target === undefined ? (
        <Text dimColor>{selectedId === null ? 'No frame selected. Press 1, 2 or 3.' : 'The selected conversation left the museum.'}</Text>
      ) : (
        <Box flexDirection="column">
          <Text weight="semibold">
            {`Selected: ${target.label} `}
            <Text dimColor>{`· ${target.isStale ? 'stale' : target.status} · ${target.messageCount} messages · ${target.sessionId.slice(0, 8)}`}</Text>
          </Text>
          <Text dimColor>Its own snapshot, published by that conversation (shown as plain text):</Text>
          {transcriptLines($, e, target.snapshot)}
        </Box>
      )}
      {composer}
      {notice !== null && (
        <Text color={notice.isError ? 'error' : undefined} dimColor={!notice.isError}>
          {notice.text}
        </Text>
      )}
      {sends.length > 0 && sendLines($, e, sends)}
      <Box flexDirection="row" gap={1}>
        {me.isEnrolled ? <Text dimColor>{`This conversation is enrolled as "${me.label ?? ''}".`}</Text> : <Text dimColor>This conversation is not enrolled.</Text>}
        {me.isEnrolled ? (
          <Button key="leave" dimColor onPress={() => void leave($)}>
            Leave the museum
          </Button>
        ) : (
          <Button key="enroll" dimColor onPress={() => void enroll($, '')}>
            Enroll this conversation
          </Button>
        )}
      </Box>
    </Box>
  )
}
