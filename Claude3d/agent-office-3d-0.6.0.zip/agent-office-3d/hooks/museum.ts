// Enrollment through $.store, the gallery of enrolled conversations, and the
// receipts this conversation keeps, while enrolled, about messages sent to it.

import { atom, read, update } from 'claude-code'

import type { MuseumAgent, MuseumCamera, MuseumFrame, MuseumNeedsUser, MuseumRecord, MuseumScan, SendTarget, TurnReason } from '../types'
import { deriveSend } from '../src/delivery'
import {
  KEY_PREFIX,
  LABEL_CHARS,
  MAX_AGENTS,
  PROJECT_CHARS,
  NEEDS_USER_CHARS,
  STALE_MS,
  addReceipt,
  buildSnapshot,
  findNonce,
  isOpenReceipt,
  keyFor,
  noteConversation,
  noteTurnEnd,
  noteTurnStart,
  parseRecord,
} from '../src/records'
import { inert, oneLine } from '../src/sanitize'
import { OVERVIEW, SLOTS, cameraForSlot, tweenCamera } from '../src/scene'
import { workersNow } from './office'
import type { Engine } from './shared'
import { errorText, noticeOf, ownMessages, sendTo, serial } from './shared'

// This module's $.state values (the contract is ../types; each module that reads or writes one declares it).
const agentReceiptsAtom = atom({ plugin: 'agent-office-3d', key: 'agentReceipts' } as const, [])
const cameraAtom = atom({ plugin: 'agent-office-3d', key: 'camera' } as const, OVERVIEW)
const draftAtom = atom({ plugin: 'agent-office-3d', key: 'draft' } as const, '')
const framesAtom = atom({ plugin: 'agent-office-3d', key: 'frames' } as const, [])
const noticeAtom = atom({ plugin: 'agent-office-3d', key: 'notice' } as const, null)
const pendingAtom = atom({ plugin: 'agent-office-3d', key: 'pending' } as const, [])
const scanAtom = atom({ plugin: 'agent-office-3d', key: 'scan' } as const, { at: 0, error: null, total: 0, staleCount: 0 })
const selectedAtom = atom({ plugin: 'agent-office-3d', key: 'selected' } as const, null)
const selfAtom = atom({ plugin: 'agent-office-3d', key: 'self' } as const, { sessionId: null, isEnrolled: false, label: null })
const sendsAtom = atom({ plugin: 'agent-office-3d', key: 'sends' } as const, [])
const viewAtom = atom({ plugin: 'agent-office-3d', key: 'view' } as const, 'overview')

export const GALLERY = 'agent-office-3d'
const HEARTBEAT_MS = 5000
const TWEEN_MS = 100
const TWEEN_STEPS = 7

// This conversation's own enrollment record, if it enrolled. Only this session writes its key.
let mine: MuseumRecord | null = null
let isBusy = false
let lastWriteAt = 0
let lastRefreshAt = 0
let tween: { cancel: () => void } | null = null

export const isEnrolled = (): boolean => mine !== null

async function publishedNeedsUser($: Engine): Promise<MuseumNeedsUser> {
  const pending = (await read($, pendingAtom)).filter(p => p.identity === 'main')
  const ask = pending.find(p => p.kind === 'question') ?? pending.find(p => p.kind === 'approval')
  return ask === undefined || ask.kind === 'external' ? null : { kind: ask.kind, text: inert(ask.text, NEEDS_USER_CHARS) }
}

/** This session's agents as the office sees them, bounded to what a record may carry: its swarm, for other sessions' offices. */
async function publishedAgents($: Engine): Promise<MuseumAgent[]> {
  const workers = await workersNow($)
  return workers
    .filter(w => w.kind === 'subagent' || w.kind === 'teammate')
    .slice(0, MAX_AGENTS)
    .map(w => ({ key: w.key, name: oneLine(w.name, 60), state: w.state, stateLabel: oneLine(w.stateLabel, 40), light: w.light, hand: w.hand?.kind ?? null }))
}

async function writeMine($: Engine, now: number): Promise<void> {
  if (mine === null) return
  mine = { ...mine, heartbeatAt: now, status: isBusy ? 'busy' : 'idle', needsUser: await publishedNeedsUser($), agents: await publishedAgents($) }
  await $.store.set(keyFor(mine.sessionId), mine)
  lastWriteAt = now
}

/** Re-reads this conversation's own messages when due, and writes its record when it changed or a heartbeat is due. */
export async function refreshMine($: Engine, force: boolean): Promise<void> {
  if (mine === null) return
  const now = await $.clock.now()
  const isWaiting = mine.receipts.some(isOpenReceipt)
  if (force || isWaiting || now - lastRefreshAt >= HEARTBEAT_MS) {
    const messages = await ownMessages($)
    lastRefreshAt = now
    if (mine === null || !Array.isArray(messages)) return
    const snapshot = buildSnapshot(messages)
    const receipts = noteConversation(mine.receipts, messages, now)
    const needsUser = await publishedNeedsUser($)
    const before = JSON.stringify([mine.snapshot, mine.receipts, mine.messageCount, mine.needsUser])
    mine = { ...mine, snapshot, receipts, messageCount: messages.length }
    if (before !== JSON.stringify([snapshot, receipts, messages.length, needsUser])) {
      await writeMine($, now)
      return
    }
  }
  if (force || now - lastWriteAt >= HEARTBEAT_MS || (mine.status === 'busy') !== isBusy) await writeMine($, now)
}

/** At session.start: keep an enrollment made earlier in this same running session (a reload); drop an older one. */
export async function adoptEnrollment($: Engine): Promise<void> {
  const sessionId = await $.session.id()
  const now = await $.clock.now()
  const raw = await $.store.get(keyFor(sessionId))
  const saved = parseRecord(raw)
  if (saved !== null && now - saved.heartbeatAt <= STALE_MS) mine = saved
  else if (raw !== undefined) await $.store.delete(keyFor(sessionId))
  await update($, selfAtom, () => ({ sessionId, isEnrolled: mine !== null, label: mine?.label ?? null }))
}

export function enroll($: Engine, labelArg: string): Promise<string> {
  return serial(async () => {
    const sessionId = await $.session.id()
    const cwd = await $.session.cwd()
    const folder = cwd.split(/[\\/]/).filter(Boolean).at(-1) ?? 'conversation'
    const label = oneLine(labelArg, LABEL_CHARS) || oneLine(`${folder} · ${sessionId.slice(0, 8)}`, LABEL_CHARS)
    const now = await $.clock.now()
    const same = mine?.sessionId === sessionId ? mine : null
    mine = {
      v: 1,
      sessionId,
      label,
      project: oneLine(folder, PROJECT_CHARS) || 'project',
      enrolledAt: same?.enrolledAt ?? now,
      heartbeatAt: now,
      status: isBusy ? 'busy' : 'idle',
      needsUser: null,
      messageCount: 0,
      snapshot: [],
      receipts: same?.receipts ?? [],
      agents: [],
    }
    await refreshMine($, true)
    await update($, selfAtom, () => ({ sessionId, isEnrolled: true, label }))
    return label
  })
}

export function leave($: Engine): Promise<boolean> {
  return serial(async () => {
    if (mine === null) return false
    const id = mine.sessionId
    mine = null
    await $.store.delete(keyFor(id))
    await update($, selfAtom, me => ({ ...me, isEnrolled: false, label: null }))
    return true
  })
}

/** The store key of a project's opt-out: a short hash of its working folder (a store key is a plain name). */
function hiddenKey(cwd: string): string {
  let h = 0x811c9dc5
  for (const ch of cwd.toLowerCase()) {
    h ^= ch.charCodeAt(0)
    h = Math.imul(h, 0x01000193) >>> 0
  }
  return `office.v1.hidden.${h.toString(16).padStart(8, '0')}`
}

/** Whether the person removed this project from the office (a mark in the store, by working folder). */
export async function isProjectHidden($: Engine): Promise<boolean> {
  const raw = await $.store.get(hiddenKey(await $.session.cwd()))
  return typeof raw === 'object' && raw !== null && (raw as { isHidden?: unknown }).isHidden === true
}

/** Removes this project from the office (this session leaves; its later sessions stay out) or puts it back (this session enrolls now). */
export async function setProjectHidden($: Engine, isHidden: boolean): Promise<string> {
  const key = hiddenKey(await $.session.cwd())
  if (isHidden) {
    await $.store.set(key, { v: 1, isHidden: true, at: await $.clock.now() })
    await leave($)
    return 'This project is out of the office: its sessions no longer appear there. Add it back any time.'
  }
  await $.store.delete(key)
  const label = await enroll($, '')
  return `This project is in the office as "${label}".`
}

/** At session start: every project is in the office unless the person removed it, or turned the option off. */
export async function autoEnroll($: Engine, isEnabled: boolean): Promise<'enrolled' | 'already' | 'hidden' | 'off'> {
  if (!isEnabled) return 'off'
  if (isEnrolled()) return 'already'
  if (await isProjectHidden($)) return 'hidden'
  await enroll($, '')
  return 'enrolled'
}

/** At session.end: an enrollment never outlives its session. */
export async function dropEnrollment($: Engine): Promise<void> {
  tween?.cancel()
  const id = mine?.sessionId
  mine = null
  if (id !== undefined) await $.store.delete(keyFor(id)).catch(() => undefined)
}

// The main loop's side of a museum message, while this conversation is enrolled.
export async function noteMainReceive($: Engine, text: string, originKind: string, claimedPlugin: string | null): Promise<void> {
  const nonce = mine !== null ? findNonce(text) : null
  if (nonce === null) return
  const at = await $.clock.now()
  await serial(async () => {
    if (mine === null) return
    mine = { ...mine, receipts: addReceipt(mine.receipts, { nonce, at, originKind, claimedPlugin }) }
    await writeMine($, at)
  })
}

export async function noteMainTurnStart($: Engine, turnId: string, text: string): Promise<void> {
  isBusy = true
  if (mine === null) return
  const at = await $.clock.now()
  await serial(async () => {
    if (mine === null) return
    mine = { ...mine, receipts: noteTurnStart(mine.receipts, { turnId, text, at }) }
    await writeMine($, at)
  })
}

export async function noteMainTurnEnd($: Engine, turnId: string, reason: TurnReason, answer: string): Promise<void> {
  isBusy = false
  if (mine === null) return
  const at = await $.clock.now()
  await serial(async () => {
    if (mine === null) return
    mine = { ...mine, receipts: noteTurnEnd(mine.receipts, { turnId, reason, answer, at }) }
    await refreshMine($, true)
  })
}

/** Reads every enrolled record but this conversation's own, and moves every send on by its target's receipts. */
export async function scan($: Engine): Promise<MuseumFrame[]> {
  const now = await $.clock.now()
  const me = await read($, selfAtom)
  let error: string | null = null
  const found: MuseumFrame[] = []
  try {
    const keys = (await $.store.keys()).filter(k => k.startsWith(KEY_PREFIX)).slice(0, 64)
    for (const key of keys) {
      const record = parseRecord(await $.store.get(key))
      // A record must sit under its own session's key; anything else is ignored.
      if (record === null || keyFor(record.sessionId) !== key || record.sessionId === me.sessionId) continue
      found.push({ ...record, isStale: now - record.heartbeatAt > STALE_MS })
    }
  } catch (err) {
    error = errorText(err)
  }
  found.sort((a, b) => a.enrolledAt - b.enrolledAt || (a.sessionId < b.sessionId ? -1 : 1))
  const frames = found.slice(0, 12)
  if (JSON.stringify(frames) !== JSON.stringify(await read($, framesAtom))) await update($, framesAtom, () => frames)
  const info: MuseumScan = { at: now, error, total: found.length, staleCount: found.filter(f => f.isStale).length }
  const shown = await read($, scanAtom)
  if (shown.error !== info.error || shown.total !== info.total || shown.staleCount !== info.staleCount) await update($, scanAtom, () => info)
  const agentReceipts = await read($, agentReceiptsAtom)
  // This conversation keeps no receipts of its own prompts: its sends move on by $.prompt.submit resolving (shared.ts).
  const receiptsFor = (target: SendTarget) =>
    target.kind === 'agent' ? agentReceipts : target.kind === 'main' ? [] : frames.find(f => f.sessionId === target.sessionId)?.receipts
  const sends = await read($, sendsAtom)
  if (sends.some(s => JSON.stringify(deriveSend(s, receiptsFor(s.target))) !== JSON.stringify(s))) {
    await update($, sendsAtom, list => list.map(s => deriveSend(s, receiptsFor(s.target))))
  }
  return frames
}

/** Moves the gallery camera to `to` in short eased steps, cancelling any move under way. */
async function fly($: Engine, to: MuseumCamera): Promise<void> {
  tween?.cancel()
  const from = await read($, cameraAtom)
  let done = 0
  const timer = $.clock.every(TWEEN_MS, () => {
    done += 1
    const isDone = done >= TWEEN_STEPS
    if (isDone) {
      timer.cancel()
      if (tween === timer) tween = null
    }
    void update($, cameraAtom, () => (isDone ? to : tweenCamera(from, to, done / TWEEN_STEPS))).catch(() => undefined)
  })
  tween = timer
}

export async function selectSlot($: Engine, slot: number): Promise<string> {
  const frames = await read($, framesAtom)
  const frame = slot >= 0 && slot < SLOTS.length ? frames[slot] : undefined
  if (frame === undefined) {
    const text = `Frame ${slot + 1} is empty: nothing selected.`
    const notice = await noticeOf($, text, true)
    await update($, noticeAtom, () => notice)
    return text
  }
  await update($, selectedAtom, () => frame.sessionId)
  await update($, viewAtom, () => 'frame')
  await fly($, cameraForSlot(slot))
  return `Selected frame ${slot + 1}: ${frame.label}.`
}

export async function showOverview($: Engine): Promise<void> {
  await update($, viewAtom, () => 'overview')
  await fly($, OVERVIEW)
}

export async function stepFrame($: Engine, by: 1 | -1): Promise<void> {
  const [frames, selectedId] = await Promise.all([read($, framesAtom), read($, selectedAtom)])
  const used = SLOTS.map((_, i) => i).filter(i => frames[i] !== undefined)
  if (used.length === 0) return
  const at = used.findIndex(i => frames[i]?.sessionId === selectedId)
  const next = used[(at < 0 ? (by === 1 ? 0 : used.length - 1) : at + by + used.length) % used.length]!
  await selectSlot($, next)
}

/** The gallery's Send: to the selected enrolled conversation, fixed before the first await that could let the selection change. */
export async function sendToSelectedFrame($: Engine, typed: string | null): Promise<{ isSent: boolean; text: string }> {
  const [selectedId, frames, draft] = await Promise.all([read($, selectedAtom), read($, framesAtom), read($, draftAtom)])
  const target = frames.find(f => f.sessionId === selectedId)
  const body = (typed ?? draft).trim()
  let result: { isSent: boolean; text: string }
  if (selectedId === null) result = { isSent: false, text: 'Select a frame first: nothing was sent.' }
  else if (target === undefined) result = { isSent: false, text: 'The selected conversation is no longer enrolled: nothing was sent.' }
  else {
    const sending = sendTo($, { kind: 'peer', sessionId: target.sessionId }, target.label, body)
    if (body !== '') await update($, draftAtom, () => '')
    result = await sending
  }
  const notice = await noticeOf($, result.text, !result.isSent)
  await update($, noticeAtom, () => notice)
  return result
}
