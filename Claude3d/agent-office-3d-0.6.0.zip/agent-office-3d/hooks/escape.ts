// The cooperative escape room: a room off the Agent Arcade where the person
// and an AI teammate work through a themed room's locks together. The person
// inspects objects, which reveals their clues, and tries answers on the locks;
// the teammate talks it through with them.
//
// The information boundary, by construction: the room data (src/escape/rooms.ts)
// holds answers only as salted hashes, so there is no answer anywhere to leak.
// What the teammate is told is built in exactly one place, `teammateView`,
// from the room's public text (title, intro, object names and descriptions,
// the lock prompts), the clues of objects the person has already inspected,
// which locks are solved, and the recent log. Never a hash, never the salt,
// never an undiscovered clue, never a lock's success text before it is solved,
// never the room module itself. The teammate reasons from the same evidence
// the person has, and nothing else: it may infer an answer from the clues
// found, but it cannot know one.
//
// Like the arcade, this module is a feature module of the fullscreen window:
// its own $.state atom, commands from the window checked again here, and a
// model call started from the window's timer (escapeTick), never awaited by it.

import { atom, read, update } from 'claude-code'

import { ROOMS, checkAnswer, nextRoom, roomById } from '../src/escape/rooms'
import type { EscapeRoom } from '../src/escape/rooms'
import { inert, oneLine } from '../src/sanitize'
import type { EscapeEffort, EscapeLogLine, EscapeState, EscapeTeammate } from '../types'
import type { Engine } from './shared'
import { errorText } from './shared'

/** The models a teammate seat may hold, by full id, with the name the window shows. */
export const ESCAPE_MODELS: readonly { id: string; name: string }[] = [
  { id: 'claude-fable-5-1', name: 'Fable 5.1' },
  { id: 'claude-opus-5-5', name: 'Opus 5.5' },
  { id: 'claude-sonnet-5-5', name: 'Sonnet 5.5' },
  { id: 'claude-haiku-5-5', name: 'Haiku 5.5' },
]
export const ESCAPE_EFFORTS: readonly EscapeEffort[] = ['low', 'medium', 'high', 'xhigh', 'max']

const LOG_LINES = 60
const LOG_FOR_TEAMMATE = 24
const SAY_CHARS = 600
const GUESS_CHARS = 80
const REPLY_CHARS = 1200
const REPLY_TIMEOUT_MS = 120000
const REPLY_MAX_TOKENS = 500

export function freshEscape(teammate: EscapeTeammate | null = null): EscapeState {
  return { roomId: null, discovered: [], solved: [], log: [], teammate, busy: false, error: null, isEscaped: false }
}

// This module's $.state value (the contract is ../types).
const escapeAtom = atom({ plugin: 'agent-office-3d', key: 'escape' } as const, freshEscape())

const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v)

const withLine = (s: EscapeState, who: EscapeLogLine['who'], text: string): EscapeState => ({ ...s, log: [...s.log, { who, text }].slice(-LOG_LINES) })

async function setEscape($: Engine, fn: (s: EscapeState) => EscapeState): Promise<EscapeState> {
  let out: EscapeState | null = null
  await update($, escapeAtom, s => {
    out = fn(s)
    return out
  })
  return out!
}

const modelName = (id: string): string => ESCAPE_MODELS.find(m => m.id === id)?.name ?? id

/** The exit lock stays shut until every other lock in the room is open. */
const isExitLocked = (room: EscapeRoom, solved: readonly string[]): boolean => room.puzzles.some(p => p.id !== room.exit && !solved.includes(p.id))

// ─── Commands from the window (checked again here: they came from a page) ──
/**
 * One escape command the window posted: `{ type: 'escape', action, ... }`.
 * Answers what to tell the person about the command itself, if anything;
 * what happens in the room goes to the room's log.
 */
export async function escapeCommandFromWindow($: Engine, cmd: Record<string, unknown>): Promise<string | null> {
  if (!isRecord(cmd)) return null
  const state = await read($, escapeAtom)
  switch (cmd.action) {
    case 'enter': {
      const wanted = typeof cmd.roomId === 'string' ? roomById(cmd.roomId) : undefined
      if (typeof cmd.roomId === 'string' && wanted === undefined) return 'There is no such escape room.'
      const room = wanted ?? nextRoom(state.roomId)
      await setEscape($, s => withLine({ ...freshEscape(s.teammate), roomId: room.id }, 'room', room.intro))
      return null
    }
    case 'leave':
      await setEscape($, s => freshEscape(s.teammate))
      return null
    case 'inspect': {
      const room = roomById(state.roomId)
      if (room === undefined) return 'You are not in an escape room.'
      const obj = room.objects.find(o => o.id === cmd.objectId)
      if (obj === undefined) return 'There is no such object in this room.'
      await setEscape($, s => {
        const discovered = s.discovered.includes(obj.id) ? s.discovered : [...s.discovered, obj.id]
        const text = obj.clue === undefined ? `You look over the ${obj.name.toLowerCase()}: ${obj.description} Nothing more to find there.` : `You inspect the ${obj.name.toLowerCase()}. ${obj.clue}`
        return withLine({ ...s, discovered }, 'room', text)
      })
      return null
    }
    case 'try': {
      const room = roomById(state.roomId)
      if (room === undefined) return 'You are not in an escape room.'
      const puzzle = room.puzzles.find(p => p.id === cmd.puzzleId)
      if (puzzle === undefined) return 'There is no such lock in this room.'
      const guess = typeof cmd.text === 'string' ? oneLine(cmd.text, GUESS_CHARS) : ''
      if (guess === '') return 'Type an answer first.'
      if (state.solved.includes(puzzle.id)) return 'That lock is already open.'
      if (puzzle.id === room.exit && isExitLocked(room, state.solved)) {
        await setEscape($, s => withLine(s, 'room', 'The way out does not budge yet: something else in the room must come first.'))
        return null
      }
      if (!checkAnswer(puzzle, guess)) {
        await setEscape($, s => withLine(s, 'room', `You try "${guess}". Nothing happens: that is not it.`))
        return null
      }
      await setEscape($, s => {
        const solved = s.solved.includes(puzzle.id) ? s.solved : [...s.solved, puzzle.id]
        const next = withLine({ ...s, solved }, 'room', `"${guess}" is right. ${puzzle.successText}`)
        return puzzle.id === room.exit ? { ...next, isEscaped: true } : next
      })
      return null
    }
    case 'say': {
      if (state.roomId === null) return 'You are not in an escape room.'
      const text = typeof cmd.text === 'string' ? inert(cmd.text, SAY_CHARS).trim() : ''
      if (text === '') return 'Type something first.'
      // The teammate's reply is due now; the window's timer runs it (escapeTick).
      let counted = false
      await setEscape($, s => {
        // Counted in the same step as the line is written, so a reply in flight that read the state without it sees the count move.
        if (!counted) {
          sayCount += 1
          counted = true
        }
        return { ...withLine(s, 'you', text), busy: s.teammate !== null, error: null }
      })
      return state.teammate === null ? 'Nobody is seated beside you: seat a teammate first.' : null
    }
    case 'unseat':
    case 'teammate': {
      if (cmd.action === 'unseat' || cmd.model === undefined || cmd.model === null) {
        await setEscape($, s => ({ ...(s.teammate === null ? s : withLine(s, 'room', `${modelName(s.teammate.model)} leaves the room.`)), teammate: null, busy: false }))
        return null
      }
      const model = ESCAPE_MODELS.find(m => m.id === cmd.model)
      const effort = ESCAPE_EFFORTS.find(e => e === cmd.effort)
      if (model === undefined || effort === undefined) return 'That teammate request was not understood: nothing changed.'
      const seat: EscapeTeammate = { model: model.id, effort }
      await setEscape($, s => ({ ...(s.roomId === null ? s : withLine(s, 'room', `${model.name} (${effort}) sits down beside you.`)), teammate: seat, error: null }))
      return null
    }
    default:
      return null
  }
}

// ─── The teammate's view: the single place the room is read for it ─────────
/** Who the teammate is, in the room, with nothing of the room in it. */
export const TEAMMATE_SYSTEM =
  'You are locked in an escape room with a human teammate, working the room together. You can only see what is listed for you: ' +
  'the room, its objects, the clues your teammate has already uncovered by inspecting things, the locks and which are open, and your recent conversation. ' +
  'You have no answer key and no other knowledge of this room; treat every clue listed as the whole of what either of you knows. ' +
  'Reason out loud from that evidence as a good teammate does: connect clues to locks, point out contradictions or things that do not add up, ' +
  'ask your teammate what they saw, and suggest what to inspect or try next. When the clues found so far let you work out a lock, say the answer and the reasoning; ' +
  'when they do not, say what is still missing rather than guessing confidently. Never claim to know something the listed evidence does not support. ' +
  'Answer in plain prose, a few sentences at most, as yourself, speaking to your teammate.'

/**
 * Everything the teammate is told about the room, as one prompt. This is the
 * only function that reads a room for the teammate, so the boundary can be
 * audited here: the title and intro; every object's name and description;
 * the clue of each object in `state.discovered` and nothing of the others;
 * each lock's prompt and whether it is open; and the recent log (the person's
 * words, its own earlier replies, and what the room reported, which is only
 * what the person saw). No `answerHash`, no salt, no success text of an
 * unsolved lock, no `clueIds`.
 */
export function teammateView(room: EscapeRoom, state: EscapeState): string {
  const objects = room.objects
    .map(o => {
      const found = state.discovered.includes(o.id)
      const detail = found ? (o.clue === undefined ? 'Inspected: nothing more to find there.' : `Inspected, found: ${o.clue}`) : 'Not inspected yet.'
      return `- ${o.name}: ${o.description} ${detail}`
    })
    .join('\n')
  const locks = room.puzzles
    .map(p => {
      const solved = state.solved.includes(p.id)
      const exit = p.id === room.exit ? ' (the way out)' : ''
      return `- ${p.prompt}${exit} ${solved ? 'OPEN.' : 'Still locked.'}`
    })
    .join('\n')
  const log = state.log
    .slice(-LOG_FOR_TEAMMATE)
    .map(l => `${l.who === 'you' ? 'Teammate' : l.who === 'teammate' ? 'You' : 'Room'}: ${l.text}`)
    .join('\n')
  return (
    `Room: ${room.title}\n${room.intro}\n\n` +
    `Objects in the room:\n${objects}\n\n` +
    `Locks:\n${locks}\n\n` +
    `Recent conversation (Teammate is your human teammate; Room is what happened):\n${log || '(nothing yet)'}\n\n` +
    'Your reply to your teammate:'
  )
}

// ─── The teammate's reply ──────────────────────────────────────────────────
let inFlight = false
/** Bumped by every `say`: a reply that finishes after a newer `say` leaves `busy` on, so the next tick answers that too. */
let sayCount = 0

async function teammateReply($: Engine): Promise<void> {
  const start = await read($, escapeAtom)
  const room = roomById(start.roomId)
  if (room === undefined || start.teammate === null) {
    await setEscape($, s => ({ ...s, busy: false }))
    return
  }
  const seat = start.teammate
  const roomId = room.id
  const saidAt = sayCount
  try {
    const r = await $.model.complete({ model: seat.model, effort: seat.effort, system: TEAMMATE_SYSTEM, prompt: teammateView(room, start), maxTokens: REPLY_MAX_TOKENS, timeoutMs: REPLY_TIMEOUT_MS })
    const after = await read($, escapeAtom)
    if (after.roomId !== roomId) return // the person left or changed rooms meanwhile: the reply is dropped
    if (!r.isAnswered) {
      const why = r.reason === 'api-error' ? `the request failed (${r.status})` : r.reason === 'aborted' ? 'the request timed out' : 'the reply was empty'
      await setEscape($, s => ({ ...s, busy: false, error: `${modelName(seat.model)}: ${why}` }))
      return
    }
    const text = inert(r.text, REPLY_CHARS).trim()
    await setEscape($, s => ({ ...withLine(s, 'teammate', text || '…'), busy: sayCount !== saidAt, error: null }))
  } catch (err) {
    await setEscape($, s => ({ ...s, busy: false, error: `${modelName(seat.model)}: ${errorText(err)}` }))
  }
}

/**
 * Runs the teammate's reply when one is due (`busy`). From the window's timer
 * it is never awaited (a model call takes seconds); `wait` awaits it, for the
 * CLI and tests.
 */
export async function escapeTick($: Engine, wait = false): Promise<void> {
  if (inFlight) return
  inFlight = true // claimed before any await, so two ticks in one moment start one reply
  const run = (async () => {
    const s = await read($, escapeAtom)
    if (!s.busy || s.roomId === null || s.teammate === null) return
    await teammateReply($)
  })().finally(() => {
    inFlight = false
  })
  if (wait) await run
}

// ─── For the window ────────────────────────────────────────────────────────
/** The escape room as the window draws it: visible objects (clues only once discovered), locks with their flags, the log, the seat, busy and error. */
export async function escapeOut($: Engine): Promise<unknown> {
  const s = await read($, escapeAtom)
  const room = roomById(s.roomId)
  return {
    rooms: ROOMS.map(r => ({ id: r.id, title: r.title, theme: r.theme })),
    models: ESCAPE_MODELS,
    efforts: ESCAPE_EFFORTS,
    room:
      room === undefined
        ? null
        : {
            id: room.id,
            title: room.title,
            theme: room.theme,
            intro: room.intro,
            objects: room.objects.map(o => {
              const isDiscovered = s.discovered.includes(o.id)
              return { id: o.id, name: o.name, description: o.description, isDiscovered, clue: isDiscovered ? o.clue ?? null : null }
            }),
            puzzles: room.puzzles.map(p => {
              const isSolved = s.solved.includes(p.id)
              const isExit = p.id === room.exit
              return { id: p.id, prompt: p.prompt, isSolved, isExit, isLocked: isExit && !isSolved && isExitLocked(room, s.solved), successText: isSolved ? p.successText : null }
            }),
            exit: room.exit,
          },
    discovered: s.discovered,
    solved: s.solved,
    log: s.log,
    teammate: s.teammate,
    busy: s.busy,
    error: s.error,
    isEscaped: s.isEscaped,
  }
}

/**
 * `/3d escape <what>`: `status` (the room as JSON), `tick` (runs a due
 * teammate reply and waits for it), or a command as JSON as the window would
 * post it: {"action":"enter","roomId":"mansion"}.
 */
export async function escapeCli($: Engine, args: string): Promise<string> {
  const what = args.trim()
  if (what === '' || what === 'status') return JSON.stringify(await escapeOut($), null, 2)
  if (what === 'tick') {
    await escapeTick($, true)
    return JSON.stringify(await escapeOut($), null, 2)
  }
  let cmd: unknown
  try {
    cmd = JSON.parse(what)
  } catch {
    return '/3d escape: status | tick | {"action":"enter"|"leave"|"inspect"|"try"|"say"|"teammate",...}'
  }
  if (!isRecord(cmd)) return 'The escape command must be a JSON object.'
  const text = await escapeCommandFromWindow($, cmd)
  return text ?? 'ok'
}
