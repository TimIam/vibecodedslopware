// The world editor: natural-language edits to the fullscreen office, as
// validated data with a preview, undo and persistence, never as code.
//
// `/3d design <text>` queues a request; the window's timer (designTick, on
// the session's own `$`, where the engine accepts a model call) sends it to
// the model with the exact vocabulary, the scene as it is, and the anchors the
// office has now. The answer is JSON edits; each is validated, resolved
// against the office, and the valid ones are folded into a preview the
// window draws translucent. Apply keeps it (and persists it, after a
// known-good snapshot of what it replaces), cancel drops it, undo goes back
// one applied scene, reset empties it.
//
// Nothing here can touch a status light, a hand, an android or an arcade
// board: the vocabulary (src/design/schema.ts) has no role for them.

import { atom, read, update } from 'claude-code'

import { BOUNDS, describeEdit, emptyDoc, foldEdits, resolveEdit, summarizeDoc, validate, validateDoc } from '../src/design/schema'
import { oneLine } from '../src/sanitize'
import type { DesignContext, DesignOut, DesignState, SceneDoc, SceneEdit } from '../types'
import type { Engine } from './shared'
import { errorText } from './shared'

// This module's $.state value (the contract is ../types).
const designAtom = atom({ plugin: 'agent-office-3d', key: 'design' } as const, freshDesign() as DesignState)

/** Where the applied scene lives in $.store, and the snapshot taken before each apply. */
export const STORE_KEY = 'design.v1'
export const KNOWN_GOOD_KEY = 'design.v1.known-good'

/** The model call: the session's default model, medium effort, a bounded answer. */
export const DESIGN_MODEL = { model: 'sonnet', effort: 'medium', maxTokens: 1500, timeoutMs: 120000 } as const

export function freshDesign(): DesignState {
  return { doc: emptyDoc(), preview: null, history: [], pending: null, busy: false, error: null }
}

const USAGE = [
  '/3d design <what you want>: ask for a change in words (flowers on my desk, make the arcade carpet blue, a bigger desk for agent 2 …); a preview appears in the window',
  '/3d design apply: keep the preview',
  '/3d design cancel: drop the preview (or the queued request)',
  '/3d design undo: drop the preview, or go back one applied scene',
  '/3d design reset: empty the scene (undo brings it back)',
  '/3d design remove <id>: preview the scene without that prop',
  '/3d design list: the scene in words',
  '/3d design status: the editor as JSON',
].join('\n')

// Function declarations, not arrows: the engine follows `$` into these when it scans the module's calls.
function state($: Engine): Promise<DesignState> {
  return read($, designAtom)
}
function setState($: Engine, fn: (d: DesignState) => DesignState): Promise<void> {
  return update($, designAtom, fn)
}

/** The applied scene to the store, with what it replaces as the known-good snapshot. */
async function persist($: Engine, previous: SceneDoc, doc: SceneDoc): Promise<void> {
  await $.store.set(KNOWN_GOOD_KEY, previous)
  await $.store.set(STORE_KEY, doc)
}

/**
 * At session start: the applied scene from the store, checked field by field.
 * A scene that does not pass gives way to the known-good snapshot, or to an
 * empty scene, and says so.
 */
export async function loadDesign($: Engine): Promise<void> {
  let doc = emptyDoc()
  let error: string | null = null
  const raw = await $.store.get(STORE_KEY).catch(() => undefined)
  if (raw !== undefined) {
    const checked = validateDoc(raw)
    if (checked.ok) doc = checked.doc
    else {
      const good = validateDoc(await $.store.get(KNOWN_GOOD_KEY).catch(() => undefined))
      doc = good.ok ? good.doc : emptyDoc()
      error = `The saved design was not usable (${checked.reason}); ${good.ok ? 'the last known-good design was loaded' : 'starting from an empty scene'}.`
    }
  }
  await setState($, d => ({ ...d, doc, preview: null, pending: null, busy: false, error }))
}

// ─── The person's actions ──────────────────────────────────────────────────
async function queueRequest($: Engine, text: string): Promise<string> {
  const request = oneLine(text, BOUNDS.request)
  if (request === '') return USAGE
  const d = await state($)
  if (d.busy) return 'A design request is still being worked on: wait for its preview, or /3d design cancel.'
  await setState($, s => ({ ...s, pending: { request, edits: [], explanation: '' }, preview: null, busy: true, error: null }))
  return `Queued: "${request}". The office window sends it to the model; the preview appears there (/3d design apply keeps it, cancel drops it).`
}

/** A preview without one prop, made here (no model): the person applies or cancels it like any other. */
async function queueRemove($: Engine, id: string): Promise<string> {
  const checked = validate({ type: 'removeProp', id: id.trim() })
  if (!checked.ok) return `Not removed: ${checked.reason}`
  const d = await state($)
  if (d.busy) return 'A design request is still being worked on: wait for its preview, or /3d design cancel.'
  const folded = foldEdits(d.doc, [checked.edit])
  if (folded.refused.length > 0) return `Not removed: ${folded.refused[0]!.reason}`
  await setState($, s => ({ ...s, pending: { request: `remove ${checked.edit.type === 'removeProp' ? checked.edit.id : ''}`, edits: [checked.edit], explanation: 'Removed from the window.' }, preview: folded.doc, busy: false, error: null }))
  return `Preview: ${describeEdit(checked.edit)}. /3d design apply keeps it.`
}

async function applyPreview($: Engine): Promise<string> {
  const d = await state($)
  if (d.preview === null) return d.busy ? 'The preview is not ready yet.' : 'There is no preview to apply.'
  const previous = d.doc
  const next = d.preview
  const count = d.pending?.edits.length ?? 0
  await setState($, s => ({ ...s, doc: next, preview: null, pending: null, busy: false, error: null, history: [...s.history, previous].slice(-BOUNDS.history) }))
  await persist($, previous, next)
  return `Applied ${count} edit${count === 1 ? '' : 's'}. /3d design undo goes back.`
}

async function cancelPreview($: Engine): Promise<string> {
  const d = await state($)
  if (d.preview === null && d.pending === null && !d.busy) return 'There is nothing to cancel.'
  await setState($, s => ({ ...s, preview: null, pending: null, busy: false, error: null }))
  return d.busy ? 'The request was cancelled; an answer still on its way is dropped.' : 'The preview was dropped.'
}

async function undo($: Engine): Promise<string> {
  const d = await state($)
  if (d.preview !== null || d.busy) return cancelPreview($)
  const previous = d.history.at(-1)
  if (previous === undefined) return 'There is nothing to undo.'
  const current = d.doc
  await setState($, s => ({ ...s, doc: previous, history: s.history.slice(0, -1), pending: null, preview: null, error: null }))
  await persist($, current, previous)
  return `Went back one scene (${d.history.length - 1} more to undo).`
}

async function reset($: Engine): Promise<string> {
  const d = await state($)
  const empty = emptyDoc()
  await setState($, s => ({ ...s, doc: empty, preview: null, pending: null, busy: false, error: null, history: [...s.history, d.doc].slice(-BOUNDS.history) }))
  await persist($, d.doc, empty)
  return 'The scene is empty. /3d design undo brings the last one back.'
}

/** `/3d design <text>`: undo | reset | apply | cancel | status | list | remove <id> | a request in words. */
export async function designCommand($: Engine, args: string): Promise<string> {
  const what = args.trim()
  const sub = (what.split(/\s+/)[0] ?? '').toLowerCase()
  const rest = what.slice(sub.length).trim()
  switch (sub) {
    case '':
    case 'help':
      return USAGE
    case 'status':
      return JSON.stringify(await state($), null, 2)
    case 'list': {
      const d = await state($)
      return `${d.preview === null ? 'Applied scene' : 'Preview (not applied)'}:\n${summarizeDoc(d.preview ?? d.doc)}`
    }
    case 'apply':
      return applyPreview($)
    case 'cancel':
      return cancelPreview($)
    case 'undo':
      return undo($)
    case 'reset':
      return reset($)
    case 'remove':
      return queueRemove($, rest)
    default:
      return queueRequest($, what)
  }
}

const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v)

/**
 * One design command the window posted: `{ type: 'design', action:
 * 'request'|'apply'|'cancel'|'undo'|'reset'|'remove', text?, id? }` (checked
 * again here: it came from a page). Answers what to tell the person, if anything.
 */
export async function designCommandFromWindow($: Engine, cmd: unknown): Promise<string | null> {
  if (!isRecord(cmd) || cmd.type !== 'design') return null
  switch (cmd.action) {
    case 'request':
      return typeof cmd.text === 'string' && cmd.text.trim() !== '' ? queueRequest($, cmd.text) : null
    case 'apply':
      return applyPreview($)
    case 'cancel':
      return cancelPreview($)
    case 'undo':
      return undo($)
    case 'reset':
      return reset($)
    case 'remove':
      return typeof cmd.id === 'string' && cmd.id.trim() !== '' ? queueRemove($, cmd.id.slice(0, BOUNDS.id + 1)) : null
    default:
      return null
  }
}

// ─── The model ─────────────────────────────────────────────────────────────
const EDIT_SCHEMA = [
  'Edits (every field shown is required unless marked optional; no other fields exist):',
  '{"type":"addProp","prop":{"id":"<lowercase letters, digits, - or _>","name":"<short name>","anchor":<anchor>,"offset":{"x":0,"y":0,"z":0},"yaw":0,"parts":[<part>...]}}',
  '  — adds the prop, or replaces the prop with that id. offset is metres from the anchor in its frame; yaw is degrees (optional).',
  '{"type":"removeProp","id":"<id>"}',
  '{"type":"moveProp","id":"<id>","anchor":<anchor> (optional),"offset":{"x":0,"y":0,"z":0} (optional),"yaw":0 (optional)}',
  '{"type":"resizeDesk","desk":<desk anchor>,"w":<metres>,"d":<metres>}',
  '{"type":"room","project":"<project>","carpet":"#rrggbb" (optional),"walls":"#rrggbb" (optional),"width":<metres> (optional),"depth":<metres> (optional)}',
  '{"type":"theme","carpet":"#rrggbb" (optional),"walls":"#rrggbb" (optional),"ceiling":"#rrggbb" (optional),"deskWood":"#rrggbb" (optional)}',
  '',
  'Anchors:',
  '{"kind":"desk","key":"<worker key from the list below>"}',
  '{"kind":"desk","session":"<session id>","seat":"lead"} or "agent 1", "agent 2" …',
  '{"kind":"room","project":"<project from the list below>"} — "arcade" is the Agent Arcade',
  '{"kind":"hallway"}',
  'Desk frame: the origin is the centre of the desk top on the floor; the top surface is 0.74 m up; +x is the worker\'s right, +z is toward the worker\'s chair, −z toward the visitor. A thing on the desk needs y 0.74.',
  'Room frame: the origin is the room\'s centre on the floor; the room is 14 m by 14 m, the door wall at z −7, the windows at z +7; keep props out of the middle 10 m where the desks are unless asked.',
  'Hallway frame: the origin is the entrance end on the hallway\'s centre line; x runs along the hallway (0 to its length), z is ±1.8.',
  '',
  'Parts (each has "color":"#rrggbb", and optional "roughness" 0–1, "metalness" 0–1, "at":{"x","y","z"} where it stands inside the prop; a box, cylinder or cone rises from "at", a sphere rests on it):',
  '{"shape":"box","w":<m>,"h":<m>,"d":<m>}  {"shape":"cylinder","r":<m>,"h":<m>}  {"shape":"sphere","r":<m>}  {"shape":"cone","r":<m>,"h":<m>}  {"shape":"text","text":"<label>","size":<m tall>}',
].join('\n')

const boundsText = (): string =>
  [
    `Bounds: at most ${BOUNDS.maxEdits} edits per answer, ${BOUNDS.maxParts} parts per prop, ${BOUNDS.maxProps} props in the scene.`,
    `Sizes ${BOUNDS.size.min}–${BOUNDS.size.max} m; radii ${BOUNDS.radius.min}–${BOUNDS.radius.max} m; label height ${BOUNDS.textSize.min}–${BOUNDS.textSize.max} m, label text at most ${BOUNDS.text} characters; names at most ${BOUNDS.name} characters.`,
    `Offsets: from a desk within ±${BOUNDS.offset.desk.xz} m (x, z) and 0–${BOUNDS.offset.desk.y} m up; from a room's centre within ±${BOUNDS.offset.room.xz} m and 0–${BOUNDS.offset.room.y} m up; along the hallway x ${BOUNDS.offset.hallway.xMin}–${BOUNDS.offset.hallway.xMax} m, z ±${BOUNDS.offset.hallway.z} m, 0–${BOUNDS.offset.hallway.y} m up. A part's "at" within ±${BOUNDS.partAt.xz} m and 0–${BOUNDS.partAt.y} m up.`,
    `Desks ${BOUNDS.desk.w.min}–${BOUNDS.desk.w.max} m wide (w) and ${BOUNDS.desk.d.min}–${BOUNDS.desk.d.max} m deep (d); the default desk is 0.9 by 0.6. Rooms ${BOUNDS.room.width.min}–${BOUNDS.room.width.max} m wide and deep; the default is 14 by 14.`,
    'Colours are hex strings only. Strings must be plain words: anything with <, >, a URL, a scheme like javascript: or data:, url( or an event handler like onclick= is refused.',
  ].join('\n')

/** The system prompt: the vocabulary, the bounds, and the office as it is. */
export function designSystemPrompt(doc: SceneDoc, ctx: DesignContext): string {
  const desks = ctx.desks.length === 0 ? '(no desks right now)' : ctx.desks.map(d => `- key "${oneLine(d.key, BOUNDS.key)}": ${oneLine(d.label, 40)} of session ${oneLine(d.session, BOUNDS.session)}`).join('\n')
  const rooms = ['- project "arcade": the Agent Arcade', ...ctx.rooms.map(r => `- project "${oneLine(r.project, BOUNDS.project)}": ${oneLine(r.title, 80)}`)].join('\n')
  return [
    'You are the world editor of a small 3D office, the Agent Office: a hallway of project rooms, each session with a lead desk and its agents behind it, and an Agent Arcade.',
    'You change the scene only by answering with JSON edits in the vocabulary below. The office is drawn from that data by a fixed renderer: there is no way to write code, scripts, markup, URLs or styles, and any string carrying them is refused.',
    'You cannot change status lights, raised hands, the androids or the arcade boards: they are not in the vocabulary. If asked, say so in the explanation and send no edit for it.',
    '',
    EDIT_SCHEMA,
    '',
    boundsText(),
    '',
    'The scene now:',
    summarizeDoc(doc),
    '',
    'Desks that exist now (anchor by key, or by session and seat):',
    desks,
    'Rooms that exist now:',
    rooms,
    '',
    'Answer with JSON only, no markdown fences, no prose outside it: {"edits":[...],"explanation":"one or two plain sentences on what you did"}.',
    'Build things from a few parts (a plant: a cylinder pot, a thin cylinder stem, spheres for leaves or flower heads). Choose short ids. To change an existing prop, send addProp with its id again. If the request cannot be done in this vocabulary, answer {"edits":[],"explanation":"..."} saying why.',
  ].join('\n')
}

/** The model's text as the JSON object it should be, fences and prose around it tolerated; null when it is not one. */
function parseAnswer(text: string): { edits: unknown[]; explanation: string } | null {
  const start = text.indexOf('{')
  const end = text.lastIndexOf('}')
  if (start < 0 || end <= start) return null
  let parsed: unknown
  try {
    parsed = JSON.parse(text.slice(start, end + 1))
  } catch {
    return null
  }
  if (!isRecord(parsed) || !Array.isArray(parsed.edits)) return null
  return { edits: parsed.edits, explanation: typeof parsed.explanation === 'string' ? parsed.explanation : '' }
}

/** The valid, resolved edits in an answer, and why each other one was refused, named by its place and type. */
export function checkEdits(raw: unknown[], ctx: DesignContext): { edits: SceneEdit[]; refused: string[] } {
  const edits: SceneEdit[] = []
  const refused: string[] = []
  raw.slice(0, BOUNDS.maxEdits).forEach((item, i) => {
    const typeName = isRecord(item) && typeof item.type === 'string' ? oneLine(item.type, 20) : 'edit'
    const label = `#${i + 1} (${typeName})`
    const checked = validate(item)
    if (!checked.ok) return void refused.push(`${label}: ${checked.reason}`)
    const resolved = resolveEdit(checked.edit, ctx)
    if (!resolved.ok) return void refused.push(`${label}: ${resolved.reason}`)
    edits.push(resolved.edit)
  })
  if (raw.length > BOUNDS.maxEdits) refused.push(`${raw.length - BOUNDS.maxEdits} more edits past the ${BOUNDS.maxEdits} allowed`)
  return { edits, refused }
}

let inFlight = false

async function perform($: Engine, ctx: DesignContext, request: string, doc: SceneDoc): Promise<void> {
  const r = await $.model.complete({ ...DESIGN_MODEL, system: designSystemPrompt(doc, ctx), prompt: `Request: ${request}` })
  const now = await state($)
  // Cancelled, or replaced by another request, while the model worked: this answer is dropped.
  if (!now.busy || now.pending === null || now.pending.request !== request) return
  if (!r.isAnswered) {
    const why = r.reason === 'api-error' ? `the request failed (${r.status})` : r.reason === 'aborted' ? 'the request timed out' : 'the reply was empty'
    await setState($, s => ({ ...s, busy: false, pending: null, preview: null, error: `The model gave no answer: ${why}.` }))
    return
  }
  const answer = parseAnswer(r.text)
  if (answer === null) {
    await setState($, s => ({ ...s, busy: false, pending: null, preview: null, error: `The model's answer was not the JSON expected (${oneLine(r.text, 120) || 'empty'}): nothing changed.` }))
    return
  }
  const { edits, refused } = checkEdits(answer.edits, ctx)
  const folded = foldEdits(now.doc, edits)
  for (const f of folded.refused) refused.push(`#${f.index + 1}: ${f.reason}`)
  const kept = edits.filter((_, i) => !folded.refused.some(f => f.index === i))
  const explanation = oneLine(answer.explanation, BOUNDS.explanation)
  const error = refused.length === 0 ? null : oneLine(`Refused ${refused.length} of ${answer.edits.length} edit${answer.edits.length === 1 ? '' : 's'}: ${refused.join('; ')}`, 600)
  if (kept.length === 0) {
    await setState($, s => ({ ...s, busy: false, pending: { request, edits: [], explanation }, preview: null, error: error ?? `No edits: ${explanation || 'the model proposed none'}` }))
    return
  }
  await setState($, s => ({ ...s, busy: false, pending: { request, edits: kept, explanation }, preview: folded.doc, error }))
}

/**
 * Performs the queued request, if any: one model call, then the preview.
 * Called from the window's timer (never awaited there: a model call takes
 * seconds; this returns when the preview is in). `ctx` is what the office
 * has now: its desks and rooms, the anchors a request may name.
 */
export async function designTick($: Engine, ctx: DesignContext): Promise<void> {
  if (inFlight) return
  const d = await state($)
  if (!d.busy || d.pending === null) return
  inFlight = true
  const request = d.pending.request
  try {
    await perform($, ctx, request, d.doc)
  } catch (err) {
    const text = errorText(err)
    await setState($, s => (s.busy && s.pending?.request === request ? { ...s, busy: false, pending: null, preview: null, error: `The design request failed: ${text}` } : s)).catch(() => undefined)
  } finally {
    inFlight = false
  }
}

/** Ids of props the preview adds or changes against the applied scene. */
function changedIds(doc: SceneDoc, preview: SceneDoc): string[] {
  const before = new Map(doc.props.map(p => [p.id, JSON.stringify(p)]))
  return preview.props.filter(p => before.get(p.id) !== JSON.stringify(p)).map(p => p.id)
}

/** What the window draws: the preview when there is one, else the applied scene, and the editor's state. */
export async function designOut($: Engine, ctx: DesignContext): Promise<DesignOut> {
  const d = await state($)
  return {
    doc: d.preview ?? d.doc,
    isPreview: d.preview !== null,
    changed: d.preview === null ? [] : changedIds(d.doc, d.preview),
    pending: d.pending === null ? null : { ...d.pending, words: d.pending.edits.map(describeEdit) },
    busy: d.busy,
    error: d.error,
    history: d.history.length,
    anchors: { desks: ctx.desks.map(x => ({ key: x.key, label: oneLine(x.label, 40), session: x.session })), rooms: ctx.rooms.map(r => ({ project: r.project, title: oneLine(r.title, 80) })) },
  }
}
