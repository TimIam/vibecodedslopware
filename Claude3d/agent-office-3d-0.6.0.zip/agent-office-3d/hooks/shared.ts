// Helpers both views use, and the one way the mod sends: to an explicit,
// already-captured target, through the documented $.session.send.

import { atom, update } from 'claude-code'
import type { EngineInterface } from 'claude-code'

import type { MuseumNotice, MuseumSend, SendTarget } from '../types'
import { MAX_SENDS, MAX_TEXT, compose, newNonce } from '../src/delivery'
import type { MessageLike } from '../src/records'
import { inert, oneLine } from '../src/sanitize'

// This module's $.state values (the contract is ../types; each module that reads or writes one declares it).
const sendsAtom = atom({ plugin: 'agent-office-3d', key: 'sends' } as const, [])

export type Engine = EngineInterface

export const errorText = (err: unknown): string => oneLine(err instanceof Error ? err.message : String(err), 200)

// Record writes from hooks and timers run one at a time.
let queue: Promise<unknown> = Promise.resolve()
export function serial<T>(work: () => Promise<T>): Promise<T> {
  const run = queue.then(work, work)
  queue = run.catch(() => undefined)
  return run
}

export async function noticeOf($: Engine, text: string, isError: boolean): Promise<MuseumNotice> {
  return { text: oneLine(text, 300), isError, at: await $.clock.now() }
}

export async function ownMessages($: Engine, agentId?: string): Promise<MessageLike[] | { deny: string }> {
  const list = agentId === undefined ? await $.session.messages() : await $.session.messages({ agentId })
  if (!Array.isArray(list)) return { deny: oneLine((list as { deny?: unknown }).deny ?? 'not readable', 200) }
  return list.map(m => ({ role: m.role, text: m.text, toolUses: m.toolUses }))
}

export const targetKey = (target: SendTarget): string =>
  target.kind === 'peer' ? `peer:${target.sessionId}` : target.kind === 'agent' ? `agent:${target.agentId}` : 'main'

// Targets with a send in flight, checked and set with no await between, so a
// double press cannot send twice.
const inFlight = new Set<string>()

/** Sends to this conversation waiting for a timer to submit them (see sendTo). */
const pendingPrompts: { id: string; text: string }[] = []

/**
 * Submits every pending send to this conversation as a prompt of the person's
 * own. Called from the mod's timers only: there the engine accepts
 * $.prompt.submit. Each call resolves only when the turn it queued starts
 * (after any turn now running), so none is awaited: the record says `queued`
 * now and `turn-started` then, or `failed` with the engine's reason.
 */
export async function flushPrompts($: Engine): Promise<void> {
  if (pendingPrompts.length === 0) return
  const batch = pendingPrompts.splice(0, pendingPrompts.length)
  for (const { id, text } of batch) {
    void $.prompt.submit({ text, asUser: true }).then(
      async () => {
        await update($, sendsAtom, list => list.map(s => (s.id === id && s.state === 'queued' ? { ...s, state: 'turn-started' } : s)))
      },
      async (err: unknown) => {
        const reason = errorText(err) || 'refused'
        await update($, sendsAtom, list => list.map(s => (s.id === id ? { ...s, state: 'failed', reason } : s)))
      },
    )
  }
}

/**
 * Sends `body` to `target`, both fixed by the caller before this runs, so no
 * later change of selection can redirect it. Records the send's states.
 */
export async function sendTo(
  $: Engine,
  target: SendTarget,
  targetLabel: string,
  body: string,
): Promise<{ isSent: boolean; text: string; send: MuseumSend | null }> {
  const key = targetKey(target)
  if (body === '') return { isSent: false, text: 'Type a message first: nothing was sent.', send: null }
  if (body.length > MAX_TEXT) return { isSent: false, text: `Messages are limited to ${MAX_TEXT} characters: nothing was sent.`, send: null }
  if (inFlight.has(key)) return { isSent: false, text: `A send to ${targetLabel} is still in flight: nothing more was sent.`, send: null }
  inFlight.add(key)
  try {
    const nonce = newNonce()
    const record: MuseumSend = {
      id: nonce,
      nonce,
      target,
      targetLabel,
      text: inert(body, 300),
      state: 'sending',
      reason: null,
      createdAt: await $.clock.now(),
      queuedAt: null,
      receipt: null,
    }
    await update($, sendsAtom, list => [...list, record].slice(-MAX_SENDS))
    if (target.kind === 'main') {
      // This conversation: the text goes into its own prompt queue as the person's words, bare and unframed.
      // The engine refuses $.prompt.submit from a command or press (it would wait on the turn that hook holds),
      // so the send only joins `pendingPrompts`; the mod's own timer submits it (flushPrompts) within a second or two.
      const at = await $.clock.now()
      const queued: MuseumSend = { ...record, state: 'queued', queuedAt: at }
      await update($, sendsAtom, list => list.map(s => (s.id === record.id ? queued : s)))
      pendingPrompts.push({ id: record.id, text: body })
      return { isSent: true, text: 'Queued as your own prompt in this conversation: it runs as soon as the session is idle.', send: queued }
    }
    let isDelivered = false
    let reason = 'not delivered'
    try {
      const to = target.kind === 'peer' ? { sessionId: target.sessionId } : { agentId: target.agentId }
      const sent = await $.session.send({ to, text: compose(body, nonce) })
      isDelivered = sent.isDelivered
      if (!sent.isDelivered) reason = oneLine(sent.reason, 200) || reason
    } catch (err) {
      reason = errorText(err) || reason
    }
    const at = await $.clock.now()
    await update($, sendsAtom, list =>
      list.map(s => (s.id !== record.id ? s : isDelivered ? { ...s, state: 'queued', queuedAt: at } : { ...s, state: 'failed', reason })),
    )
    const text = isDelivered ? `Queued for ${targetLabel}; not yet seen by it.` : `Not sent to ${targetLabel}: ${reason}`
    return { isSent: isDelivered, text, send: { ...record, state: isDelivered ? 'queued' : 'failed', queuedAt: isDelivered ? at : null, reason: isDelivered ? null : reason } }
  } finally {
    inFlight.delete(key)
  }
}
