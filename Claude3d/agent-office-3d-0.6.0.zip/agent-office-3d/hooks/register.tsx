// Agent Office 3D: a walkable 3D office of this session and of every other
// session that is in the office, in a fullscreen window (/3d). Inside Claude
// Code itself there is one small pane (/office) with the button into the
// window, and the gallery of enrolled conversations (/museum).
//
// - Workers are actual identities only: this conversation, the agents
//   $.agent.list() lists, and the sessions that are in the office (every
//   project by default; a project can be removed from the pane). States come
//   from this session's own supported hooks; a hand goes up only for a real
//   pending question (AskUserQuestion in flight) or a shown permission dialog.
// - The office observes. It never answers a question, never approves or denies
//   a permission, and sends only when the person asks, to the one identity
//   they chose.
// - Nothing here reads another session's files or any internal registry.

import { atom, read } from 'claude-code'
import type { Register } from 'claude-code'

import { describeState, isOutstanding } from '../src/delivery'
import { SLOTS } from '../src/scene'
import {
  GALLERY,
  adoptEnrollment,
  autoEnroll,
  dropEnrollment,
  enroll,
  isEnrolled,
  isProjectHidden,
  leave,
  noteMainReceive,
  noteMainTurnEnd,
  noteMainTurnStart,
  refreshMine,
  scan,
  selectSlot,
  sendToSelectedFrame,
  setProjectHidden,
  showOverview,
} from './museum'
import { OFFICE, agentReceive, approvalShown, autoOpenOnce, callEnded, callStarted, openOffice, pollAgents, turnEnded, turnStarted, workersNow } from './office'
import { arcadeCli } from './arcade'
import { designCommand, loadDesign } from './design'
import { escapeCli } from './escape'
import { fullscreenDiag, resumeFullscreen, startFullscreen, stopFullscreen } from './fullscreen'
import { kanbanCli, loadKanban } from './kanban'
import { renderGalleryPane, renderOfficePane } from './panes'
import type { Engine } from './shared'
import { errorText, flushPrompts, serial } from './shared'

// This module's $.state values (the contract is ../types; each module that reads or writes one declares it).
const scanAtom = atom({ plugin: 'agent-office-3d', key: 'scan' } as const, { at: 0, error: null, total: 0, staleCount: 0 })
const selectedAtom = atom({ plugin: 'agent-office-3d', key: 'selected' } as const, null)
const selfAtom = atom({ plugin: 'agent-office-3d', key: 'self' } as const, { sessionId: null, isEnrolled: false, label: null })
const sendsAtom = atom({ plugin: 'agent-office-3d', key: 'sends' } as const, [])

const TICK_MS = 1500

let ticking = false

async function tick($: Engine): Promise<void> {
  if (ticking) return
  ticking = true
  try {
    if (isEnrolled()) await serial(() => refreshMine($, false))
    await flushPrompts($)
    await pollAgents($)
    const panes = await $.ui.panes()
    const isOpen = panes.some(p => p.id === GALLERY || p.id === OFFICE)
    if (isOpen || (await read($, sendsAtom)).some(isOutstanding)) await scan($)
  } catch {
    // The next tick tries again; a failure here must not stop the timer.
  } finally {
    ticking = false
  }
}

async function sendsReport($: Engine) {
  return (await read($, sendsAtom)).map(s => ({
    nonce: s.nonce,
    target: s.target,
    targetLabel: s.targetLabel,
    state: s.state,
    described: describeState(s),
    reason: s.reason,
    createdAt: s.createdAt,
    queuedAt: s.queuedAt,
    receipt: s.receipt,
  }))
}

async function museumStatus($: Engine): Promise<string> {
  const frames = await scan($)
  const [selected, me, info] = await Promise.all([read($, selectedAtom), read($, selfAtom), read($, scanAtom)])
  return JSON.stringify(
    {
      self: me,
      selected,
      scan: info,
      frames: frames.slice(0, SLOTS.length).map((f, i) => ({
        slot: i + 1,
        sessionId: f.sessionId,
        label: f.label,
        status: f.isStale ? 'stale' : f.status,
        needsUser: f.needsUser,
        messageCount: f.messageCount,
        receipts: f.receipts,
        lastLines: f.snapshot.slice(-3),
      })),
      sends: await sendsReport($),
    },
    null,
    2,
  )
}

/** The office as JSON: this project's place in it, every worker with its evidence, and the sends from here. */
async function officeStatus($: Engine): Promise<string> {
  await scan($)
  await pollAgents($)
  const [workers, me, isHidden] = await Promise.all([workersNow($), read($, selfAtom), isProjectHidden($)])
  return JSON.stringify(
    {
      project: { isInOffice: me.isEnrolled && !isHidden, isHidden, label: me.label },
      workers: workers.map((w, i) => ({
        n: i + 1,
        key: w.key,
        kind: w.kind,
        group: w.group,
        name: w.name,
        state: w.state,
        stateLabel: w.stateLabel,
        light: w.light,
        icon: w.icon,
        evidence: w.evidence,
        hand: w.hand,
        isListed: w.isListed,
        canSend: w.target !== null,
        noSendReason: w.noSendReason,
      })),
      sends: await sendsReport($),
    },
    null,
    2,
  )
}

const MUSEUM_USAGE = [
  '/museum: open the gallery of enrolled conversations',
  '/museum enroll [label]: put THIS conversation in the office and gallery of other sessions (publishes a bounded snapshot of it)',
  '/museum leave: remove this conversation and delete its snapshot',
  '/museum select <1-3|overview>: select a frame',
  '/museum send <text>: send to the selected frame only',
  '/museum status: the gallery as JSON',
].join('\n')

const OFFICE_USAGE = [
  '/office: the pane with the button into the 3D office',
  '/office enter: open the 3D office window (the same as /3d)',
  '/office add: put this project in the office (every project is, unless removed)',
  '/office remove: take this project out of the office; its sessions stay out until added back',
  '/office status: the office as JSON',
].join('\n')

const THREE_D_USAGE = [
  '/3d: open the office as a fullscreen game window (WASD + mouse), linked live to this session',
  '/3d close: close the window; /3d diag: report its link',
  '/3d arcade <status | tick | {json}>: the Agent Arcade from the prompt',
  '/3d design <words | apply | cancel | undo | reset | list | status>: the world editor',
  '/3d kanban <status | reload | {json}>: the kanban wall',
  '/3d escape <status | tick | {json}>: the escape room',
  '/3d status: the office as JSON (the same as /office status)',
].join('\n')

const splitArgs = (args: string) => {
  const trimmed = args.trim()
  const sub = (trimmed.split(/\s+/)[0] ?? '').toLowerCase()
  return { sub, rest: trimmed.slice(sub.length).trim() }
}

export const register: Register = (on, options) => {
  const isAutoOpen = options.autoOpen !== false
  const isAutoEnroll = options.autoEnroll !== false

  on('session.start', async ($, e, next) => {
    await adoptEnrollment($)
    // Every project is in the office unless the person removed it: this session publishes its record from the start.
    await autoEnroll($, isAutoEnroll).catch(err => $.ui.log(`agent-office-3d: not enrolled: ${errorText(err)}`))
    await resumeFullscreen($).catch(() => undefined)
    // The world editor's applied scene and the project's kanban board, for the window.
    await loadDesign($).catch(err => $.ui.log(`agent-office-3d: design not loaded: ${errorText(err)}`))
    await loadKanban($).catch(err => $.ui.log(`agent-office-3d: kanban not loaded: ${errorText(err)}`))
    $.clock.every(TICK_MS, () => {
      void tick($)
    })
    for (const spec of [
      {
        name: 'office',
        description: 'Agent Office: the pane with the button into the 3D office; enter | add | remove | status',
        argumentHint: '[enter | add | remove | status]',
        immediate: true as const,
      },
      {
        name: '3d',
        description: 'Agent Office 3D: a fullscreen game window of the office, linked live; close | arcade | design | kanban | escape | status',
        argumentHint: '[close | arcade … | design <words> | kanban … | escape … | status]',
        immediate: true as const,
      },
      {
        name: 'museum',
        description: 'Session Museum: the gallery of enrolled conversations; enroll | leave | select | send | status',
        argumentHint: '[enroll [label] | leave | select <1-3|overview> | send <text> | status]',
        immediate: true as const,
      },
    ]) {
      try {
        await $.command.register(spec)
      } catch (err) {
        $.ui.log(`agent-office-3d: /${spec.name} not registered: ${errorText(err)}`)
      }
    }
    await autoOpenOnce($, isAutoOpen)
    await pollAgents($)
    return next(e)
  })

  on('session.end', async ($, e, next) => {
    await dropEnrollment($)
    return next(e)
  })

  on('turn.start', async ($, e, next) => {
    if (e.agentId === undefined) await noteMainTurnStart($, e.turnId, e.text)
    await turnStarted($, e.agentId, e.turnId, e.text)
    return next(e)
  })

  on('turn.complete', async ($, e, next) => {
    const result = await next(e)
    await turnEnded($, e.agentId, e.turnId, e.reason, e.answer)
    if (e.agentId === undefined) await noteMainTurnEnd($, e.turnId, e.reason, e.answer)
    return result
  })

  on('agent.spawn', async ($, e, next) => {
    const result = await next(e)
    await pollAgents($)
    return result
  }).catch(($, e, next) => next(e))

  // Every tool call is observed and passed on unchanged: the office never
  // answers, approves or refuses one.
  on('tool.call', async ($, e, next) => {
    const id = await callStarted($, e, e)
    try {
      return await next(e)
    } finally {
      await callEnded($, id)
    }
  }).catch(($, e, next) => next(e))

  // A permission dialog is being shown: recorded, then left to Claude Code's
  // own prompt and the person. Nothing is decided here.
  on('classic.PermissionRequest', async ($, e, next) => {
    await approvalShown($, e.agent_id, e.tool_name, e.tool_input)
    return next(e)
  }).catch(($, e, next) => next(e))

  // Arrival only: the hook runs before any approval and before a model reads
  // the message. The delivery is always passed on.
  on('session.receive', async ($, e, next) => {
    const origin = e.origin
    const claimedPlugin = 'plugin' in origin && typeof origin.plugin === 'string' ? origin.plugin : null
    if (e.agentId === undefined) await noteMainReceive($, e.text, origin.kind, claimedPlugin)
    else await agentReceive($, e.agentId, e.text, origin.kind, claimedPlugin)
    return next(e)
  }).catch(($, e, next) => next(e))

  on('command.run', { command: 'office' }, async ($, e) => {
    const { sub } = splitArgs(e.args)
    switch (sub) {
      case '':
      case 'open':
      case 'pane':
        await openOffice($)
        await scan($)
        return {}
      case 'enter':
      case 'window':
      case '3d':
        return { text: await startFullscreen($) }
      case 'add':
      case 'join':
        return { text: await setProjectHidden($, false) }
      case 'remove':
      case 'leave':
        return { text: await setProjectHidden($, true) }
      case 'status':
        return { text: await officeStatus($) }
      default:
        return { text: OFFICE_USAGE }
    }
  })

  on('command.run', { command: '3d' }, async ($, e) => {
    const { sub } = splitArgs(e.args)
    if (sub === '' || sub === 'full' || sub === 'fullscreen' || sub === 'window' || sub === 'open') return { text: await startFullscreen($) }
    if (sub === 'close') return { text: await stopFullscreen($) }
    if (sub === 'diag') return { text: await fullscreenDiag($) }
    if (sub === 'arcade') return { text: await arcadeCli($, e.args.trim().slice('arcade'.length)) }
    if (sub === 'design') return { text: await designCommand($, e.args.trim().slice('design'.length)) }
    if (sub === 'kanban') return { text: await kanbanCli($, e.args.trim().slice('kanban'.length)) }
    if (sub === 'escape') return { text: await escapeCli($, e.args.trim().slice('escape'.length)) }
    if (sub === 'status') return { text: await officeStatus($) }
    if (sub === 'pane' || sub === 'panel') {
      await openOffice($)
      return { text: 'The in-app office views were retired: this pane holds the button into the 3D window, which /3d opens directly.' }
    }
    return { text: THREE_D_USAGE }
  })

  on('command.run', { command: 'museum' }, async ($, e) => {
    const { sub, rest } = splitArgs(e.args)
    switch (sub) {
      case '':
      case 'open':
        await $.ui.open({ id: GALLERY, title: 'Session Museum' })
        await scan($)
        return {}
      case 'enroll': {
        const label = await enroll($, rest)
        return {
          text: `This conversation is in the office and the Session Museum as "${label}". It publishes a bounded snapshot of its own transcript, and whether it waits on a question or approval, to the mod's local store. /museum leave removes it.`,
        }
      }
      case 'leave':
        return { text: (await leave($)) ? 'This conversation left the office and the Session Museum; its snapshot was deleted.' : 'This conversation was not enrolled.' }
      case 'select': {
        if (rest.toLowerCase() === 'overview') {
          await showOverview($)
          return { text: 'Overview.' }
        }
        await scan($)
        return { text: await selectSlot($, Number.parseInt(rest, 10) - 1) }
      }
      case 'send':
        return { text: (await sendToSelectedFrame($, rest)).text }
      case 'status':
      case 'refresh':
        return { text: await museumStatus($) }
      default:
        return { text: MUSEUM_USAGE }
    }
  })

  on('ui.render', { component: 'Pane', requestId: OFFICE }, async ($, e) => renderOfficePane($, e))
  on('ui.render', { component: 'Pane', requestId: GALLERY }, async ($, e) => renderGalleryPane($, e))
}
