// The kanban wall board: this session's project board, read from a markdown
// file in the working folder (KANBAN.md, ROADMAP.md, TODO.md…), shown on a
// wall of the project's room in the fullscreen office, and changed from the
// window's panel with every change written back into that file by line.
//
// The file is the source of truth: the board in $.state is a parse of it,
// re-read whenever its modification time moves (so an edit by the person or
// by an agent shows up within two seconds), and every command re-reads the
// file before writing so a concurrent change is merged by card id, never
// clobbered. Only this session's project is readable from here: other
// sessions' rooms show no board.
//
// Integration points (docs/KANBAN.md): `loadKanban` at session start,
// `kanbanTick` from the window's timer, `kanbanOut` in the state the window
// draws, `kanbanCommandFromWindow` for `{ type: 'kanban', ... }` commands.

import { atom, read, update } from 'claude-code'

import { addCard, editCard, findCard, findColumn, moveCard, parse, removeCard, serialize, shapeOf, toggleCard } from '../src/kanban/markdown'
import type { KanbanBoard } from '../src/kanban/markdown'
import { inert, oneLine } from '../src/sanitize'
import type { KanbanState } from '../types'
import type { Engine } from './shared'
import { errorText } from './shared'

// This module's $.state value (the contract is ../types; each module that reads or writes one declares it).
const kanbanAtom = atom({ plugin: 'agent-office-3d', key: 'kanban' } as const, { file: null, board: null, mtimeMs: 0, error: null, dirty: false } as KanbanState)

/** The files looked for in the working folder, in order; the first found is the board. */
export const KANBAN_CANDIDATES = ['KANBAN.md', 'kanban.md', 'ROADMAP.md', 'roadmap.md', 'TODO.md', 'TASKS.md', 'docs/KANBAN.md', 'docs/ROADMAP.md'] as const

export const KANBAN_ACTIONS = ['toggle', 'move', 'add', 'edit', 'remove', 'reload'] as const
export type KanbanAction = (typeof KANBAN_ACTIONS)[number]

/** The window's command: `{ type: 'kanban', action, id?, column?, text? }`. */
export type KanbanCommand = { type: 'kanban'; action: KanbanAction; id?: string; column?: string; text?: string }

const CHECK_MS = 2000
const DISCOVER_MS = 10000
const TEXT_CHARS = 300
const MAX_COLUMNS = 12
const MAX_CARDS = 60
const NAME_CHARS = 60

let lastCheckAt = 0
let lastDiscoverAt = 0

const EMPTY: KanbanState = { file: null, board: null, mtimeMs: 0, error: null, dirty: false }

const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v)

const joinPath = (dir: string, name: string): string => `${dir.replace(/[\\/]+$/, '')}/${name}`

/** The board's file name relative to the working folder (what the window shows), or the path as given. */
export function kanbanFileName(file: string, cwd: string): string {
  const root = cwd.replace(/[\\/]+$/, '')
  const rel = file.startsWith(root) ? file.slice(root.length).replace(/^[\\/]+/, '') : file
  return rel.replace(/\\/g, '/')
}

async function readFile($: Engine, file: string): Promise<{ text: string; mtimeMs: number }> {
  const [text, stat] = await Promise.all([$.fs.read(file), $.fs.stat(file)])
  return { text: typeof text === 'string' ? text : '', mtimeMs: stat.mtimeMs }
}

/** Parses the file into the state, or records why it could not. */
async function take($: Engine, file: string): Promise<KanbanState> {
  let next: KanbanState
  try {
    const { text, mtimeMs } = await readFile($, file)
    const board = parse(text)
    next = { file, board, mtimeMs, error: board.columns.length === 0 ? 'The file has no columns: add `## <column>` headings with task lists.' : null, dirty: false }
  } catch (err) {
    next = { file, board: null, mtimeMs: 0, error: `Could not read ${file}: ${errorText(err)}`, dirty: false }
  }
  await update($, kanbanAtom, () => next)
  return next
}

/** Finds the project's board file (the first of KANBAN_CANDIDATES in the working folder) and parses it. */
export async function loadKanban($: Engine): Promise<KanbanState> {
  const cwd = await $.session.cwd()
  lastDiscoverAt = lastCheckAt = await $.clock.now()
  for (const name of KANBAN_CANDIDATES) {
    const file = joinPath(cwd, name)
    if (await $.fs.exists(file).catch(() => false)) return take($, file)
  }
  await update($, kanbanAtom, () => EMPTY)
  return EMPTY
}

/**
 * From the window's timer: every 2 s re-stats the board file and re-reads it
 * when its modification time moved; with no board, looks for one every 10 s.
 */
export async function kanbanTick($: Engine): Promise<void> {
  const now = await $.clock.now()
  if (now - lastCheckAt < CHECK_MS) return
  lastCheckAt = now
  const state = await read($, kanbanAtom)
  if (state.file === null) {
    if (now - lastDiscoverAt >= DISCOVER_MS) await loadKanban($)
    return
  }
  if (state.dirty) return // a write of ours is in flight: its own re-read follows
  let mtimeMs: number
  try {
    mtimeMs = (await $.fs.stat(state.file)).mtimeMs
  } catch {
    await update($, kanbanAtom, () => EMPTY) // the file went away: a board is looked for again in ten seconds
    lastDiscoverAt = now
    return
  }
  if (mtimeMs !== state.mtimeMs) await take($, state.file)
}

type Checked = { action: KanbanAction; id: string | null; column: string | null; text: string | null }

/** The command's fields, bounded and typed, or why they were refused. */
function check(cmd: Record<string, unknown>): Checked | string {
  const action = KANBAN_ACTIONS.find(a => a === cmd.action)
  if (action === undefined) return 'That board command was not understood: nothing changed.'
  const id = typeof cmd.id === 'string' && /^[0-9a-f]{8}(-\d+)?$/.test(cmd.id) ? cmd.id : null
  const column = typeof cmd.column === 'string' ? oneLine(cmd.column, NAME_CHARS) : null
  let text: string | null = null
  if (typeof cmd.text === 'string') {
    const raw = inert(cmd.text, TEXT_CHARS * 4).trim()
    if (raw.includes('\n')) return 'A card is one line: nothing changed.'
    if (raw.length > TEXT_CHARS) return `A card is at most ${TEXT_CHARS} characters: nothing changed.`
    text = raw
  }
  if ((action === 'toggle' || action === 'edit' || action === 'remove' || action === 'move') && id === null) return 'That card id was not understood: nothing changed.'
  if ((action === 'move' || action === 'add') && (column === null || column === '')) return 'That column name was not understood: nothing changed.'
  if ((action === 'edit' || action === 'add') && (text === null || text === '')) return 'Type the card first: nothing changed.'
  return { action, id, column, text }
}

/** `c` applied to `board`, or why it could not be. */
function apply(board: KanbanBoard, c: Checked): KanbanBoard | string {
  const where = c.column === null ? null : findColumn(board, c.column)
  if ((c.action === 'move' || c.action === 'add') && where === null) return `The board has no column named "${c.column}": nothing changed.`
  if (c.id !== null && findCard(board, c.id) === null) return 'That card is not on the board (it may have been changed elsewhere): nothing changed.'
  switch (c.action) {
    case 'toggle':
      return toggleCard(board, c.id!)
    case 'edit':
      return editCard(board, c.id!, c.text!)
    case 'remove':
      return removeCard(board, c.id!)
    case 'move':
      return moveCard(board, c.id!, where!.name)
    case 'add':
      if (where!.cards.some(k => k.text === c.text)) return `"${c.text}" is already in ${where!.name}: nothing changed.`
      return addCard(board, where!.name, c.text!)
    default:
      return board
  }
}

/**
 * One kanban command the window posted, checked again here (it came from a
 * page): ids must exist, texts are one line of at most 300 characters,
 * column names must exist. The file is re-read first; when it changed since
 * the board was read, the change is re-applied to the fresh parse by card id,
 * or refused when the card is gone. Answers what to tell the person, or null.
 */
export async function kanbanCommandFromWindow($: Engine, cmd: Record<string, unknown>): Promise<string | null> {
  if (cmd.type !== 'kanban') return null
  const c = check(cmd)
  if (typeof c === 'string') return c
  if (c.action === 'reload') {
    const s = await loadKanban($)
    return s.file === null ? 'This project has no board file (KANBAN.md, ROADMAP.md, TODO.md…).' : null
  }
  const state = await read($, kanbanAtom)
  if (state.file === null) return 'This project has no board file (KANBAN.md, ROADMAP.md, TODO.md…).'
  const file = state.file
  let current: { text: string; mtimeMs: number }
  try {
    current = await readFile($, file)
  } catch (err) {
    await update($, kanbanAtom, s => ({ ...s, error: `Could not read ${file}: ${errorText(err)}` }))
    return `The board file could not be read: ${errorText(err)}`
  }
  // The board the change applies to: the one in state, unless the file moved since it was read (then a fresh parse).
  const moved = state.board === null || current.mtimeMs !== state.mtimeMs
  const base = moved ? parse(current.text) : state.board!
  const next = apply(base, c)
  if (typeof next === 'string') {
    if (moved) await update($, kanbanAtom, () => ({ file, board: base, mtimeMs: current.mtimeMs, error: null, dirty: false }))
    return moved ? `The board changed under you and was reloaded. ${next}` : next
  }
  let text: string
  try {
    text = serialize(next, current.text)
  } catch (err) {
    return `That change could not be written: ${errorText(err)}`
  }
  await update($, kanbanAtom, s => ({ ...s, dirty: true }))
  try {
    await $.fs.write(file, text)
    const after = await $.fs.stat(file)
    await update($, kanbanAtom, () => ({ file, board: parse(text), mtimeMs: after.mtimeMs, error: null, dirty: false }))
  } catch (err) {
    await update($, kanbanAtom, s => ({ ...s, dirty: false, error: `Could not write ${file}: ${errorText(err)}` }))
    return `The board could not be written: ${errorText(err)}`
  }
  return moved ? 'The board had changed elsewhere; your change was merged into it.' : null
}

/** The board as the window draws it, bounded; `{ file: null }` when the project has no board. */
export async function kanbanOut($: Engine): Promise<unknown> {
  const state = await read($, kanbanAtom)
  if (state.file === null) return { file: null }
  const cwd = await $.session.cwd()
  const board = state.board
  return {
    file: kanbanFileName(state.file, cwd),
    title: oneLine(board?.title ?? '', 80),
    columns: (board?.columns ?? []).slice(0, MAX_COLUMNS).map(c => ({
      name: oneLine(c.name, NAME_CHARS),
      total: c.cards.length,
      cards: c.cards.slice(0, MAX_CARDS).map(k => ({ id: k.id, text: oneLine(k.text, TEXT_CHARS), done: k.done, line: k.line })),
    })),
    error: state.error,
    updatedAt: state.mtimeMs,
  }
}

/** `/3d kanban <what>` (optional): `status` (what the window gets), `reload`, or a command as JSON as the window would post it. */
export async function kanbanCli($: Engine, args: string): Promise<string> {
  const what = args.trim()
  if (what === '' || what === 'status') return JSON.stringify(await kanbanOut($), null, 2)
  if (what === 'reload') return (await kanbanCommandFromWindow($, { type: 'kanban', action: 'reload' })) ?? 'ok'
  if (what === 'shape') {
    const s = await read($, kanbanAtom)
    if (s.file === null) return 'no board'
    return shapeOf(await $.fs.read(s.file).then(t => (typeof t === 'string' ? t : '')))
  }
  let cmd: unknown
  try {
    cmd = JSON.parse(what)
  } catch {
    return '/3d kanban: status | reload | shape | {"action":"toggle"|"move"|"add"|"edit"|"remove","id"?,"column"?,"text"?}'
  }
  if (!isRecord(cmd)) return 'The kanban command must be a JSON object.'
  return (await kanbanCommandFromWindow($, { type: 'kanban', ...cmd })) ?? 'ok'
}
