# Office 3D 0.3.0 — private Windows transfer

## Exact build
This archive contains the Mini's installed runtime source from eb749f84f7156ccd36eea1b5ca78125f36c35b27 (integration d018504a08bf3516e8fc5bbe4a49eb04236c9f76), byte-for-byte. The plugin manifest is session-museum 0.3.0. It is not GitHub's older 0.2.1. Source-only: no engine executable, credentials, conversation logs, stores or caches. Runtime geometry is included in src/world3d/canonical.ts; its canonical JSON and exporter are also included. No Blender or npm dependencies are needed merely to load this plugin.

## Windows loading (PC installer)
1. Preserve the old 0.2.1 installation separately. Do not mix its files into this directory or overwrite an active installation without coordinating the session. Expand this ZIP into a new stable folder. The plugin root contains .claude-plugin/plugin.json directly.
2. Check Claude Code in the actual Desktop Code session using /status. This build was validated with Claude Code 2.1.299 and Desktop 2.42304.0 on macOS. Windows native rendering has NOT yet been verified. Confirm that the PC engine supports mods, Svg, Client, and the hooks in this build; use its own diagnostics. Do not disable security controls to load it.
3. Read-only shell validation: claude plugin validate "C:\path\to\office3d-0.3.0". Select the actual installed engine, not an unrelated older CLI.
4. For a session-only CLI load: claude --plugin-dir "C:\path\to\office3d-0.3.0". This is the documented local loader, but the terminal fallback displays text desks, NOT the visual 3D pane. Do not present terminal loading as successful Desktop installation.
5. For Desktop, use the PC engine's supported local-plugin/session loading flow and its normal approval. A project-scoped alternative documented currently is placing the plugin at <project>/.claude/skills/session-museum/ (manifest directly below that folder), then starting/reloading the intended Code session. Confirm this route is supported by that PC version before copying. It affects sessions in that project; do not silently install user-wide or fabricate a session id/junction. A Mac dev-mod symlink is not a portable installation.
6. In the intended Desktop Code session, confirm /plugin reports session-museum version 0.3.0 without load errors, then run /office3d. /office opens the earlier 2D overview. If /office3d is absent, inspect the plugin root, actual loaded version and duplicate plugin names; do not substitute 0.2.1.

## Controls and limitations
Click the native pane for focus. w/s forward/back; a/d turn; q/e sidestep; r/f look; c sit; x stand; n/p or 1-9 select desk; o overview. Experimental keyboard/drag input is optional. The 3D frame is software-projected SVG, not WebGL. Declared redraw cap: 10/second; displayed native FPS is unmeasured. The approval-hand visual remains unverified. Native subagent/peer Send (A2) was denied on the Mini: do not retry or reroute that action as part of installation. Do not enroll or copy conversations from the Mini. c4d3e37 timing instrumentation and b907eef late furniture changes are NOT in this installed build.

## Verification and privacy
Original Mini acceptance: 179/179 engine tests and native drawing/walking/sitting/selection/question-state checks. No fresh tests are claimed for this packaging or Windows. Every packaged source byte was compared with both the installed tree and eb749f8. SHA256SUMS.txt lists every payload file; TRANSFER-MANIFEST.json records provenance. This archive deliberately excludes private evidence/screenshots, .git/history, session stores, untracked A2 retry notes, generated engine declarations, caches and unrelated projects. It is for Tim's private device transfer; no public publication is implied.

Official loading references (consulted 2026-10-18):
- https://code.claude.com/docs/en/plugins/create#load-a-plugin-for-one-session
- https://code.claude.com/docs/en/plugins/create#share-the-plugin-through-a-repository
- https://code.claude.com/docs/en/plugins/mods
