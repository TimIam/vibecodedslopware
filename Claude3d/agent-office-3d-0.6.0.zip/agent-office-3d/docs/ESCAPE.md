# The cooperative escape room

A room off the Agent Arcade where the person and an AI teammate work through a
themed room's locks together. The person inspects objects (which reveals their
clues) and tries answers on the locks; the teammate talks it through with them,
reasoning only from what the person has already found. The teammate is never
told an answer, by construction: the room data holds no answers at all.

Files, all new, under `.claude/skills/session-museum/`:

| File | What it is |
| --- | --- |
| `src/escape/rooms.ts` | The three rooms as data, a small SHA-256, `hash`, `normalise`, `checkAnswer`, `ROOMS`, `roomById`, `nextRoom`. |
| `hooks/escape.ts` | The `escape` state atom, `escapeCommandFromWindow`, `escapeTick`, `escapeOut`, `teammateView`, `TEAMMATE_SYSTEM`, `escapeCli`. |
| `types/index.d.ts` | `EscapeState` and friends, and the `PluginState` declaration for the `escape` key. |
| `game/escape.js` | `buildEscapeRoom` (the 3D room) and `escapePanel` (the panel HTML), no imports. |
| `tests/escape.test.ts` | 12 tests, all passing: `claude.exe plugin test . tests/escape.test.ts`. |

## The themes

Rotation order (`enter` with no `roomId` takes the one after the current):

1. **Blackwood Manor** (`mansion`), a spooky mansion. Five objects (a portrait,
   a stopped grandfather clock, a bookshelf, a cracked mirror, a candelabra),
   three locks: a wall safe (four digits, from the portrait and the clock), a
   music box (a dance, from the candelabra), and the front door (the raven's
   word, from the bookshelf and the mirror), which is the exit.
2. **Station Kepler-9** (`station`), a failing space station. Six objects (a
   console, an oxygen rack, a maintenance hatch, an air vent, a crew locker, a
   taped photograph), three locks: the pod bay keypad (three digits, from the
   console, the rack and the hatch), a fuse box (a colour, from the vent), and
   the voice panel (the commander's passphrase, from the locker and the photo),
   which is the exit.
3. **The Meridian Vault** (`vault`), a heist gone sideways. Five objects (a
   ledger, a wall of deposit boxes, an oil painting, a wall timer with no clue,
   rolled plans), two locks: the inner safe (four digits, from the ledger and
   the boxes) and the inner door (the ship's name, from the painting and the
   plans), which is the exit.

Every room is solvable from its clues alone (the test solves each). The exit
lock stays shut until every other lock in the room is open. Each room has at
least one object with nothing behind it.

## The information boundary

Three layers, each enough on its own:

1. **There is no answer to leak.** `src/escape/rooms.ts` stores each lock's
   answer only as `answerHash`, a SHA-256 of `<salt>:<normalised answer>`, where
   normalising is lower case, whitespace folded to one space, trimmed. A guess is
   hashed the same way and the two hashes are compared (`checkAnswer`). The plain
   answers appear nowhere in the module: not as a literal, not inside a clue
   (the mirror shows the word reversed, the collar spells the name letter by
   letter, the passport writes the year in words). The salt is a fixed string
   that only keeps a stored hash from being looked up in a table of common words.
2. **One function builds the teammate's prompt.** `teammateView(room, state)`
   in `hooks/escape.ts` is the single place a room is read on the teammate's
   behalf, so the boundary is one function to audit. It emits: the room's title
   and intro; every object's name and description; the clue of each object in
   `state.discovered` and the words "Not inspected yet." for the others; each
   lock's prompt with OPEN or Still locked; and the recent log, which is the
   person's words, the teammate's earlier replies, and what the room reported,
   which is only what the person saw. It never emits `answerHash`, the salt,
   `clueIds`, an undiscovered clue, or the `successText` of an unsolved lock.
   The system prompt (`TEAMMATE_SYSTEM`) names no room, object or lock.
3. **The teammate has no tools, memory or retrieval.** Its reply is one
   `$.model.complete` call with that system prompt and that prompt, no tools, no
   history beyond the log, started from the window's timer. It cannot read the
   room module, the state, or any file.

What the teammate can do: connect found clues to locks, point out
contradictions, ask what the person saw, propose what to inspect or try next,
and infer an answer from the clues found so far (then the lock still decides).

What the window is told (`escapeOut`) obeys the same line: an object's `clue`
is `null` until it is inspected, a lock's `successText` is `null` until it is
solved, and hashes are never sent.

## How the boundary is tested

`tests/escape.test.ts` (12 tests) keeps the plain answers in a list that exists
only in the test file, and checks, for every room:

- Entering a room reveals no clue (state and log); inspecting one object
  reveals exactly that object's clue and no other.
- A wrong answer fails and the log carries neither the answer nor a hash; the
  right answer solves, however it is cased or spaced; a solved lock refuses a
  second try; the exit refuses to open while another lock is shut; escaping
  needs the exit lock; `leave` clears everything.
- Every exported field of every room (`JSON.stringify(ROOMS)`) and the system
  prompt contain none of the plain answers.
- `teammateView` with nothing discovered contains every object's name and
  description and every lock prompt, and none of: any clue, any hash, the salt,
  any unsolved lock's success text, any answer. With one object discovered,
  exactly its clue appears. With a lock solved, its success text appears and
  the others' still do not.
- The same holds for what the mocked `model.complete` actually received after a
  real `inspect`, `try`, `say` and `escapeTick` in each room.
- A `say` sets `busy` and queues exactly one completion; the reply lands in the
  log as the teammate; an empty reply leaves an error; a second `say` while a
  reply is in flight gets its own reply afterwards; a reply that lands after
  `leave` is dropped; invalid models and efforts are refused.
- The SHA-256 matches the standard vectors for one- and two-block messages.

The test kit lets a test import only its own files and `claude-code` (no
`node:fs`, and the kit's `$.fs` serves the engine, not a test), so the module's
*text* is checked from the shell, and should stay in the review checklist:

```bash
grep -ic -e 0315 -e waltz -e nevermore -e 763 -e blue -e biscuit -e 1974 -e "meridian star" .claude/skills/session-museum/src/escape/rooms.ts .claude/skills/session-museum/hooks/escape.ts
```

Every count is 0. (Those are the answers; they live in this file and the test
and nowhere else in the mod.)

The tests hand the hook a `$` of their own (`state.get/set` as `read` and
`update` use them, a clock, a scripted `model.complete`), the way
`tests/kanban.test.ts` does, because a hook's `$` refuses calls its own module's
scan does not list and `hooks/escape.ts` is not yet wired into `register.tsx`.

## Integration points

All in the fullscreen window's existing plumbing (`hooks/fullscreen.ts`,
`game/game.js`), following the arcade exactly:

1. **Commands.** In `fullscreen.ts` `onCommand`, beside the `arcade` branch:

   ```ts
   if (cmd.type === 'escape') {
     const text = await escapeCommandFromWindow($, cmd)
     if (text !== null) await update($, noticeAtom, () => ({ text: oneLine(text, 300), isError: true, at: 0 }))
     return true
   }
   ```

   `escapeCommandFromWindow($, cmd)` takes `{ type: 'escape', action, roomId?, objectId?, puzzleId?, text?, model?, effort? }` with `action` one of `enter`, `leave`, `inspect`, `try`, `say`, `teammate` (no `model` unseats; `unseat` is an alias). It answers a one-line notice for a malformed command, or `null`; what happens in the room goes to the room's log.
2. **The timer.** In `fullscreen.ts` `tick`, beside `await arcadeTick($)`: `await escapeTick($)`. It starts a due teammate reply (one model call) and never awaits it there; `escapeTick($, true)` awaits it, for the CLI and tests.
3. **The state.** In `fullscreen.ts` `writeState`'s `body`: `escape: await escapeOut($)`. The window then reads `state.escape`.
4. **The CLI (optional).** `escapeCli($, args)` is `/3d escape status | tick | <command JSON>`, like `arcadeCli`; wire it in `register.tsx` if wanted.
5. **The types.** `types/index.d.ts` declares `escape: EscapeState`. TypeScript cannot merge a second declaration of the `'agent-office-3d'` property, so under a strict `tsc` the one-line fix is to add `escape: EscapeState` (imported from `./escape`) to the block in `types/index.d.ts`. The runtime is unaffected either way.
6. **The page.** In `game.js`:
   - `import { buildEscapeRoom, escapePanel } from './escape.js'`.
   - Build the room where the escape room should stand (a room slot next to the arcade): `const escape = buildEscapeRoom(THREE, { box, mat, textSprite, solid }, parent, { x: roomX0(index), z: HALL.depth })`. It builds the walls, door frame, sign, props and a console with a chair, and returns `{ group, seat, setTheme, sign, card }`. `seat` is `{ kind: 'escape', pos, stand, yaw, number: 'escape' }`, like an arcade seat: add it to the targets `toggleSit` considers, and on sit open the escape panel (a `#escape` panel styled like `#arcade`) instead of the arcade one; `standUp` returns the player to `seat.stand`. `setTheme(state.escape.room?.id ?? null)` recolours the room when the room changes.
   - Draw: `panel.innerHTML = escapePanel(state.escape)` whenever `state.escape` changes while seated. The HTML has no listeners; one click handler on the panel reads `e.target.closest('[data-escape]')` and posts:

     | `data-escape` | post |
     | --- | --- |
     | `enter` | `{ type: 'escape', action: 'enter', roomId: btn.dataset.id }` (no id: next in rotation) |
     | `inspect` | `{ action: 'inspect', objectId: btn.dataset.id }` |
     | `try` | `{ action: 'try', puzzleId: id, text: panel.querySelector(`[data-escape-input="${id}"]`).value }` |
     | `say` | `{ action: 'say', text: panel.querySelector('[data-escape-say]').value }` then clear it |
     | `teammate` | `{ action: 'teammate', model: [data-escape-model].value, effort: [data-escape-effort].value }` |
     | `unseat` | `{ action: 'unseat' }` |
     | `leave` | `{ action: 'leave' }` |

     Enter in an input can trigger the matching button. Everything in the panel is escaped text.

## The state

`$.state` key `escape` (`types/index.d.ts`):

```ts
{ roomId: string | null; discovered: string[]; solved: string[]; log: { who: 'you' | 'teammate' | 'room'; text: string }[]
  teammate: { model: string; effort: 'low' | 'medium' | 'high' | 'xhigh' | 'max' } | null; busy: boolean; error: string | null; isEscaped: boolean }
```

`busy` means a teammate reply is due or in flight (set by `say`, cleared when
the reply lands or fails). The log is bounded at 60 lines; the teammate sees the
last 24. The teammate seat survives entering and leaving rooms. Models are the
four ids `claude-fable-5-1`, `claude-opus-5-5`, `claude-sonnet-5-5`,
`claude-haiku-5-5`; anything else is refused.

## Adding a room

Add an `EscapeRoom` to `ROOMS` in `src/escape/rooms.ts`: 4 to 6 objects, 2 to 3
puzzles with the exit last, each `answerHash` made with `hash(answer)` (compute
it once, outside the repository, and paste the hex; never commit the answer),
and clues that lead to the answer without containing it (the test fails on an
answer that appears in any room field). Add its answers to the test's `ANSWERS`
and to the grep line above.
