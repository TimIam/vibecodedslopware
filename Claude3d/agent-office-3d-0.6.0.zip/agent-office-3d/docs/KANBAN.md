# The kanban wall board

Every project room in the fullscreen office shows its project's board on a wall, live, and the person can change it
from a panel. The board lives in a markdown file of the project; every change is written back into that file, by
line, and a change made anywhere else (an editor, an agent, `git pull`) shows on the wall within two seconds.

Files (all under `.claude/skills/session-museum/`):

| File | What it holds |
| --- | --- |
| `src/kanban/markdown.ts` | Pure: `parse(text)`, `serialize(board, originalText)`, `cardId`, `shapeOf`, and the board edits (`toggleCard`, `editCard`, `moveCard`, `addCard`, `removeCard`, `findCard`, `findColumn`) |
| `hooks/kanban.ts` | The `$.state` atom `kanban`; `loadKanban`, `kanbanTick`, `kanbanCommandFromWindow`, `kanbanOut`, `kanbanCli`, `KANBAN_CANDIDATES` |
| `game/kanban.js` | The page module: `buildKanbanWall`, `kanbanPanel`, `kanbanCommandFor`, `KANBAN_TARGET` |
| `types/index.d.ts` | `KanbanState`, `KanbanOut`, `KanbanCommand`, and the `PluginState` declaration |
| `tests/kanban.test.ts` | 17 tests: the three file shapes, round trips, every edit, the hook's finding, reloading, commands and merging |

## The board in the file

A board is `{ title, columns: { name, cards: { id, text, done, line }[] }[] }`. The title is the file's first `#`
heading. The file is looked for in the session's working folder, the first of these that exists: `KANBAN.md`,
`kanban.md`, `ROADMAP.md`, `roadmap.md`, `TODO.md`, `TASKS.md`, `docs/KANBAN.md`, `docs/ROADMAP.md`.

Three shapes are read, in order of preference:

1. **Task lists under headings.** Each `## <name>` heading is a column; the task items under it (`- [ ] text`,
   `- [x] text`; `*` and `+` bullets too) are its cards. Lines indented under an item (a note, a nested bullet) are
   part of that card's text, joined with newlines, their own indent kept. Headings of other levels (`###`) do not
   start a column: their items belong to the enclosing `##` column.
2. **Bullets under headings.** A file with headings and plain bullet lists (`- text`) but no task items: one column
   per heading, every bullet a card that is not done. Ticking such a card writes `- [x] text`; a card added to a
   bullet file is written as a plain bullet while it is not done, so the file keeps its own style.
3. **Lists with no headings.** Task or bullet items in a file with no `##` headings (or `#` headings used as
   columns when there are two or more and no `##`) become one column, `Tasks`. Items that come before the first
   column heading in a file that has headings also go into a `Tasks` column, first.

In every shape a card is a list item that is not nested under another one; in a task file a plain bullet is a card
too (so a `## Done` section of plain bullets still shows). A file with no columns at all (no list and no column
heading) is reported as an error on the wall, and `kanbanOut` lists no columns.

What is **preserved**: everything that is not a card line. Prose, fenced code blocks (skipped entirely, so a
`- [ ]` inside one is not a card), ordered lists, blank lines, other headings, line endings (LF or CRLF, kept as the
file has them). `serialize(board, originalText)` re-parses the original text, matches cards by id and rewrites only
the lines a change needs:

| Change | Lines touched |
| --- | --- |
| nothing | none: the text comes back byte for byte |
| toggle or edit | that card's lines (an edit replaces the card and its continuation with the one new line) |
| move between columns | the card's lines leave its list; the card is appended after the last item of the other column's list (right under the heading when that list is empty, after a blank line if one follows the heading; at the end of the file for a headingless board) |
| add | appended the same way, as `- [ ] text` (or `- text` in a bullet file), with the indent and bullet character of that list's last item |
| remove | that card's lines, nothing else |

Card **ids** are a stable hash (FNV-1a, 8 hex digits) of the column name and the card's text; two cards with the same
text in one column get `-2`, `-3`… appended, in order. A move or an edit therefore changes a card's id: the hook
re-parses the written file and the window gets the new ids with the next state. A column named in a board that the
file does not have makes `serialize` throw.

## The hook: `hooks/kanban.ts`

The `$.state` atom `kanban` holds `{ file, board, mtimeMs, error, dirty }` for this session's project: the file's
path (null when the project has none), its parse (null when it could not be read), the file's modification time when
`board` was read, the last error, and whether a write of this session's own is in flight.

- `loadKanban($)` looks for the first candidate in `$.session.cwd()`, parses it, and sets `file` and `mtimeMs`.
- `kanbanTick($)` is called from the window's timer (every 250 ms); it does something every 2 s at most: it re-stats
  the file and re-reads it when `mtimeMs` moved, so a change made elsewhere shows up live. When the file is gone,
  or there is no board, it looks for a candidate again every 10 s. It does nothing while `dirty`.
- `kanbanCommandFromWindow($, cmd)` takes `{ type: 'kanban', action, id?, column?, text? }` with `action` one of
  `toggle`, `move`, `add`, `edit`, `remove`, `reload`, and answers the text to show the person, or null. Every field
  is checked again on this side, because it came from a page: the action must be one of those, an id must be an id
  the board has, a text is one line of at most 300 characters (made inert), a column name must name a column of the
  board (exact, else case-insensitively), and adding a text a column already holds is refused. The file is re-read
  before every write; when its modification time moved since the board was read, the fresh parse is used and the
  change is applied to it by card id (the person is told "your change was merged"); when the card is gone from the
  fresh parse, the change is refused, the fresh board is kept, and the answer says the board changed under them.
  After a write the stored board is a re-parse of the written text, so line numbers and ids are current.
- `kanbanOut($)` is what the window draws: `{ file, title, columns: [{ name, total, cards: [{ id, text, done, line }] }],
  error, updatedAt }` with the file name relative to the working folder, at most 12 columns and 60 cards each (`total`
  says how many the column really has), every text one bounded line; or `{ file: null }` for a project with no board.
  `updatedAt` is the file's modification time.
- `kanbanCli($, args)` is optional, for a `/3d kanban <status | reload | shape | {json}>` subcommand.

## The page: `game/kanban.js`

An ES module with no imports; the host passes `THREE` and its own helpers in.

- `buildKanbanWall(THREE, { box, mat, textSprite }, parent, { x, z, rotY })` builds a framed 1.9 by 1.2 m panel
  with a canvas texture at the wall's foot (`rotY` turns +z into the room, as the whiteboard's does) and returns
  `{ group, board, canvas, draw(board) }`. `draw` paints the title, the file name and the done count, then the
  columns with their names and counts and each card as a box with a checkbox, its text wrapped to three lines, done
  cards struck through, and `+N more` when a column does not fit. It repaints only when the board it is given
  differs from the last one drawn; `draw(null)` or `draw({ file: null })` paints the "no board file" notice.
- `kanbanPanel(board)` returns the panel's HTML (every text escaped): per card a row with a checkbox
  (`data-kanban="toggle" data-id`), a move `<select data-kanban="move" data-id>` listing the column names, an edit
  button (`data-kanban="edit"`, which opens an inline editor whose Save carries `data-kanban="edit-save"`) and a
  remove button (`data-kanban="remove"`); an add box per column (`<input data-add-text="<column>">` with
  `data-kanban="add" data-column`); and a Reload button (`data-kanban="reload"`). It adds no listeners of its own.
- `kanbanCommandFor(el, root)` turns a clicked or changed control into the command to post, or null (it opens and
  closes the inline editor itself), so the host's one listener can be
  `const cmd = kanbanCommandFor(e.target.closest('[data-kanban]'), ui.kanban); if (cmd) post(cmd)`.
- `KANBAN_TARGET = { kind: 'kanban' }`: the target kind the host registers at the wall's position, so the person can
  walk up to the wall and press E to open the panel.

## Integration points

Nothing is wired yet; these are the five places:

1. **Session start** (`hooks/register.tsx`, in `session.start` next to `resumeFullscreen`): `await loadKanban($)`.
2. **The timer** (`hooks/fullscreen.ts` `tick`, beside `arcadeTick`): `await kanbanTick($)`.
3. **The state** (`hooks/fullscreen.ts` `writeState`, beside `arcade`): `kanban: await kanbanOut($)`.
4. **The commands** (`hooks/fullscreen.ts` `onCommand`, like `arcade`): on `cmd.type === 'kanban'`, `const text = await
   kanbanCommandFromWindow($, cmd)`, shown as a notice when not null; answer true so the state goes out at once.
5. **The page** (`game/game.js`): `import { buildKanbanWall, kanbanPanel, kanbanCommandFor, KANBAN_TARGET } from './kanban.js'`;
   in `buildRoomShell`, for the session's own room, `const wall = buildKanbanWall(THREE, { box, mat, textSprite }, parent,
   { x: x1 - 0.08, z: z0 + 6.5, rotY: -Math.PI / 2 })` (the wall across from the whiteboard; any wall placement works),
   and a target `{ ...KANBAN_TARGET, pos, stand, yaw }` registered where `findTarget` considers arcade seats; on each
   state `wall.draw(state.kanban)`; on E at that target, show a `#kanban` panel with `kanbanPanel(state.kanban)` and
   redraw it on each state while open; one click/change listener on the panel posting `kanbanCommandFor(...)`.
   Rooms of other sessions get a wall drawn with `{ file: null }`, or none.

`types/index.d.ts` declares `kanban: KanbanState` under `PluginState['agent-office-3d']` the way `types/index.d.ts`
declares its keys. TypeScript does not merge two literal declarations of one property, so when the contract is
compiled as one, move that line (and `import type { KanbanState } from './kanban'`) into `index.d.ts`'s block.

The tests (`claude plugin test . tests/kanban.test.ts`) hand the hook a `$` of their own (`session.cwd`, a clock,
`fs.*` over an in-memory file map, `state.get/set`), since the kit's `$` is the engine's and a hook's `$` refuses
calls its module's scan does not list until `hooks/kanban.ts` is imported by `register.tsx`.

## Limits

- **This session's room only.** `$.fs` reaches files under this session's working folder; other sessions' folders
  are not readable from here, so their rooms show no board (`{ file: null }`). A session that wants its board on its
  own wall runs this mod itself; publishing boards through the shared `$.store` record is a possible later step.
- Cards are matched by id (column plus text): two edits of the same card from two places within the same two
  seconds race on the text, and the second one is refused as "not on the board" rather than merged.
- Reordering cards within a column is not a command; a move appends at the end of the target list.
- Only `##` headings (or `#` when used as columns) are columns; `###` sections fold into their `##` column.
