# The world editor

Natural-language edits to the fullscreen office, as validated data with a preview, undo and persistence. Never code: the model answers with JSON in a fixed vocabulary, every edit is checked field by field, and the window draws the result through a fixed renderer.

Files:

- `src/design/schema.ts`: the vocabulary, its bounds, `validate`, `validateDoc`, `resolveEdit`, `foldEdits` / `applyEdits`, `describeEdit`, `summarizeDoc`.
- `hooks/design.ts`: the feature module (state, commands, the model call, persistence).
- `game/design.js`: the window side (`applyDesign`, `designPanel`).
- `types/index.d.ts` (its world-editor section): the types, and the `design` state key.
- `tests/design.test.ts`: 13 tests.

## The vocabulary

A **scene** (`SceneDoc`) is `{ v: 1, props, desks, rooms, theme }`.

A **prop** is `{ id, name, anchor, offset, yaw, parts }`: a stable id (lowercase letters, digits, `-`, `_`; up to 32 characters), a name, where it is, and one to twelve **parts** from a fixed set of primitives, each with a hex colour and optionally a roughness, a metalness (both 0 to 1) and `at`, the point inside the prop it stands on:

| shape | fields |
| --- | --- |
| `box` | `w`, `h`, `d` |
| `cylinder` | `r`, `h` |
| `sphere` | `r` |
| `cone` | `r`, `h` |
| `text` | `text` (up to 40 characters), `size` (its height) |

A box, cylinder or cone rises from its `at`; a sphere rests on it; a label stands on it facing the viewer of the anchor.

An **anchor** is one of:

- `{ kind: 'desk', key }`: a desk by the worker key the office uses (`main`, `agent:<id>`, `peer:<session>`, `peer:<session>:agent:<id>`).
- `{ kind: 'desk', session, seat }`: the `lead` or `agent 1`, `agent 2` … desk of a session. Resolved to the key form against the office before the edit is kept.
- `{ kind: 'room', project }`: a project's room; `arcade` is the Agent Arcade.
- `{ kind: 'hallway' }`.

Frames, in metres:

- Desk: the origin is the centre of the desk top's footprint on the floor; the top surface is 0.74 m up; +x is the worker's right, +z toward the worker's chair, −z toward the visitor. Flowers on the desk: `offset { x: 0.35, y: 0.74, z: 0.1 }`.
- Room: the origin is the room's centre on the floor; for a 14 m room the door wall is at z −7 and the windows at z +7; world axes.
- Hallway: the origin is the entrance end on the hallway's centre line; x runs along it.

The `offset` is from the anchor in that frame; `yaw` (degrees) is added to the anchor's facing.

The **edits** (`SceneEdit`):

| type | fields | effect |
| --- | --- | --- |
| `addProp` | `prop` | adds the prop; with an existing id, replaces that prop |
| `removeProp` | `id` | removes it |
| `moveProp` | `id`, and any of `anchor`, `offset`, `yaw` | moves or turns it |
| `resizeDesk` | `desk` (a desk anchor), `w`, `d` | the desk top's width and depth |
| `room` | `project`, and any of `carpet`, `walls`, `width`, `depth` | a room's colours and size |
| `theme` | any of `carpet`, `walls`, `ceiling`, `deskWood` | the named colour roles |

Colours are `#rrggbb` strings only. There is no role for a status light, a hand, an android or an arcade board, so no edit can reach them.

## Bounds (`BOUNDS` in the schema)

| what | bound |
| --- | --- |
| props in a scene | 40 |
| parts per prop | 12 |
| edits per request | 20 (more are cut and reported) |
| resized desks / styled rooms | 64 / 32 |
| box sides, cylinder and cone heights | 0.02 to 3 m |
| radii | 0.01 to 1.5 m |
| label height / label text | 0.05 to 0.5 m / 40 characters |
| a part's `at` | ±2 m in x and z, 0 to 3 m up |
| offset from a desk | ±3 m in x and z, 0 to 2.5 m up |
| offset from a room's centre | ±7 m in x and z, 0 to 2.8 m up |
| offset along the hallway | x 0 to 60 m, z ±1.8 m, 0 to 2.8 m up |
| yaw | ±360° |
| desk top | 0.6 to 2.4 m wide, 0.4 to 1.4 m deep (default 0.9 by 0.6) |
| room | 10 to 20 m wide and deep (default 14 by 14) |
| name / worker key / project / session id | 40 / 120 / 80 / 64 characters |
| request text / explanation | 400 / 300 characters |
| scenes kept for undo | 20 |

Every string, in every field, is refused when it carries `<` or `>`, `javascript:`, `vbscript:`, `data:`, `file:`, `url(`, an event handler (`on` + a word + `=`), a `scheme://` URL, an HTML entity, a control character or an invisible (zero-width, bidi, BOM) character. Unknown fields are refused by name; so are sizes and offsets outside their bounds, non-hex colours, more parts or edits than allowed, and any anchor that is not one of the four forms above. `validate` normalises what passes (trimmed strings, lowercase colours, `yaw` defaulting to 0, optional fields absent rather than undefined), and `validateDoc` checks a whole scene the same way, with unique ids, before it is loaded from the store.

`foldEdits(doc, edits)` applies edits in order and never changes the scene it was given; it reports (by index) a remove or move of an unknown prop, a prop past the cap, a move that leaves the offset outside its new anchor's bounds, and a desk still named by session and seat. `applyEdits` is the same without the report.

## The flow

1. `/3d design <text>` (or the window's request box) queues the request: `pending = { request, edits: [], explanation: '' }`, `busy = true`. A command hook cannot call the model (the engine refuses it there), so the command only queues.
2. `designTick($, ctx)`, from the window's timer, sees the queued request and makes one `$.model.complete` call: `model: 'sonnet'`, `effort: 'medium'`, `maxTokens: 1500`, `timeoutMs: 120000`. A second tick while one is in flight does nothing.
3. The answer is parsed as JSON (fences and prose around it tolerated), every edit is validated and resolved against `ctx`, the valid ones are folded onto the applied scene, and the result becomes `preview`, with `pending` holding the kept edits and the explanation. Refused edits are named in `error` by place and type (`#2 (addProp): prop.name: contains angle brackets`), and the valid ones still go through. A malformed answer, an empty one or no answer leaves the scene untouched with the error.
4. The person applies (`doc = preview`, the old scene pushed onto `history`, persisted), cancels (the preview and the request are dropped; an answer still on its way is dropped too), undoes (a preview is dropped, else the last applied scene comes back, persisted) or resets (an empty scene, the old one in history).

Persistence: on every apply, undo and reset the scene is written to `$.store` under `design.v1`, after the scene it replaces is written under `design.v1.known-good`. `loadDesign($)` reads `design.v1` through `validateDoc`; a scene that fails gives way to the known-good one, or to an empty scene, and `error` says so. The store is shared between sessions, so the scene is the same in every session's window.

## The prompt

`designSystemPrompt(doc, ctx)` is the system prompt; the user prompt is `Request: <text>`. The system prompt holds, in order:

1. What the editor is, and that it changes the scene only through the JSON vocabulary: no code, scripts, markup, URLs or styles, and no status lights, hands, androids or arcade boards.
2. The exact edit shapes, the anchor forms, the three frames and the part shapes (the `EDIT_SCHEMA` text in `hooks/design.ts`).
3. The bounds, as numbers.
4. The scene now (`summarizeDoc`): each prop with its id, name, part count, anchor and offset; the resized desks; the styled rooms; the theme.
5. The anchors available: every desk in `ctx.desks` as `key "<key>": <label> of session <session>`, and every room in `ctx.rooms` plus `arcade`.
6. The answer format: JSON only, `{ "edits": [...], "explanation": "..." }`; build things from a few parts; reuse an id to change a prop; an empty edit list with the reason when the request cannot be done.

## Wiring (the integration points)

The module registers nothing. The coordinating session wires five points:

1. **`loadDesign($)` at session start**, in the `session.start` hook, next to `resumeFullscreen`.
2. **`designTick($, ctx)` in the window's timer** (`fullscreen.ts` `tick`), next to `arcadeTick`, not awaited: `void designTick($, designContext)`. The context comes from what `writeState` already has:

   ```ts
   const designContext: DesignContext = {
     desks: sessions.flatMap(s => [
       { key: s.lead, label: 'Lead', session: s.id },
       ...s.agents.map((key, i) => ({ key, label: `Agent ${i + 1}`, session: s.id })),
     ]),
     rooms: [...new Set(sessions.map(s => s.project))].map(project => ({ project, title: project })),
   }
   ```

   (`Lead` and `Agent n` are the labels `game.js` gives desks, so `{ session, seat: 'agent 2' }` resolves to the same desk the window calls Agent 2.)
3. **`designOut($, ctx)` in the state** the window gets: `design: await designOut($, designContext)` in `writeState`'s body, next to `arcade`.
4. **`designCommandFromWindow($, cmd)` in the window's commands**, in `onCommand`: `if (cmd.type === 'design') { const text = await designCommandFromWindow($, cmd); if (text !== null) <show it as the notice>; return true }`. And `/3d design …` in the `3d` command: `if (sub === 'design') return { text: await designCommand($, e.args.trim().slice('design'.length)) }`.
5. **`applyDesign` and `designPanel` in the page** (`game.js`): `import { applyDesign, designPanel } from './design.js'`; in `applyState`, after `syncWorld`, `applyDesign(THREE, scene, groups, state.design, designCtx)` where `groups` is any object the page keeps (the module stores its group under `groups.design`) and

   ```js
   const designCtx = {
     deskPosition: key => { const d = deskByKey(key); return d ? { x: d.x, z: d.z - 0.55, yaw: 0 } : null }, // the desk top's centre; desks are built unturned
     roomRect: project => { const r = project === 'arcade' ? roomOf.get(ARCADE_PROJECT) : roomOf.get(project); return r ? { x0: roomX0(r.index), z0: HALL.depth, x1: roomX0(r.index) + ROOM.width, z1: HALL.depth + ROOM.depth } : null },
     hallway: { x0: 0, z0: 0, x1: hallLength(), z1: HALL.depth },
   }
   ```

   `applyDesign` answers `{ group, drawn, theme, desks, rooms }`: the props are drawn by the module; the theme, the resized desks and the styled rooms are for the page to apply where it builds the world (`buildRoomShell`, `buildDesk`, the carpet and wall materials), since those meshes are the page's own. Preview props are translucent (`changed` ids, or all props when `isPreview` without `changed`). A prop whose anchor is not in the office is kept but hidden.

   The panel: `el.innerHTML = designPanel(state.design)` wherever the page shows it (a `#design` box styled like `#arcade` works); one click listener on it reads `e.target.closest('[data-design]')` and posts `{ type: 'design', action: el.dataset.design, text: el.closest('#design').querySelector('[data-design-text]')?.value, id: el.dataset.id }`. The module adds no listeners of its own.

The state key: `types/index.d.ts` (its world-editor section) declares `design: DesignState` under `PluginState['agent-office-3d']`. TypeScript does not merge two declarations of the same property with different object types, so fold the key into the block in `types/index.d.ts` (and drop the declaration at the end of `design.d.ts`), or reference `design.d.ts` from the manifest's `types` in its place. The engine's call gate is satisfied once `hooks/design.ts` is imported from a registered hooks module: every call it makes (`$.model.complete`, `$.store.get` / `set`, `$.state.get` / `set`, `$.clock.now`) is already in the plugin's scan.

The command line, once wired: `/3d design <text>` | `apply` | `cancel` | `undo` | `reset` | `remove <id>` | `list` | `status`.

## Deliberately impossible

- **Code, markup, styles, URLs.** There is no field that takes them; every string is scanned for them and refused; the renderer draws text onto a canvas as text and the panel escapes everything it shows.
- **Status lights, raised hands, androids, screens, arcade boards.** No anchor, part or theme role names them. A request about them gets an empty edit list and an explanation.
- **Unbounded scenes.** 40 props, 12 parts each, 20 edits a request, sizes and offsets within their anchors; a request that exceeds a bound is cut or refused, never clamped silently.
- **Edits that skip the preview.** Every change, including a remove from the window, is a preview until the person applies it. The model's answer never touches the applied scene.
- **A corrupt store taking the scene down.** The scene is checked whole on load, and the known-good snapshot (taken before every apply) is the fallback, then an empty scene.
- **An answer landing after a cancel.** The tick compares the request it answered with the one still queued and drops a stale answer.
- **Scripts in the model's reach.** The model sees the vocabulary, the bounds, the scene summary and the anchor names: never file paths, worker conversations or the store.
