# Provenance of reused code

Authorized by the person (2026-10-16): copy only essential reusable rendering, controls or math from
`/Users/tim/Documents/Codex/2026-10-16/task/social-museum`, preserving every original, and only after feasibility
proved it useful. The originals were only read (`shasum`, `git show`); nothing in that checkout was changed.

Feasibility showed (docs/FEASIBILITY.md) that the museum must project its own 3D room in TypeScript, so two small pieces
of pure placement math were useful. Nothing else was taken: no three.js, no scene, textures, lighting, controls wiring,
billing, authentication, Supabase, social integrations, user data, marketing, secrets or assets.

| Reused as | From | Source state | What changed |
| --- | --- | --- | --- |
| `wallToWorld` in `plugin/src/scene.ts` | `social-museum/src/layout.js` `wallToWorld` (line 23) | commit `006812674c7af5cd09a63b88614bd7d507280408`; the function is identical in that commit and in the working tree read at 2026-10-16T22:55Z | Typed; walls are this room's three (`WALLS`), not `config.js`'s; default offset 0 |
| `viewpointFor` in `plugin/src/scene.ts` | `social-museum/src/controls.js` `viewpointFor` (line 296) | same commit; identical in the working tree | Typed; the walkable-union clamp and collider push-out replaced by a clamp inside this single empty room; conventions kept (`rotY` turns +Z to (sin, 0, cos); camera yaw θ looks down (-sin θ, 0, -cos θ)) |

File hashes at the time of reading (SHA-256):

| File | Working tree | `HEAD` |
| --- | --- | --- |
| `src/layout.js` | `ecd3a07c9cb0b3ae8a0a1c3e77a2a06ae3b5d02eb1e5cabd409ca563d0a495e0` | `30afdbda17da1f3e01d2b7e1f4eb15fe82a9dc95f1e7acd41edb86a20fafad66` |
| `src/controls.js` | `88cb95a16c7f1a7ff2847211fad6b2d1858cfb6f15265be2d7ca605214fe8123` | `b761a267f1686a7b64551bfc8f52c2cd1e5f9067fe092a17eeee202f6acdcc93` |

The social-museum package is `"license": "UNLICENSED"` (the person's own private code); its third-party notice covers
three.js, none of which is reused here.
