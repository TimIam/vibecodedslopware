// The arcade's seats and turns against a mocked model, driven through the
// mod's own command (as the window's posts are, in the end): only legal moves
// are ever played, whoever proposes them; an agent's illegal answer is bounced
// back with the reason and the game goes stuck after three; the person's moves
// obey the same rules and the turn order.

import { describe, expect, mock, test } from 'claude-code/testing'
import type { On } from 'claude-code'

type Rec = Record<string, any>

/** The engine beneath the mod, for these tests: a clock, a session, an empty store, and a model that answers from a script. */
function engine(on: On, replies: string[]) {
  const asked: Rec[] = []
  mock.clock(on, { now: 1800000000000 })
  const store = new Map<string, unknown>()
  on('session.start', ($, e) => ({ cwd: e.cwd }))
  on('session.id', () => ({ value: 'a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6' }))
  on('session.cwd', () => ({ value: '/tmp/arcade-test' }))
  on('session.messages', () => ({ value: [] }))
  on('agent.list', () => ({ value: [] }))
  on('store.get', ($, e) => ({ value: store.get(e.key) }))
  on('store.set', ($, e) => {
    store.set(e.key, e.value)
    return { value: undefined }
  })
  on('store.delete', ($, e) => {
    store.delete(e.key)
    return { value: undefined }
  })
  on('store.keys', () => ({ value: [...store.keys()] }))
  on('ui.panes', () => ({ value: [] }))
  on('ui.open', () => ({ value: { isPlaced: true } }))
  on('command.register', ($, e) => ({ value: { name: e.name } }))
  on('ui.log', () => ({ value: undefined }))
  on('model.complete', ($, e) => {
    asked.push({ model: e.model, effort: e.effort, prompt: String(e.prompt), system: String(e.system) })
    const text = replies.shift() ?? ''
    const usage = { input_tokens: 1, output_tokens: 1, cache_creation_input_tokens: 0, cache_read_input_tokens: 0 }
    // A `$`-noun call is answered with `{ value }` (as the clock and store mocks do); any other shape answers only once.
    return { value: text === '' ? { isAnswered: false, reason: 'empty-reply', usage } : { isAnswered: true, text, usage } } as any
  })
  return { asked }
}

const start = ($: any) => $.session.start({ cwd: '/tmp/arcade-test', surface: 'desktop', isInteractive: true })
const arcade = async ($: any, cmd: Rec | string): Promise<string> =>
  (await $.command.run({ command: '3d', args: `arcade ${typeof cmd === 'string' ? cmd : JSON.stringify(cmd)}` })).text
const games = async ($: any): Promise<Rec> => JSON.parse(await arcade($, 'status'))
const chess = async ($: any): Promise<Rec> => (await games($)).chess
const ttt = async ($: any): Promise<Rec> => (await games($)).tictactoe
/** Plays any agent move that is due and waits for it. */
const tick = ($: any) => arcade($, 'tick')

describe('seats and the person', () => {
  test('a game waits for both seats; the person moves only legal moves, and only on their turn', async ($, on) => {
    engine(on, [])
    await start($)
    expect(await arcade($, { game: 'chess', action: 'seat', side: 'a', seat: { kind: 'human' } })).toBe('ok')
    expect((await chess($)).status).toBe('waiting')
    expect(await arcade($, { game: 'chess', action: 'move', move: 'e4' })).toContain('not running')
    await arcade($, { game: 'chess', action: 'seat', side: 'b', seat: { kind: 'human' } })
    expect((await chess($)).status).toBe('playing')
    expect(await arcade($, { game: 'chess', action: 'move', move: 'e5' })).toContain('not a legal move')
    expect((await chess($)).moves).toEqual([])
    expect(await arcade($, { game: 'chess', action: 'move', move: 'Nf3' })).toBe('ok')
    const g = await chess($)
    expect(g.moves).toEqual(['g1f3'])
    expect(g.history).toEqual(['Nf3'])
    expect(g.turn).toBe('b')
    expect(g.fen.startsWith('rnbqkbnr/pppppppp/8/8/8/5N2/PPPPPPPP/RNBQKB1R b')).toBe(true)
  })

  test('a seat takes only the models and efforts offered; reset keeps the seats and clears the board', async ($, on) => {
    engine(on, [])
    await start($)
    expect(await arcade($, { game: 'chess', action: 'seat', side: 'a', seat: { kind: 'agent', model: 'gpt-9', effort: 'high' } })).toContain('not understood')
    expect(await arcade($, { game: 'chess', action: 'seat', side: 'a', seat: { kind: 'agent', model: 'claude-haiku-5-5', effort: 'ultra' } })).toContain('not understood')
    await arcade($, { game: 'chess', action: 'seat', side: 'a', seat: { kind: 'agent', model: 'claude-haiku-5-5', effort: 'low' } })
    expect((await chess($)).seats.a).toEqual({ kind: 'agent', model: 'claude-haiku-5-5', effort: 'low', name: 'Haiku 5.5 · low' })
    await arcade($, { game: 'chess', action: 'seat', side: 'b', seat: { kind: 'human' } })
    await arcade($, { game: 'chess', action: 'reset' })
    const g = await chess($)
    expect(g.moves).toEqual([])
    expect(g.seats.b).toEqual({ kind: 'human' })
    expect(g.status).toBe('playing')
  })
})

describe('an agent at the table', () => {
  test('its move is one completion with the legal moves listed; an illegal answer is bounced back with the reason, then the legal one is played', async ($, on) => {
    // "Nc3" is a white move: not legal for black. (Nc6 would be, and would be played.)
    const { asked } = engine(on, ['Nc3? no wait: zz99', 'e7e5\nMirror the centre.'])
    await start($)
    await arcade($, { game: 'chess', action: 'seat', side: 'a', seat: { kind: 'human' } })
    await arcade($, { game: 'chess', action: 'seat', side: 'b', seat: { kind: 'agent', model: 'claude-sonnet-5-5', effort: 'high', name: 'Sonny' } })
    await arcade($, { game: 'chess', action: 'move', move: 'e4' })
    await tick($)
    const g = await chess($)
    expect(asked.length).toBe(2)
    expect(asked[0]).toMatchObject({ model: 'claude-sonnet-5-5', effort: 'high' })
    expect(asked[0]!.system).toContain('as Black')
    expect(asked[0]!.prompt).toContain('Legal moves (UCI):')
    expect(asked[0]!.prompt).toContain('e7e5')
    expect(asked[0]!.prompt).toContain('Moves so far: 1. e4')
    expect(asked[1]!.prompt).toContain('Your previous answer was refused')
    expect(g.moves).toEqual(['e2e4', 'e7e5'])
    expect(g.history).toEqual(['e4', 'e5'])
    expect(g.lastReply).toBe('Mirror the centre.')
    expect(g.error).toBe(null)
    expect(g.attempts).toBe(0)
    expect(g.thinking).toBe(null)
    expect(g.turn).toBe('a')
  })

  test('three answers without a legal move leave the game stuck, with the reason; retry runs it again', async ($, on) => {
    const { asked } = engine(on, ['a1a1', 'e2e4', '', 'e7e5'])
    await start($)
    await arcade($, { game: 'chess', action: 'seat', side: 'a', seat: { kind: 'human' } })
    await arcade($, { game: 'chess', action: 'seat', side: 'b', seat: { kind: 'agent', model: 'claude-haiku-5-5', effort: 'low' } })
    await arcade($, { game: 'chess', action: 'move', move: 'd4' })
    await tick($)
    let g = await chess($)
    expect(asked.length).toBe(3)
    expect(g.status).toBe('stuck')
    expect(g.error).toContain('no legal move in 3 tries')
    expect(g.moves).toEqual(['d2d4'])
    await tick($) // stuck: nothing starts
    expect(asked.length).toBe(3)
    await arcade($, { game: 'chess', action: 'retry' })
    await tick($)
    g = await chess($)
    expect(g.status).toBe('playing')
    expect(g.moves).toEqual(['d2d4', 'e7e5'])
  })

  test('two agents play each other to the end, and a finished game starts no move', async ($, on) => {
    // Fool's mate in four plies: white f3 g4, black e5 Qh4#.
    const { asked } = engine(on, ['f2f3', 'e7e5', 'g2g4', 'd8h4\nMate.'])
    await start($)
    await arcade($, { game: 'chess', action: 'seat', side: 'a', seat: { kind: 'agent', model: 'claude-haiku-5-5', effort: 'low' } })
    await arcade($, { game: 'chess', action: 'seat', side: 'b', seat: { kind: 'agent', model: 'claude-opus-5-5', effort: 'max' } })
    for (let i = 0; i < 6; i++) await tick($)
    const g = await chess($)
    expect(asked.length).toBe(4)
    expect(g.history).toEqual(['f3', 'e5', 'g4', 'Qh4#'])
    expect(g.status).toBe('over')
    expect(g.result).toBe('checkmate')
    expect(g.winner).toBe('b')
    expect(g.lastReply).toBe('Mate.')
  })

  test('tic-tac-toe: the person and an agent, squares by name; a win ends it', async ($, on) => {
    engine(on, ['c3\nCorner.', 'a3', 'b2'])
    await start($)
    await arcade($, { game: 'tictactoe', action: 'seat', side: 'a', seat: { kind: 'human' } })
    await arcade($, { game: 'tictactoe', action: 'seat', side: 'b', seat: { kind: 'agent', model: 'claude-fable-5-1', effort: 'medium' } })
    expect(await arcade($, { game: 'tictactoe', action: 'move', move: 'd9' })).toContain('not a legal move')
    await arcade($, { game: 'tictactoe', action: 'move', move: 'a1' })
    await tick($)
    let g = await ttt($)
    expect(g.history).toEqual(['Xa1', 'Oc3'])
    expect(g.lastReply).toBe('Corner.')
    await arcade($, { game: 'tictactoe', action: 'move', move: 'b1' })
    await tick($)
    await arcade($, { game: 'tictactoe', action: 'move', move: 'c1' })
    g = await ttt($)
    expect(g.status).toBe('over')
    expect(g.result).toBe('win')
    expect(g.winner).toBe('a')
    expect(g.legal).toEqual([])
  })
})
