// The arcade's rules: the chess move generator against the standard perft
// counts (which any castling, en passant, promotion or check mistake breaks),
// notation both ways, the game's results, and tic-tac-toe.

import { describe, expect, test } from 'claude-code/testing'

import { asciiBoard, initialState, legalMoves, parseFen, parseMove, perft, play, status, toFen, toSan, toUci } from '../src/arcade/chess'
import { tttAscii, tttInitial, tttLegalMoves, tttParseMove, tttPlay, tttStatus } from '../src/arcade/tictactoe'

const playAll = (sans: string[]) => sans.reduce((s, san) => {
  const m = parseMove(s, san)
  if (m === null) throw new Error(`${san} is not legal after ${s.history.join(' ')}`)
  return play(s, m)
}, initialState())

describe('chess: move generation', () => {
  test('the opening position has twenty moves, and the standard perft counts to depth 3', async () => {
    const s = initialState()
    expect(legalMoves(s).length).toBe(20)
    expect(perft(s, 2)).toBe(400)
    expect(perft(s, 3)).toBe(8902)
  })

  test('Kiwipete (castling both ways, en passant, promotions, checks): perft 48 and 2039', async () => {
    const s = parseFen('r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1')
    expect(perft(s, 1)).toBe(48)
    expect(perft(s, 2)).toBe(2039)
  })

  test('position 3 (en passant that exposes the king, promotions): perft 14, 191, 2812', async () => {
    const s = parseFen('8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1')
    expect(perft(s, 1)).toBe(14)
    expect(perft(s, 2)).toBe(191)
    expect(perft(s, 3)).toBe(2812)
  })

  test('position 4 (promotions with checks, castling rights lost by capture): perft 6, 264, 9467', async () => {
    const s = parseFen('r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1')
    expect(perft(s, 1)).toBe(6)
    expect(perft(s, 2)).toBe(264)
    expect(perft(s, 3)).toBe(9467)
  })

  test('FEN round-trips, with the en passant square and the clocks', async () => {
    const s = playAll(['e4', 'c5', 'Nf3'])
    expect(toFen(s)).toBe('rnbqkbnr/pp1ppppp/8/2p5/4P3/5N2/PPPP1PPP/RNBQKB1R b KQkq - 1 2')
    const e4 = play(initialState(), parseMove(initialState(), 'e2e4')!)
    expect(toFen(e4)).toBe('rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1')
  })
})

describe('chess: notation and legality', () => {
  test('UCI and SAN name the same moves; an illegal move is never found', async () => {
    const s = initialState()
    expect(toUci(parseMove(s, 'Nf3')!)).toBe('g1f3')
    expect(toSan(s, parseMove(s, 'g1f3')!)).toBe('Nf3')
    expect(parseMove(s, 'e5')).toBe(null) // not white's pawn
    expect(parseMove(s, 'Ke2')).toBe(null) // blocked
    expect(parseMove(s, 'e2e5')).toBe(null)
    expect(parseMove(s, 'Nf3!?')).not.toBe(null)
    expect(parseMove(s, 'xyz')).toBe(null)
  })

  test('castling, en passant and promotion read and write as SAN', async () => {
    let s = playAll(['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Nf6'])
    const castle = parseMove(s, 'O-O')!
    expect(castle.isCastle).toBe(true)
    s = play(s, castle)
    expect(s.history.at(-1)).toBe('O-O')
    expect(s.board[5]).toBe('R') // the rook came to f1
    expect(parseMove(s, '0-0')).toBe(null) // black has no castling move here (nothing between? the bishop is in the way)
    // En passant: after 1.e4 e5 2.Nf3 Nc6 3.Bc4 Nf6 4.O-O d5 5.exd5 ... set up a clean one instead.
    let ep = parseFen('rnbqkbnr/ppp1pppp/8/3pP3/8/8/PPPP1PPP/RNBQKBNR w KQkq d6 0 3')
    const take = parseMove(ep, 'exd6')!
    expect(take.isEnPassant).toBe(true)
    ep = play(ep, take)
    expect(ep.board[35]).toBe(null) // d5 pawn is gone
    expect(ep.history.at(-1)).toBe('exd6')
    // Promotion with check.
    let pr = parseFen('6k1/4P3/8/8/8/8/8/4K3 w - - 0 1')
    const promo = parseMove(pr, 'e8=Q')!
    expect(promo.promotion).toBe('q')
    pr = play(pr, promo)
    expect(pr.history.at(-1)).toBe('e8=Q+') // the new queen checks along the eighth rank
    expect(parseMove(parseFen('6k1/4P3/8/8/8/8/8/4K3 w - - 0 1'), 'e7e8')!.promotion).toBe('q') // UCI without the piece: a queen
    expect(parseMove(parseFen('6k1/4P3/8/8/8/8/8/4K3 w - - 0 1'), 'e8=N')!.promotion).toBe('n')
  })

  test('disambiguation names the file, the rank, or both', async () => {
    // Two rooks can reach d1: the file tells them apart. With the king between them, only one can, and nothing is added.
    const s = parseFen('4k3/8/8/8/8/8/8/R4RK1 w - - 0 1')
    expect(toSan(s, parseMove(s, 'a1d1')!)).toBe('Rad1')
    const blocked = parseFen('4k3/8/8/8/8/8/8/R3K2R w KQ - 0 1')
    expect(toSan(blocked, parseMove(blocked, 'a1d1')!)).toBe('Rd1')
    // Same file: the rank tells them apart.
    const t = parseFen('4k3/8/8/8/8/R7/8/R3K3 w - - 0 1')
    expect(toSan(t, parseMove(t, 'a1a2')!)).toBe('R1a2')
    const knights = parseFen('4k3/8/8/8/8/2N1N3/8/4K3 w - - 0 1')
    expect(toSan(knights, parseMove(knights, 'c3d5')!)).toBe('Ncd5')
    // Three queens on the same square: file and rank both needed for the one sharing both.
    const queens = parseFen('4k3/8/8/8/8/8/1Q1Q4/1Q2K3 w - - 0 1')
    expect(toSan(queens, parseMove(queens, 'b2c1')!)).toBe('Qb2c1')
  })
})

describe('chess: results', () => {
  test("fool's mate is checkmate for black; the history ends in #", async () => {
    const s = playAll(['f3', 'e5', 'g4', 'Qh4'])
    expect(status(s)).toEqual({ over: true, result: 'checkmate', winner: 'b' })
    expect(s.history.at(-1)).toBe('Qh4#')
    expect(legalMoves(s).length).toBe(0)
  })

  test('stalemate, the fifty-move rule, insufficient material and threefold repetition are draws', async () => {
    expect(status(parseFen('7k/5Q2/6K1/8/8/8/8/8 b - - 0 1'))).toEqual({ over: true, result: 'stalemate', winner: null })
    expect(status(parseFen('4k3/8/8/8/8/8/8/4K2R w K - 100 80'))).toEqual({ over: true, result: 'fifty-move', winner: null })
    expect(status(parseFen('4k3/8/8/8/8/8/8/4KB2 w - - 0 1'))).toEqual({ over: true, result: 'material', winner: null })
    const shuffle = playAll(['Nf3', 'Nf6', 'Ng1', 'Ng8', 'Nf3', 'Nf6', 'Ng1', 'Ng8'])
    expect(status(shuffle)).toEqual({ over: true, result: 'repetition', winner: null })
  })

  test('check is reported, and a move that leaves the king in check is not offered', async () => {
    const s = parseFen('4k3/8/8/8/8/8/4r3/4K3 w - - 0 1')
    expect(status(s)).toEqual({ over: false, inCheck: true })
    expect(legalMoves(s).map(toUci).sort()).toEqual(['e1d1', 'e1e2', 'e1f1'])
    expect(asciiBoard(s).split('\n')[0]).toBe('8  . . . . k . . .')
  })
})

describe('tic-tac-toe', () => {
  test('X first; squares by name or number; a taken square is illegal; three in a row wins; a full board draws', async () => {
    let s = tttInitial()
    expect(tttLegalMoves(s).length).toBe(9)
    expect(tttParseMove(s, 'b2')).toBe(4)
    expect(tttParseMove(s, '5')).toBe(4)
    s = tttPlay(s, 4)
    expect(tttParseMove(s, 'b2')).toBe(-1)
    expect(s.turn).toBe('o')
    for (const m of [0, 1, 8, 2]) s = tttPlay(s, m) // O a3, X b3, O c1, X c3 -> X has b3? no: X b2, c3, b3 -> not a line yet
    expect(tttStatus(s)).toEqual({ over: false })
    s = tttPlay(s, 6) // O a1
    s = tttPlay(s, 7) // X b1: b1, b2, b3 column
    expect(tttStatus(s)).toEqual({ over: true, winner: 'x' })
    expect(tttLegalMoves(s)).toEqual([])
    expect(s.history).toEqual(['Xb2', 'Oa3', 'Xb3', 'Oc1', 'Xc3', 'Oa1', 'Xb1'])
    expect(tttAscii(s).split('\n')[0]).toBe('3  O X X')
    let d = tttInitial()
    for (const m of [0, 1, 2, 4, 3, 5, 7, 6, 8]) d = tttPlay(d, m)
    expect(tttStatus(d)).toEqual({ over: true, winner: null })
  })
})
