// Bones (Knucklebones): the seed and its deterministic rolls, placement and
// full columns, scoring with doubles and triples, knocking out the opponent's
// matching dice, the end of the game and its result, the forgiving parser,
// replay, the model's prompt and the window's view of the position.

import { describe, expect, test } from 'claude-code/testing'

import { GAME, columnScore, parseSeed, rolls, type BonesState, type BonesView } from '../src/arcade/bones'

const seedOf = (n: number) => `seed:${n}`
/** The game after the seed `n` and the given column letters. */
const after = (n: number, moves: string): BonesState => GAME.replay([seedOf(n), ...(moves === '' ? [] : moves.split(' '))])
const view = (s: BonesState) => GAME.out(s) as BonesView
/** An independent scorer, to check the engine's against. */
const score = (grid: number[][]) => grid.reduce((t, col) => t + col.reduce((c, d) => c + d * col.filter(x => x === d).length, 0), 0)

/** The first seed (from 1) whose first rolls satisfy `wanted`, searching up to `limit` seeds. */
function seedWhere(count: number, wanted: (r: number[]) => boolean, limit = 200000): number {
  for (let seed = 1; seed <= limit; seed++) if (wanted(rolls(seed, count))) return seed
  throw new Error('no seed found')
}

/** Plays the first legal column every turn until the game ends. */
function playOut(s: BonesState, cap = 200): BonesState {
  for (let i = 0; i < cap && !GAME.status(s).over; i++) s = GAME.play(s, GAME.legal(s)[0]!)
  return s
}

describe('bones: the seed and its rolls', () => {
  test('the module describes itself as rules.ts asks', async () => {
    expect(GAME.kind).toBe('bones')
    expect(GAME.title).toBe('Bones')
    expect(GAME.sides).toEqual({ a: 'Player 1', b: 'Player 2' })
    expect(typeof GAME.seedMove).toBe('function')
  })

  test('before the seed there is no roll and nothing is legal', async () => {
    const s = GAME.initial()
    expect(s.roll).toBe(null)
    expect(s.seed).toBe(null)
    expect(GAME.turn(s)).toBe('a')
    expect(GAME.legal(s)).toEqual([])
    expect(GAME.parse(s, 'a')).toBe(null)
    expect(() => GAME.play(s, 'a')).toThrow()
    expect(GAME.status(s)).toEqual({ over: false })
    expect(view(s).roll).toBe(null)
  })

  test('seedMove gives seed:<digits> within 32 bits, and parseSeed reads it back', async () => {
    for (let i = 0; i < 20; i++) {
      const m = GAME.seedMove!()
      expect(/^seed:\d+$/.test(m)).toBe(true)
      const n = parseSeed(m)!
      expect(n).toBe(Number(m.slice(5)))
      expect(n >= 0 && n < 4294967296).toBe(true)
    }
    expect(parseSeed('seed:0')).toBe(0)
    expect(parseSeed(' seed:42 ')).toBe(42)
    expect(parseSeed('seed:99999999999')).toBe(99999999999 >>> 0)
    expect(parseSeed('a')).toBe(null)
    expect(parseSeed('seed:')).toBe(null)
    expect(parseSeed('seed:12x')).toBe(null)
  })

  test('the seed move rolls the first die for Player 1 and opens all three columns', async () => {
    const s = GAME.replay([seedOf(7)])
    expect(s.seed).toBe(7)
    expect(s.roll).toBe(rolls(7, 1)[0])
    expect(s.roll! >= 1 && s.roll! <= 6).toBe(true)
    expect(GAME.turn(s)).toBe('a')
    expect(GAME.legal(s)).toEqual(['a', 'b', 'c'])
    expect(GAME.play(GAME.initial(), 'seed:7')).toEqual(s)
    expect(() => GAME.play(s, 'seed:8')).toThrow() // one seed per game
  })

  test('rolls are deterministic for a seed, in 1..6, and differ between seeds', async () => {
    expect(rolls(123, 12)).toEqual(rolls(123, 12))
    expect(rolls(123, 30).every(r => r >= 1 && r <= 6 && Number.isInteger(r))).toBe(true)
    expect(rolls(123, 20)).not.toEqual(rolls(124, 20))
    expect(rolls(1, 20)).not.toEqual(rolls(2, 20))
    const counts = new Array(7).fill(0)
    for (const r of rolls(99, 6000)) counts[r]++
    for (let face = 1; face <= 6; face++) expect(counts[face] > 800 && counts[face] < 1200).toBe(true)
  })

  test('the same move list always gives the same game, and a different seed a different one', async () => {
    const moves = [seedOf(31), 'a', 'b', 'c', 'a', 'b', 'c']
    const s1 = GAME.replay(moves)
    const s2 = GAME.replay(moves)
    expect(s1).toEqual(s2)
    expect(GAME.history(s1)).toEqual(GAME.history(s2))
    const dice = (s: BonesState) => s.plays.map(p => p.die)
    expect(dice(s1)).toEqual(rolls(31, 6))
    expect(dice(GAME.replay([seedOf(32), 'a', 'b', 'c', 'a', 'b', 'c']))).toEqual(rolls(32, 6))
    expect(rolls(31, 6)).not.toEqual(rolls(32, 6))
  })

  test('each placement takes the next roll of the stream, whichever column it goes to', async () => {
    const seed = 555
    const want = rolls(seed, 5)
    let s = GAME.replay([seedOf(seed)])
    const cols = ['c', 'a', 'b', 'b', 'c']
    for (let i = 0; i < cols.length; i++) {
      expect(s.roll).toBe(want[i])
      s = GAME.play(s, cols[i]!)
      expect(s.plays[i]).toEqual({ side: i % 2 === 0 ? 'a' : 'b', column: cols[i], die: want[i] })
    }
    expect(s.roll).toBe(rolls(seed, 6)[5])
  })
})

describe('bones: placing dice', () => {
  // Six distinct first rolls: nothing matches, so no die is knocked out while the columns fill.
  const distinct = () => seedWhere(6, r => new Set(r).size === 6)

  test('Player 1 moves first, the sides alternate, and a die lands in the mover\'s own grid', async () => {
    const seed = distinct()
    const s1 = after(seed, 'b')
    expect(GAME.turn(s1)).toBe('b')
    expect(s1.grids.a[1]).toEqual([rolls(seed, 1)[0]])
    expect(s1.grids.b).toEqual([[], [], []])
    const s2 = GAME.play(s1, 'b')
    expect(GAME.turn(s2)).toBe('a')
    expect(s2.grids.b[1]).toEqual([rolls(seed, 2)[1]])
    expect(s2.grids.a[1]).toEqual([rolls(seed, 1)[0]]) // a different value, so it stays
  })

  test('a column fills bottom-first and a full column is no longer legal', async () => {
    const seed = distinct()
    const r = rolls(seed, 6)
    const s = after(seed, 'a c a c a c')
    expect(s.grids.a[0]).toEqual([r[0], r[2], r[4]])
    expect(s.grids.b[2]).toEqual([r[1], r[3], r[5]])
    expect(GAME.legal(s)).toEqual(['b', 'c']) // Player 1's column a is full
    expect(() => GAME.play(s, 'a')).toThrow()
    expect(GAME.parse(s, 'a')).toBe(null)
    const t = GAME.play(s, 'b') // Player 2's column c is full
    expect(GAME.legal(t)).toEqual(['a', 'b'])
  })

  test('play leaves the given state alone', async () => {
    const s = after(5, 'a')
    const copy = JSON.parse(JSON.stringify(s))
    GAME.play(s, 'b')
    expect(JSON.parse(JSON.stringify(s))).toEqual(copy)
  })

  test('play takes only the letters legal lists', async () => {
    const s = after(5, '')
    expect(() => GAME.play(s, 'd')).toThrow()
    expect(() => GAME.play(s, '1')).toThrow()
    expect(() => GAME.play(s, 'A')).toThrow()
  })
})

describe('bones: scoring', () => {
  test('columnScore sums distinct dice and multiplies matches', async () => {
    expect(columnScore([])).toBe(0)
    expect(columnScore([5])).toBe(5)
    expect(columnScore([1, 2, 3])).toBe(6)
    expect(columnScore([4, 4])).toBe(16)
    expect(columnScore([4, 4, 4])).toBe(36)
    expect(columnScore([5, 5, 2])).toBe(22)
    expect(columnScore([6, 6, 6])).toBe(54)
    expect(columnScore([1, 1, 1])).toBe(9)
  })

  test('a double in a column scores through the engine', async () => {
    // Player 1 rolls the same value twice; Player 2's rolls differ from it, so nothing is knocked out.
    const seed = seedWhere(4, r => r[0] === r[2] && r[1] !== r[0] && r[3] !== r[0])
    const v = rolls(seed, 1)[0]!
    const s = after(seed, 'b c b c')
    expect(s.grids.a[1]).toEqual([v, v])
    const g = view(s)
    expect(g.columnScores.a).toEqual([0, 4 * v, 0])
    expect(g.scores.a).toBe(4 * v)
    expect(g.scores.b).toBe(score(s.grids.b))
  })

  test('a triple in a column scores nine times the die', async () => {
    const seed = seedWhere(6, r => r[0] === r[2] && r[2] === r[4] && r[1] !== r[0] && r[3] !== r[0] && r[5] !== r[0])
    const v = rolls(seed, 1)[0]!
    const s = after(seed, 'a c a c a c')
    expect(s.grids.a[0]).toEqual([v, v, v])
    expect(view(s).columnScores.a[0]).toBe(9 * v)
    expect(view(s).scores.a).toBe(9 * v)
  })

  test('the total is the sum of the column scores, as an independent scorer agrees', async () => {
    const s = playOut(after(2024, ''))
    const g = view(s)
    expect(g.scores.a).toBe(score(s.grids.a))
    expect(g.scores.b).toBe(score(s.grids.b))
    expect(g.columnScores.a.reduce((x, y) => x + y, 0)).toBe(g.scores.a)
    expect(g.columnScores.b.reduce((x, y) => x + y, 0)).toBe(g.scores.b)
  })
})

describe('bones: knocking dice out', () => {
  // P1 4→a, P2 x→c, P1 2→a, P2 y→c, P1 4→b, P2 4→a: P2's 4 knocks P1's 4 out of column a, and nothing else.
  const setup = () => {
    const seed = seedWhere(6, r => r[0] === 4 && r[1] !== 4 && r[2] === 2 && r[3] !== 4 && r[4] === 4 && r[5] === 4)
    return { seed, r: rolls(seed, 6) }
  }

  test('placing a die removes the opponent\'s matching dice in that column, and only those', async () => {
    const { seed, r } = setup()
    const before = after(seed, 'a c a c b')
    expect(before.grids.a).toEqual([[4, 2], [4], []])
    expect(before.grids.b).toEqual([[], [], [r[1], r[3]]])
    expect(before.roll).toBe(4)
    const s = GAME.play(before, 'a')
    expect(s.grids.a).toEqual([[2], [4], []]) // the 4 in a is gone; the 2 in a and the 4 in b stay
    expect(s.grids.b).toEqual([[4], [], [r[1], r[3]]])
    expect(s.removed).toEqual({ column: 'a', values: [4] })
    expect(view(s).removed).toEqual({ column: 'a', values: [4] })
    expect(view(s).lastMove).toEqual({ side: 'b', column: 'a', die: 4 })
    expect(view(s).scores.a).toBe(2 + 4)
  })

  test('a knocked-out column has room again', async () => {
    const { seed } = setup()
    const s = GAME.play(after(seed, 'a c a c b'), 'a')
    expect(s.grids.a[0]!.length).toBe(1)
    expect(GAME.legal(s)).toEqual(['a', 'b', 'c'])
  })

  test('removed is null when a placement knocks nothing out, and removes every matching die at once', async () => {
    const { seed } = setup()
    expect(after(seed, 'a c').removed).toBe(null) // P2's first die went to an empty-opposite column
    // P1 places two 4s in a (a double), then P2 places a 4 in a: both go.
    const seed2 = seedWhere(4, r => r[0] === 4 && r[1] !== 4 && r[2] === 4 && r[3] === 4)
    const s = after(seed2, 'a c a a')
    expect(s.grids.a[0]).toEqual([])
    expect(s.grids.b[0]).toEqual([4])
    expect(s.removed).toEqual({ column: 'a', values: [4, 4] })
    expect(view(s).scores.a).toBe(0)
  })
})

describe('bones: the end of the game', () => {
  test('the game ends as soon as either grid is full, with the higher total winning', async () => {
    let s = after(77, '')
    let steps = 0
    while (!GAME.status(s).over) {
      expect(GAME.legal(s).length > 0).toBe(true)
      s = GAME.play(s, GAME.legal(s)[0]!)
      if (++steps > 200) throw new Error('the game did not end')
    }
    const full = (g: number[][]) => g.reduce((n, c) => n + c.length, 0) === 9
    expect(full(s.grids.a) || full(s.grids.b)).toBe(true)
    const a = score(s.grids.a)
    const b = score(s.grids.b)
    const st = GAME.status(s)
    if (a === b) expect(st).toEqual({ over: true, winner: null, result: 'draw' })
    else expect(st).toEqual({ over: true, winner: a > b ? 'a' : 'b', result: 'full board' })
    expect(s.roll).toBe(null)
    expect(GAME.legal(s)).toEqual([])
    expect(GAME.parse(s, 'a')).toBe(null)
    expect(() => GAME.play(s, 'a')).toThrow()
    expect(view(s).roll).toBe(null)
  })

  test('the game does not end while both grids have room', async () => {
    const s = after(77, 'a b c a b c a b c a b c a b c a') // 8 dice placed each side at most
    expect(GAME.status(s)).toEqual({ over: false })
  })

  test('both winners happen across seeds, and the loser\'s full grid ends it too', async () => {
    const winners = new Set<string>()
    for (let seed = 1; seed <= 60; seed++) {
      const s = playOut(after(seed, ''))
      const st = GAME.status(s)
      expect(st.over).toBe(true)
      if (st.over && st.winner !== null) {
        winners.add(st.winner)
        expect(st.result).toBe('full board')
        expect(score(s.grids[st.winner]) > score(s.grids[st.winner === 'a' ? 'b' : 'a'])).toBe(true)
      }
    }
    expect(winners.has('a')).toBe(true)
    expect(winners.has('b')).toBe(true)
  })

  test('equal totals on a full grid are a draw', async () => {
    let found: BonesState | null = null
    for (let seed = 1; seed <= 100000 && found === null; seed++) {
      const s = playOut(after(seed, ''))
      if (score(s.grids.a) === score(s.grids.b)) found = s
    }
    expect(found).not.toBe(null)
    expect(GAME.status(found!)).toEqual({ over: true, winner: null, result: 'draw' })
    expect(GAME.ascii(found!)).toContain('a draw')
  })
})

describe('bones: parsing answers', () => {
  const s = after(9, '')

  test('the column letter, in any case, with spaces, a col/column prefix or trailing punctuation', async () => {
    for (const text of ['b', 'B', ' b ', 'b.', 'b!', 'col b', 'column b', 'Column B', 'col: b', 'column b.', '"b"', '(b)', '`b`', '**b**', 'b\nbecause the double scores', '\n\nb\n'])
      expect(GAME.parse(s, text)).toBe('b')
    expect(GAME.parse(s, 'A')).toBe('a')
    expect(GAME.parse(s, 'c,')).toBe('c')
  })

  test('the column\'s number, 1 to 3', async () => {
    expect(GAME.parse(s, '1')).toBe('a')
    expect(GAME.parse(s, '2')).toBe('b')
    expect(GAME.parse(s, 'column 3')).toBe('c')
  })

  test('nonsense, other letters, a full column and the seed move are refused', async () => {
    for (const text of ['', 'd', 'ab', 'a or b', 'the middle one', '4', '0', 'seed:5', 'column', 'bb', 'b4'])
      expect(GAME.parse(s, text)).toBe(null)
    const seed = seedWhere(6, r => new Set(r).size === 6)
    const full = after(seed, 'a c a c a c')
    expect(GAME.parse(full, 'a')).toBe(null)
    expect(GAME.parse(full, 'column a')).toBe(null)
    expect(GAME.parse(full, 'b')).toBe('b')
  })

  test('parse never returns a move legal leaves out', async () => {
    let t = after(13, '')
    for (let i = 0; i < 40 && !GAME.status(t).over; i++) {
      for (const text of ['a', 'b', 'c', 'A', 'col b', '1', '2', '3']) {
        const m = GAME.parse(t, text)
        if (m !== null) expect(GAME.legal(t)).toContain(m)
      }
      t = GAME.play(t, GAME.legal(t)[0]!)
    }
  })
})

describe('bones: replay', () => {
  test('replay of a state\'s own moves gives the state back', async () => {
    const s = after(21, 'a b c c b a a')
    expect(GAME.replay(s.moves)).toEqual(s)
    expect(s.moves).toEqual([seedOf(21), 'a', 'b', 'c', 'c', 'b', 'a', 'a'])
  })

  test('replay of nothing is the initial state, and a first move that is not a seed stops it', async () => {
    expect(GAME.replay([])).toEqual(GAME.initial())
    const s = GAME.replay(['a', 'b'])
    expect(s).toEqual(GAME.initial())
    expect(s.plays).toEqual([])
  })

  test('replay stops at the first bad move and keeps what came before', async () => {
    const seed = seedWhere(6, r => new Set(r).size === 6)
    const good = after(seed, 'a c a c a c')
    const s = GAME.replay([seedOf(seed), 'a', 'c', 'a', 'c', 'a', 'c', 'a', 'b', 'b']) // Player 1's a is full
    expect(s).toEqual(good)
    expect(s.plays.length).toBe(6)
    const t = GAME.replay([seedOf(seed), 'a', 'x', 'b'])
    expect(t.plays.length).toBe(1)
    expect(GAME.turn(t)).toBe('b')
  })

  test('replay reads stored moves forgivingly, as parse does', async () => {
    expect(GAME.replay([seedOf(3), 'A', 'col b', '3'])).toEqual(after(3, 'a b c'))
  })

  test('a second seed move in the list is a bad move', async () => {
    const s = GAME.replay([seedOf(3), 'a', 'seed:4', 'b'])
    expect(s.plays.length).toBe(1)
    expect(s.seed).toBe(3)
  })
})

describe('bones: history and ascii', () => {
  test('history lists each turn as side, column and die', async () => {
    const seed = 42
    const r = rolls(seed, 3)
    const s = after(seed, 'b a c')
    expect(GAME.history(s)).toEqual([`P1 b:${r[0]}`, `P2 a:${r[1]}`, `P1 c:${r[2]}`])
    expect(GAME.history(GAME.initial())).toEqual([])
    expect(GAME.history(after(seed, ''))).toEqual([]) // the seed is not a turn
  })

  test('ascii shows both grids, the dice, column scores, totals and the roll', async () => {
    const seed = seedWhere(4, r => r[0] === r[2] && r[1] !== r[0] && r[3] !== r[0])
    const v = rolls(seed, 1)[0]!
    const s = after(seed, 'b c b c')
    const text = GAME.ascii(s)
    expect(text).toContain('Player 1 (P1)')
    expect(text).toContain('Player 2 (P2)')
    expect(text).toContain(`total ${4 * v}`)
    expect(text).toContain(`total ${score(s.grids.b)}`)
    expect(text).toContain('a  b  c')
    expect(text).toContain(`score  0 ${String(4 * v).padStart(2)}  0`)
    expect(text).toContain(`Player 1 (P1) to move, rolled a ${s.roll}.`)
    expect(GAME.ascii(GAME.initial())).toContain('No die rolled yet.')
    const over = playOut(after(77, ''))
    expect(GAME.ascii(over)).toContain('Game over')
  })
})

describe('bones: the prompt', () => {
  test('the system text states the rules and the answer format', async () => {
    const { system } = GAME.prompt(after(9, ''), 'a', null)
    expect(system).toContain('Knucklebones')
    expect(system).toContain('three columns')
    expect(system).toContain('multiply')
    expect(system).toContain('removes every die of the same value')
    expect(system).toContain('either grid is full')
    expect(system).toContain('column letter alone on the first line')
    expect(system).toContain('one short line of reasoning')
  })

  test('the prompt names the side, both grids, the moves, the roll and the legal columns', async () => {
    const seed = 9
    const s = after(seed, 'a b')
    const { prompt } = GAME.prompt(s, 'a', null)
    expect(prompt).toContain('You are Player 1 (P1).')
    expect(prompt).toContain('Player 2 (P2)')
    expect(prompt).toContain(`Moves so far: ${GAME.history(s).join(', ')}`)
    expect(prompt).toContain("It is Player 1's turn (yours).")
    expect(prompt).toContain(`The die rolled for this turn: ${s.roll}.`)
    expect(prompt).toContain('Legal columns: a, b, c')
    expect(prompt).not.toContain('refused')
    expect(prompt.trim().endsWith('Your move:')).toBe(true)
    const theirs = GAME.prompt(s, 'b', null).prompt
    expect(theirs).toContain('You are Player 2 (P2).')
    expect(theirs).toContain("It is Player 1's turn.")
  })

  test('the prompt lists only columns with room, and says (none) before any move', async () => {
    const seed = seedWhere(6, r => new Set(r).size === 6)
    const s = after(seed, 'a c a c a c')
    expect(GAME.prompt(s, 'a', null).prompt).toContain('Legal columns: b, c')
    expect(GAME.prompt(after(seed, ''), 'a', null).prompt).toContain('Moves so far: (none)')
  })

  test('the prompt carries the refusal note when given', async () => {
    const { prompt } = GAME.prompt(after(9, ''), 'a', 'not a column letter.')
    expect(prompt).toContain('Your previous answer was refused: not a column letter. Choose from the legal columns above.')
  })
})

describe('bones: the window\'s view', () => {
  test('out has the right shape, bottom-first grids and copies of the state', async () => {
    const seed = 15
    const s = after(seed, 'a a b')
    const g = view(s)
    expect(Object.keys(g).sort()).toEqual(['columnScores', 'grids', 'lastMove', 'removed', 'roll', 'scores'])
    expect(g.grids.a.length).toBe(3)
    expect(g.grids.b.length).toBe(3)
    expect(g.grids.a).toEqual(s.grids.a)
    expect(g.grids.b).toEqual(s.grids.b)
    expect(g.columnScores.a.length).toBe(3)
    expect(g.columnScores.b.length).toBe(3)
    expect(g.roll).toBe(s.roll)
    expect(g.lastMove).toEqual({ side: 'a', column: 'b', die: rolls(seed, 3)[2] })
    expect(g.removed === null || (typeof g.removed.column === 'string' && Array.isArray(g.removed.values))).toBe(true)
    g.grids.a[0]!.push(6)
    expect(s.grids.a[0]!.length).toBe(1)
    expect(JSON.parse(JSON.stringify(g))).toEqual(g)
  })

  test('out before any move has empty grids, zero scores and no last move', async () => {
    expect(view(GAME.initial())).toEqual({
      grids: { a: [[], [], []], b: [[], [], []] },
      scores: { a: 0, b: 0 },
      columnScores: { a: [0, 0, 0], b: [0, 0, 0] },
      roll: null,
      lastMove: null,
      removed: null,
    })
    const seeded = view(after(5, ''))
    expect(seeded.roll).toBe(rolls(5, 1)[0])
    expect(seeded.lastMove).toBe(null)
  })
})
