// Checkers: the rules the arcade enforces, from the opening position through
// mandatory and multiple captures, crowning, kings, the ends of a game, the
// forgiving reading of a model's answer, and the shapes the window and the
// model are given.

import { describe, expect, test } from 'claude-code/testing'

import {
  GAME, ascii, history, initial, legalMoves, mustCapture, numberedSquare, out, parse, play, position, prompt, replay, squareIndex, squareName, squareNumber, status,
} from '../src/arcade/checkers'

const sorted = (xs: string[]) => [...xs].sort()
const count = (cells: (string | null)[], side: 'a' | 'b') => cells.filter(c => c !== null && c.toLowerCase() === side).length
const throws = (f: () => unknown): boolean => {
  try {
    f()
    return false
  } catch {
    return true
  }
}

describe('checkers: the board and the opening', () => {
  test('twelve men each on the dark squares; Black at the top, Red at the bottom, Black to move', async () => {
    const s = initial()
    expect(count(s.cells, 'a')).toBe(12)
    expect(count(s.cells, 'b')).toBe(12)
    expect(s.cells[squareIndex('a1')]).toBe('b')
    expect(s.cells[squareIndex('h8')]).toBe('a')
    expect(s.cells[squareIndex('a8')]).toBe(null) // a light square
    expect(s.cells[squareIndex('b2')]).toBe('b')
    expect(s.cells[squareIndex('d4')]).toBe(null)
    expect(s.cells.filter((c, i) => c !== null && (i % 8 + Math.floor(i / 8)) % 2 !== 0).length).toBe(0)
    expect(s.turn).toBe('a')
    expect(status(s)).toEqual({ over: false })
  })

  test('Black has seven opening moves, then Red has seven', async () => {
    const s = initial()
    expect(sorted(legalMoves(s))).toEqual(['b6-a5', 'b6-c5', 'd6-c5', 'd6-e5', 'f6-e5', 'f6-g5', 'h6-g5'])
    expect(mustCapture(s)).toBe(false)
    const t = play(s, 'f6-e5')
    expect(t.turn).toBe('b')
    expect(sorted(legalMoves(t))).toEqual(['a3-b4', 'c3-b4', 'c3-d4', 'e3-d4', 'e3-f4', 'g3-f4', 'g3-h4'])
  })

  test('square names, indices and the standard 1–32 numbering agree', async () => {
    expect(squareName(0)).toBe('a1')
    expect(squareName(63)).toBe('h8')
    expect(squareIndex('h1')).toBe(7)
    expect(squareIndex('a8')).toBe(56)
    expect(squareIndex('i9')).toBe(-1)
    expect(squareIndex('a')).toBe(-1)
    expect(squareNumber(squareIndex('b8'))).toBe(1)
    expect(squareNumber(squareIndex('h8'))).toBe(4)
    expect(squareNumber(squareIndex('a7'))).toBe(5)
    expect(squareNumber(squareIndex('a1'))).toBe(29)
    expect(squareNumber(squareIndex('g1'))).toBe(32)
    expect(squareNumber(squareIndex('a8'))).toBe(-1)
    for (let n = 1; n <= 32; n++) expect(squareNumber(numberedSquare(n))).toBe(n)
    expect(numberedSquare(0)).toBe(-1)
    expect(numberedSquare(33)).toBe(-1)
  })

  test('ascii draws rank 8 first with men, kings, dots on empty dark squares and the files below', async () => {
    const rows = ascii(initial()).split('\n')
    expect(rows.length).toBe(9)
    expect(rows[0]).toBe('8    b   b   b   b')
    expect(rows[1]).toBe('7  b   b   b   b  ')
    expect(rows[3]).toBe('5  .   .   .   .  ')
    expect(rows[4]).toBe('4    .   .   .   .')
    expect(rows[7]).toBe('1  r   r   r   r  ')
    expect(rows[8]).toBe('   a b c d e f g h')
    const kings = ascii(position('Kb8 / Kg1')).split('\n')
    expect(kings[0]).toBe('8    B   .   .   .')
    expect(kings[7]).toBe('1  .   .   .   R  ')
  })
})

describe('checkers: men and kings', () => {
  test('a man moves one square diagonally forward only', async () => {
    expect(sorted(legalMoves(position('d4 /')))).toEqual(['d4-c3', 'd4-e3'])
    expect(sorted(legalMoves(position('/ e3', 'b')))).toEqual(['e3-d4', 'e3-f4'])
    expect(legalMoves(position('d4 / e3', 'b'))).toEqual(['e3xc5']) // the Black man ahead must be taken
    expect(sorted(legalMoves(position('a5 /')))).toEqual(['a5-b4'])
    expect(parse(position('d4 /'), 'd4-c5')).toBe(null)
    expect(parse(position('d4 /'), 'd4-e5')).toBe(null)
  })

  test('a man does not capture backwards; a king captures in all four directions', async () => {
    // A Red man sits behind the Black man: no capture, so the simple moves stand.
    expect(sorted(legalMoves(position('d4 / e5')))).toEqual(['d4-c3', 'd4-e3'])
    // The same square with a king on it: the backward jump is the only legal move.
    expect(legalMoves(position('Kd4 / e5'))).toEqual(['d4xf6'])
    expect(sorted(legalMoves(position('Kd4 / c5 e3', 'a')))).toEqual(['d4xb6', 'd4xf2'])
    expect(sorted(legalMoves(position('Kd4 /')))).toEqual(['d4-c3', 'd4-c5', 'd4-e3', 'd4-e5'])
  })

  test('a man reaching the far rank is crowned and its move ends there, even with a jump still open', async () => {
    // e3 jumps d2 to c1, where a king could go on over b2 to a3; the crowning ends the move.
    const s = position('e3 / d2 b2')
    expect(legalMoves(s)).toEqual(['e3xc1'])
    const t = play(s, 'e3xc1')
    expect(t.cells[squareIndex('c1')]).toBe('A')
    expect(t.cells[squareIndex('d2')]).toBe(null)
    expect(t.cells[squareIndex('b2')]).toBe('b')
    expect(t.turn).toBe('b')
    expect(t.quiet).toBe(0)
    expect(status(t)).toEqual({ over: false })
    // Red moves; then the new king takes the jump it was denied.
    const u = play(t, 'b2-a3')
    expect(sorted(legalMoves(u))).toEqual(['c1-b2', 'c1-d2'])
    const r = position('d2 / ', 'a')
    expect(sorted(legalMoves(r))).toEqual(['d2-c1', 'd2-e1'])
    expect(play(r, 'd2-c1').cells[squareIndex('c1')]).toBe('A')
    const red = position('/ c7', 'b')
    expect(sorted(legalMoves(red))).toEqual(['c7-b8', 'c7-d8'])
    expect(play(red, 'c7-b8').cells[squareIndex('b8')]).toBe('B')
  })
})

describe('checkers: captures', () => {
  test('a capture is mandatory: it excludes every simple move, and the other pieces stay put', async () => {
    const s = position('d4 h6 / c3')
    expect(legalMoves(s)).toEqual(['d4xb2'])
    expect(mustCapture(s)).toBe(true)
    expect(parse(s, 'h6-g5')).toBe(null)
    expect(parse(s, 'd4-e3')).toBe(null)
    const t = play(s, 'd4xb2')
    expect(t.cells[squareIndex('c3')]).toBe(null)
    expect(t.cells[squareIndex('b2')]).toBe('a')
    expect(t.cells[squareIndex('d4')]).toBe(null)
    expect(t.quiet).toBe(0)
  })

  test('a jump goes on while it can: only the complete sequence is legal, as one move string', async () => {
    const s = position('d6 / c5 c3')
    expect(legalMoves(s)).toEqual(['d6xb4xd2'])
    expect(parse(s, 'd6xb4')).toBe(null)
    const t = play(s, 'd6xb4xd2')
    expect(t.cells[squareIndex('d6')]).toBe(null)
    expect(t.cells[squareIndex('c5')]).toBe(null)
    expect(t.cells[squareIndex('b4')]).toBe(null)
    expect(t.cells[squareIndex('c3')]).toBe(null)
    expect(t.cells[squareIndex('d2')]).toBe('a')
    expect(history(t)).toEqual(['B d6xb4xd2'])
  })

  test('a shorter branch is legal when it is complete: no obligation to take the most pieces', async () => {
    const s = position('d6 / c5 c3 e5')
    expect(sorted(legalMoves(s))).toEqual(['d6xb4xd2', 'd6xf4'])
    expect(play(s, 'd6xf4').cells[squareIndex('c5')]).toBe('b')
  })

  test('a man keeps jumping forward only, past an enemy it could not take backwards', async () => {
    expect(legalMoves(position('f6 / e5 e3 c5'))).toEqual(['f6xd4xf2'])
  })

  test('a king may circle back onto the square it left, taking everything on the way', async () => {
    const s = position('Kd4 / c5 e5 c7 e7')
    expect(sorted(legalMoves(s))).toEqual(['d4xb6xd8xf6xd4', 'd4xf6xd8xb6xd4'])
    const t = play(s, 'd4xf6xd8xb6xd4')
    expect(count(t.cells, 'b')).toBe(0)
    expect(t.cells[squareIndex('d4')]).toBe('A')
    expect(status(t)).toEqual({ over: true, winner: 'a', result: 'no moves' })
  })

  test('a piece already jumped is not jumped twice', async () => {
    // The king at d4 can take e5 to f6; from f6 the only enemy is the one it just jumped.
    expect(legalMoves(position('Kd4 / e5'))).toEqual(['d4xf6'])
  })
})

describe('checkers: the end of a game', () => {
  test('a side with no pieces has lost', async () => {
    const s = position('/ a3', 'a')
    expect(status(s)).toEqual({ over: true, winner: 'b', result: 'no moves' })
    expect(legalMoves(s)).toEqual([])
    expect(parse(s, 'a3-b4')).toBe(null)
    const t = play(position('d4 / c3'), 'd4xb2')
    expect(status(t)).toEqual({ over: true, winner: 'a', result: 'no moves' })
    expect(GAME.legal(t)).toEqual([])
  })

  test('a side whose every piece is blocked has lost', async () => {
    const s = position('b2 / a1 c1 d2 b4 d4', 'a')
    expect(status(s)).toEqual({ over: true, winner: 'b', result: 'no moves' })
    expect(status(position('b2 / a1 c1 d2 b4 d4', 'b')).over).toBe(false)
  })

  test('fifty consecutive moves without a capture or a crowning draw the game', async () => {
    let s = position('Kb8 / Kg1')
    const shuffle = ['b8-a7', 'g1-h2', 'a7-b8', 'h2-g1']
    for (let i = 0; i < 49; i++) s = play(s, shuffle[i % 4]!)
    expect(s.quiet).toBe(49)
    expect(status(s)).toEqual({ over: false })
    s = play(s, shuffle[49 % 4]!)
    expect(s.quiet).toBe(50)
    expect(status(s)).toEqual({ over: true, winner: null, result: 'fifty-move' })
    expect(legalMoves(s)).toEqual([])
    expect(parse(s, 'h2-g1')).toBe(null)
  })

  test('a capture or a crowning resets the quiet count', async () => {
    const capture = play(position('Kd4 / e5 Kh8', 'a', 49), 'd4xf6')
    expect(capture.quiet).toBe(0)
    expect(status(capture)).toEqual({ over: false })
    const crown = play(position('b2 Kh8 / Kg1 Ka7', 'a', 49), 'b2-c1')
    expect(crown.quiet).toBe(0)
    expect(status(crown)).toEqual({ over: false })
    const quiet = play(position('Kb8 / Kg1', 'a', 49), 'b8-c7')
    expect(status(quiet)).toEqual({ over: true, winner: null, result: 'fifty-move' })
  })

  test('a win is seen before the fifty-move draw', async () => {
    // Red's one man on a1 is held by the Black king on b2, which the Black man on c3 keeps it from jumping.
    const s = play(position('Kb8 Kb2 c3 / a1', 'a', 49), 'b8-a7')
    expect(s.quiet).toBe(50)
    expect(legalMoves({ ...s, quiet: 0 })).toEqual([])
    expect(status(s)).toEqual({ over: true, winner: 'a', result: 'no moves' })
  })
})

describe('checkers: reading moves', () => {
  test('parse reads case, spaces, separators and trailing decoration forgivingly', async () => {
    const s = initial()
    expect(parse(s, 'b6-a5')).toBe('b6-a5')
    expect(parse(s, 'B6-A5')).toBe('b6-a5')
    expect(parse(s, '  b6 - a5  ')).toBe('b6-a5')
    expect(parse(s, 'b6-a5.')).toBe('b6-a5')
    expect(parse(s, 'b6-a5!')).toBe('b6-a5')
    expect(parse(s, 'b6a5')).toBe('b6-a5')
    expect(parse(s, 'b6xa5')).toBe('b6-a5')
    expect(parse(s, '"b6-a5"')).toBe('b6-a5')
    expect(parse(s, 'b6–a5')).toBe('b6-a5')
    expect(parse(s, 'b6-a5 (opens the flank)')).toBe('b6-a5')
    expect(parse(s, 'b6-a5\nIt keeps the back rank.')).toBe('b6-a5')
  })

  test('parse reads captures with x, :, × or - and the standard numbering', async () => {
    const s = position('d6 / c5 c3')
    expect(parse(s, 'd6xb4xd2')).toBe('d6xb4xd2')
    expect(parse(s, 'D6XB4XD2')).toBe('d6xb4xd2')
    expect(parse(s, 'd6:b4:d2')).toBe('d6xb4xd2')
    expect(parse(s, 'd6×b4×d2')).toBe('d6xb4xd2')
    expect(parse(s, 'd6-b4-d2')).toBe('d6xb4xd2')
    expect(parse(s, 'd6b4d2')).toBe('d6xb4xd2')
    // d6 = 10, b4 = 17, d2 = 26 in the standard numbering.
    expect(parse(s, '10x17x26')).toBe('d6xb4xd2')
    expect(parse(s, '10-17-26')).toBe('d6xb4xd2')
    expect(parse(s, '10:17:26')).toBe('d6xb4xd2')
    expect(parse(s, '10x17')).toBe(null)
    const o = initial()
    expect(parse(o, '9-13')).toBe('b6-a5')
    expect(parse(o, '11-15')).toBe('f6-e5')
    expect(parse(o, '12-16')).toBe('h6-g5')
    expect(parse(play(o, 'f6-e5'), '22-18')).toBe('c3-d4')
  })

  test('parse never returns a move legal leaves out', async () => {
    const s = initial()
    for (const bad of ['', '   ', 'b6', 'b6-b5', 'a6-b5', 'b6-a5-b4', 'c3-b4', '9-10', '0-5', '9-99', '33-29', 'zz', 'resign', 'e2e4', 'd6xb4', 'x', '-']) {
      expect(parse(s, bad)).toBe(null)
    }
    const must = position('d4 h6 / c3')
    expect(parse(must, 'h6-g5')).toBe(null)
    expect(parse(must, '18-22')).toBe(null)
    expect(parse(must, 'd4xb2')).toBe('d4xb2')
    expect(parse(must, '18x25')).toBe('d4xb2')
  })

  test('play refuses anything parse would', async () => {
    const s = initial()
    expect(throws(() => play(s, 'b6-b5'))).toBe(true)
    expect(throws(() => play(s, 'B6-A5'))).toBe(true) // the canonical string only
    expect(throws(() => play(play(s, 'b6-a5'), 'b6-c5'))).toBe(true) // not Black's turn
    expect(throws(() => play(s, 'b6-a5'))).toBe(false)
  })

  test('replay applies the moves in order and stops at the first it cannot apply', async () => {
    const s = replay(['b6-a5', 'c3-b4', 'nonsense', 'a5-b6'])
    expect(s.moves).toEqual(['b6-a5', 'c3-b4'])
    expect(s.turn).toBe('a')
    expect(replay(['9-13', 'C3-B4']).moves).toEqual(['b6-a5', 'c3-b4'])
    expect(replay([]).moves).toEqual([])
    expect(replay(['b6-a5', 'b4-a5']).moves).toEqual(['b6-a5'])
    // A whole game: the forced exchange after 11-15 22-18 15x22 25x18.
    const g = replay(['f6-e5', 'c3-d4', 'e5xc3', 'b2xd4'])
    expect(g.moves.length).toBe(4)
    expect(g.cells[squareIndex('d4')]).toBe('b')
    expect(g.cells[squareIndex('c3')]).toBe(null)
    expect(g.cells[squareIndex('e5')]).toBe(null)
    expect(count(g.cells, 'a')).toBe(11)
    expect(count(g.cells, 'b')).toBe(11)
    expect(history(g)).toEqual(['B f6-e5', 'R c3-d4', 'B e5xc3', 'R b2xd4'])
  })
})

describe('checkers: what the model and the window are given', () => {
  test('prompt names the side, the turn, the moves so far and every legal move', async () => {
    const { system, prompt: p } = prompt(initial(), 'a', null)
    expect(system).toContain('Capturing is mandatory')
    expect(system).toContain('move alone on the first line')
    expect(p).toContain('You are Black')
    expect(p).toContain("It is Black's turn (yours)")
    expect(p).toContain('Moves so far: (none)')
    expect(p).toContain('Legal moves (7): ')
    for (const m of legalMoves(initial())) expect(p).toContain(m)
    expect(p.includes('mandatory')).toBe(false)
    expect(p.includes('refused')).toBe(false)
    const red = prompt(play(initial(), 'b6-a5'), 'b', null).prompt
    expect(red).toContain('You are Red')
    expect(red).toContain("It is Red's turn (yours)")
    expect(red).toContain('Moves so far: B b6-a5')
  })

  test('prompt says when a capture is mandatory, and repeats a refused answer', async () => {
    const s = position('d4 h6 / c3')
    const p = prompt(s, 'a', null).prompt
    expect(p).toContain('capturing is mandatory')
    expect(p).toContain('Legal moves (1): d4xb2')
    const again = prompt(s, 'a', 'h6-g5 is not a legal move.').prompt
    expect(again).toContain('Your previous answer was refused: h6-g5 is not a legal move. Choose from the legal moves above.')
  })

  test('out has sixty-four cells, the last move and the capture flag', async () => {
    const o = out(initial())
    expect(o.cells.length).toBe(64)
    expect(o.cells[0]).toBe('b')
    expect(o.cells[7]).toBe(null)
    expect(o.cells[56]).toBe(null)
    expect(o.cells[57]).toBe('a')
    expect(o.lastMove).toBe(null)
    expect(o.mustCapture).toBe(false)
    const after = out(play(initial(), 'b6-a5'))
    expect(after.lastMove).toBe('b6-a5')
    expect(after.cells[squareIndex('a5')]).toBe('a')
    const taking = out(position('d4 / c3', 'a'))
    expect(taking.mustCapture).toBe(true)
    const king = out(play(position('d2 /'), 'd2-c1'))
    expect(king.cells[squareIndex('c1')]).toBe('A')
    expect(Object.keys(king).sort()).toEqual(['cells', 'lastMove', 'mustCapture'])
    expect(JSON.parse(JSON.stringify(king))).toEqual(king)
  })

  test('GAME is the module the arcade registers', async () => {
    expect(GAME.kind).toBe('checkers')
    expect(GAME.title).toBe('Checkers')
    expect(GAME.sides).toEqual({ a: 'Black', b: 'Red' })
    const s = GAME.initial()
    expect(GAME.turn(s)).toBe('a')
    expect(GAME.legal(s).length).toBe(7)
    expect(GAME.parse(s, '9-13')).toBe('b6-a5')
    const t = GAME.play(s, 'b6-a5')
    expect(GAME.turn(t)).toBe('b')
    expect(GAME.history(t)).toEqual(['B b6-a5'])
    expect(GAME.status(t)).toEqual({ over: false })
    expect(GAME.ascii(t).split('\n').length).toBe(9)
    expect(GAME.replay(['b6-a5']).moves).toEqual(['b6-a5'])
    expect(GAME.out(t).lastMove).toBe('b6-a5')
    expect(GAME.prompt(t, 'b', null).prompt).toContain('You are Red')
  })
})
