// The escape room against a mocked model: entering reveals nothing, inspecting
// reveals exactly one clue, locks open only to the right answer and never say
// what it was, the exit needs the other locks first, and the teammate's prompt
// carries only what the person has found: for every room, never an
// undiscovered clue, a hash, the salt or a plain answer. The plain answers
// live only in this file, and the room module is checked for them.

import { describe, expect, test } from 'claude-code/testing'

import { ROOMS, checkAnswer, hash, nextRoom, normalise, sha256Hex } from '../src/escape/rooms'
import { ESCAPE_EFFORTS, ESCAPE_MODELS, TEAMMATE_SYSTEM, escapeCommandFromWindow, escapeOut, escapeTick, freshEscape, teammateView } from '../hooks/escape'

type Rec = Record<string, any>

/**
 * The answers, kept here and nowhere in the mod. (A test below reads the
 * room module's source and checks none of these strings is in it.)
 */
const ANSWERS: Record<string, Record<string, string>> = {
  mansion: { safe: '0315', musicbox: 'waltz', door: 'nevermore' },
  station: { keypad: '763', fuse: 'blue', voice: 'biscuit' },
  vault: { boxlock: '1974', door: 'meridian star' },
}

// ─── The hook against a `$` of the test's own ───────────────────────────────
// The kit's `$` is the engine's own (session.start, command.run…), not a
// plugin's: a hook's `$` refuses a call its module's scan does not list, and
// hooks/escape.ts is not yet wired into register.tsx (the coordinating session
// does that). So these tests hand the hook a `$` of their own: `state.get/set`
// as `read` and `update` use them (`{ value, version }`, `ifVersion`), a clock,
// and a `model.complete` that answers from a script and records what it was
// asked. It stands for the engine exactly as `on('model.complete', …)` would.
function engine(replies: string[]) {
  const asked: Rec[] = []
  const state = new Map<string, { value: unknown; version: number }>()
  // `hold()` makes the next completion wait until `release()`: a reply in flight while the room moves on.
  let gate: Promise<void> | null = null
  let open: (() => void) | null = null
  const hold = () => {
    gate = new Promise<void>(resolve => {
      open = resolve
    })
  }
  const release = () => {
    open?.()
    gate = null
    open = null
  }
  const $ = {
    clock: { now: async () => 1800000000000 },
    state: {
      get: async (ref: { plugin: string; key: string }) => state.get(`${ref.plugin}/${ref.key}`) ?? { value: undefined, version: 0 },
      set: async (ref: { plugin: string; key: string }, value: unknown, options?: { ifVersion?: number }) => {
        const k = `${ref.plugin}/${ref.key}`
        const held = state.get(k) ?? { value: undefined, version: 0 }
        if (options?.ifVersion !== undefined && options.ifVersion !== held.version) return { isSet: false, version: held.version }
        state.set(k, { value, version: held.version + 1 })
        return { isSet: true, version: held.version + 1 }
      },
    },
    model: {
      complete: async (e: Rec) => {
        asked.push({ model: e.model, effort: e.effort, prompt: String(e.prompt), system: String(e.system) })
        if (gate !== null) await gate
        const text = replies.shift() ?? ''
        const usage = { input_tokens: 1, output_tokens: 1, cache_creation_input_tokens: 0, cache_read_input_tokens: 0 }
        return text === '' ? { isAnswered: false, reason: 'empty-reply', usage } : { isAnswered: true, text, usage }
      },
    },
  }
  return { $: $ as any, asked, hold, release }
}

/**
 * Everything the room module holds, as data: every field of every room. The
 * kit lets a test import only its own files and 'claude-code' (no node:fs, no
 * `$.fs` of its own), so the module's text is checked from the shell instead
 * (docs/ESCAPE.md, "How the boundary is tested"); here, every string the
 * module exports is checked, which is every clue, prompt, name and success text.
 */
const roomData = (): string => JSON.stringify(ROOMS).toLowerCase()

/** Waits (real time, a few ms at most) until `ok` holds: for work the hook left running unawaited. */
async function until(ok: () => boolean): Promise<void> {
  for (let i = 0; i < 200 && !ok(); i++) await new Promise(resolve => setTimeout(resolve, 1))
  expect(ok()).toBe(true)
}

const cmd = ($: any, c: Rec) => escapeCommandFromWindow($, { type: 'escape', ...c })
const out = async ($: any): Promise<Rec> => (await escapeOut($)) as Rec
const roomText = (s: Rec) => s.log.map((l: Rec) => l.text).join('\n')

/** Every string that must never reach the teammate: hashes, the salt, undiscovered clues, success text of unsolved locks, the answers. */
function forbidden(roomId: string, discovered: string[], solved: string[]): string[] {
  const room = ROOMS.find(r => r.id === roomId)!
  return [
    ...room.puzzles.map(p => p.answerHash),
    'agent-office-3d/escape',
    ...room.objects.filter(o => o.clue !== undefined && !discovered.includes(o.id)).map(o => o.clue!),
    ...room.puzzles.filter(p => !solved.includes(p.id)).map(p => p.successText),
    ...Object.values(ANSWERS[roomId]!),
  ]
}

describe('the rooms and their hashes', () => {
  test('SHA-256 is right, hashing normalises case and spaces, and the answers open their own locks only', async () => {
    expect(sha256Hex('abc')).toBe('ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')
    expect(sha256Hex('')).toBe('e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855')
    // A two-block message (over 55 bytes), so the padding path is exercised too.
    expect(sha256Hex('abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq')).toBe('248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1')
    expect(normalise('  Meridian   STAR ')).toBe('meridian star')
    expect(hash('Nevermore')).toBe(hash(' nevermore  '))
    expect(ROOMS.map(r => r.id)).toEqual(['mansion', 'station', 'vault'])
    for (const room of ROOMS) {
      expect(room.objects.length).toBeGreaterThanOrEqual(4)
      expect(room.objects.length).toBeLessThanOrEqual(6)
      expect(room.puzzles.length).toBeGreaterThanOrEqual(2)
      expect(room.puzzles.length).toBeLessThanOrEqual(3)
      expect(room.puzzles.some(p => p.id === room.exit)).toBe(true)
      for (const p of room.puzzles) {
        expect(p.answerHash).toMatch(/^[0-9a-f]{64}$/)
        expect(checkAnswer(p, ANSWERS[room.id]![p.id]!)).toBe(true)
        expect(checkAnswer(p, '')).toBe(false)
        expect(checkAnswer(p, 'open sesame')).toBe(false)
        // Every clue a lock leans on is an object of the room that has a clue.
        for (const id of p.clueIds) expect(room.objects.find(o => o.id === id)?.clue).toBeDefined()
        // No other lock of the room opens to this answer.
        for (const q of room.puzzles) if (q !== p) expect(checkAnswer(q, ANSWERS[room.id]![p.id]!)).toBe(false)
      }
    }
    expect(nextRoom(null).id).toBe('mansion')
    expect(nextRoom('mansion').id).toBe('station')
    expect(nextRoom('vault').id).toBe('mansion')
  })

  test('the room module holds no plain answer: not in a clue, a prompt, a name, a success text or any other field', async () => {
    const fields = roomData()
    expect(fields.length).toBeGreaterThan(1000)
    for (const answers of Object.values(ANSWERS)) for (const a of Object.values(answers)) expect(fields.includes(a.toLowerCase())).toBe(false)
    // Nor does what the teammate is told about itself.
    for (const answers of Object.values(ANSWERS)) for (const a of Object.values(answers)) expect(TEAMMATE_SYSTEM.toLowerCase().includes(a.toLowerCase())).toBe(false)
    // And no answer is a hex string, so none can hide inside a hash either.
    for (const answers of Object.values(ANSWERS)) for (const a of Object.values(answers)) expect(/^[0-9a-f]+$/.test(a) && fields.includes(a)).toBe(false)
  })
})

describe('the room, from the window', () => {
  test('entering reveals no clue; inspecting reveals exactly that one', async () => {
    const { $ } = engine([])
    expect(await cmd($, { action: 'enter', roomId: 'mansion' })).toBe(null)
    let s = await out($)
    expect(s.room.id).toBe('mansion')
    expect(s.discovered).toEqual([])
    expect(s.isEscaped).toBe(false)
    expect(s.room.objects.every((o: Rec) => o.clue === null && o.isDiscovered === false)).toBe(true)
    expect(s.log.length).toBe(1)
    expect(s.log[0].who).toBe('room')
    const room = ROOMS[0]!
    for (const o of room.objects) if (o.clue !== undefined) expect(roomText(s).includes(o.clue)).toBe(false)
    expect(await cmd($, { action: 'inspect', objectId: 'clock' })).toBe(null)
    s = await out($)
    expect(s.discovered).toEqual(['clock'])
    const clock = s.room.objects.find((o: Rec) => o.id === 'clock')
    expect(clock.isDiscovered).toBe(true)
    expect(clock.clue).toBe(room.objects.find(o => o.id === 'clock')!.clue)
    expect(roomText(s).includes(clock.clue)).toBe(true)
    for (const o of room.objects) if (o.id !== 'clock') expect(s.room.objects.find((x: Rec) => x.id === o.id).clue).toBe(null)
    for (const o of room.objects) if (o.clue !== undefined && o.id !== 'clock') expect(roomText(s).includes(o.clue)).toBe(false)
    // Inspecting again adds no second entry; an unknown object is refused; an object without a clue says so.
    await cmd($, { action: 'inspect', objectId: 'clock' })
    expect((await out($)).discovered).toEqual(['clock'])
    expect(await cmd($, { action: 'inspect', objectId: 'chandelier' })).toContain('no such object')
    await cmd($, { action: 'enter', roomId: 'vault' })
    await cmd($, { action: 'inspect', objectId: 'timer' })
    s = await out($)
    expect(s.discovered).toEqual(['timer'])
    expect(roomText(s)).toContain('Nothing more to find')
  })

  test('a wrong answer fails without saying the answer; the right one opens the lock; the exit waits for the rest', async () => {
    const { $ } = engine([])
    await cmd($, { action: 'enter', roomId: 'vault' })
    const a = ANSWERS.vault!
    await cmd($, { action: 'try', puzzleId: 'boxlock', text: '1066' })
    let s = await out($)
    expect(s.solved).toEqual([])
    expect(roomText(s)).toContain('Nothing happens')
    expect(roomText(s).includes(a.boxlock!)).toBe(false)
    expect(roomText(s).includes(a.door!)).toBe(false)
    expect(JSON.stringify(s).includes(ROOMS[2]!.puzzles[0]!.answerHash)).toBe(false)
    // The exit first: held shut.
    await cmd($, { action: 'try', puzzleId: 'door', text: a.door! })
    s = await out($)
    expect(s.solved).toEqual([])
    expect(s.isEscaped).toBe(false)
    expect(roomText(s)).toContain('does not budge')
    expect(s.room.puzzles.find((p: Rec) => p.id === 'door').isLocked).toBe(true)
    // Then in order, with the answer written sloppily.
    await cmd($, { action: 'try', puzzleId: 'boxlock', text: ` ${a.boxlock} ` })
    s = await out($)
    expect(s.solved).toEqual(['boxlock'])
    expect(s.room.puzzles.find((p: Rec) => p.id === 'boxlock').isSolved).toBe(true)
    expect(roomText(s)).toContain(ROOMS[2]!.puzzles[0]!.successText)
    expect(s.room.puzzles.find((p: Rec) => p.id === 'door').isLocked).toBe(false)
    expect(await cmd($, { action: 'try', puzzleId: 'boxlock', text: a.boxlock! })).toContain('already open')
    await cmd($, { action: 'try', puzzleId: 'door', text: 'MERIDIAN   Star' })
    s = await out($)
    expect(s.solved).toEqual(['boxlock', 'door'])
    expect(s.isEscaped).toBe(true)
    expect(await cmd($, { action: 'try', puzzleId: 'door', text: '' })).toContain('Type an answer')
    expect(await cmd($, { action: 'try', puzzleId: 'window', text: 'x' })).toContain('no such lock')
  })

  test('every room is solvable from its answers, escaping only at the exit, and leave clears it', async () => {
    const { $ } = engine([])
    for (const room of ROOMS) {
      await cmd($, { action: 'enter', roomId: room.id })
      for (const p of room.puzzles) {
        if (p.id === room.exit) continue
        await cmd($, { action: 'try', puzzleId: p.id, text: ANSWERS[room.id]![p.id]! })
        expect((await out($)).isEscaped).toBe(false)
      }
      await cmd($, { action: 'try', puzzleId: room.exit, text: ANSWERS[room.id]![room.exit]! })
      const s = await out($)
      expect(s.isEscaped).toBe(true)
      expect(s.solved.length).toBe(room.puzzles.length)
    }
    await cmd($, { action: 'leave' })
    const s = await out($)
    expect(s.room).toBe(null)
    expect(s.log).toEqual([])
    expect(s.isEscaped).toBe(false)
    expect(await cmd($, { action: 'inspect', objectId: 'clock' })).toContain('not in an escape room')
  })

  test('enter with no room takes the next theme in rotation, fresh each time', async () => {
    const { $ } = engine([])
    await cmd($, { action: 'enter' })
    expect((await out($)).room.id).toBe('mansion')
    await cmd($, { action: 'inspect', objectId: 'mirror' })
    await cmd($, { action: 'enter' })
    let s = await out($)
    expect(s.room.id).toBe('station')
    expect(s.discovered).toEqual([])
    await cmd($, { action: 'enter' })
    expect((await out($)).room.id).toBe('vault')
    await cmd($, { action: 'enter' })
    expect((await out($)).room.id).toBe('mansion')
    expect(await cmd($, { action: 'enter', roomId: 'dungeon' })).toContain('no such escape room')
    s = await out($)
    expect(s.rooms.map((r: Rec) => r.id)).toEqual(['mansion', 'station', 'vault'])
    expect(s.rooms.map((r: Rec) => r.theme)).toEqual(['a spooky mansion', 'a failing space station', 'a heist gone sideways'])
  })
})

describe('the teammate', () => {
  test('a seat takes only the models and efforts offered', async () => {
    const { $ } = engine([])
    expect(await cmd($, { action: 'teammate', model: 'gpt-9', effort: 'high' })).toContain('not understood')
    expect(await cmd($, { action: 'teammate', model: 'claude-haiku-5-5', effort: 'ultra' })).toContain('not understood')
    expect((await out($)).teammate).toBe(null)
    expect(await cmd($, { action: 'teammate', model: 'claude-haiku-5-5', effort: 'low' })).toBe(null)
    expect((await out($)).teammate).toEqual({ model: 'claude-haiku-5-5', effort: 'low' })
    expect(ESCAPE_MODELS.map(m => m.id)).toEqual(['claude-fable-5-1', 'claude-opus-5-5', 'claude-sonnet-5-5', 'claude-haiku-5-5'])
    expect([...ESCAPE_EFFORTS]).toEqual(['low', 'medium', 'high', 'xhigh', 'max'])
    // The seat survives entering a room; unseating clears it.
    await cmd($, { action: 'enter', roomId: 'station' })
    expect((await out($)).teammate).toEqual({ model: 'claude-haiku-5-5', effort: 'low' })
    await cmd($, { action: 'teammate' })
    expect((await out($)).teammate).toBe(null)
  })

  test('a say queues one completion; the reply lands in the log; nothing runs without a seat or a say', async () => {
    const { $, asked } = engine(['The clock says a quarter past three: try 0315 on the safe?'])
    await escapeTick($, true)
    expect(asked.length).toBe(0)
    await cmd($, { action: 'enter', roomId: 'mansion' })
    expect(await cmd($, { action: 'say', text: 'Anyone there?' })).toContain('seat a teammate')
    await escapeTick($, true)
    expect(asked.length).toBe(0)
    await cmd($, { action: 'teammate', model: 'claude-sonnet-5-5', effort: 'medium' })
    await cmd($, { action: 'inspect', objectId: 'clock' })
    expect(await cmd($, { action: 'say', text: 'What do you make of the clock?' })).toBe(null)
    let s = await out($)
    expect(s.busy).toBe(true)
    await escapeTick($, true)
    await escapeTick($, true)
    expect(asked.length).toBe(1)
    expect(asked[0]).toMatchObject({ model: 'claude-sonnet-5-5', effort: 'medium', system: TEAMMATE_SYSTEM })
    expect(asked[0]!.prompt).toContain('Teammate: What do you make of the clock?')
    s = await out($)
    expect(s.busy).toBe(false)
    expect(s.error).toBe(null)
    const last = s.log.at(-1)
    expect(last.who).toBe('teammate')
    expect(last.text).toContain('quarter past three')
    // Its guess is the teammate's own words from the clue; the lock still decides.
    expect(s.solved).toEqual([])
  })

  test('an empty reply leaves an error and clears busy', async () => {
    const { $, asked } = engine([''])
    await cmd($, { action: 'enter', roomId: 'station' })
    await cmd($, { action: 'teammate', model: 'claude-opus-5-5', effort: 'high' })
    await cmd($, { action: 'say', text: 'Hello?' })
    await escapeTick($, true)
    const s = await out($)
    expect(asked.length).toBe(1)
    expect(s.busy).toBe(false)
    expect(s.error).toContain('Opus 5.5')
    expect(s.log.filter((l: Rec) => l.who === 'teammate')).toEqual([])
  })

  test('the prompt carries only discovered clues, never undiscovered ones, hashes, the salt or an answer, in every room', async () => {
    for (const room of ROOMS) {
      // Nothing found yet: the prompt names every object but shows no clue at all.
      const fresh = { ...freshEscape({ model: 'claude-haiku-5-5', effort: 'low' }), roomId: room.id, log: [{ who: 'room' as const, text: room.intro }] }
      let view = teammateView(room, fresh)
      expect(view).toContain(room.title)
      expect(view).toContain(room.intro)
      for (const o of room.objects) {
        expect(view).toContain(o.name)
        expect(view).toContain(o.description)
      }
      for (const p of room.puzzles) expect(view).toContain(p.prompt)
      for (const bad of forbidden(room.id, [], [])) expect(view.includes(bad)).toBe(false)
      expect(view.includes('clueIds')).toBe(false)
      // One object at a time: exactly its clue appears, and no other.
      for (const o of room.objects) {
        const one = { ...fresh, discovered: [o.id] }
        view = teammateView(room, one)
        if (o.clue !== undefined) expect(view).toContain(o.clue)
        for (const bad of forbidden(room.id, [o.id], [])) expect(view.includes(bad)).toBe(false)
      }
      // Solving a lock lets its success text through (the person saw it), but the exit's stays out until solved.
      const first = room.puzzles[0]!
      const solvedOne = { ...fresh, discovered: room.objects.map(o => o.id), solved: [first.id] }
      view = teammateView(room, solvedOne)
      for (const o of room.objects) if (o.clue !== undefined) expect(view).toContain(o.clue)
      expect(view).toContain('OPEN.')
      for (const bad of forbidden(room.id, room.objects.map(o => o.id), [first.id])) expect(view.includes(bad)).toBe(false)
      // The system prompt has nothing of any room in it.
      for (const bad of forbidden(room.id, [], [])) expect(TEAMMATE_SYSTEM.includes(bad)).toBe(false)
      for (const o of room.objects) expect(TEAMMATE_SYSTEM.includes(o.name)).toBe(false)
    }
  })

  test('the same boundary holds for what the model is actually sent, through the window commands, in every room', async () => {
    const { $, asked } = engine(['Hm.', 'Hm.', 'Hm.'])
    for (const room of ROOMS) {
      await cmd($, { action: 'enter', roomId: room.id })
      await cmd($, { action: 'teammate', model: 'claude-fable-5-1', effort: 'xhigh' })
      const found = room.objects[1]!
      await cmd($, { action: 'inspect', objectId: found.id })
      await cmd($, { action: 'try', puzzleId: room.exit, text: 'something wrong' })
      await cmd($, { action: 'say', text: 'Ideas?' })
      await escapeTick($, true)
      const ask = asked.at(-1)!
      expect(ask).toMatchObject({ model: 'claude-fable-5-1', effort: 'xhigh' })
      if (found.clue !== undefined) expect(ask.prompt).toContain(found.clue)
      expect(ask.prompt).toContain('Teammate: Ideas?')
      for (const bad of forbidden(room.id, [found.id], [])) {
        expect(ask.prompt.includes(bad)).toBe(false)
        expect(ask.system.includes(bad)).toBe(false)
      }
    }
    expect(asked.length).toBe(3)
  })

  test('a second say while the reply is in flight gets its own reply afterwards', async () => {
    const { $, asked, hold, release } = engine(['First.', 'Second.'])
    await cmd($, { action: 'enter', roomId: 'vault' })
    await cmd($, { action: 'teammate', model: 'claude-haiku-5-5', effort: 'low' })
    await cmd($, { action: 'say', text: 'One' })
    hold()
    const running = escapeTick($, true)
    await escapeTick($, true) // a second tick while one is in flight starts nothing
    await until(() => asked.length === 1) // the completion is in flight, held by the gate
    await cmd($, { action: 'say', text: 'Two' })
    expect(asked.length).toBe(1)
    expect(asked[0]!.prompt.includes('Teammate: Two')).toBe(false)
    release()
    await running
    expect((await out($)).busy).toBe(true)
    await escapeTick($, true)
    const s = await out($)
    expect(asked.length).toBe(2)
    expect(asked[1]!.prompt).toContain('Teammate: Two')
    expect(asked[1]!.prompt).toContain('You: First.')
    expect(s.busy).toBe(false)
    expect(s.log.filter((l: Rec) => l.who === 'teammate').map((l: Rec) => l.text)).toEqual(['First.', 'Second.'])
    // A reply that lands after the person has left the room is dropped.
    hold()
    await cmd($, { action: 'say', text: 'Three' })
    const late = escapeTick($, true)
    await until(() => asked.length === 3)
    await cmd($, { action: 'leave' })
    release()
    await late
    expect((await out($)).log).toEqual([])
  })
})
