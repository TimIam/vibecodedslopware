// The projected gallery: camera math and the SVG's bounds.

import { describe, expect, test } from 'claude-code/testing'

import { OVERVIEW, SLOTS, VIEW, cameraForSlot, clipNear, makeProjector, renderGallerySvg, slotCenter, tweenCamera } from '../src/scene'

const frame = (i: number, label: string, line: string) => ({
  v: 1 as const,
  sessionId: `${i}aaaaaaa-0000-4000-8000-000000000000`,
  label,
  enrolledAt: i,
  heartbeatAt: 0,
  status: 'idle' as const,
  messageCount: 24,
  snapshot: Array.from({ length: 24 }, (_, k) => ({ role: (k % 2 ? 'assistant' : 'user') as 'user' | 'assistant', text: line })),
  receipts: [],
  isStale: false,
})

describe('scene', () => {
  test('each frame camera looks straight at its frame, which projects to the centre', () => {
    for (let i = 0; i < SLOTS.length; i++) {
      const pr = makeProjector(cameraForSlot(i))
      const v = pr.view(slotCenter(i))
      expect(v[2]).toBeLessThan(0)
      const p = pr.project(v)
      expect(Math.abs(p.x - VIEW.width / 2)).toBeLessThan(1)
      expect(Math.abs(p.y - VIEW.height / 2)).toBeLessThan(1)
    }
  })

  test('the overview sees the back frame ahead and the side frames to either side', () => {
    const pr = makeProjector(OVERVIEW)
    const [left, back, right] = [0, 1, 2].map(i => pr.project(pr.view(slotCenter(i))))
    expect(left!.x).toBeLessThan(back!.x)
    expect(back!.x).toBeLessThan(right!.x)
  })

  test('near-plane clipping drops what is behind the camera', () => {
    expect(clipNear([[0, 0, 1], [1, 0, 1], [0, 1, 1]])).toEqual([])
    expect(clipNear([[0, 0, -1], [1, 0, -1], [0, 1, 1]]).every(v => v[2] <= -VIEW.near + 1e-9)).toBe(true)
  })

  test('a tween turns the short way and lands exactly', () => {
    const a = { ...OVERVIEW, yaw: 3 }
    const b = { ...OVERVIEW, yaw: -3 }
    expect(Math.abs(tweenCamera(a, b, 0.5).yaw)).toBeGreaterThan(3)
    expect(tweenCamera(a, b, 1)).toEqual(b)
  })

  test('the SVG stays far under the 131,072-character limit at its fullest', () => {
    const long = 'x'.repeat(600)
    const frames = [0, 1, 2].map(i => frame(i, 'L'.repeat(60), long))
    for (const camera of [OVERVIEW, cameraForSlot(0), cameraForSlot(1), cameraForSlot(2)]) {
      const svg = renderGallerySvg({ frames, selectedId: frames[1]!.sessionId, camera, caption: 'c'.repeat(500) })
      expect(svg.length).toBeLessThan(40_000)
      expect(svg.startsWith('<svg')).toBe(true)
      expect(svg.endsWith('</svg>')).toBe(true)
    }
  })
})
