// The kanban wall board: a markdown file's three shapes parse into a board;
// serialising writes only the lines a change needs and leaves the rest of the
// file byte for byte; the hook finds the first board file, reloads when the
// file moves, and applies the window's commands with every argument checked
// again, merging a concurrent change by card id.

import { describe, expect, mock, test } from 'claude-code/testing'

import { KANBAN_CANDIDATES, kanbanCommandFromWindow, kanbanOut, kanbanTick, loadKanban } from '../hooks/kanban'
import { cardId, parse, serialize, shapeOf } from '../src/kanban/markdown'

const NOW = 1800000000000
const CWD = '/tmp/kanban-test'

const ROADMAP = `# Agent Office 3D roadmap

Last updated 2026-10-19. Items move down as they ship; nothing here is promised.

## Now

- [x] Fullscreen office window
- [ ] Kanban wall board
  Reads KANBAN.md and friends; writes back by line.
  - keep the rest of the file untouched
- [ ] Checkers at the arcade

## Next

- [ ] Connect Four
- [ ] A world editor

## Later

- [ ] Escape room

## Notes

Nothing in **Later** has a date. Ask before promising one.

\`\`\`md
- [ ] not a task: this is a code block
\`\`\`

1. an ordered list is prose here
`

const BULLETS = `# Chores

## Todo
- Water the plants
- Call the plumber

## Done
- Take out the bins
`

const FLAT = `- [ ] write the parser
- [x] read the spec
- [ ] run the tests
`

const id = (column: string, text: string) => cardId(column, text)

describe('parsing', () => {
  test('headings with task lists: a column per ## heading, nested lines in the card, code blocks and prose skipped', () => {
    const b = parse(ROADMAP)
    expect(b.title).toBe('Agent Office 3D roadmap')
    expect(b.columns.map(c => c.name)).toEqual(['Now', 'Next', 'Later', 'Notes'])
    expect(b.columns[0]!.cards.map(k => [k.text, k.done, k.line])).toEqual([
      ['Fullscreen office window', true, 7],
      ['Kanban wall board\n  Reads KANBAN.md and friends; writes back by line.\n  - keep the rest of the file untouched', false, 8],
      ['Checkers at the arcade', false, 11],
    ])
    expect(b.columns[1]!.cards.map(k => k.text)).toEqual(['Connect Four', 'A world editor'])
    expect(b.columns[2]!.cards.map(k => k.text)).toEqual(['Escape room'])
    expect(b.columns[3]!.cards).toEqual([])
    expect(b.columns[1]!.cards[0]!.id).toBe(id('Next', 'Connect Four'))
    expect(shapeOf(ROADMAP)).toBe('tasks')
  })

  test('headings with plain bullets: a column per heading, every bullet a card that is not done', () => {
    const b = parse(BULLETS)
    expect(b.title).toBe('Chores')
    expect(b.columns.map(c => [c.name, c.cards.map(k => k.text), c.cards.map(k => k.done)])).toEqual([
      ['Todo', ['Water the plants', 'Call the plumber'], [false, false]],
      ['Done', ['Take out the bins'], [false]],
    ])
    expect(shapeOf(BULLETS)).toBe('bullets')
  })

  test('task lists with no headings: one column, Tasks; a file with nothing has no columns', () => {
    const b = parse(FLAT)
    expect(b.title).toBe('')
    expect(b.columns.map(c => c.name)).toEqual(['Tasks'])
    expect(b.columns[0]!.cards.map(k => [k.text, k.done])).toEqual([
      ['write the parser', false],
      ['read the spec', true],
      ['run the tests', false],
    ])
    expect(shapeOf(FLAT)).toBe('flat')
    expect(parse('# Only a title\n\nSome prose.\n').columns).toEqual([])
    expect(shapeOf('')).toBe('none')
  })

  test('ids are stable hashes of column and text; duplicates in one column are numbered', () => {
    const a = parse(ROADMAP)
    const b = parse(ROADMAP)
    expect(a.columns[0]!.cards.map(k => k.id)).toEqual(b.columns[0]!.cards.map(k => k.id))
    expect(/^[0-9a-f]{8}$/.test(a.columns[0]!.cards[0]!.id)).toBe(true)
    const dup = parse('## A\n- [ ] same\n- [ ] same\n')
    expect(dup.columns[0]!.cards.map(k => k.id)).toEqual([id('A', 'same'), `${id('A', 'same')}-2`])
    expect(parse('## A\n- [ ] x\n').columns[0]!.cards[0]!.id).not.toBe(parse('## B\n- [ ] x\n').columns[0]!.cards[0]!.id)
  })
})

describe('serialising', () => {
  test('nothing changed: the file comes back byte for byte, with LF or CRLF endings', () => {
    expect(serialize(parse(ROADMAP), ROADMAP)).toBe(ROADMAP)
    const crlf = ROADMAP.replace(/\n/g, '\r\n')
    expect(serialize(parse(crlf), crlf)).toBe(crlf)
    expect(serialize(parse(BULLETS), BULLETS)).toBe(BULLETS)
    expect(serialize(parse(FLAT), FLAT)).toBe(FLAT)
  })

  test('toggle: only that card line changes', () => {
    const b = parse(ROADMAP)
    b.columns[1]!.cards[0]!.done = true
    expect(serialize(b, ROADMAP)).toBe(ROADMAP.replace('- [ ] Connect Four', '- [x] Connect Four'))
    const crlf = ROADMAP.replace(/\n/g, '\r\n')
    const c = parse(crlf)
    c.columns[0]!.cards[0]!.done = false
    expect(serialize(c, crlf)).toBe(crlf.replace('- [x] Fullscreen office window', '- [ ] Fullscreen office window'))
  })

  test('edit: the card and its continuation lines are replaced by the new text alone', () => {
    const b = parse(ROADMAP)
    b.columns[0]!.cards[1]!.text = 'Kanban wall board (live)'
    expect(serialize(b, ROADMAP)).toBe(
      ROADMAP.replace('- [ ] Kanban wall board\n  Reads KANBAN.md and friends; writes back by line.\n  - keep the rest of the file untouched\n', '- [ ] Kanban wall board (live)\n'),
    )
  })

  test('move: the card leaves one list and is appended to the other, continuation lines and all', () => {
    const b = parse(ROADMAP)
    const [card] = b.columns[0]!.cards.splice(1, 1)
    b.columns[1]!.cards.push(card!)
    expect(serialize(b, ROADMAP)).toBe(
      ROADMAP.replace('- [ ] Kanban wall board\n  Reads KANBAN.md and friends; writes back by line.\n  - keep the rest of the file untouched\n', '').replace(
        '- [ ] A world editor\n',
        '- [ ] A world editor\n- [ ] Kanban wall board\n  Reads KANBAN.md and friends; writes back by line.\n  - keep the rest of the file untouched\n',
      ),
    )
  })

  test('add: appended to the column list; to an empty column, right under its heading; to a flat file, at the end', () => {
    const b = parse(ROADMAP)
    b.columns[2]!.cards.push({ id: id('Later', 'Voice'), text: 'Voice', done: false, line: 0 })
    b.columns[3]!.cards.push({ id: id('Notes', 'Write the docs'), text: 'Write the docs', done: false, line: 0 })
    expect(serialize(b, ROADMAP)).toBe(
      ROADMAP.replace('- [ ] Escape room\n', '- [ ] Escape room\n- [ ] Voice\n').replace('## Notes\n\n', '## Notes\n\n- [ ] Write the docs\n'),
    )
    const f = parse(FLAT)
    f.columns[0]!.cards.push({ id: id('Tasks', 'ship it'), text: 'ship it', done: true, line: 0 })
    expect(serialize(f, FLAT)).toBe(`${FLAT}- [x] ship it\n`)
    // A bullet file stays a bullet file: a new card that is not done is a plain bullet; a done one is a task.
    const p = parse(BULLETS)
    p.columns[0]!.cards.push({ id: id('Todo', 'Buy milk'), text: 'Buy milk', done: false, line: 0 })
    p.columns[1]!.cards[0]!.done = true
    expect(serialize(p, BULLETS)).toBe(BULLETS.replace('- Call the plumber\n', '- Call the plumber\n- Buy milk\n').replace('- Take out the bins', '- [x] Take out the bins'))
  })

  test('remove: the card lines go, nothing else; a column the file lacks is refused', () => {
    const b = parse(ROADMAP)
    b.columns[0]!.cards.splice(1, 1)
    b.columns[1]!.cards.splice(0, 1)
    expect(serialize(b, ROADMAP)).toBe(
      ROADMAP.replace('- [ ] Kanban wall board\n  Reads KANBAN.md and friends; writes back by line.\n  - keep the rest of the file untouched\n', '').replace('- [ ] Connect Four\n', ''),
    )
    const c = parse(ROADMAP)
    c.columns.push({ name: 'Nowhere', cards: [{ id: 'deadbeef', text: 'x', done: false, line: 0 }] })
    expect(() => serialize(c, ROADMAP)).toThrow('no column named "Nowhere"')
  })

  test('the written file parses back to the board that was written', () => {
    const b = parse(ROADMAP)
    b.columns[0]!.cards[2]!.done = true
    const [card] = b.columns[1]!.cards.splice(1, 1)
    b.columns[2]!.cards.push(card!)
    b.columns[2]!.cards.push({ id: id('Later', 'Voice'), text: 'Voice', done: false, line: 0 })
    const text = serialize(b, ROADMAP)
    const again = parse(text)
    expect(again.columns.map(c => [c.name, c.cards.map(k => [k.text, k.done])])).toEqual([
      ['Now', [['Fullscreen office window', true], ['Kanban wall board\n  Reads KANBAN.md and friends; writes back by line.\n  - keep the rest of the file untouched', false], ['Checkers at the arcade', true]]],
      ['Next', [['Connect Four', false]]],
      ['Later', [['Escape room', false], ['A world editor', false], ['Voice', false]]],
      ['Notes', []],
    ])
    expect(serialize(again, text)).toBe(text)
  })
})

// ─── The hook against a mocked `$` with an in-memory file system ───────────
// The kit's `$` is the engine's own (session.start, tool.call…), not a
// plugin's: a hook's `$` refuses a call its module's scan does not list, and
// hooks/kanban.ts is not yet wired into register.tsx. So these tests hand the
// hook a `$` of their own: `session.cwd`, a clock, `fs.exists/read/write/stat`
// over an in-memory file map, and `state.get/set` as `read` and `update` use
// them (`{ value, version }`, `ifVersion`). It stands for the engine exactly
// as the `on('fs.read', …)` mocks would, with the same answers.
type Rec = Record<string, any>

function engine(files: Record<string, string>) {
  let now = NOW
  const fs = new Map<string, { text: string; mtimeMs: number }>()
  let stamp = 1000
  const norm = (p: string) => p.replace(/\\/g, '/')
  const touch = (name: string, text: string) => fs.set(norm(`${CWD}/${name}`), { text, mtimeMs: (stamp += 1) })
  for (const [name, text] of Object.entries(files)) touch(name, text)
  const writes: { path: string; text: string }[] = []
  const state = new Map<string, { value: unknown; version: number }>()
  const $ = {
    session: { cwd: async () => CWD },
    clock: { now: async () => now },
    fs: {
      exists: async (path: string) => fs.has(norm(path)),
      read: async (path: string) => {
        const f = fs.get(norm(path))
        if (f === undefined) throw new Error(`ENOENT: ${path}`)
        return f.text
      },
      stat: async (path: string) => {
        const f = fs.get(norm(path))
        if (f === undefined) throw new Error(`ENOENT: ${path}`)
        return { kind: 'file', size: f.text.length, mtimeMs: f.mtimeMs, isLink: false }
      },
      write: async (path: string, text: string) => {
        writes.push({ path: norm(path), text })
        fs.set(norm(path), { text, mtimeMs: (stamp += 1) })
      },
    },
    state: {
      get: async (ref: { plugin: string; key: string }) => state.get(`${ref.plugin}/${ref.key}`) ?? { value: undefined, version: 0 },
      set: async (ref: { plugin: string; key: string }, value: unknown, options?: { ifVersion?: number }) => {
        const k = `${ref.plugin}/${ref.key}`
        const held = state.get(k) ?? { value: undefined, version: 0 }
        if (options?.ifVersion !== undefined && options.ifVersion !== held.version) return { isSet: false, version: held.version }
        state.set(k, { value, version: held.version + 1 })
        return { isSet: true, version: held.version + 1 }
      },
    },
  }
  const clock = { advance: async (ms: number) => void (now += ms) }
  const text = (name: string) => fs.get(norm(`${CWD}/${name}`))?.text
  const remove = (name: string) => fs.delete(norm(`${CWD}/${name}`))
  return { $: $ as any, clock, touch, text, remove, writes }
}

const cmd = ($: any, c: Rec) => kanbanCommandFromWindow($, { type: 'kanban', ...c })
const out = async ($: any): Promise<Rec> => (await kanbanOut($)) as Rec

describe('finding and reloading the board', () => {
  test('the first candidate in the working folder is the board; none means no board', async () => {
    const e = engine({ 'ROADMAP.md': ROADMAP, 'TODO.md': FLAT, 'docs/KANBAN.md': BULLETS })
    const $ = e.$
    const s = await loadKanban($)
    expect(s.file).toBe(`${CWD}/ROADMAP.md`)
    expect(s.board?.title).toBe('Agent Office 3D roadmap')
    expect(s.error).toBe(null)
    const o = await out($)
    expect(o.file).toBe('ROADMAP.md')
    expect(o.columns.map((c: Rec) => c.name)).toEqual(['Now', 'Next', 'Later', 'Notes'])
    expect(o.columns[0].total).toBe(3)
    expect(o.columns[0].cards[1].text).toContain('Kanban wall board')
    expect(o.updatedAt).toBe(s.mtimeMs)
    expect(KANBAN_CANDIDATES[0]).toBe('KANBAN.md')
    e.remove('ROADMAP.md')
    e.remove('TODO.md')
    e.remove('docs/KANBAN.md')
    expect((await loadKanban($)).file).toBe(null)
    expect(await out($)).toEqual({ file: null })
  })

  test('the tick re-reads the file when its modification time moves, at most every two seconds', async () => {
    const e = engine({ 'KANBAN.md': FLAT })
    const $ = e.$
    await loadKanban($)
    e.touch('KANBAN.md', FLAT.replace('- [ ] run the tests', '- [x] run the tests'))
    await e.clock.advance(1000)
    await kanbanTick($)
    expect((await out($)).columns[0].cards[2].done).toBe(false) // too soon
    await e.clock.advance(1500)
    await kanbanTick($)
    expect((await out($)).columns[0].cards[2].done).toBe(true)
    // The file gone: no board, found again later.
    e.remove('KANBAN.md')
    await e.clock.advance(2500)
    await kanbanTick($)
    expect(await out($)).toEqual({ file: null })
    e.touch('TASKS.md', FLAT)
    await e.clock.advance(2500)
    await kanbanTick($)
    expect(await out($)).toEqual({ file: null }) // a new file is looked for every ten seconds
    await e.clock.advance(10000)
    await kanbanTick($)
    expect((await out($)).file).toBe('TASKS.md')
  })
})

describe('commands from the window', () => {
  test('toggle, edit, move, add and remove each write the file with only that change', async () => {
    const e = engine({ 'KANBAN.md': ROADMAP })
    const $ = e.$
    await loadKanban($)
    let want = ROADMAP
    expect(await cmd($, { action: 'toggle', id: id('Next', 'Connect Four') })).toBe(null)
    want = want.replace('- [ ] Connect Four', '- [x] Connect Four')
    expect(e.text('KANBAN.md')).toBe(want)
    expect(await cmd($, { action: 'edit', id: id('Now', 'Checkers at the arcade'), text: 'Checkers and Connect Four at the arcade' })).toBe(null)
    want = want.replace('- [ ] Checkers at the arcade', '- [ ] Checkers and Connect Four at the arcade')
    expect(e.text('KANBAN.md')).toBe(want)
    expect(await cmd($, { action: 'move', id: id('Later', 'Escape room'), column: 'Next' })).toBe(null)
    want = want.replace('- [ ] Escape room\n', '').replace('- [ ] A world editor\n', '- [ ] A world editor\n- [ ] Escape room\n')
    expect(e.text('KANBAN.md')).toBe(want)
    expect(await cmd($, { action: 'add', column: 'later', text: 'Voice chat' })).toBe(null) // column names match case-insensitively
    want = want.replace('## Later\n\n', '## Later\n\n- [ ] Voice chat\n')
    expect(e.text('KANBAN.md')).toBe(want)
    expect(await cmd($, { action: 'remove', id: id('Now', 'Fullscreen office window') })).toBe(null)
    want = want.replace('- [x] Fullscreen office window\n', '')
    expect(e.text('KANBAN.md')).toBe(want)
    expect(e.writes.length).toBe(5)
    const o = await out($)
    expect(o.columns.map((c: Rec) => c.cards.map((k: Rec) => k.text))).toEqual([
      ['Kanban wall board Reads KANBAN.md and friends; writes back by line. - keep the rest of the file untouched', 'Checkers and Connect Four at the arcade'],
      ['Connect Four', 'A world editor', 'Escape room'],
      ['Voice chat'],
      [],
    ])
    expect(o.columns[1].cards[0].done).toBe(true)
    expect(await cmd($, { action: 'reload' })).toBe(null)
    expect(e.text('KANBAN.md')).toBe(want)
  })

  test('bad ids, long or multi-line texts, unknown columns, duplicates and unknown actions are refused without a write', async () => {
    const e = engine({ 'KANBAN.md': ROADMAP })
    const $ = e.$
    await loadKanban($)
    expect(await cmd($, { action: 'toggle', id: 'nope' })).toContain('not understood')
    expect(await cmd($, { action: 'toggle', id: 'deadbeef' })).toContain('not on the board')
    expect(await cmd($, { action: 'edit', id: id('Next', 'Connect Four'), text: 'x'.repeat(301) })).toContain('at most 300')
    expect(await cmd($, { action: 'add', column: 'Next', text: 'two\nlines' })).toContain('one line')
    expect(await cmd($, { action: 'add', column: 'Next', text: '   ' })).toContain('Type the card')
    expect(await cmd($, { action: 'add', column: 'Someday', text: 'x' })).toContain('no column named "Someday"')
    expect(await cmd($, { action: 'move', id: id('Next', 'Connect Four'), column: 'Someday' })).toContain('no column named "Someday"')
    expect(await cmd($, { action: 'add', column: 'Next', text: 'Connect Four' })).toContain('already in Next')
    expect(await cmd($, { action: 'burn' })).toContain('not understood')
    expect(await cmd($, { action: 'toggle', id: id('Next', 'Connect Four'), type: 'arcade' } as Rec)).toBe(null)
    expect(e.writes.length).toBe(0)
    expect(e.text('KANBAN.md')).toBe(ROADMAP)
    // A 300-character one-line text is fine.
    expect(await cmd($, { action: 'add', column: 'Next', text: 'y'.repeat(300) })).toBe(null)
    expect(e.writes.length).toBe(1)
  })

  test('a concurrent change: merged by card id when the card is still there, reported when it is gone', async () => {
    const e = engine({ 'KANBAN.md': ROADMAP })
    const $ = e.$
    await loadKanban($)
    // Someone else ticked a card and added one since the board was read.
    const elsewhere = ROADMAP.replace('- [ ] A world editor', '- [x] A world editor').replace('- [ ] Escape room\n', '- [ ] Escape room\n- [ ] Added elsewhere\n')
    e.touch('KANBAN.md', elsewhere)
    expect(await cmd($, { action: 'toggle', id: id('Next', 'Connect Four') })).toContain('merged')
    expect(e.text('KANBAN.md')).toBe(elsewhere.replace('- [ ] Connect Four', '- [x] Connect Four'))
    const o = await out($)
    expect(o.columns[1].cards.map((k: Rec) => k.done)).toEqual([true, true])
    expect(o.columns[2].cards.map((k: Rec) => k.text)).toEqual(['Escape room', 'Added elsewhere'])
    // The card itself removed elsewhere: the change is refused and the fresh board shown.
    const gone = e.text('KANBAN.md')!.replace('- [ ] Checkers at the arcade\n', '')
    e.touch('KANBAN.md', gone)
    const reply = await cmd($, { action: 'edit', id: id('Now', 'Checkers at the arcade'), text: 'Checkers' })
    expect(reply).toContain('changed under you')
    expect(reply).toContain('not on the board')
    expect(e.text('KANBAN.md')).toBe(gone)
    expect((await out($)).columns[0].cards.length).toBe(2)
  })

  test('with no board file every command but reload says so, and a bad file reports its error', async () => {
    const e = engine({})
    const $ = e.$
    await loadKanban($)
    expect(await cmd($, { action: 'add', column: 'Now', text: 'x' })).toContain('no board file')
    expect(await cmd($, { action: 'reload' })).toContain('no board file')
    e.touch('KANBAN.md', '# Just a title\n\nNo lists here.\n')
    expect(await cmd($, { action: 'reload' })).toBe(null)
    const o = await out($)
    expect(o.file).toBe('KANBAN.md')
    expect(o.columns).toEqual([])
    expect(o.error).toContain('no columns')
  })
})
