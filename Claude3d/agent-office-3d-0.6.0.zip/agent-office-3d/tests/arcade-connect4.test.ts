// Connect Four's rules: who moves, how discs stack, every kind of four, the
// draw, the forgiving parser that never finds an illegal column, replay,
// the model's prompt and the window's view of the position.

import { describe, expect, test } from 'claude-code/testing'

import { GAME, type Connect4State } from '../src/arcade/connect4'

const after = (moves: string): Connect4State => GAME.replay(moves === '' ? [] : moves.split(' '))
/** The disc at a column letter and a 1-based row. */
const at = (s: Connect4State, col: string, row: number) => s.cells[(row - 1) * 7 + 'abcdefg'.indexOf(col)]
const view = (s: Connect4State) => GAME.out(s) as { cols: number; rows: number; cells: (string | null)[]; lastMove: string | null; winningLine: number[] | null }

describe('connect4: turns and stacking', () => {
  test('the module describes itself as rules.ts asks', async () => {
    expect(GAME.kind).toBe('connect4')
    expect(GAME.title).toBe('Connect Four')
    expect(GAME.sides).toEqual({ a: 'Red', b: 'Yellow' })
  })

  test('Red (side a) moves first and the sides alternate', async () => {
    const s = GAME.initial()
    expect(GAME.turn(s)).toBe('a')
    expect(GAME.status(s)).toEqual({ over: false })
    expect(GAME.turn(GAME.play(s, 'd'))).toBe('b')
    expect(GAME.turn(after('d d'))).toBe('a')
    expect(GAME.turn(after('d d d'))).toBe('b')
  })

  test('every column is legal at the start, and discs stack from the bottom', async () => {
    expect(GAME.legal(GAME.initial())).toEqual(['a', 'b', 'c', 'd', 'e', 'f', 'g'])
    const s = after('d d d')
    expect(at(s, 'd', 1)).toBe('a')
    expect(at(s, 'd', 2)).toBe('b')
    expect(at(s, 'd', 3)).toBe('a')
    expect(at(s, 'd', 4)).toBe(null)
    expect(at(s, 'c', 1)).toBe(null)
    expect(s.cells.filter(c => c !== null).length).toBe(3)
  })

  test('a full column is no longer legal and cannot be played', async () => {
    const s = after('d d d d d d')
    expect(at(s, 'd', 6)).toBe('b')
    expect(GAME.legal(s)).toEqual(['a', 'b', 'c', 'e', 'f', 'g'])
    expect(() => GAME.play(s, 'd')).toThrow()
    expect(() => GAME.play(GAME.initial(), 'h')).toThrow()
    expect(() => GAME.play(GAME.initial(), '4')).toThrow() // play takes the letter legal lists, nothing looser
  })

  test('play leaves the given state alone', async () => {
    const s = GAME.initial()
    GAME.play(s, 'a')
    expect(s.cells.every(c => c === null)).toBe(true)
    expect(s.moves).toEqual([])
    expect(GAME.turn(s)).toBe('a')
  })
})

describe('connect4: results', () => {
  test('four along the bottom row wins for Red, and nothing is legal afterwards', async () => {
    const s = after('a a b b c c')
    expect(GAME.status(s)).toEqual({ over: false })
    const won = GAME.play(s, 'd')
    expect(GAME.status(won)).toEqual({ over: true, winner: 'a', result: 'four in a row' })
    expect(GAME.legal(won)).toEqual([])
    expect(() => GAME.play(won, 'e')).toThrow()
    expect(view(won).winningLine).toEqual([0, 1, 2, 3])
  })

  test('four along a row above the bottom wins', async () => {
    // Row 1: R Y R Y R Y ... then Yellow takes b2 c2 d2 e2? Red first: build Red's four on row 2 instead.
    // Red: b2 c2 d2 e2 over a row 1 of Yellow discs; Yellow's fillers go to g.
    const s = after('b b c c d d e')
    // b1 R, b2 Y, c1 R, c2 Y, d1 R, d2 Y, e1 R: Yellow has b2 c2 d2, Red has b1 c1 d1 e1 -> Red already won on row 1.
    expect(GAME.status(s)).toEqual({ over: true, winner: 'a', result: 'four in a row' })
    expect(view(s).winningLine).toEqual([1, 2, 3, 4])
    // Yellow's turn to complete row 2: block Red first with a different build.
    const t = after('a b a c a d g e')
    // a1 R, b1 Y, a2 R, c1 Y, a3 R, d1 Y, g1 R, e1 Y -> Yellow b1 c1 d1 e1
    expect(GAME.status(t)).toEqual({ over: true, winner: 'b', result: 'four in a row' })
    expect(view(t).winningLine).toEqual([1, 2, 3, 4])
  })

  test('four up a column wins for Yellow', async () => {
    const s = after('a g a g a g b')
    expect(GAME.status(s)).toEqual({ over: false })
    const won = GAME.play(s, 'g')
    expect(GAME.status(won)).toEqual({ over: true, winner: 'b', result: 'four in a row' })
    expect(view(won).winningLine).toEqual([6, 13, 20, 27])
  })

  test('four on the rising diagonal wins', async () => {
    // Red a1, b2, c3, d4 with Yellow's discs as the steps.
    const s = after('a b b c c g c d d d g g')
    expect(at(s, 'a', 1)).toBe('a')
    expect(at(s, 'b', 2)).toBe('a')
    expect(at(s, 'c', 3)).toBe('a')
    expect(at(s, 'd', 3)).toBe('b')
    expect(GAME.status(s)).toEqual({ over: false })
    const won = GAME.play(s, 'd')
    expect(at(won, 'd', 4)).toBe('a')
    expect(GAME.status(won)).toEqual({ over: true, winner: 'a', result: 'four in a row' })
    expect(view(won).winningLine).toEqual([0, 8, 16, 24])
  })

  test('four on the falling diagonal wins', async () => {
    // Red g1, f2, e3, d4.
    const s = after('g f f e e a e d d d a a')
    expect(at(s, 'g', 1)).toBe('a')
    expect(at(s, 'f', 2)).toBe('a')
    expect(at(s, 'e', 3)).toBe('a')
    expect(GAME.status(s)).toEqual({ over: false })
    const won = GAME.play(s, 'd')
    expect(GAME.status(won)).toEqual({ over: true, winner: 'a', result: 'four in a row' })
    expect(view(won).winningLine).toEqual([6, 12, 18, 24])
  })

  test('a win completed in the top row counts', async () => {
    // Column a: R, Y, then Red a3 a4 a5 a6 while Yellow stacks in b.
    const s = after('a a a b a b a b')
    expect(at(s, 'a', 5)).toBe('a')
    expect(at(s, 'a', 6)).toBe(null)
    expect(GAME.status(s)).toEqual({ over: false })
    expect(GAME.legal(s)).toContain('a')
    const won = GAME.play(s, 'a')
    expect(at(won, 'a', 6)).toBe('a')
    expect(GAME.status(won)).toEqual({ over: true, winner: 'a', result: 'four in a row' })
    expect(view(won).winningLine).toEqual([14, 21, 28, 35])
    expect(GAME.legal(won)).toEqual([])
  })

  test('a full board with no four is a draw', async () => {
    // Columns a, b, d, e, g read R Y R Y R Y from the bottom; c and f read Y R Y R Y R:
    // rows run R R Y R R Y R, columns alternate, and no diagonal runs past three.
    const moves = [
      ...'aaaaaa', ...'bbbbbb',
      ...'dccddccddccd',
      ...'eeeeee',
      ...'gffggffggffg',
    ]
    const s = GAME.replay(moves)
    expect(s.moves.length).toBe(42)
    expect(s.cells.every(c => c !== null)).toBe(true)
    expect(at(s, 'c', 1)).toBe('b')
    expect(at(s, 'f', 6)).toBe('a')
    expect(GAME.status(s)).toEqual({ over: true, winner: null, result: 'draw' })
    expect(GAME.legal(s)).toEqual([])
    expect(view(s).winningLine).toBe(null)
    expect(GAME.parse(s, 'a')).toBe(null)
  })
})

describe('connect4: parsing and replay', () => {
  test('parse reads a column forgivingly', async () => {
    const s = GAME.initial()
    const forms = ['c', 'C', ' c ', 'col c', 'column c', 'Column C', 'col: c', 'COL-C', '3', '3.', 'c.', 'c!', 'c,', '"c"', "'c'", '(c)', 'c\nbecause the centre is strong', '\n\nc\n']
    for (const text of forms) expect([text, GAME.parse(s, text)]).toEqual([text, 'c'])
    expect(GAME.parse(s, '1')).toBe('a')
    expect(GAME.parse(s, '7')).toBe('g')
    expect(GAME.parse(s, 'column 7')).toBe('g')
    expect(GAME.parse(s, 'A')).toBe('a')
    expect(GAME.parse(s, 'g')).toBe('g')
  })

  test('parse never names a column legal leaves out', async () => {
    const s = after('d d d d d d')
    expect(GAME.parse(s, 'd')).toBe(null)
    expect(GAME.parse(s, '4')).toBe(null)
    expect(GAME.parse(s, 'column d')).toBe(null)
    expect(GAME.parse(s, 'e')).toBe('e')
    const fresh = GAME.initial()
    for (const text of ['h', 'H', '8', '0', 'cd', 'c4', 'dc', 'the middle', '', '   ', 'column', 'col', 'resign', 'c d', 'c or d']) {
      expect([text, GAME.parse(fresh, text)]).toEqual([text, null])
    }
    const won = after('a a b b c c d')
    expect(GAME.parse(won, 'e')).toBe(null)
  })

  test('replay stops at the first bad move', async () => {
    const s = GAME.replay(['d', 'd', 'h', 'e'])
    expect(s.moves).toEqual(['d', 'd'])
    expect(GAME.turn(s)).toBe('a')
    const full = GAME.replay(['d', 'd', 'd', 'd', 'd', 'd', 'd', 'e'])
    expect(full.moves).toEqual(['d', 'd', 'd', 'd', 'd', 'd'])
    const won = GAME.replay(['a', 'a', 'b', 'b', 'c', 'c', 'd', 'e', 'f'])
    expect(won.moves).toEqual(['a', 'a', 'b', 'b', 'c', 'c', 'd'])
    expect(GAME.replay([]).moves).toEqual([])
    expect(GAME.replay([])).toEqual(GAME.initial())
  })

  test('replay reproduces what play built', async () => {
    let s = GAME.initial()
    for (const m of ['d', 'c', 'd', 'e', 'b']) s = GAME.play(s, m)
    expect(GAME.replay(s.moves)).toEqual(s)
  })

  test('history names each move by side letter and column', async () => {
    expect(GAME.history(after('d c d'))).toEqual(['Rd', 'Yc', 'Rd'])
    expect(GAME.history(GAME.initial())).toEqual([])
  })

  test('ascii draws row 1 at the bottom with the column letters under it', async () => {
    const s = after('d d a')
    const lines = GAME.ascii(s).split('\n')
    expect(lines.length).toBe(7)
    expect(lines[0]).toBe('6  . . . . . . .')
    expect(lines[4]).toBe('2  . . . Y . . .')
    expect(lines[5]).toBe('1  R . . R . . .')
    expect(lines[6]).toBe('   a b c d e f g')
  })
})

describe('connect4: the prompt and the window', () => {
  test('prompt names the side, lists the legal columns and the refusal when given', async () => {
    const s = after('d d d d d d')
    const p = GAME.prompt(s, 'a', null)
    expect(p.system).toContain('Connect Four')
    expect(p.system).toContain('column letter alone on the first line')
    expect(p.prompt).toContain('You are Red (R).')
    expect(p.prompt).toContain('Legal columns: a, b, c, e, f, g')
    expect(p.prompt).toContain('Moves so far: Rd Yd Rd Yd Rd Yd')
    expect(p.prompt).toContain("It is Red's turn (yours).")
    expect(p.prompt).toContain(GAME.ascii(s))
    expect(p.prompt).not.toContain('refused')
    const q = GAME.prompt(s, 'b', 'd is full.')
    expect(q.prompt).toContain('You are Yellow (Y).')
    expect(q.prompt).toContain('Your previous answer was refused: d is full. Choose from the legal columns above.')
    expect(GAME.prompt(GAME.initial(), 'a', null).prompt).toContain('Moves so far: (none)')
    expect(GAME.prompt(GAME.initial(), 'a', null).prompt).toContain('Legal columns: a, b, c, d, e, f, g')
  })

  test('out has the window shape: 7 by 6, 42 cells bottom row first, the last column, the winning four', async () => {
    const o = view(GAME.initial())
    expect(o.cols).toBe(7)
    expect(o.rows).toBe(6)
    expect(o.cells.length).toBe(42)
    expect(o.cells.every(c => c === null)).toBe(true)
    expect(o.lastMove).toBe(null)
    expect(o.winningLine).toBe(null)
    const s = after('d c')
    const p = view(s)
    expect(p.lastMove).toBe('c')
    expect(p.cells[3]).toBe('a')
    expect(p.cells[2]).toBe('b')
    expect(p.cells.filter(c => c !== null).length).toBe(2)
    const won = view(after('a a b b c c d'))
    expect(won.winningLine).toEqual([0, 1, 2, 3])
    expect(won.lastMove).toBe('d')
    expect(JSON.parse(JSON.stringify(GAME.out(s)))).toEqual(GAME.out(s))
  })
})
