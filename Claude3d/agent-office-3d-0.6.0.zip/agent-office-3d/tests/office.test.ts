// The agent office's evidence and its in-app pane, exercised through the
// engine's test kit. The hooks on the test's `on` stand for the engine beneath
// the mod: the clock, store, agent list, messages, tool calls, turns and
// session.send. The window itself is a browser page (not drawn here); what it
// is sent is what `/office status` reports.

import { describe, expect, mock, test } from 'claude-code/testing'
import type { On } from 'claude-code'

const PLUGIN = 'agent-office-3d'
const OFFICE = 'agent-office'
const SELF = 'self0000-0000-4000-8000-000000000000'
const PEER = 'peer0000-0000-4000-8000-00000000000p'
const NOW = 1_800_000_000_000
const MY_KEY = `museum.v1.session.${SELF}`

type Agent = { id: string; description: string; type: string; status: string; name?: string; teammateId?: string; parentId?: string }
type Rec = Record<string, unknown>

const agent = (id: string, status: string, extra: Partial<Agent> = {}): Agent => ({ id, description: `task ${id}`, type: 'general-purpose', status, ...extra })

const peerRecord = (extra: Rec = {}): Rec => ({
  v: 1,
  sessionId: PEER,
  label: 'Museum test peer',
  enrolledAt: NOW - 5_000,
  heartbeatAt: NOW - 500,
  status: 'idle',
  needsUser: null,
  messageCount: 1,
  snapshot: [{ role: 'user', text: 'peer line' }],
  receipts: [],
  ...extra,
})

function office(on: On, opts: { store?: Rec; agents?: Agent[] } = {}) {
  const clock = mock.clock(on, { now: NOW })
  const store = new Map<string, unknown>(Object.entries(opts.store ?? {}))
  const agents: Agent[] = [...(opts.agents ?? [])]
  const opened: Rec[] = []
  const permissionRequests: Rec[] = []
  const toolGates = new Map<string, number>()
  on('session.start', ($, e) => ({ cwd: e.cwd }))
  on('session.id', () => ({ value: SELF }))
  on('session.cwd', () => ({ value: '/tmp/office-test' }))
  on('session.messages', () => ({ value: [{ role: 'user', text: 'main line from the person', toolUses: [] }] }))
  on('agent.list', () => ({ value: agents.map(a => ({ ...a })) }))
  on('store.get', ($, e) => ({ value: store.has(e.key) ? JSON.parse(JSON.stringify(store.get(e.key))) : undefined }))
  on('store.set', ($, e) => {
    store.set(e.key, JSON.parse(JSON.stringify(e.value)))
    return { value: undefined }
  })
  on('store.delete', ($, e) => {
    store.delete(e.key)
    return { value: undefined }
  })
  on('store.keys', () => ({ value: [...store.keys()] }))
  on('ui.panes', () => ({ value: opened.map(o => ({ id: String(o.id), title: String(o.title), isShown: true, isFocused: false, isPlaced: true })) }))
  on('ui.open', ($, e) => {
    opened.push({ ...e })
    return { value: { isPlaced: true } }
  })
  on('command.register', ($, e) => ({ value: { name: e.name } }))
  on('ui.log', () => ({ value: undefined }))
  on('turn.start', ($, e) => ({ turnId: e.turnId }))
  on('turn.complete', () => ({ text: '' }))
  on('session.receive', ($, e) => ({ text: e.text }))
  on('classic.PermissionRequest', ($, e) => {
    permissionRequests.push({ ...e })
    return {}
  })
  on('tool.call', async ($, e) => {
    const wait = toolGates.get(String(e.tool)) ?? 0
    if (wait > 0) await clock.sleep(wait)
    return { result: 'ok' }
  })
  return { clock, store, agents, opened, permissionRequests, toolGates }
}

const PANE_PROPS = { title: 'Agent Office', isFocused: true, bodyColumns: 110, placement: 'dock' as const, scroll: { offset: 0, bodyRows: 50 }, view: {} }

async function start($: any) {
  await $.session.start({ cwd: '/tmp/office-test', surface: 'desktop', isInteractive: true })
}
const status = async ($: any) => JSON.parse((await $.command.run({ command: 'office', args: 'status' })).text)
const worker = async ($: any, key: string) => (await status($)).workers.find((w: Rec) => w.key === key)
const mountOffice = ($: any, surface: 'desktop' | 'terminal') =>
  $.ui.mount({ plugin: PLUGIN, surface, component: 'Pane', requestId: OFFICE, props: PANE_PROPS, viewport: { columns: 120, rows: 50, isFullscreen: true } })
const textOf = async (ui: any): Promise<string> => (await ui.findAll({ type: 'Text' })).map((t: any) => t.text).join('\n')

describe('the pane and auto-open', () => {
  test('opens once per session, without focus, and not again on a reload or a later start', async ($, on) => {
    const { opened } = office(on)
    await start($)
    await start($)
    await $.turn.start({ text: 'hello', turnId: 't1' })
    await $.turn.complete({ answer: 'hi', durationMs: 1, isAborted: false, turnId: 't1', reason: 'answer' })
    expect(opened.length).toBe(1)
    expect(opened[0]!.id).toBe(OFFICE)
    expect(opened[0]!.focus).toBeUndefined()
    // Asked for again by the person: it opens (an open id is retitled, never duplicated by the engine).
    await $.command.run({ command: 'office', args: '' })
    expect(opened.length).toBe(2)
    expect(opened.every(o => o.id === OFFICE)).toBe(true)
  })

  test('does not open when the person turned auto-open off', { options: { autoOpen: false } }, async ($, on) => {
    const { opened } = office(on)
    await start($)
    expect(opened.length).toBe(0)
  })

  test('holds the button into the 3D office and the one that removes or adds this project, on both surfaces', async ($, on) => {
    office(on)
    await start($)
    for (const surface of ['desktop', 'terminal'] as const) {
      const ui = await mountOffice($, surface)
      const enter = await ui.find({ type: 'Button', key: 'enter' })
      expect(enter?.text).toContain('Enter the 3D office')
      expect(enter?.props.hotkey).toBe('e')
      expect((await ui.find({ type: 'Button', key: 'toggle' }))?.text).toContain('Remove this project from the office')
      expect(await textOf(ui)).toContain('This project is in the office as')
      expect(await ui.findAll({ type: 'Svg' })).toEqual([])
      await ui.unmount()
    }
  })
})

describe('every project is in the office', () => {
  test('a session enrolls itself when it starts, under its own key only, labelled by its folder', async ($, on) => {
    const { store } = office(on)
    await start($)
    const mine = store.get(MY_KEY) as Rec
    expect(mine.sessionId).toBe(SELF)
    expect(mine.project).toBe('office-test')
    expect(String(mine.label)).toContain('office-test')
    expect([...store.keys()]).toEqual([MY_KEY])
    expect((await status($)).project).toMatchObject({ isInOffice: true, isHidden: false })
  })

  test('not when the option is off', { options: { autoEnroll: false } }, async ($, on) => {
    const { store } = office(on)
    await start($)
    expect(store.has(MY_KEY)).toBe(false)
    expect((await status($)).project.isInOffice).toBe(false)
  })

  test('the pane removes this project: its record goes, the mark keeps later sessions out, and the pane adds it back', async ($, on) => {
    const { store, clock } = office(on)
    await start($)
    const ui = await mountOffice($, 'desktop')
    await ui.press({ key: 'toggle' })
    await clock.settle()
    expect(store.has(MY_KEY)).toBe(false)
    expect([...store.keys()].some(k => k.startsWith('office.v1.hidden.'))).toBe(true)
    expect(await textOf(ui)).toContain('out of the office')
    expect((await ui.find({ type: 'Button', key: 'toggle' }))?.text).toContain('Add this project to the office')
    // A later session of the same project stays out.
    await start($)
    expect(store.has(MY_KEY)).toBe(false)
    expect((await status($)).project).toMatchObject({ isInOffice: false, isHidden: true })
    await ui.press({ key: 'toggle' })
    await clock.settle()
    expect(store.has(MY_KEY)).toBe(true)
    expect([...store.keys()].some(k => k.startsWith('office.v1.hidden.'))).toBe(false)
    expect((await status($)).project.isInOffice).toBe(true)
    await ui.unmount()
  })

  test('/office remove and add do the same from the prompt', async ($, on) => {
    const { store } = office(on)
    await start($)
    expect((await $.command.run({ command: 'office', args: 'remove' })).text).toContain('out of the office')
    expect(store.has(MY_KEY)).toBe(false)
    expect((await $.command.run({ command: 'office', args: 'add' })).text).toContain('in the office as')
    expect(store.has(MY_KEY)).toBe(true)
  })
})

describe('workers come only from actual identities', () => {
  test('only this conversation before any agent exists; an agent appears when listed', async ($, on) => {
    const { clock, agents } = office(on)
    await start($)
    expect((await status($)).workers.map((w: Rec) => w.key)).toEqual(['main'])
    agents.push(agent('a1', 'running', { type: 'general-purpose', description: 'scan the docs' }))
    await clock.advance(1600)
    const w = await worker($, 'agent:a1')
    expect(w).toMatchObject({ kind: 'subagent', group: 'session', state: 'working', light: 'green', icon: '⚙', isListed: true, canSend: true })
    expect(w.evidence).toContain('$.agent.list() says "running"')
  })

  test('each listed status maps to its state, light, icon and label', async ($, on) => {
    const { clock } = office(on, {
      agents: [
        agent('r', 'running'),
        agent('c', 'completed'),
        agent('f', 'failed'),
        agent('k', 'killed'),
        agent('i', 'idle'),
        agent('p', 'pending'),
        agent('w', 'waiting'),
        agent('t', 'idle', { teammateId: 'scout@team', name: 'scout' }),
      ],
    })
    await start($)
    await clock.advance(1600)
    const byKey = Object.fromEntries((await status($)).workers.map((w: Rec) => [w.key, w]))
    const view = (k: string) => [byKey[k].state, byKey[k].light, byKey[k].icon, byKey[k].stateLabel]
    expect(view('agent:r')).toEqual(['working', 'green', '⚙', 'Working'])
    expect(view('agent:c')).toEqual(['completed', 'green', '✓', 'Completed'])
    expect(view('agent:f')).toEqual(['failed', 'red', '✕', 'Failed'])
    expect(view('agent:k')).toEqual(['failed', 'red', '✕', 'Stopped'])
    expect(view('agent:i')).toEqual(['idle', 'yellow', '◌', 'Idle'])
    expect(view('agent:p')).toEqual(['idle', 'yellow', '◌', 'Not started'])
    // `waiting` does not say on what: shown as unknown, never guessed.
    expect(view('agent:w')).toEqual(['unknown', 'off', '?', 'Held (reason not exposed)'])
    expect(byKey['agent:t'].kind).toBe('teammate')
    expect(byKey['agent:t'].name).toBe('scout')
  })

  test("this conversation's state follows its own turns; a turn ending in error shows failed", async ($, on) => {
    office(on)
    await start($)
    expect((await worker($, 'main')).state).toBe('unknown')
    await $.turn.start({ text: 'go', turnId: 'm1' })
    expect((await worker($, 'main')).state).toBe('working')
    await $.turn.complete({ answer: '', durationMs: 1, isAborted: false, turnId: 'm1', reason: 'error' })
    expect(await worker($, 'main')).toMatchObject({ state: 'failed', light: 'red', stateLabel: 'Failed (error)' })
    await $.turn.start({ text: 'again', turnId: 'm2' })
    await $.turn.complete({ answer: 'done', durationMs: 1, isAborted: false, turnId: 'm2', reason: 'answer' })
    expect((await worker($, 'main')).state).toBe('idle')
  })

  test('enrolled peers are a separate group; a silent peer shows disconnected, not working', async ($, on) => {
    const { clock, store } = office(on, { store: { [`museum.v1.session.${PEER}`]: peerRecord({ status: 'busy' }) } })
    await start($)
    const p = await worker($, `peer:${PEER}`)
    expect(p).toMatchObject({ kind: 'peer', group: 'peers', state: 'working' })
    store.set(`museum.v1.session.${PEER}`, peerRecord({ heartbeatAt: NOW - 60_000, status: 'busy' }))
    await clock.advance(1600)
    expect(await worker($, `peer:${PEER}`)).toMatchObject({ state: 'unknown', light: 'off', stateLabel: 'Disconnected' })
  })
})

describe('hands', () => {
  test('an AskUserQuestion in flight raises a hand with the actual question; it clears when answered', async ($, on) => {
    const { clock, toolGates } = office(on)
    await start($)
    toolGates.set('AskUserQuestion', 1000)
    const asking = $.tool.call({ tool: 'AskUserQuestion', questions: [{ question: 'Ship <b>now</b>?', header: 'Ship', multiSelect: false, options: [] }] } as any)
    await clock.settle()
    const raised = await worker($, 'main')
    expect(raised).toMatchObject({ state: 'needs-user', light: 'red', icon: '✋', hand: { kind: 'question', text: 'Ship <b>now</b>?' } })
    const ui = await mountOffice($, 'desktop')
    expect(await textOf(ui)).toContain('1 hand up')
    await ui.unmount()
    await clock.advance(1000)
    await asking
    expect((await worker($, 'main')).hand).toBe(null)
  })

  test('a call in flight to an external service is a yellow wait, never a hand', async ($, on) => {
    const { clock, toolGates } = office(on)
    await start($)
    await $.turn.start({ text: 'look it up', turnId: 'm1' })
    toolGates.set('WebFetch', 1000)
    const fetching = $.tool.call({ tool: 'WebFetch', url: 'https://example.com', prompt: 'read' } as any)
    await clock.settle()
    expect(await worker($, 'main')).toMatchObject({ state: 'waiting-external', light: 'yellow', hand: null, stateLabel: 'Waiting on WebFetch' })
    await clock.advance(1000)
    await fetching
    expect(await worker($, 'main')).toMatchObject({ state: 'working', hand: null })
  })

  test('a shown permission dialog raises an approval hand; the office passes the event on and decides nothing', async ($, on) => {
    const { clock, toolGates, permissionRequests } = office(on, { agents: [agent('a1', 'running')] })
    await start($)
    await clock.advance(1600)
    toolGates.set('Bash', 1000)
    const running = $.tool.call({ tool: 'Bash', command: 'rm -rf build', agentId: 'a1' } as any)
    await clock.settle()
    const answer = await $.classic.PermissionRequest({ tool_name: 'Bash', tool_input: { command: 'rm -rf build' }, agent_id: 'a1' } as any)
    expect(permissionRequests.length).toBe(1)
    expect(answer).toEqual({})
    const raised = await worker($, 'agent:a1')
    expect(raised).toMatchObject({ state: 'needs-user', hand: { kind: 'approval', text: 'Bash: rm -rf build' } })
    expect((await worker($, 'main')).hand).toBe(null)
    await clock.advance(1000)
    await running
    expect((await worker($, 'agent:a1')).hand).toBe(null)
  })

  test('a peer raises a hand only when it published one from its own hooks', async ($, on) => {
    office(on, { store: { [`museum.v1.session.${PEER}`]: peerRecord({ needsUser: { kind: 'approval', text: 'Edit: config.json' } }) } })
    await start($)
    expect(await worker($, `peer:${PEER}`)).toMatchObject({ state: 'needs-user', hand: { kind: 'approval', text: 'Edit: config.json' } })
  })
})

describe('kept desks: agents the list stops carrying', () => {
  test('a completed general-purpose subagent keeps an honest, sendable desk after the list drops it; resumed, it is live again', async ($, on) => {
    const { clock, agents } = office(on, { agents: [agent('g1', 'running')] })
    await start($)
    await clock.advance(1600)
    agents[0]!.status = 'completed'
    await clock.advance(1600)
    agents.splice(0, 1)
    await clock.advance(1600)
    const kept = await worker($, 'agent:g1')
    expect(kept).toMatchObject({ state: 'completed', stateLabel: 'Completed · not listed', isListed: false, canSend: true })
    expect(kept.evidence).toContain('no longer lists it (last seen "completed")')
    expect(kept.evidence).toContain('a message resumes it from its transcript')
    agents.push(agent('g1', 'running'))
    await clock.advance(1600)
    const live = (await status($)).workers.filter((w: Rec) => w.key === 'agent:g1')
    expect(live.length).toBe(1)
    expect(live[0]).toMatchObject({ state: 'working', isListed: true })
  })

  test('Explore and Plan are one-shot and a stopped agent refuses messages: kept, but no Send', async ($, on) => {
    const { clock, agents } = office(on, {
      agents: [agent('e1', 'completed', { type: 'Explore' }), agent('p1', 'completed', { type: 'Plan' }), agent('k1', 'killed')],
    })
    await start($)
    await clock.advance(1600)
    expect(await worker($, 'agent:e1')).toMatchObject({ canSend: false })
    agents.splice(0, 3)
    await clock.advance(1600)
    for (const id of ['e1', 'p1']) {
      const w = await worker($, `agent:${id}`)
      expect(w).toMatchObject({ isListed: false, canSend: false })
      expect(w.noSendReason).toContain('one-shot')
    }
    expect(await worker($, 'agent:k1')).toMatchObject({ stateLabel: 'Stopped · not listed', canSend: false })
  })

  test('kept desks are bounded', async ($, on) => {
    const ids = Array.from({ length: 12 }, (_, i) => `g${i}`)
    const { clock, agents } = office(on, { agents: ids.map(id => agent(id, 'completed')) })
    await start($)
    await clock.advance(1600)
    agents.splice(0, agents.length)
    await clock.advance(1600)
    const kept = (await status($)).workers.filter((w: Rec) => w.isListed === false)
    expect(kept.length).toBe(8)
  })
})
