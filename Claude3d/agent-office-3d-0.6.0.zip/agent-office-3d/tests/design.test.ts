// The world editor: the vocabulary's gate (what it lets through and what it
// refuses), folding edits without touching the scene given, and the editor
// driven through its exported functions with a hand-made `$` (the engine
// refuses plugin calls from a module outside the registered hooks graph, so
// the test supplies the state, the store, the clock and the model itself):
// a request becomes a preview of only the valid edits with the refused ones
// named, apply persists and keeps the known-good snapshot, undo restores,
// reset clears, and a malformed answer leaves the scene untouched.

import { describe, expect, test } from 'claude-code/testing'

import { applyDesign, designPanel } from '../game/design.js'
import { KNOWN_GOOD_KEY, STORE_KEY, checkEdits, designCommand, designCommandFromWindow, designOut, designSystemPrompt, designTick, loadDesign } from '../hooks/design'
import { BOUNDS, applyEdits, describeEdit, emptyDoc, foldEdits, resolveEdit, validate, validateDoc } from '../src/design/schema'
import type { DesignContext, SceneDoc, SceneEdit } from '../types'

type Rec = Record<string, any>
const round5 = (n: number) => Math.round(n * 1e5) / 1e5

const usage = { input_tokens: 1, output_tokens: 1, cache_creation_input_tokens: 0, cache_read_input_tokens: 0 }

/** The engine beneath the editor: versioned state, a store map, a fixed clock, a model answering from a script. */
function engine(replies: string[]) {
  const state = new Map<string, { value: unknown; version: number }>()
  const store = new Map<string, unknown>()
  const asked: Rec[] = []
  const keyOf = (ref: Rec) => `${ref.plugin}.${ref.key}`
  const $: any = {
    state: {
      get: async (ref: Rec) => state.get(keyOf(ref)) ?? { value: undefined, version: 0 },
      set: async (ref: Rec, value: unknown, opts?: { ifVersion?: number }) => {
        const held = state.get(keyOf(ref)) ?? { value: undefined, version: 0 }
        if (opts?.ifVersion !== undefined && opts.ifVersion !== held.version) return { isSet: false }
        state.set(keyOf(ref), { value, version: held.version + 1 })
        return { isSet: true }
      },
    },
    store: {
      get: async (key: string) => store.get(key),
      set: async (key: string, value: unknown) => void store.set(key, value),
      delete: async (key: string) => void store.delete(key),
      keys: async () => [...store.keys()],
    },
    clock: { now: async () => 1800000000000 },
    model: {
      complete: async (e: Rec) => {
        asked.push(e)
        const text = replies.shift() ?? ''
        return text === '' ? { isAnswered: false, reason: 'empty-reply', usage } : { isAnswered: true, text, usage }
      },
    },
    ui: { log: () => undefined, toast: async () => undefined },
  }
  return { $, store, asked }
}

const ctx: DesignContext = {
  desks: [
    { key: 'main', label: 'Lead', session: 's1' },
    { key: 'agent:a1', label: 'Agent 1', session: 's1' },
    { key: 'peer:s2', label: 'Lead', session: 's2' },
  ],
  rooms: [{ project: 'Office3D-Test', title: 'Office3D-Test' }],
}

const flowers = (id = 'flowers', extra: Rec = {}) => ({
  type: 'addProp',
  prop: {
    id,
    name: 'Flowers',
    anchor: { kind: 'desk', key: 'main' },
    offset: { x: 0.35, y: 0.74, z: 0.1 },
    parts: [
      { shape: 'cylinder', r: 0.04, h: 0.1, color: '#a8664a', roughness: 0.8 },
      { shape: 'cylinder', r: 0.01, h: 0.2, color: '#2f6b3a', at: { x: 0, y: 0.1, z: 0 } },
      { shape: 'sphere', r: 0.03, color: '#ff5a8a', at: { x: 0, y: 0.3, z: 0 } },
    ],
    ...extra,
  },
})
const resize = { type: 'resizeDesk', desk: { kind: 'desk', session: 's1', seat: 'agent 1' }, w: 1.4, d: 0.8 }
const theme = { type: 'theme', carpet: '#334455', deskWood: '#8a6a40' }

const refused = (edit: unknown): string => {
  const r = validate(edit)
  if (r.ok) throw new Error(`accepted: ${JSON.stringify(edit)}`)
  return r.reason
}

describe('the gate', () => {
  test('a correct addProp, resizeDesk and theme pass, normalised', async () => {
    const a = validate(flowers())
    expect(a.ok).toBe(true)
    if (a.ok && a.edit.type === 'addProp') {
      expect(a.edit.prop.yaw).toBe(0)
      expect(a.edit.prop.parts.length).toBe(3)
      expect(a.edit.prop.parts[0]).toEqual({ shape: 'cylinder', r: 0.04, h: 0.1, color: '#a8664a', roughness: 0.8 })
    }
    const r = validate(resize)
    expect(r.ok).toBe(true)
    if (r.ok) expect(r.edit).toEqual({ type: 'resizeDesk', desk: { kind: 'desk', session: 's1', seat: 'agent 1' }, w: 1.4, d: 0.8 })
    const t = validate({ ...theme, walls: '#ABCDEF' })
    expect(t.ok).toBe(true)
    if (t.ok) expect(t.edit).toEqual({ type: 'theme', carpet: '#334455', deskWood: '#8a6a40', walls: '#abcdef' })
    expect(validate({ type: 'room', project: 'arcade', carpet: '#112233', width: 16 }).ok).toBe(true)
    expect(validate({ type: 'moveProp', id: 'flowers', offset: { x: -0.3, y: 0.74, z: 0 } }).ok).toBe(true)
    expect(validate({ type: 'removeProp', id: 'flowers' }).ok).toBe(true)
  })

  test('each attack is refused, with the field named', async () => {
    expect(refused({ ...flowers(), extra: 1 })).toContain('unknown field extra')
    expect(refused(flowers('flowers', { script: 'alert(1)' }))).toContain('unknown field script')
    expect(refused(flowers('flowers', { name: 'x'.repeat(BOUNDS.name + 1) }))).toContain(`at most ${BOUNDS.name}`)
    expect(refused(flowers('flowers', { parts: [{ shape: 'sphere', r: 0.1, color: 'red' }] }))).toContain('hex colour')
    expect(refused(flowers('flowers', { parts: [{ shape: 'sphere', r: 0.1, color: 'rgb(1,2,3)' }] }))).toContain('hex colour')
    expect(refused(flowers('flowers', { name: '<img src=x>' }))).toContain('angle brackets')
    expect(refused(flowers('flowers', { name: 'javascript:alert(1)' }))).toContain('javascript:')
    expect(refused(flowers('flowers', { name: 'url(evil)' }))).toContain('url(')
    expect(refused(flowers('flowers', { name: 'x onload=alert(1)' }))).toContain('event handler')
    expect(refused(flowers('flowers', { name: 'see https://example.com' }))).toContain('URL')
    expect(refused(flowers('flowers', { name: 'data:text/html;base64,AA' }))).toContain('data:')
    expect(refused(flowers('flowers', { parts: [{ shape: 'text', text: '&lt;b&gt;', size: 0.2, color: '#ffffff' }] }))).toContain('HTML entity')
    expect(refused(flowers('flowers', { name: 'a\u0000b' }))).toContain('control')
    expect(refused(flowers('flowers', { id: 'Flowers!' }))).toContain('prop.id')
    expect(refused(flowers('flowers', { parts: [{ shape: 'box', w: 5, h: 0.1, d: 0.1, color: '#ffffff' }] }))).toContain(`between ${BOUNDS.size.min} and ${BOUNDS.size.max}`)
    expect(refused(flowers('flowers', { parts: [{ shape: 'sphere', r: 0.1, color: '#ffffff', at: { x: 0, y: 9, z: 0 } }] }))).toContain('parts[0].at.y')
    expect(refused(flowers('flowers', { parts: [{ shape: 'sphere', r: Number.NaN, color: '#ffffff' }] }))).toContain('must be a number')
    expect(refused(flowers('flowers', { parts: [{ shape: 'sphere', r: 0.1, color: '#ffffff', roughness: 2 }] }))).toContain('roughness')
    expect(refused(flowers('flowers', { parts: [{ shape: 'torus', r: 0.1, color: '#ffffff' }] }))).toContain('shape')
    expect(refused(flowers('flowers', { parts: [{ shape: 'sphere', r: 0.1, w: 1, color: '#ffffff' }] }))).toContain('unknown field w')
    expect(refused(flowers('flowers', { offset: { x: 4, y: 0.74, z: 0 } }))).toContain('prop.offset.x')
    expect(refused(flowers('flowers', { anchor: { kind: 'room', project: 'arcade' }, offset: { x: 0, y: 3.5, z: 0 } }))).toContain('prop.offset.y')
    expect(refused(flowers('flowers', { parts: Array.from({ length: BOUNDS.maxParts + 1 }, () => ({ shape: 'sphere', r: 0.05, color: '#ffffff' })) }))).toContain(`at most ${BOUNDS.maxParts} parts`)
    expect(refused(flowers('flowers', { parts: [] }))).toContain('at least one')
    expect(refused(flowers('flowers', { anchor: { kind: 'android', key: 'main' } }))).toContain('kind')
    expect(refused(flowers('flowers', { anchor: { kind: 'desk' } }))).toContain('needs a key')
    expect(refused(flowers('flowers', { anchor: { kind: 'desk', key: 'main', session: 's1', seat: 'lead' } }))).toContain('not both')
    expect(refused(flowers('flowers', { anchor: { kind: 'desk', session: 's1', seat: 'boss' } }))).toContain('seat')
    expect(refused(flowers('flowers', { anchor: { kind: 'hallway', project: 'x' } }))).toContain('hallway')
    expect(refused(flowers('flowers', { anchor: { kind: 'room' } }))).toContain('project')
    expect(refused({ type: 'resizeDesk', desk: { kind: 'desk', key: 'main' }, w: 9, d: 0.8 })).toContain('edit.w')
    expect(refused({ type: 'resizeDesk', desk: { kind: 'room', project: 'arcade' }, w: 1, d: 0.8 })).toContain('must be a desk')
    expect(refused({ type: 'room', project: 'arcade', width: 40 })).toContain('edit.width')
    expect(refused({ type: 'room', project: 'arcade' })).toContain('needs a carpet')
    expect(refused({ type: 'theme', lights: '#00ff00' })).toContain('unknown field lights')
    expect(refused({ type: 'theme', hand: '#00ff00' })).toContain('unknown field hand')
    expect(refused({ type: 'theme' })).toContain('needs a carpet')
    expect(refused({ type: 'setStatus', key: 'main', light: 'green' })).toContain('edit.type')
    expect(refused({ type: 'moveProp', id: 'flowers' })).toContain('needs an anchor')
    expect(refused('addProp')).toContain('must be an object')
    expect(refused(null)).toContain('must be an object')
    expect(refused([flowers()])).toContain('must be an object')
  })

  test('a scene from the store is checked whole: ids unique, every prop and size within bounds', async () => {
    const good = applyEdits(emptyDoc(), [validate(flowers()).ok ? (validate(flowers()) as any).edit : null])
    expect(validateDoc(good).ok).toBe(true)
    expect(validateDoc(JSON.parse(JSON.stringify(good)))).toEqual({ ok: true, doc: good })
    expect(validateDoc(null).ok).toBe(false)
    expect(validateDoc({ ...good, v: 2 }).ok).toBe(false)
    expect(validateDoc({ ...good, props: [...good.props, ...good.props] })).toMatchObject({ ok: false, reason: expect.stringContaining('used twice') })
    expect(validateDoc({ ...good, desks: { main: { w: 99, d: 0.6 } } })).toMatchObject({ ok: false, reason: expect.stringContaining('doc.desks.main.w') })
    expect(validateDoc({ ...good, theme: { carpet: 'javascript:' } }).ok).toBe(false)
    expect(validateDoc({ ...good, extra: true })).toMatchObject({ ok: false, reason: expect.stringContaining('unknown field extra') })
  })
})

describe('folding edits', () => {
  const edit = (v: unknown): SceneEdit => {
    const r = validate(v)
    if (!r.ok) throw new Error(r.reason)
    return r.edit
  }

  test('applyEdits is pure: the scene given is not changed, and the result is a new scene', async () => {
    const start = emptyDoc()
    const frozen = JSON.stringify(start)
    const one = applyEdits(start, [edit(flowers()), edit(theme), edit({ type: 'room', project: 'arcade', carpet: '#112233' })])
    expect(JSON.stringify(start)).toBe(frozen)
    expect(one.props.map(p => p.id)).toEqual(['flowers'])
    expect(one.theme).toEqual({ carpet: '#334455', deskWood: '#8a6a40' })
    expect(one.rooms).toEqual({ arcade: { carpet: '#112233' } })
    const two = applyEdits(one, [edit({ type: 'moveProp', id: 'flowers', offset: { x: -0.3, y: 0.74, z: 0 }, yaw: 90 }), edit({ type: 'theme', walls: '#ffffff' }), edit({ type: 'room', project: 'arcade', width: 16 })])
    expect(one.props[0]!.offset.x).toBe(0.35)
    expect(two.props[0]!.offset.x).toBe(-0.3)
    expect(two.props[0]!.yaw).toBe(90)
    expect(two.theme).toEqual({ carpet: '#334455', deskWood: '#8a6a40', walls: '#ffffff' })
    expect(two.rooms).toEqual({ arcade: { carpet: '#112233', width: 16 } })
    const three = applyEdits(two, [edit({ type: 'removeProp', id: 'flowers' })])
    expect(two.props.length).toBe(1)
    expect(three.props.length).toBe(0)
    // An addProp with a known id replaces that prop in place.
    const four = applyEdits(two, [edit(flowers('flowers', { name: 'Roses' }))])
    expect(four.props.length).toBe(1)
    expect(four.props[0]!.name).toBe('Roses')
  })

  test('folding is bounded and names what it could not apply', async () => {
    const many = Array.from({ length: BOUNDS.maxProps + 1 }, (_, i) => edit(flowers(`p${i}`)))
    const capped = foldEdits(emptyDoc(), many)
    expect(capped.doc.props.length).toBe(BOUNDS.maxProps)
    expect(capped.refused).toEqual([{ index: BOUNDS.maxProps, reason: `the scene holds at most ${BOUNDS.maxProps} props` }])
    const r2 = foldEdits(emptyDoc(), [edit({ type: 'removeProp', id: 'ghost' }), edit({ type: 'moveProp', id: 'ghost', yaw: 10 }), edit(resize)])
    expect(r2.doc).toEqual(emptyDoc())
    expect(r2.refused.map(r => r.index)).toEqual([0, 1, 2])
    expect(r2.refused[2]!.reason).toContain('not resolved')
    // A move onto an anchor whose bounds the offset breaks is refused, and the prop stays where it was.
    // (With the anchor given, the validator itself refuses an offset outside it; without one, the fold checks against the prop's anchor.)
    expect(refused({ type: 'moveProp', id: 'flowers', anchor: { kind: 'desk', key: 'main' }, offset: { x: 50, y: 0, z: 0 } })).toContain('edit.offset.x')
    const far = foldEdits(applyEdits(emptyDoc(), [edit(flowers())]), [edit({ type: 'moveProp', id: 'flowers', anchor: { kind: 'hallway' }, offset: { x: 50, y: 0, z: 0 } }), edit({ type: 'moveProp', id: 'flowers', offset: { x: -5, y: 0, z: 0 } })])
    expect(far.doc.props[0]!.anchor).toEqual({ kind: 'hallway' })
    expect(far.doc.props[0]!.offset.x).toBe(50)
    expect(far.refused).toEqual([{ index: 1, reason: 'offset.x: must be between 0 and 60' }])
  })

  test('anchors are resolved against the office: a seat becomes its key; a desk or room that is not there refuses the edit', async () => {
    const r = resolveEdit(edit(resize), ctx)
    expect(r).toEqual({ ok: true, edit: { type: 'resizeDesk', desk: { kind: 'desk', key: 'agent:a1' }, w: 1.4, d: 0.8 } })
    expect(resolveEdit(edit({ ...resize, desk: { kind: 'desk', session: 's1', seat: 'agent 2' } }), ctx)).toMatchObject({ ok: false, reason: expect.stringContaining('no agent 2 desk') })
    expect(resolveEdit(edit(flowers('f', { anchor: { kind: 'desk', key: 'peer:nobody' } })), ctx)).toMatchObject({ ok: false, reason: expect.stringContaining('no desk has the key') })
    expect(resolveEdit(edit(flowers('f', { anchor: { kind: 'room', project: 'Nope' } })), ctx)).toMatchObject({ ok: false, reason: expect.stringContaining('no room') })
    expect(resolveEdit(edit(flowers('f', { anchor: { kind: 'room', project: 'arcade' } })), ctx).ok).toBe(true)
    expect(resolveEdit(edit({ type: 'room', project: 'Nope', carpet: '#000000' }), ctx).ok).toBe(false)
    expect(resolveEdit(edit({ type: 'room', project: 'Office3D-Test', carpet: '#000000' }), ctx).ok).toBe(true)
    expect(describeEdit(edit(flowers()))).toBe('add "Flowers" (flowers: 3 parts) at the desk of main + (0.35 m, 0.74 m, 0.1 m)')
    expect(describeEdit(edit(resize))).toBe('resize the agent 1 desk of session s1 to 1.4 m by 0.8 m')
  })
})

const answer = (edits: unknown[], explanation = 'Done.') => JSON.stringify({ edits, explanation })
const design = async ($: any) => JSON.parse(await designCommand($, 'status'))

describe('the editor', () => {
  test('a request is queued by the command and performed by the tick: the preview holds only the valid edits, and the error names the refused ones', async () => {
    const { $, store, asked } = engine([
      '```json\n' + answer([flowers(), { type: 'addProp', prop: { ...flowers('bad').prop, name: '<script>' } }, { type: 'theme', carpet: 'blue' }, resize, { type: 'room', project: 'Nope', carpet: '#000000' }], 'Flowers on your desk, and a wider desk for agent 1.') + '\n```',
    ])
    await loadDesign($)
    expect(await designCommand($, 'status')).toContain('"busy": false')
    const queued = await designCommand($, 'I want flowers on my desk')
    expect(queued).toContain('Queued')
    let d = await design($)
    expect(d.busy).toBe(true)
    expect(d.pending).toEqual({ request: 'I want flowers on my desk', edits: [], explanation: '' })
    expect(asked.length).toBe(0)
    expect(await designCommand($, 'make it red')).toContain('still being worked on')
    await designTick($, ctx)
    expect(asked.length).toBe(1)
    expect(asked[0]).toMatchObject({ model: 'sonnet', effort: 'medium', maxTokens: 1500, timeoutMs: 120000, prompt: 'Request: I want flowers on my desk' })
    expect(asked[0]!.system).toContain('"type":"addProp"')
    expect(asked[0]!.system).toContain('key "agent:a1": Agent 1 of session s1')
    expect(asked[0]!.system).toContain('project "Office3D-Test"')
    expect(asked[0]!.system).toContain('Props: none yet.')
    expect(asked[0]!.system).toContain('JSON only')
    d = await design($)
    expect(d.busy).toBe(false)
    expect(d.doc).toEqual(emptyDoc())
    expect(d.preview.props.map((p: Rec) => p.id)).toEqual(['flowers'])
    expect(d.preview.desks).toEqual({ 'agent:a1': { w: 1.4, d: 0.8 } })
    expect(d.pending.edits.length).toBe(2)
    expect(d.pending.explanation).toBe('Flowers on your desk, and a wider desk for agent 1.')
    expect(d.error).toContain('Refused 3 of 5')
    expect(d.error).toContain('#2 (addProp): prop.name: contains angle brackets')
    expect(d.error).toContain('#3 (theme): edit.carpet: must be a hex colour')
    expect(d.error).toContain('#5 (room): edit.project: no room for the project Nope')
    expect(store.size).toBe(0) // nothing persisted until apply
    const out = await designOut($, ctx)
    expect(out.isPreview).toBe(true)
    expect(out.changed).toEqual(['flowers'])
    expect(out.doc).toEqual(d.preview)
    expect(out.pending?.words).toEqual(['add "Flowers" (flowers: 3 parts) at the desk of main + (0.35 m, 0.74 m, 0.1 m)', 'resize the desk of agent:a1 to 1.4 m by 0.8 m'])
    expect(out.history).toBe(0)
    expect(out.anchors.desks.length).toBe(3)
    // A tick with nothing queued asks nothing.
    await designTick($, ctx)
    expect(asked.length).toBe(1)
  })

  test('apply persists the scene with a known-good snapshot of what it replaced; undo restores; reset clears; the window takes the same actions', async () => {
    const { $, store } = engine([answer([flowers()]), answer([theme, { type: 'room', project: 'arcade', carpet: '#223344' }])])
    await loadDesign($)
    expect(await designCommand($, 'apply')).toContain('no preview')
    expect(await designCommand($, 'undo')).toContain('nothing to undo')
    await designCommand($, 'flowers please')
    await designTick($, ctx)
    expect(await designCommand($, 'apply')).toContain('Applied 1 edit')
    const first = (await design($)).doc
    expect(first.props.map((p: Rec) => p.id)).toEqual(['flowers'])
    expect(store.get(STORE_KEY)).toEqual(first)
    expect(store.get(KNOWN_GOOD_KEY)).toEqual(emptyDoc())
    expect((await designOut($, ctx)).isPreview).toBe(false)
    // The second request goes through the window's commands.
    expect(await designCommandFromWindow($, { type: 'design', action: 'request', text: 'a dark theme and a blue arcade carpet' })).toContain('Queued')
    await designTick($, ctx)
    let out = await designOut($, ctx)
    expect(out.isPreview).toBe(true)
    expect(out.changed).toEqual([]) // no prop changed: the theme and a room did
    expect(out.doc.theme).toEqual({ carpet: '#334455', deskWood: '#8a6a40' })
    expect(await designCommandFromWindow($, { type: 'design', action: 'apply' })).toContain('Applied 2 edits')
    const second = (await design($)).doc
    expect(store.get(STORE_KEY)).toEqual(second)
    expect(store.get(KNOWN_GOOD_KEY)).toEqual(first)
    expect((await design($)).history.length).toBe(2)
    // Undo goes back one applied scene, and persists that too.
    expect(await designCommand($, 'undo')).toContain('Went back')
    expect((await design($)).doc).toEqual(first)
    expect(store.get(STORE_KEY)).toEqual(first)
    expect(store.get(KNOWN_GOOD_KEY)).toEqual(second)
    // A remove from the window is a preview too; cancel drops it.
    expect(await designCommandFromWindow($, { type: 'design', action: 'remove', id: 'flowers' })).toContain('Preview: remove the prop flowers')
    out = await designOut($, ctx)
    expect(out.isPreview).toBe(true)
    expect(out.doc.props).toEqual([])
    expect(await designCommandFromWindow($, { type: 'design', action: 'cancel' })).toContain('dropped')
    expect((await design($)).doc).toEqual(first)
    expect(await designCommandFromWindow($, { type: 'design', action: 'remove', id: '<b>' })).toContain('Not removed')
    expect(await designCommandFromWindow($, { type: 'arcade', action: 'reset' })).toBe(null)
    expect(await designCommandFromWindow($, { type: 'design', action: 'format' })).toBe(null)
    // Reset empties the scene; undo brings it back.
    expect(await designCommand($, 'reset')).toContain('empty')
    expect((await design($)).doc).toEqual(emptyDoc())
    expect(store.get(STORE_KEY)).toEqual(emptyDoc())
    expect(store.get(KNOWN_GOOD_KEY)).toEqual(first)
    await designCommandFromWindow($, { type: 'design', action: 'undo' })
    expect((await design($)).doc).toEqual(first)
    expect(await designCommand($, 'list')).toContain('flowers "Flowers": 3 parts at the desk of main')
    // A new engine loads what was persisted.
    const again = engine([])
    for (const [k, v] of store) again.store.set(k, v)
    await loadDesign(again.$)
    expect((await design(again.$)).doc).toEqual(first)
  })

  test('a malformed answer, an empty one, and no answer leave the scene untouched, with the error', async () => {
    const { $, store } = engine(['Sure! Here are the flowers you wanted.', '{"edits": "none"}', answer([], 'Status lights are not something I can change.'), ''])
    await loadDesign($)
    await designCommand($, 'flowers')
    await designTick($, ctx)
    let d = await design($)
    expect(d.doc).toEqual(emptyDoc())
    expect(d.preview).toBe(null)
    expect(d.pending).toBe(null)
    expect(d.busy).toBe(false)
    expect(d.error).toContain('not the JSON expected')
    expect(d.error).toContain('Sure! Here are the flowers')
    await designCommand($, 'flowers')
    await designTick($, ctx)
    expect((await design($)).error).toContain('not the JSON expected')
    await designCommand($, 'make the lights green')
    await designTick($, ctx)
    d = await design($)
    expect(d.preview).toBe(null)
    expect(d.pending).toEqual({ request: 'make the lights green', edits: [], explanation: 'Status lights are not something I can change.' })
    expect(d.error).toContain('No edits: Status lights are not something I can change.')
    expect(await designCommand($, 'cancel')).toContain('dropped')
    await designCommand($, 'flowers')
    await designTick($, ctx)
    expect((await design($)).error).toContain('no answer')
    expect((await design($)).doc).toEqual(emptyDoc())
    expect(store.size).toBe(0)
  })

  test('cancel during the model call drops the answer; a corrupt store falls back to the known-good scene', async () => {
    let release: () => void = () => undefined
    const gate = new Promise<void>(r => (release = r))
    const { $, store } = engine([])
    $.model.complete = async () => {
      await gate
      return { isAnswered: true, text: answer([flowers()]), usage }
    }
    await loadDesign($)
    await designCommand($, 'flowers')
    const ticking = designTick($, ctx)
    expect(await designCommand($, 'cancel')).toContain('cancelled')
    release()
    await ticking
    const d = await design($)
    expect(d.preview).toBe(null)
    expect(d.pending).toBe(null)
    expect(d.busy).toBe(false)
    // The store: a scene that fails the check gives way to the known-good one, and the person is told.
    const good = applyEdits(emptyDoc(), [(validate(flowers()) as any).edit])
    store.set(STORE_KEY, { v: 1, props: [{ id: 'x', name: '<script>', anchor: { kind: 'hallway' }, offset: { x: 0, y: 0, z: 0 }, yaw: 0, parts: [] }], desks: {}, rooms: {}, theme: {} })
    store.set(KNOWN_GOOD_KEY, good)
    await loadDesign($)
    let loaded = await design($)
    expect(loaded.doc).toEqual(good)
    expect(loaded.error).toContain('known-good')
    store.set(KNOWN_GOOD_KEY, 'garbage')
    await loadDesign($)
    loaded = await design($)
    expect(loaded.doc).toEqual(emptyDoc())
    expect(loaded.error).toContain('empty scene')
  })

  test('the prompt carries the vocabulary, the bounds and the scene; more edits than allowed are cut and said', async () => {
    const doc = applyEdits(emptyDoc(), [(validate(flowers()) as any).edit])
    const system = designSystemPrompt(doc, ctx)
    expect(system).toContain(`at most ${BOUNDS.maxEdits} edits per answer`)
    expect(system).toContain('- flowers "Flowers": 3 parts at the desk of main')
    expect(system).toContain('project "arcade": the Agent Arcade')
    expect(system).toContain('cannot change status lights')
    const many = Array.from({ length: BOUNDS.maxEdits + 2 }, (_, i) => flowers(`p${i}`))
    const { edits, refused } = checkEdits(many, ctx)
    expect(edits.length).toBe(BOUNDS.maxEdits)
    expect(refused).toEqual([`2 more edits past the ${BOUNDS.maxEdits} allowed`])
  })
})

/** A stub of the few three.js classes the renderer uses, recording what it builds. */
function stubThree() {
  class Vec {
    x = 0
    y = 0
    z = 0
    set(x: number, y: number, z: number) {
      this.x = x
      this.y = y
      this.z = z
    }
  }
  class Obj {
    name = ''
    visible = true
    position = new Vec()
    rotation = new Vec()
    children: Obj[] = []
    add(o: Obj) {
      this.children.push(o)
    }
    remove(o: Obj) {
      this.children = this.children.filter(c => c !== o)
    }
    traverse(fn: (o: Obj) => void) {
      fn(this)
      for (const c of this.children) c.traverse(fn)
    }
  }
  class Mesh extends Obj {
    castShadow = false
    receiveShadow = false
    constructor(
      public geometry: Rec,
      public material: Rec,
    ) {
      super()
    }
  }
  const geo = (kind: string) =>
    class {
      kind = kind
      args: unknown[]
      constructor(...args: unknown[]) {
        this.args = args
      }
      dispose() {}
    }
  class Material {
    [k: string]: unknown
    constructor(p: Rec) {
      Object.assign(this, p)
    }
    dispose() {}
  }
  class Texture {
    canvas: unknown
    constructor(c: unknown) {
      this.canvas = c
    }
    dispose() {}
  }
  return {
    Group: Obj,
    Mesh,
    BoxGeometry: geo('box'),
    CylinderGeometry: geo('cylinder'),
    ConeGeometry: geo('cone'),
    SphereGeometry: geo('sphere'),
    PlaneGeometry: geo('plane'),
    MeshStandardMaterial: Material,
    MeshBasicMaterial: Material,
    CanvasTexture: Texture,
    SRGBColorSpace: 'srgb',
    DoubleSide: 2,
  }
}

describe('the window', () => {
  const winCtx = {
    deskPosition: (key: string) => (key === 'main' ? { x: 10, z: 5, yaw: Math.PI / 2 } : null),
    roomRect: (project: string) => (project === 'arcade' ? { x0: 0.5, z0: 4, x1: 14.5, z1: 18 } : null),
    hallway: { x0: 0, z0: 0, x1: 46, z1: 4 },
  }

  test('props are built from the data at their anchors, rebuilt only when they change, translucent in a preview, hidden when the anchor is gone', async () => {
    const THREE = stubThree()
    const scene = new THREE.Group()
    const groups: Rec = {}
    const doc = applyEdits(emptyDoc(), [
      (validate(flowers()) as any).edit,
      (validate({ type: 'addProp', prop: { id: 'sign', name: 'Sign', anchor: { kind: 'room', project: 'arcade' }, offset: { x: 0, y: 2, z: -6 }, parts: [{ shape: 'box', w: 1, h: 0.5, d: 0.05, color: '#ffffff' }] } }) as any).edit,
      (validate({ type: 'addProp', prop: { id: 'lost', name: 'Lost', anchor: { kind: 'desk', key: 'gone' }, offset: { x: 0, y: 0, z: 0 }, parts: [{ shape: 'cone', r: 0.2, h: 0.5, color: '#ff0000' }] } }) as any).edit,
    ])
    const out = applyDesign(THREE, scene, groups, { doc, isPreview: true, changed: ['sign'] }, winCtx)
    expect(scene.children.length).toBe(1)
    expect(groups.design.children.length).toBe(3)
    expect(out.drawn).toBe(2)
    const flowersNode = groups.designNodes.get('flowers')
    const signNode = groups.designNodes.get('sign')
    const lostNode = groups.designNodes.get('lost')
    // The desk at (10, 5) faces yaw π/2: the offset (0.35, 0.74, 0.1) turns with it.
    expect(round5(flowersNode.group.position.x)).toBe(round5(10 + 0.1))
    expect(round5(flowersNode.group.position.z)).toBe(round5(5 - 0.35))
    expect(flowersNode.group.position.y).toBe(0.74)
    expect(round5(flowersNode.group.rotation.y)).toBe(round5(Math.PI / 2))
    expect(flowersNode.group.children.length).toBe(3)
    expect(flowersNode.group.children[0].material.transparent).toBe(false)
    expect(flowersNode.group.children[0].material.color).toBe('#a8664a')
    expect(flowersNode.group.children[0].material.roughness).toBe(0.8)
    expect(flowersNode.group.children[0].position.y).toBe(0.05) // a cylinder rises from its `at`
    expect(round5(flowersNode.group.children[2].position.y)).toBe(round5(0.33)) // a sphere rests on it
    expect(signNode.group.position.x).toBe(7.5)
    expect(signNode.group.position.z).toBe(5)
    expect(signNode.group.children[0].material.transparent).toBe(true)
    expect(signNode.group.children[0].material.opacity).toBe(0.45)
    expect(lostNode.group.visible).toBe(false)
    // Applied: the sign is rebuilt opaque, the flowers are kept as they were.
    const again = applyDesign(THREE, scene, groups, { doc, isPreview: false, changed: [] }, winCtx)
    expect(again.group).toBe(groups.design)
    expect(groups.designNodes.get('flowers')).toBe(flowersNode)
    expect(groups.designNodes.get('sign')).not.toBe(signNode)
    expect(groups.designNodes.get('sign').group.children[0].material.transparent).toBe(false)
    expect(again.theme).toEqual({})
    // A prop gone from the scene is removed; the rest of the scene is handed back for the host.
    const less = { ...applyEdits(doc, [(validate({ type: 'removeProp', id: 'sign' }) as any).edit, (validate(theme) as any).edit]), desks: { main: { w: 1.2, d: 0.7 } } }
    const third = applyDesign(THREE, scene, groups, { doc: less, isPreview: false, changed: [] }, winCtx)
    expect(groups.design.children.length).toBe(2)
    expect(groups.designNodes.has('sign')).toBe(false)
    expect(third.theme).toEqual({ carpet: '#334455', deskWood: '#8a6a40' })
    expect(third.desks).toEqual({ main: { w: 1.2, d: 0.7 } })
    // Nothing at all draws nothing and throws nothing.
    expect(applyDesign(THREE, scene, groups, null, winCtx).drawn).toBe(0)
    expect(groups.design.children.length).toBe(0)
  })

  test('the panel escapes every string, offers the actions as data-design buttons, and lists the props with a remove button each', async () => {
    const doc = applyEdits(emptyDoc(), [(validate(flowers('f1', { name: 'Tom & Jerry' })) as any).edit])
    const html = designPanel({
      doc,
      isPreview: true,
      changed: ['f1'],
      pending: { request: 'flowers <b>now</b>', edits: [], explanation: 'Said "ok" & more', words: ['add "Flowers" <here>'] },
      busy: false,
      error: 'Refused #2: <script>',
      history: 2,
    })
    expect(html).toContain('flowers &lt;b&gt;now&lt;/b&gt;')
    expect(html).toContain('Said &quot;ok&quot; &amp; more')
    expect(html).toContain('<li>add &quot;Flowers&quot; &lt;here&gt;</li>')
    expect(html).toContain('Refused #2: &lt;script&gt;')
    expect(html).toContain('Tom &amp; Jerry')
    expect(html).not.toContain('<script>')
    expect(html).not.toContain('<b>now')
    expect(html).toContain('<button data-design="apply">Apply</button>')
    expect(html).toContain('<button data-design="cancel">Cancel</button>')
    expect(html).toContain('<button data-design="undo">Undo (2)</button>')
    expect(html).toContain('<button data-design="reset">Reset</button>')
    expect(html).toContain('<button data-design="remove" data-id="f1">remove</button>')
    expect(html).toContain('data-design="request"')
    expect(html).not.toContain('onclick')
    const idle = designPanel({ doc: emptyDoc(), isPreview: false, changed: [], pending: null, busy: false, error: null, history: 0 })
    expect(idle).toContain('<button data-design="apply" disabled>Apply</button>')
    expect(idle).toContain('<button data-design="undo" disabled>Undo</button>')
    expect(idle).toContain('no props yet')
    expect(designPanel({ busy: true })).toContain('Asking the model')
    expect(designPanel(undefined)).toContain('World editor')
  })
})
