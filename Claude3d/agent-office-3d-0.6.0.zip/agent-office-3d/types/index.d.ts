// The mod's state contract: the session values it keeps in $.state, and the
// shapes it shares between sessions through $.store.

// The contract is one self-contained file (the engine reads it whole): the world editor, the escape room
// and the kanban board declare their shapes below, beside the office's own.

/** One line of a conversation's own transcript, already made inert. */
export type MuseumLine = { role: 'user' | 'assistant'; text: string }

export type TurnReason = 'answer' | 'aborted' | 'refusal' | 'error'

/**
 * What a receiving loop observed about one message sent to it, each field on
 * its own hook's evidence. For an enrolled peer the peer writes it into its
 * own store key; for this session's own agents this session records it.
 */
export type MuseumReceipt = {
  nonce: string
  /** session.receive saw it (before any approval and before any model read). */
  arrivedAt: number
  originKind: string
  /** The sending plugin as the sender claims it; shown, never trusted. */
  claimedPlugin: string | null
  /** A row of the receiver's own $.session.messages() carries the nonce. */
  inConversationAt: number | null
  /** The first turn of that loop that started after arrival. */
  turnStartedAt: number | null
  turnId: string | null
  /** That turn's start text carries the nonce: the link is confirmed. */
  turnCarriesNonce: boolean
  turnEndedAt: number | null
  turnReason: TurnReason | null
  /** The start of that turn's final text, inert, as turn.complete gave it. */
  turnAnswerHead: string | null
  /** That final text carries `ACK <nonce>` (the test conversations' protocol). */
  acknowledged: boolean
}

/** What an enrolled conversation publishes about a question or approval it is waiting on. */
export type MuseumNeedsUser = { kind: 'question' | 'approval'; text: string } | null

/** The record an enrolled conversation keeps under `museum.v1.session.<its id>`. */
/** One agent of an enrolled session, as that session published it: its office state in words, nothing more. */
export type MuseumAgent = {
  key: string
  name: string
  state: string
  stateLabel: string
  light: 'green' | 'yellow' | 'red' | 'off'
  hand: 'question' | 'approval' | null
}

export type MuseumRecord = {
  v: 1
  sessionId: string
  label: string
  /** The session's project: the name of its working folder (a room in the fullscreen office). */
  project: string
  enrolledAt: number
  heartbeatAt: number
  status: 'idle' | 'busy'
  needsUser: MuseumNeedsUser
  /** How many messages its transcript held when the snapshot was taken. */
  messageCount: number
  snapshot: MuseumLine[]
  receipts: MuseumReceipt[]
  /** The session's agents at the last write (its swarm in the fullscreen office). */
  agents: MuseumAgent[]
}

export type MuseumFrame = MuseumRecord & { isStale: boolean }

export type MuseumCamera = { x: number; y: number; z: number; yaw: number; pitch: number }

export type MuseumSendState =
  | 'sending'
  | 'failed'
  | 'queued'
  | 'arrived'
  | 'in-conversation'
  | 'turn-started'
  | 'answered'
  | 'turn-failed'
  | 'unverified'

/** Where a send goes: an enrolled peer session, an agent of this session, or this conversation's own prompt queue. */
export type SendTarget = { kind: 'peer'; sessionId: string } | { kind: 'agent'; agentId: string } | { kind: 'main' }

export type MuseumSend = {
  id: string
  nonce: string
  target: SendTarget
  targetLabel: string
  text: string
  state: MuseumSendState
  reason: string | null
  createdAt: number
  queuedAt: number | null
  receipt: MuseumReceipt | null
}

export type MuseumSelf = { sessionId: string | null; isEnrolled: boolean; label: string | null }

export type MuseumScan = { at: number; error: string | null; total: number; staleCount: number }

export type MuseumNotice = { text: string; isError: boolean; at: number } | null

export type MuseumView = 'overview' | 'frame'

/** One of this session's agents, as $.agent.list() answered. */
export type OfficeAgent = {
  id: string
  name: string | null
  description: string
  type: string
  status: 'pending' | 'running' | 'waiting' | 'idle' | 'completed' | 'failed' | 'killed'
  isTeammate: boolean
  parentId: string | null
}

/**
 * An agent the office saw in $.agent.list() that the list no longer carries.
 * Kept (bounded) because a completed general-purpose or custom subagent stays
 * addressable: the docs say a message resumes it from its transcript.
 */
export type OfficeRetired = OfficeAgent & { retiredAt: number }

/**
 * Something a loop of this session is waiting on right now, from this
 * session's own hooks: an AskUserQuestion call in flight (`question`), a
 * permission dialog shown for a call (`approval`), or a call in flight to an
 * external service (`external`). Cleared when that call or turn ends.
 */
export type OfficePending = {
  id: string
  /** `main`, or `agent:<id>`. */
  identity: string
  kind: 'question' | 'approval' | 'external'
  tool: string
  text: string
  since: number
}

/** Which loops of this session have a turn running, and how each last ended. */
export type OfficeTurn = { identity: string; isRunning: boolean; lastReason: TurnReason | null; at: number }


/**
 * The fullscreen window's bridge (game/server.mjs, a detached process): the
 * folder it made, the state file this session writes, the command file the
 * window appends to, how many command lines were already acted on, and the
 * address it serves.
 */
export type FullscreenBridge = { dir: string; stateFile: string; cmdFile: string; readyFile: string; cmdSeen: number; url: string }

// ─── The Agent Arcade (hooks/arcade.ts) ────────────────────────────────────
/** A game's key, as src/arcade/games.ts lists it (`chess`, `tictactoe`, `connect4`, `checkers`, `bones`, …). */
export type ArcadeKind = string
/** Chess: a is White, b is Black. Tic-tac-toe: a is X, b is O. */
export type ArcadeSide = 'a' | 'b'
export type ArcadeEffort = 'low' | 'medium' | 'high' | 'xhigh' | 'max'
/** Who holds a seat: the person at the window, or an agent (a model and how hard it thinks). */
export type ArcadeSeat = { kind: 'human' } | { kind: 'agent'; model: string; effort: ArcadeEffort; name: string }
export type ArcadeGame = {
  kind: ArcadeKind
  /** Bumped by every seat change, reset or retry: a move started for an older id is dropped. */
  id: number
  seats: { a: ArcadeSeat | null; b: ArcadeSeat | null }
  /** The moves from the start: UCI for chess, a cell index for tic-tac-toe. The rules replay them. */
  moves: string[]
  /** The moves in notation, for display. */
  history: string[]
  turn: ArcadeSide
  status: 'waiting' | 'playing' | 'over' | 'stuck'
  result: string | null
  winner: ArcadeSide | null
  thinking: ArcadeSide | null
  /** The agent's own one-line reason for its last move, inert and bounded. */
  lastReply: string | null
  error: string | null
  attempts: number
  updatedAt: number
}
/** One game per registered kind; a kind missing here is a fresh game. */
export type ArcadeState = Record<string, ArcadeGame>

// ─── The world editor (hooks/design.ts, src/design/schema.ts, game/design.js) ──
// The scene document the office is decorated from, the edits that change it,
// and the editor's session state. Everything here is data: props made of a few
// primitives, desk sizes, room colours and sizes, a theme of named colour roles.
// Nothing in it can name a status light, a raised hand, an android or an arcade
// board: those have no role in this vocabulary, so no edit can reach them.
/** A colour as `#rrggbb` only. */
export type Hex = string

/** Metres. x right, y up, z toward the viewer of the anchor (see the anchors). */
export type Vec3 = { x: number; y: number; z: number }

/** What every primitive carries: a colour and, optionally, a surface and where it stands inside its prop. */
export type PartBase = {
  color: Hex
  roughness?: number
  metalness?: number
  /** The point the part stands on, inside the prop (a box, cylinder or cone rises from it; a sphere rests on it). Default the prop's origin. */
  at?: Vec3
}

export type Part =
  | ({ shape: 'box'; w: number; h: number; d: number } & PartBase)
  | ({ shape: 'cylinder'; r: number; h: number } & PartBase)
  | ({ shape: 'sphere'; r: number } & PartBase)
  | ({ shape: 'cone'; r: number; h: number } & PartBase)
  /** A short label, `size` metres tall, facing the viewer of the anchor. */
  | ({ shape: 'text'; text: string; size: number } & PartBase)

/**
 * A desk, by the worker key the office uses for it, or by a session and a
 * seat (`lead`, `agent 1`, `agent 2` …). The second form is resolved to the
 * first against the DesignContext before an edit is kept.
 */
export type DeskAnchor = { kind: 'desk'; key: string } | { kind: 'desk'; session: string; seat: string }

/**
 * Where a prop's origin is. Desk: the centre of the desk top's footprint on
 * the floor, +z toward the worker's chair, +x to the worker's right (the top
 * surface is 0.74 m up). Room: the room's centre on the floor, the door wall
 * at z −7 and the windows at z +7 for a 14 m room. Hallway: the entrance end
 * of the hallway on its centre line, x running along it.
 */
export type Anchor = DeskAnchor | { kind: 'room'; project: string } | { kind: 'hallway' }

export type Prop = {
  /** Stable: lowercase letters, digits, `-` and `_`, 32 characters at most. An addProp with an existing id replaces that prop. */
  id: string
  name: string
  anchor: Anchor
  /** From the anchor, in its frame; bounded per anchor kind (see BOUNDS). */
  offset: Vec3
  /** Degrees about y, added to the anchor's own facing. */
  yaw: number
  parts: Part[]
}

export type DeskSize = { w: number; d: number }
export type RoomStyle = { carpet?: Hex; walls?: Hex; width?: number; depth?: number }
/** The only colour roles the editor knows. */
export type Theme = { carpet?: Hex; walls?: Hex; ceiling?: Hex; deskWood?: Hex }

export type SceneEdit =
  | { type: 'addProp'; prop: Prop }
  | { type: 'removeProp'; id: string }
  | { type: 'moveProp'; id: string; anchor?: Anchor; offset?: Vec3; yaw?: number }
  | { type: 'resizeDesk'; desk: DeskAnchor; w: number; d: number }
  | { type: 'room'; project: string; carpet?: Hex; walls?: Hex; width?: number; depth?: number }
  | { type: 'theme'; carpet?: Hex; walls?: Hex; ceiling?: Hex; deskWood?: Hex }

/** The scene: what the window decorates the office with. Persisted under `design.v1` in $.store. */
export type SceneDoc = {
  v: 1
  props: Prop[]
  /** Worker key → desk top size, for desks the person resized. */
  desks: Record<string, DeskSize>
  /** Project → that room's colours and size, where changed. */
  rooms: Record<string, RoomStyle>
  theme: Theme
}

/** A request the person made, with what the model proposed for it once answered. */
export type DesignPending = { request: string; edits: SceneEdit[]; explanation: string }

export type DesignState = {
  /** The applied scene. */
  doc: SceneDoc
  /** The scene with the pending edits applied, while the person decides. */
  preview: SceneDoc | null
  /** Earlier applied scenes, newest last, bounded: undo pops one. */
  history: SceneDoc[]
  /** The queued request (edits empty while `busy`), then the proposal. */
  pending: DesignPending | null
  /** A request is queued or at the model. */
  busy: boolean
  error: string | null
}

/** What the caller knows about the office: the anchors a request may name. */
export type DesignContext = {
  desks: { key: string; label: string; session: string }[]
  rooms: { project: string; title: string }[]
}

/** What the window draws (hooks/design.ts designOut). */
export type DesignOut = {
  doc: SceneDoc
  isPreview: boolean
  /** Ids of props the preview adds or changes (drawn translucent). */
  changed: string[]
  pending: (DesignPending & { words: string[] }) | null
  busy: boolean
  error: string | null
  history: number
  anchors: DesignContext
}

// ─── The cooperative escape room (hooks/escape.ts, src/escape/rooms.ts, game/escape.js) ──
export type EscapeEffort = 'low' | 'medium' | 'high' | 'xhigh' | 'max'

/** The AI teammate's seat: a model and how hard it thinks. */
export type EscapeTeammate = { model: string; effort: EscapeEffort }

/** One line of the room's log: the person (`you`), the teammate, or the room itself (inspections, locks, events). */
export type EscapeLogLine = { who: 'you' | 'teammate' | 'room'; text: string }

export type EscapeState = {
  /** The room the person is in (src/escape/rooms.ts ids), or null between rooms. */
  roomId: string | null
  /** Objects inspected so far (ids): the only clues the teammate is ever shown. */
  discovered: string[]
  /** Puzzles solved so far (ids). */
  solved: string[]
  /** The recent conversation and events, bounded. */
  log: EscapeLogLine[]
  teammate: EscapeTeammate | null
  /** A teammate reply is due or in flight. */
  busy: boolean
  error: string | null
  /** The exit puzzle is solved. */
  isEscaped: boolean
}

// ─── The kanban wall board (hooks/kanban.ts, src/kanban/markdown.ts, game/kanban.js) ──
/** One card of the board (src/kanban/markdown.ts): a task or bullet line, by its stable id. */
export type KanbanCard = {
  /** A hash of the column and the text, numbered when the column repeats it. */
  id: string
  text: string
  done: boolean
  /** The line in the file (0-based) the card starts on. */
  line: number
}
export type KanbanColumn = { name: string; cards: KanbanCard[] }
export type KanbanBoard = { title: string; columns: KanbanColumn[] }
/** How the file is laid out: headings with task lists, headings with plain bullets, a flat task list, or nothing usable. */
export type KanbanShape = 'tasks' | 'bullets' | 'flat' | 'none'

export type KanbanState = {
  /** The board file's path, or null when the project has none. */
  file: string | null
  /** The parse of that file, or null when it could not be read. */
  board: KanbanBoard | null
  /** The file's modification time when `board` was read; a move of it triggers a re-read. */
  mtimeMs: number
  error: string | null
  /** A write of this session's own is in flight. */
  dirty: boolean
}

/** What the window draws (`kanbanOut`), or `{ file: null }` for a project with no board. */
export type KanbanOut =
  | { file: null }
  | {
      file: string
      title: string
      columns: { name: string; total: number; cards: { id: string; text: string; done: boolean; line: number }[] }[]
      error: string | null
      updatedAt: number
    }

/** The window's command, `{ type: 'kanban', ... }`, checked again on the mod side. */
export type KanbanCommand = {
  type: 'kanban'
  action: 'toggle' | 'move' | 'add' | 'edit' | 'remove' | 'reload'
  id?: string
  column?: string
  text?: string
}

declare module 'claude-code' {
  interface PluginState {
    'agent-office-3d': {
      frames: MuseumFrame[]
      selected: string | null
      draft: string
      camera: MuseumCamera
      view: MuseumView
      sends: MuseumSend[]
      self: MuseumSelf
      scan: MuseumScan
      notice: MuseumNotice
      agents: OfficeAgent[]
      retiredAgents: OfficeRetired[]
      pending: OfficePending[]
      turns: OfficeTurn[]
      agentReceipts: MuseumReceipt[]
      /** The in-app pane (hooks/office.ts, hooks/panes.tsx): opened once per session; its last notice. */
      officeAutoOpened: boolean
      officeNotice: MuseumNotice
      /** The fullscreen window's last notice (hooks/fullscreen.ts). */
      office3dNotice: MuseumNotice
      /** The open fullscreen window's bridge files (hooks/fullscreen.ts), kept so a reload re-links to it. */
      fullscreenBridge: FullscreenBridge | null
      /** The Agent Arcade's games (hooks/arcade.ts). */
      arcade: ArcadeState
      /** The world editor (hooks/design.ts): the applied scene, its preview and history. */
      design: DesignState
      /** The kanban wall board (hooks/kanban.ts): this session's project board. */
      kanban: KanbanState
      /** The cooperative escape room (hooks/escape.ts). */
      escape: EscapeState
    }
  }
}
