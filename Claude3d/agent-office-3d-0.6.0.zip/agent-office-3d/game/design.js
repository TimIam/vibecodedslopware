// The world editor in the window: draws the props of the scene the mod sends
// (hooks/design.ts designOut) and renders the editor's panel. No imports:
// the page passes its `three` in. The host owns the DOM wiring: it calls
// applyDesign from its state handler and designPanel wherever it shows the
// panel, and posts `{ type: 'design', action, text?, id? }` for the buttons.
//
// Everything drawn here comes from validated data: shapes from a fixed set,
// sizes and colours already bounded, text drawn onto a canvas as text. The
// panel escapes every string it shows.

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])
const DEG = Math.PI / 180
const PREVIEW_OPACITY = 0.45

/** The desk anchor's origin rotated by yaw; the room's and the hallway's frames are the world's. */
function resolveAnchor(anchor, ctx) {
  if (!anchor || typeof anchor !== 'object') return null
  if (anchor.kind === 'desk') {
    const d = typeof ctx.deskPosition === 'function' ? ctx.deskPosition(anchor.key) : null
    return d ? { x: d.x, z: d.z, yaw: d.yaw ?? 0 } : null
  }
  if (anchor.kind === 'room') {
    const r = typeof ctx.roomRect === 'function' ? ctx.roomRect(anchor.project) : null
    return r ? { x: (r.x0 + r.x1) / 2, z: (r.z0 + r.z1) / 2, yaw: 0 } : null
  }
  if (anchor.kind === 'hallway') {
    const h = ctx.hallway
    return h ? { x: h.x0, z: (h.z0 + h.z1) / 2, yaw: 0 } : null
  }
  return null
}

/** A label as a canvas texture on a plane, `size` metres tall, facing the viewer of the anchor. */
function labelMesh(THREE, part, translucent) {
  const text = String(part.text).slice(0, 40)
  const canvas = document.createElement('canvas')
  const font = 64
  const gc = canvas.getContext('2d')
  gc.font = `600 ${font}px "Segoe UI", system-ui, sans-serif`
  const width = Math.ceil(gc.measureText(text).width) + 32
  canvas.width = Math.max(64, width)
  canvas.height = font + 24
  gc.font = `600 ${font}px "Segoe UI", system-ui, sans-serif`
  gc.textBaseline = 'middle'
  gc.textAlign = 'center'
  gc.fillStyle = part.color
  gc.fillText(text, canvas.width / 2, canvas.height / 2)
  const tex = new THREE.CanvasTexture(canvas)
  tex.colorSpace = THREE.SRGBColorSpace
  const h = part.size
  const w = (h * canvas.width) / canvas.height
  const mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: translucent ? PREVIEW_OPACITY : 1, side: THREE.DoubleSide })
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat)
  mesh.rotation.y = Math.PI // faces −z: the visitor's side of a desk
  mesh.position.y = h / 2
  return mesh
}

function partMesh(THREE, part, translucent) {
  if (part.shape === 'text') return labelMesh(THREE, part, translucent)
  let geometry
  let lift = 0
  switch (part.shape) {
    case 'box':
      geometry = new THREE.BoxGeometry(part.w, part.h, part.d)
      lift = part.h / 2
      break
    case 'cylinder':
      geometry = new THREE.CylinderGeometry(part.r, part.r, part.h, 20)
      lift = part.h / 2
      break
    case 'cone':
      geometry = new THREE.ConeGeometry(part.r, part.h, 20)
      lift = part.h / 2
      break
    case 'sphere':
      geometry = new THREE.SphereGeometry(part.r, 16, 12)
      lift = part.r
      break
    default:
      return null
  }
  const material = new THREE.MeshStandardMaterial({
    color: part.color,
    roughness: typeof part.roughness === 'number' ? part.roughness : 0.6,
    metalness: typeof part.metalness === 'number' ? part.metalness : 0.05,
    transparent: translucent,
    opacity: translucent ? PREVIEW_OPACITY : 1,
  })
  const mesh = new THREE.Mesh(geometry, material)
  mesh.position.y = lift
  mesh.castShadow = !translucent
  mesh.receiveShadow = true
  return mesh
}

/** One prop as a group: its parts at their places inside it. */
function buildProp(THREE, prop, translucent) {
  const g = new THREE.Group()
  g.name = `design:${prop.id}`
  for (const part of prop.parts) {
    const mesh = partMesh(THREE, part, translucent)
    if (mesh === null) continue
    const at = part.at ?? { x: 0, y: 0, z: 0 }
    mesh.position.x += at.x ?? 0
    mesh.position.y += at.y ?? 0
    mesh.position.z += at.z ?? 0
    g.add(mesh)
  }
  return g
}

function dispose(group) {
  group.traverse(o => {
    if (o.geometry && typeof o.geometry.dispose === 'function') o.geometry.dispose()
    const m = o.material
    if (m) {
      if (m.map && typeof m.map.dispose === 'function') m.map.dispose()
      if (typeof m.dispose === 'function') m.dispose()
    }
  })
}

/**
 * Draws the scene's props into a group this module owns under `scene`,
 * kept in `groups.design` (made on the first call). A prop is rebuilt when
 * its data changes (keyed by its JSON) or when it moves in or out of the
 * preview (preview props are translucent); its place is resolved on every
 * call through `ctx` ({ deskPosition(key) → { x, z, yaw } | null,
 * roomRect(project) → { x0, z0, x1, z1 } | null, hallway: { x0, z0, x1, z1 } }),
 * so a desk that appears or goes is followed without a rebuild. A prop whose
 * anchor is not in the office now is kept but hidden.
 *
 * Answers the rest of the scene for the host to apply where it builds the
 * world: the theme, the resized desks and the styled rooms, plus the group
 * and how many props are drawn.
 */
export function applyDesign(THREE, scene, groups, design, ctx) {
  let g = groups.design
  if (!g) {
    g = new THREE.Group()
    g.name = 'design'
    scene.add(g)
    groups.design = g
    groups.designNodes = new Map()
  }
  const nodes = groups.designNodes
  const doc = design && design.doc && Array.isArray(design.doc.props) ? design.doc : { v: 1, props: [], desks: {}, rooms: {}, theme: {} }
  const isPreview = Boolean(design && design.isPreview)
  const changed = new Set(isPreview ? (Array.isArray(design.changed) ? design.changed : doc.props.map(p => p.id)) : [])
  const wanted = new Set(doc.props.map(p => p.id))
  for (const [id, node] of [...nodes]) {
    if (wanted.has(id)) continue
    g.remove(node.group)
    dispose(node.group)
    nodes.delete(id)
  }
  let drawn = 0
  for (const prop of doc.props) {
    if (typeof prop.id !== 'string' || !Array.isArray(prop.parts)) continue
    const translucent = changed.has(prop.id)
    const key = `${JSON.stringify(prop)}|${translucent ? 'preview' : 'applied'}`
    let node = nodes.get(prop.id)
    if (!node || node.key !== key) {
      if (node) {
        g.remove(node.group)
        dispose(node.group)
      }
      node = { key, group: buildProp(THREE, prop, translucent) }
      g.add(node.group)
      nodes.set(prop.id, node)
    }
    const at = resolveAnchor(prop.anchor, ctx ?? {})
    node.group.visible = at !== null
    if (at === null) continue
    const o = prop.offset ?? { x: 0, y: 0, z: 0 }
    const c = Math.cos(at.yaw)
    const s = Math.sin(at.yaw)
    // The offset in the anchor's frame: +x the anchor's right, +z its front, turned by its yaw about y.
    node.group.position.set(at.x + (o.x ?? 0) * c + (o.z ?? 0) * s, o.y ?? 0, at.z - (o.x ?? 0) * s + (o.z ?? 0) * c)
    node.group.rotation.y = at.yaw + (prop.yaw ?? 0) * DEG
    drawn += 1
  }
  return { group: g, drawn, theme: doc.theme ?? {}, desks: doc.desks ?? {}, rooms: doc.rooms ?? {} }
}

const m = n => `${Math.round(Number(n) * 100) / 100} m`
function anchorWords(a) {
  if (!a || typeof a !== 'object') return 'nowhere'
  if (a.kind === 'hallway') return 'the hallway'
  if (a.kind === 'room') return a.project === 'arcade' ? 'the arcade' : `the ${a.project} room`
  if (a.kind === 'desk') return 'key' in a ? `the desk of ${a.key}` : `the ${a.seat} desk of session ${a.session}`
  return 'nowhere'
}
const offsetWords = o => (o ? `(${m(o.x ?? 0)}, ${m(o.y ?? 0)}, ${m(o.z ?? 0)})` : '')

/** One edit in words (the mod sends `pending.words` too; this covers a state without them). */
function editWords(e) {
  if (!e || typeof e !== 'object') return ''
  switch (e.type) {
    case 'addProp':
      return `add "${e.prop?.name}" (${e.prop?.id}: ${e.prop?.parts?.length ?? 0} parts) at ${anchorWords(e.prop?.anchor)} + ${offsetWords(e.prop?.offset)}`
    case 'removeProp':
      return `remove the prop ${e.id}`
    case 'moveProp':
      return `move the prop ${e.id}${e.anchor ? ` to ${anchorWords(e.anchor)}` : ''}${e.offset ? ` at ${offsetWords(e.offset)}` : ''}${typeof e.yaw === 'number' ? ` turned ${e.yaw}°` : ''}`
    case 'resizeDesk':
      return `resize ${anchorWords(e.desk)} to ${m(e.w)} by ${m(e.d)}`
    case 'room':
      return `${anchorWords({ kind: 'room', project: e.project })}: ${['carpet', 'walls', 'width', 'depth'].filter(k => e[k] !== undefined).map(k => `${k} ${e[k]}`).join(', ')}`
    case 'theme':
      return `theme: ${['carpet', 'walls', 'ceiling', 'deskWood'].filter(k => e[k] !== undefined).map(k => `${k} ${e[k]}`).join(', ')}`
    default:
      return ''
  }
}

/**
 * The editor's panel as HTML (every string escaped): a request box, the
 * pending request with the model's explanation and its edits in words, the
 * error, Apply / Cancel / Undo / Reset buttons (`data-design="<action>"`),
 * and the scene's props each with a remove button (`data-design="remove"
 * data-id="<id>"`). No listeners: the host wires the clicks and posts
 * `{ type: 'design', action, text?, id? }`.
 */
export function designPanel(design) {
  const d = design && typeof design === 'object' ? design : {}
  const doc = d.doc && Array.isArray(d.doc.props) ? d.doc : { props: [] }
  const pending = d.pending && typeof d.pending === 'object' ? d.pending : null
  const isPreview = Boolean(d.isPreview)
  const history = Number(d.history) || 0
  let status
  if (d.busy) status = 'Asking the model… the preview appears here.'
  else if (isPreview) status = `Preview: ${pending?.edits?.length ?? 0} edit${pending?.edits?.length === 1 ? '' : 's'}, drawn translucent. Apply keeps it, Cancel drops it.`
  else status = 'Describe a change in words: flowers on my desk, a bigger desk, a blue carpet in the arcade…'
  const words = pending ? (Array.isArray(pending.words) ? pending.words : (pending.edits ?? []).map(editWords)) : []
  const pendingHtml = pending
    ? `<div class="pending"><div><b>Request:</b> ${esc(pending.request)}</div>` +
      (pending.explanation ? `<div><b>Model:</b> ${esc(pending.explanation)}</div>` : '') +
      (words.length > 0 ? `<ul>${words.map(w => `<li>${esc(w)}</li>`).join('')}</ul>` : '') +
      '</div>'
    : ''
  const props = doc.props
    .map(p => `<li>${esc(p.name)} <span class="dim">(${esc(p.id)} · ${esc(anchorWords(p.anchor))})</span> <button data-design="remove" data-id="${esc(p.id)}">remove</button></li>`)
    .join('')
  return (
    '<h3>World editor</h3>' +
    `<div class="status${d.error ? ' err' : ''}">${esc(status)}</div>` +
    `<div class="row"><input data-design-text maxlength="400" placeholder="What should change?"${d.busy ? ' disabled' : ''}><button data-design="request"${d.busy ? ' disabled' : ''}>Request</button></div>` +
    pendingHtml +
    (d.error ? `<div class="error">${esc(d.error)}</div>` : '') +
    `<div class="row"><button data-design="apply"${isPreview ? '' : ' disabled'}>Apply</button>` +
    `<button data-design="cancel"${isPreview || d.busy || pending ? '' : ' disabled'}>Cancel</button>` +
    `<button data-design="undo"${isPreview || history > 0 ? '' : ' disabled'}>Undo${history > 0 ? ` (${history})` : ''}</button>` +
    '<button data-design="reset">Reset</button></div>' +
    `<div class="props"><b>${isPreview ? 'Preview' : 'Scene'}:</b> ${doc.props.length === 0 ? '<span class="dim">no props yet</span>' : `<ul>${props}</ul>`}</div>`
  )
}
