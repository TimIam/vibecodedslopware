// The kanban wall board of a project room: a framed panel on a wall painted
// with the project's board (columns of cards), and the panel the person
// edits it from. No imports: the host (game.js) passes `THREE` and its own
// helpers in, and wires the DOM listeners and the commands itself.
//
// Host wiring (docs/KANBAN.md):
//   const wall = buildKanbanWall(THREE, { box, mat, textSprite }, parent, { x, z, rotY })
//   wall.draw(state.kanban)                     // each state; repaints only on change
//   register a target { ...KANBAN_TARGET, pos: wall.group.position, stand, yaw }
//   so E opens the panel: ui.kanban.innerHTML = kanbanPanel(state.kanban)
//   and a click on [data-kanban] posts { type: 'kanban', action, id, column, text }.

/** The target kind the host registers at the wall's position, so the person can walk up and press E. */
export const KANBAN_TARGET = { kind: 'kanban' }

export const KANBAN_PANEL_WIDTH = 1.9
export const KANBAN_PANEL_HEIGHT = 1.2
const CANVAS_W = 1024
const CANVAS_H = 648
const MAX_COLUMNS = 6
const CARD_LINES = 3

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])

/** Breaks `text` into at most `max` lines that fit `width` in the context's current font, the last one elided. */
function wrap(g, text, width, max) {
  const words = String(text).replace(/\s+/g, ' ').trim().split(' ')
  const lines = []
  let line = ''
  for (const w of words) {
    const probe = line === '' ? w : `${line} ${w}`
    if (g.measureText(probe).width <= width || line === '') line = probe
    else {
      lines.push(line)
      line = w
    }
    if (lines.length === max) break
  }
  if (lines.length < max && line !== '') lines.push(line)
  if (lines.length === max && (words.join(' ') !== lines.join(' ') || line !== lines[max - 1])) {
    let last = lines[max - 1]
    while (last.length > 1 && g.measureText(`${last}…`).width > width) last = last.slice(0, -1)
    lines[max - 1] = `${last}…`
  }
  return lines
}

/** Paints `board` (what `kanbanOut` gives) onto the canvas. */
function paint(canvas, board) {
  const g = canvas.getContext('2d')
  const W = canvas.width
  const H = canvas.height
  g.clearRect(0, 0, W, H)
  g.fillStyle = '#f4f6f8'
  g.fillRect(0, 0, W, H)
  // Header strip.
  g.fillStyle = '#1f2937'
  g.fillRect(0, 0, W, 64)
  g.fillStyle = '#eef2f7'
  g.font = '600 30px Segoe UI, sans-serif'
  g.textBaseline = 'middle'
  if (!board || board.file === null) {
    g.fillText('Kanban', 24, 32)
    g.fillStyle = '#4b5563'
    g.font = '26px Segoe UI, sans-serif'
    g.textBaseline = 'alphabetic'
    g.fillText('No board file in this project.', 24, 130)
    g.font = '22px Segoe UI, sans-serif'
    g.fillText('Add KANBAN.md, ROADMAP.md or TODO.md with ## columns and - [ ] tasks.', 24, 170)
    return
  }
  const columns = (board.columns ?? []).slice(0, MAX_COLUMNS)
  const total = columns.reduce((n, c) => n + (c.total ?? c.cards.length), 0)
  const done = columns.reduce((n, c) => n + c.cards.filter(k => k.done).length, 0)
  const title = board.title || board.file
  g.fillText(wrap(g, title, W - 380, 1)[0] ?? '', 24, 32)
  g.font = '22px Segoe UI, sans-serif'
  g.fillStyle = '#a9b4c2'
  g.textAlign = 'right'
  g.fillText(`${board.file} · ${done}/${total} done`, W - 24, 32)
  g.textAlign = 'left'
  g.textBaseline = 'alphabetic'
  if (board.error) {
    g.fillStyle = '#b91c1c'
    g.font = '24px Segoe UI, sans-serif'
    g.fillText(wrap(g, board.error, W - 48, 1)[0] ?? '', 24, 110)
    if (columns.length === 0) return
  }
  const gap = 14
  const top = 80
  const colW = (W - gap * (columns.length + 1)) / Math.max(1, columns.length)
  columns.forEach((c, i) => {
    const x = gap + i * (colW + gap)
    g.fillStyle = '#e5e9ef'
    g.beginPath()
    g.roundRect(x, top, colW, H - top - gap, 10)
    g.fill()
    g.fillStyle = '#111827'
    g.font = '600 22px Segoe UI, sans-serif'
    const name = wrap(g, c.name, colW - 70, 1)[0] ?? ''
    g.fillText(name, x + 12, top + 30)
    g.fillStyle = '#6b7280'
    g.font = '20px Segoe UI, sans-serif'
    g.textAlign = 'right'
    g.fillText(String(c.total ?? c.cards.length), x + colW - 12, top + 30)
    g.textAlign = 'left'
    let y = top + 46
    const cardFont = '19px Segoe UI, sans-serif'
    const lineH = 23
    let shown = 0
    for (const k of c.cards) {
      g.font = cardFont
      const lines = wrap(g, k.text, colW - 50, CARD_LINES)
      const h = lines.length * lineH + 14
      if (y + h > H - gap - 30) break
      g.fillStyle = k.done ? '#f3f4f6' : '#ffffff'
      g.beginPath()
      g.roundRect(x + 8, y, colW - 16, h, 6)
      g.fill()
      g.strokeStyle = k.done ? '#d1d5db' : '#c7ced8'
      g.lineWidth = 1
      g.stroke()
      // The checkbox.
      g.strokeStyle = k.done ? '#16a34a' : '#6b7280'
      g.lineWidth = 2
      g.strokeRect(x + 16, y + 9, 14, 14)
      if (k.done) {
        g.beginPath()
        g.moveTo(x + 19, y + 16)
        g.lineTo(x + 23, y + 20)
        g.lineTo(x + 29, y + 11)
        g.stroke()
      }
      g.fillStyle = k.done ? '#9ca3af' : '#111827'
      lines.forEach((l, j) => {
        const ly = y + 22 + j * lineH
        g.fillText(l, x + 38, ly)
        if (k.done) {
          const w = g.measureText(l).width
          g.strokeStyle = '#9ca3af'
          g.lineWidth = 1.5
          g.beginPath()
          g.moveTo(x + 38, ly - 6)
          g.lineTo(x + 38 + w, ly - 6)
          g.stroke()
        }
      })
      y += h + 8
      shown += 1
    }
    const rest = (c.total ?? c.cards.length) - shown
    if (rest > 0) {
      g.fillStyle = '#6b7280'
      g.font = 'italic 18px Segoe UI, sans-serif'
      g.fillText(`+${rest} more`, x + 14, Math.min(y + 18, H - gap - 10))
    }
  })
}

/**
 * Builds the wall board at `placement` (`{ x, z, rotY }`: the wall's foot
 * in metres, rotY turning +z to face into the room, like the whiteboard) and
 * returns `{ group, board, canvas, draw(board) }`. `draw` repaints only when
 * the board it is given differs from the last one drawn.
 */
export function buildKanbanWall(THREE, helpers, parent, placement) {
  const { box, mat, textSprite } = helpers
  const g = new THREE.Group()
  g.position.set(placement.x, 0, placement.z)
  g.rotation.y = placement.rotY ?? 0
  const canvas = document.createElement('canvas')
  canvas.width = CANVAS_W
  canvas.height = CANVAS_H
  const tex = new THREE.CanvasTexture(canvas)
  tex.colorSpace = THREE.SRGBColorSpace
  tex.anisotropy = 4
  const board = new THREE.Mesh(new THREE.PlaneGeometry(KANBAN_PANEL_WIDTH, KANBAN_PANEL_HEIGHT), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.4 }))
  board.position.set(0, 1.55, 0.025)
  g.add(board)
  const frame = mat(0x3d4452, { metalness: 0.4, roughness: 0.45 })
  box(KANBAN_PANEL_WIDTH + 0.08, KANBAN_PANEL_HEIGHT + 0.08, 0.03, frame, 0, 1.55, 0.008, g)
  box(KANBAN_PANEL_WIDTH + 0.1, 0.03, 0.09, frame, 0, 1.55 - KANBAN_PANEL_HEIGHT / 2 - 0.05, 0.045, g) // a ledge
  const sign = textSprite(['Kanban', 'walk up · E to edit'], { width: 420, height: 150, scale: 0.55 })
  sign.position.set(0, 2.35, 0.1)
  g.add(sign)
  parent.add(g)
  let drawn = ''
  const draw = next => {
    const key = JSON.stringify(next ?? null)
    if (key === drawn) return
    drawn = key
    paint(canvas, next)
    tex.needsUpdate = true
  }
  draw(null)
  return { group: g, board, canvas, draw }
}

/**
 * The panel's HTML for `board` (what `kanbanOut` gives): a row per card with
 * a toggle, a move select, an edit button and a remove button; an add box
 * per column; a Reload button. Every control carries `data-kanban` (the
 * action) with `data-id` or `data-column`; the host listens and posts. No
 * listeners of its own.
 */
export function kanbanPanel(board) {
  if (!board || board.file === null) {
    return (
      '<h3>Kanban</h3>' +
      '<div class="status">This project has no board file.</div>' +
      '<div class="dim">Add <code>KANBAN.md</code>, <code>ROADMAP.md</code>, <code>TODO.md</code> or <code>TASKS.md</code> with <code>## column</code> headings and <code>- [ ] task</code> lines.</div>' +
      '<div class="row"><button data-kanban="reload">Reload</button><span class="dim">Esc closes</span></div>'
    )
  }
  const names = board.columns.map(c => c.name)
  const options = (current, id) =>
    `<select data-kanban="move" data-id="${esc(id)}" title="Move to…">` +
    names.map(n => `<option value="${esc(n)}"${n === current ? ' selected' : ''}>${esc(n)}</option>`).join('') +
    '</select>'
  const column = c => {
    const rows = c.cards
      .map(
        k =>
          `<div class="card${k.done ? ' done' : ''}" data-card="${esc(k.id)}">` +
          `<label><input type="checkbox" data-kanban="toggle" data-id="${esc(k.id)}"${k.done ? ' checked' : ''}> ` +
          `<span class="text"${k.done ? ' style="text-decoration:line-through;opacity:.6"' : ''}>${esc(k.text)}</span></label>` +
          `<span class="tools">${options(c.name, k.id)}` +
          `<button data-kanban="edit" data-id="${esc(k.id)}" title="Edit">✎</button>` +
          `<button data-kanban="remove" data-id="${esc(k.id)}" title="Remove">✕</button></span>` +
          `<div class="editor" data-editor="${esc(k.id)}" style="display:none"><input data-edit-text="${esc(k.id)}" maxlength="300" value="${esc(k.text)}">` +
          `<button data-kanban="edit-save" data-id="${esc(k.id)}">Save</button><button data-kanban="edit-cancel" data-id="${esc(k.id)}">Cancel</button></div>` +
          '</div>',
      )
      .join('')
    const more = (c.total ?? c.cards.length) - c.cards.length
    return (
      `<div class="column" data-column="${esc(c.name)}"><div class="column-head"><b>${esc(c.name)}</b> <span class="dim">${c.total ?? c.cards.length}</span></div>` +
      (rows || '<div class="dim">No cards.</div>') +
      (more > 0 ? `<div class="dim">+${more} more in the file</div>` : '') +
      `<div class="add"><input data-add-text="${esc(c.name)}" placeholder="New card" maxlength="300">` +
      `<button data-kanban="add" data-column="${esc(c.name)}">Add</button></div></div>`
    )
  }
  const done = board.columns.reduce((n, c) => n + c.cards.filter(k => k.done).length, 0)
  const total = board.columns.reduce((n, c) => n + (c.total ?? c.cards.length), 0)
  return (
    `<h3>${esc(board.title || 'Kanban')} <span class="dim">· ${esc(board.file)}</span></h3>` +
    `<div class="status">${done}/${total} done · changes are written to the file</div>` +
    (board.error ? `<div class="error">${esc(board.error)}</div>` : '') +
    `<div class="columns">${board.columns.map(column).join('')}</div>` +
    '<div class="row"><button data-kanban="reload">Reload</button><span class="dim">Esc closes</span></div>'
  )
}

/**
 * The command for a click or change on a panel control, or null: the host
 * calls it with the element that carries `data-kanban` and the panel's root
 * (to read the inputs), and posts what it answers as `{ type: 'kanban', ... }`.
 * `edit` only opens the inline editor (answers null); `edit-save` answers the
 * edit command; `edit-cancel` closes it.
 */
export function kanbanCommandFor(el, root) {
  const action = el?.dataset?.kanban
  if (!action) return null
  const id = el.dataset.id
  if (action === 'toggle' || action === 'remove') return { type: 'kanban', action, id }
  if (action === 'move') return { type: 'kanban', action: 'move', id, column: el.value }
  if (action === 'reload') return { type: 'kanban', action: 'reload' }
  if (action === 'add') {
    const input = root?.querySelector(`[data-add-text="${CSS.escape(el.dataset.column)}"]`)
    const text = input?.value.trim() ?? ''
    if (text === '') return null
    return { type: 'kanban', action: 'add', column: el.dataset.column, text }
  }
  if (action === 'edit') {
    const editor = root?.querySelector(`[data-editor="${CSS.escape(id)}"]`)
    if (editor) {
      editor.style.display = ''
      editor.querySelector('input')?.focus()
    }
    return null
  }
  if (action === 'edit-cancel') {
    const editor = root?.querySelector(`[data-editor="${CSS.escape(id)}"]`)
    if (editor) editor.style.display = 'none'
    return null
  }
  if (action === 'edit-save') {
    const input = root?.querySelector(`[data-edit-text="${CSS.escape(id)}"]`)
    const text = input?.value.trim() ?? ''
    if (text === '') return null
    return { type: 'kanban', action: 'edit', id, text }
  }
  return null
}
