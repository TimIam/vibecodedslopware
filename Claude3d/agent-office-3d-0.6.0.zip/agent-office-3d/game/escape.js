// The escape room in the fullscreen window: the themed room built off the
// arcade, and the panel drawn while the person sits at its console. No
// imports: `buildEscapeRoom` is handed THREE and game.js's own helpers
// (`box`, `mat`, `textSprite`, `solid`), and `escapePanel` only makes HTML
// from the state the mod sends (hooks/escape.ts `escapeOut`). It attaches no
// listeners of its own: game.js wires clicks on `[data-escape]` buttons to
// posts of `{ type: 'escape', action, ... }` (see docs/ESCAPE.md).

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])

/** Each theme's look: wall tint, accent, and what stands in the room. */
export const ESCAPE_THEMES = {
  mansion: { wall: 0x3a2f33, trim: 0x6b4a2a, accent: 0xc99a3a, light: 0xffb060, sign: 'Blackwood Manor' },
  station: { wall: 0x2a3340, trim: 0x8a94a6, accent: 0x55c8ff, light: 0xff5050, sign: 'Station Kepler-9' },
  vault: { wall: 0x2b2b2b, trim: 0x4a4a52, accent: 0xd8b24a, light: 0xfff0c0, sign: 'The Meridian Vault' },
}

/**
 * Builds the escape room: a dim room of `width` x `depth` metres whose
 * near-left corner (hallway side) is `origin` ({ x, z, width?, depth? }),
 * with a door frame and a sign over it, props for the three themes, and a
 * console with one chair facing it: the seat the person sits in to play.
 * Answers `{ group, seat, setTheme, sign }`: `seat` is a seat descriptor like
 * the arcade's (`{ kind: 'escape', pos, stand, yaw, number: 'escape' }`),
 * `setTheme(roomId | null)` recolours the room for the room entered.
 */
export function buildEscapeRoom(THREE, helpers, parent, origin) {
  const { box, mat, textSprite, solid } = helpers
  const x0 = origin.x
  const z0 = origin.z
  const W = origin.width ?? 14
  const D = origin.depth ?? 14
  const H = 3
  const cx = x0 + W / 2
  const group = new THREE.Group()
  parent.add(group)

  // Walls (the front wall has the doorway), darker than the office's.
  const wallMat = mat(0x3a2f33, { roughness: 0.95 })
  const doorW = 1.6
  const doorH = 2.2
  const sideW = (W - doorW) / 2
  box(sideW, H, 0.12, wallMat, x0 + sideW / 2, H / 2, z0, group)
  box(sideW, H, 0.12, wallMat, x0 + W - sideW / 2, H / 2, z0, group)
  box(doorW, H - doorH, 0.12, wallMat, cx, doorH + (H - doorH) / 2, z0, group) // over the door
  box(0.12, H, D, wallMat, x0, H / 2, z0 + D / 2, group)
  box(0.12, H, D, wallMat, x0 + W, H / 2, z0 + D / 2, group)
  box(W, H, 0.12, wallMat, cx, H / 2, z0 + D, group)
  solid(x0 + sideW / 2, z0, sideW, 0.12)
  solid(x0 + W - sideW / 2, z0, sideW, 0.12)
  solid(x0, z0 + D / 2, 0.12, D)
  solid(x0 + W, z0 + D / 2, 0.12, D)
  solid(cx, z0 + D, W, 0.12)

  // The door frame: two posts and a lintel, in the theme's trim colour.
  const trimMat = mat(0x6b4a2a, { roughness: 0.5 })
  box(0.14, doorH, 0.3, trimMat, cx - doorW / 2 - 0.02, doorH / 2, z0, group)
  box(0.14, doorH, 0.3, trimMat, cx + doorW / 2 + 0.02, doorH / 2, z0, group)
  box(doorW + 0.3, 0.14, 0.3, trimMat, cx, doorH + 0.05, z0, group)
  solid(cx - doorW / 2 - 0.02, z0, 0.14, 0.3)
  solid(cx + doorW / 2 + 0.02, z0, 0.14, 0.3)

  // A dark floor rug and a low ceiling glow in the theme's light colour.
  const rug = new THREE.Mesh(new THREE.PlaneGeometry(W - 1, D - 1), mat(0x1c1a1e, { roughness: 1 }))
  rug.rotation.x = -Math.PI / 2
  rug.position.set(cx, 0.012, z0 + D / 2)
  rug.receiveShadow = true
  group.add(rug)
  const lamp = new THREE.PointLight(0xffb060, 10, 14, 1.6)
  lamp.position.set(cx, H - 0.4, z0 + D / 2)
  group.add(lamp)

  // Props, one cluster per theme along the back and side walls.
  // The mansion: a bookshelf, a tall clock, a portrait.
  const shelfMat = mat(0x4a3020, { roughness: 0.8 })
  box(2.0, 2.2, 0.4, shelfMat, x0 + 1.4, 1.1, z0 + D - 0.35, group)
  for (let i = 0; i < 4; i++) box(1.8, 0.04, 0.36, mat(0x2a1a10), x0 + 1.4, 0.4 + i * 0.5, z0 + D - 0.35, group)
  solid(x0 + 1.4, z0 + D - 0.35, 2.0, 0.4)
  box(0.5, 2.1, 0.4, shelfMat, x0 + 3.1, 1.05, z0 + D - 0.35, group) // the clock case
  const face = new THREE.Mesh(new THREE.CircleGeometry(0.17, 24), mat(0xf0e6c8, { roughness: 0.4 }))
  face.position.set(x0 + 3.1, 1.75, z0 + D - 0.54)
  face.rotation.y = Math.PI
  group.add(face)
  solid(x0 + 3.1, z0 + D - 0.35, 0.5, 0.4)
  box(0.9, 1.1, 0.05, mat(0xb08a3a, { metalness: 0.5, roughness: 0.4 }), x0 + 4.6, 1.7, z0 + D - 0.1, group) // the portrait's frame
  box(0.76, 0.96, 0.02, mat(0x24202a), x0 + 4.6, 1.7, z0 + D - 0.13, group)

  // The station: an oxygen rack, a console, a round porthole.
  const steel = mat(0x8a94a6, { metalness: 0.7, roughness: 0.35 })
  for (let i = 0; i < 5; i++) {
    const tank = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 1.2, 16), steel)
    tank.position.set(x0 + W - 0.6, 0.6, z0 + 2.5 + i * 0.5)
    tank.castShadow = true
    group.add(tank)
  }
  solid(x0 + W - 0.6, z0 + 3.5, 0.5, 2.6)
  box(1.2, 0.9, 0.5, mat(0x2a3340, { metalness: 0.4, roughness: 0.5 }), x0 + W - 0.9, 0.45, z0 + 6.2, group)
  const screen = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 0.5), new THREE.MeshBasicMaterial({ color: 0x55c8ff }))
  screen.position.set(x0 + W - 1.16, 1.15, z0 + 6.2)
  screen.rotation.y = -Math.PI / 2
  group.add(screen)
  solid(x0 + W - 0.9, z0 + 6.2, 1.2, 0.5)
  const port = new THREE.Mesh(new THREE.RingGeometry(0.4, 0.5, 32), steel)
  port.position.set(x0 + W - 0.07, 1.8, z0 + D - 2.5)
  port.rotation.y = -Math.PI / 2
  group.add(port)
  const stars = new THREE.Mesh(new THREE.CircleGeometry(0.4, 32), new THREE.MeshBasicMaterial({ color: 0x050a1a }))
  stars.position.set(x0 + W - 0.065, 1.8, z0 + D - 2.5)
  stars.rotation.y = -Math.PI / 2
  group.add(stars)

  // The vault: a round vault door on the left wall, a wall of deposit boxes, a lectern.
  const brass = mat(0xd8b24a, { metalness: 0.8, roughness: 0.3 })
  const vaultDoor = new THREE.Mesh(new THREE.CylinderGeometry(1.0, 1.0, 0.18, 40), mat(0x4a4a52, { metalness: 0.7, roughness: 0.4 }))
  vaultDoor.rotation.z = Math.PI / 2
  vaultDoor.position.set(x0 + 0.16, 1.3, z0 + 3.5)
  vaultDoor.castShadow = true
  group.add(vaultDoor)
  const wheel = new THREE.Mesh(new THREE.TorusGeometry(0.35, 0.04, 10, 32), brass)
  wheel.rotation.y = Math.PI / 2
  wheel.position.set(x0 + 0.3, 1.3, z0 + 3.5)
  group.add(wheel)
  solid(x0 + 0.2, z0 + 3.5, 0.4, 2.1)
  for (let r = 0; r < 4; r++) for (let c = 0; c < 6; c++) box(0.3, 0.3, 0.06, brass, x0 + 0.1, 0.5 + r * 0.36, z0 + 6.0 + c * 0.36, group)
  box(0.5, 1.1, 0.4, mat(0x3a2a1a, { roughness: 0.7 }), x0 + 1.6, 0.55, z0 + 6.6, group) // the lectern
  box(0.6, 0.04, 0.5, mat(0xe8dcc0), x0 + 1.6, 1.12, z0 + 6.6, group) // the ledger on it
  solid(x0 + 1.6, z0 + 6.6, 0.5, 0.4)

  // The console the person plays from, and its chair, mid-room facing the back wall.
  const conX = cx
  const conZ = z0 + D / 2 + 1.2
  box(1.6, 0.06, 0.8, mat(0x2a2228, { roughness: 0.5 }), conX, 0.78, conZ, group)
  for (const [lx, lz] of [[-0.7, -0.3], [0.7, -0.3], [-0.7, 0.3], [0.7, 0.3]]) box(0.06, 0.76, 0.06, mat(0x2b303a, { metalness: 0.6, roughness: 0.35 }), conX + lx, 0.38, conZ + lz, group)
  const panel = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.5), new THREE.MeshBasicMaterial({ color: 0xc99a3a }))
  panel.position.set(conX, 1.2, conZ + 0.38)
  panel.rotation.y = Math.PI
  group.add(panel)
  box(1.3, 0.6, 0.05, mat(0x1a1518), conX, 1.2, conZ + 0.41, group)
  solid(conX, conZ, 1.6, 0.8)
  // The chair: a plain stool (the office's chair helper is not among the helpers handed over).
  const seatZ = conZ - 0.9
  box(0.46, 0.08, 0.46, mat(0x3a3f4a, { roughness: 0.9 }), conX, 0.46, seatZ, group)
  box(0.06, 0.44, 0.06, mat(0x2b303a, { metalness: 0.6 }), conX, 0.22, seatZ, group)
  box(0.46, 0.5, 0.06, mat(0x3a3f4a, { roughness: 0.9 }), conX, 0.75, seatZ - 0.2, group)
  solid(conX, seatZ, 0.5, 0.5)
  const seat = {
    kind: 'escape',
    pos: new THREE.Vector3(conX, 0, seatZ),
    stand: new THREE.Vector3(conX, 0, seatZ - 0.8),
    yaw: 0,
    number: 'escape',
  }

  // The sign over the door, read from the hallway, and the theme card inside.
  const sign = textSprite(['Escape Room', 'you and a teammate · sit at the console to begin'], { width: 900, height: 150, scale: 1.1 })
  sign.position.set(cx, 2.75, z0 - 0.35)
  parent.add(sign)
  const card = textSprite(['Choose a room at the console'], { width: 900, height: 110, scale: 1.0 })
  card.position.set(cx, 2.4, z0 + D - 0.5)
  group.add(card)

  /** Recolours the room for the room entered (null: no room, the neutral look). */
  function setTheme(roomId) {
    const t = ESCAPE_THEMES[roomId] ?? { wall: 0x3a2f33, trim: 0x6b4a2a, accent: 0xc99a3a, light: 0xffb060, sign: 'Choose a room at the console' }
    wallMat.color.setHex(t.wall)
    trimMat.color.setHex(t.trim)
    panel.material.color.setHex(t.accent)
    lamp.color.setHex(t.light)
    card.userData.draw?.([t.sign])
  }

  return { group, seat, setTheme, sign, card }
}

/**
 * The panel drawn while seated at the console, from `escapeOut`'s state:
 * the room picker (no room), or the intro, the objects to inspect, the clues
 * found, the locks with an answer box each, the teammate seat, the say box,
 * the log, Leave, and the escaped banner. Buttons carry `data-escape` (the
 * action) and `data-id` (an object or lock id, or a room id for `enter`);
 * inputs carry `data-escape-input` (the lock id), `data-escape-say`,
 * `data-escape-model` and `data-escape-effort`. All text is escaped.
 */
export function escapePanel(state) {
  if (!state) return '<h3>Escape Room</h3><div class="status">Loading…</div>'
  const models = (state.models ?? []).map(m => `<option value="${esc(m.id)}"${state.teammate?.model === m.id ? ' selected' : ''}>${esc(m.name)}</option>`).join('')
  const efforts = (state.efforts ?? []).map(e => `<option value="${esc(e)}"${(state.teammate?.effort ?? 'high') === e ? ' selected' : ''}>${esc(e)}</option>`).join('')
  const teammateName = id => esc((state.models ?? []).find(m => m.id === id)?.name ?? id)
  const seatBox =
    `<div class="seat"><div class="seat-head"><b>Teammate</b> · ${state.teammate ? `${teammateName(state.teammate.model)} · ${esc(state.teammate.effort)}` : 'nobody yet'}</div>` +
    `<div class="seat-form"><select data-escape-model>${models}</select><select data-escape-effort>${efforts}</select>` +
    `<button data-escape="teammate">${state.teammate ? 'Change teammate' : 'Seat a teammate'}</button>` +
    (state.teammate ? '<button data-escape="unseat">Send them away</button>' : '') +
    '</div></div>'
  const room = state.room
  if (!room) {
    const rooms = (state.rooms ?? []).map(r => `<button data-escape="enter" data-id="${esc(r.id)}">${esc(r.title)}<span class="dim"> · ${esc(r.theme)}</span></button>`).join('')
    return (
      '<h3>Escape Room</h3>' +
      '<div class="status">Pick a room. You and your teammate see the same clues; neither of you is told the answers.</div>' +
      `<div class="row">${rooms}<button data-escape="enter">Next in rotation</button></div>` +
      seatBox +
      '<div class="row"><span class="dim">Esc stands up</span></div>'
    )
  }
  const objects = room.objects
    .map(o => {
      const head = `<button data-escape="inspect" data-id="${esc(o.id)}"${o.isDiscovered ? ' class="done"' : ''}>${o.isDiscovered ? '✓ ' : ''}${esc(o.name)}</button>`
      const body = `<div class="dim">${esc(o.description)}</div>` + (o.isDiscovered ? `<div class="clue">${o.clue === null ? 'Nothing more to find here.' : esc(o.clue)}</div>` : '')
      return `<div class="object">${head}${body}</div>`
    })
    .join('')
  const puzzles = room.puzzles
    .map(p => {
      const head = `<div><b>${p.isExit ? 'Way out' : 'Lock'}</b>${p.isSolved ? ' · open' : p.isLocked ? ' · held shut by the other locks' : ''}</div><div>${esc(p.prompt)}</div>`
      if (p.isSolved) return `<div class="puzzle solved">${head}<div class="clue">${esc(p.successText ?? '')}</div></div>`
      return `${'<div class="puzzle">'}${head}<div class="move"><input data-escape-input="${esc(p.id)}" placeholder="your answer" maxlength="80"><button data-escape="try" data-id="${esc(p.id)}">Try</button></div></div>`
    })
    .join('')
  const log = (state.log ?? [])
    .map(l => `<div class="line ${l.who === 'you' ? 'user' : l.who === 'teammate' ? 'assistant' : 'room'}"><b>${l.who === 'you' ? 'You' : l.who === 'teammate' ? teammateName(state.teammate?.model) : 'Room'}:</b> ${esc(l.text)}</div>`)
    .join('')
  const status = state.isEscaped
    ? '<div class="status banner">You escaped! Leave, or pick another room.</div>'
    : state.busy
      ? '<div class="status">Your teammate is thinking…</div>'
      : `<div class="status">${esc(room.theme)} · ${room.puzzles.filter(p => p.isSolved).length} of ${room.puzzles.length} locks open</div>`
  return (
    `<h3>${esc(room.title)}</h3>` +
    status +
    `<div class="intro">${esc(room.intro)}</div>` +
    `<div class="objects"><b>In the room</b>${objects}</div>` +
    `<div class="puzzles"><b>Locks</b>${puzzles}</div>` +
    seatBox +
    `<div class="move"><input data-escape-say placeholder="${state.teammate ? 'Say something to your teammate' : 'Seat a teammate to talk'}" maxlength="600"><button data-escape="say"${state.teammate ? '' : ' disabled'}>Say</button></div>` +
    (state.error ? `<div class="error">${esc(state.error)}</div>` : '') +
    `<div class="history">${log || '<span class="dim">Nothing has happened yet.</span>'}</div>` +
    `<div class="row"><button data-escape="leave">Leave the room</button><span class="dim">Esc stands up</span></div>`
  )
}
