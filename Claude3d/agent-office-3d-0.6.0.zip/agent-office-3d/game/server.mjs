// Agent Office fullscreen: the local bridge between the mod and the game window.
//
// The mod runs `node server.mjs --launch` once (a one-shot command): the
// launcher makes a fresh folder, starts this same file again as a detached
// process (the server), waits for its `ready.json`, prints it as one
// `READY {...}` line and exits. The engine ends a child with the dispatch that
// started it, so the server must not be the mod's own child.
//
// The server:
// - listens on 127.0.0.1 only, on a free port, and answers only requests that
//   carry the per-launch token and name this exact host (no DNS rebinding);
// - streams `state.json`, which the mod writes, to the game page as
//   Server-Sent Events whenever it changes;
// - appends each checked command the page posts to `commands.jsonl`, which the
//   mod reads and acts on (select a worker, or a Send the person typed);
// - opens Edge or Chrome as a fullscreen app window with a throwaway profile,
//   and exits, deleting its folder, when that window closes, the mod asks it
//   to (`close` in the state), or the mod stops writing (a heartbeat).
//
// Node standard library only. Nothing here reads anything but its own files.

import { spawn, spawnSync } from 'node:child_process'
import { randomBytes } from 'node:crypto'
import { appendFileSync, existsSync, mkdirSync, readFileSync, renameSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { createServer } from 'node:http'
import { homedir, tmpdir } from 'node:os'
import { basename, dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const HERE = dirname(fileURLToPath(import.meta.url))

/** Starts the server on its own. On Windows the engine runs commands in a job that kills every descendant when the command ends, so the server is created through WMI, outside that job. */
function startDetached(dir) {
  const self = fileURLToPath(import.meta.url)
  if (process.platform === 'win32') {
    const ps =
      '$si = New-CimInstance -ClassName Win32_ProcessStartup -ClientOnly -Property @{ ShowWindow = [uint16]0 }; ' +
      '$r = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $env:SM_CMD; CurrentDirectory = $env:SM_CWD; ProcessStartupInformation = $si }; ' +
      'exit [int]$r.ReturnValue'
    const r = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps], {
      env: { ...process.env, SM_CMD: `"${process.execPath}" "${self}" --dir "${dir}"${process.env.SM_NO_BROWSER === '1' ? ' --no-browser' : ''}`, SM_CWD: HERE },
      windowsHide: true,
      encoding: 'utf8',
      timeout: 20000,
    })
    if (r.status === 0) return null
    return `WMI could not start the server (code ${r.status ?? 'none'}): ${String(r.stderr ?? r.error ?? '').trim().slice(0, 300)}`
  }
  const child = spawn(process.execPath, [self, '--dir', dir], { detached: true, stdio: 'ignore' })
  child.unref()
  return null
}

const argDir = (() => {
  const i = process.argv.indexOf('--dir')
  return i >= 0 ? process.argv[i + 1] : undefined
})()

if (process.argv.includes('--launch')) {
  const dir = join(tmpdir(), `agent-office-3d-${process.pid}-${randomBytes(4).toString('hex')}`)
  mkdirSync(dir, { recursive: true })
  const failed = startDetached(dir)
  if (failed !== null) {
    process.stdout.write(`FAILED ${JSON.stringify({ reason: failed })}\n`)
    process.exit(1)
  }
  const readyFile = join(dir, 'ready.json')
  const started = Date.now()
  const wait = setInterval(() => {
    if (existsSync(readyFile)) {
      clearInterval(wait)
      process.stdout.write(`READY ${readFileSync(readyFile, 'utf8').trim()}\n`)
      process.exit(0)
    } else if (Date.now() - started > 15000) {
      clearInterval(wait)
      process.stdout.write(`FAILED ${JSON.stringify({ reason: 'the server did not start in 15 s' })}\n`)
      process.exit(1)
    }
  }, 50)
} else {
  serve()
}

function serve() {
const TOKEN = randomBytes(24).toString('hex')
const DIR = argDir ?? process.env.SM_DIR ?? join(tmpdir(), `agent-office-3d-${process.pid}-${randomBytes(4).toString('hex')}`)
const STATE_FILE = join(DIR, 'state.json')
const CMD_FILE = join(DIR, 'commands.jsonl')
const READY_FILE = join(DIR, 'ready.json')
/** The mod writes at least this often; past STALE_MS without a write the bridge closes. */
const STALE_MS = 15000
const POLL_MS = 80
const MAX_BODY = 16384
const NO_BROWSER = process.env.SM_NO_BROWSER === '1' || process.argv.includes('--no-browser')

const STATIC = {
  '/': { file: 'index.html', type: 'text/html; charset=utf-8' },
  '/game.js': { file: 'game.js', type: 'text/javascript; charset=utf-8' },
}

mkdirSync(DIR, { recursive: true })

/** The last run's log, kept outside the folder (which is deleted on close) so a failure can be read afterwards. */
const LOG_FILE = join(tmpdir(), 'agent-office-3d-fullscreen.log')
const log = msg => {
  try {
    appendFileSync(LOG_FILE, `${new Date().toISOString()} [${process.pid}] ${msg}\n`)
  } catch {}
}
try {
  writeFileSync(LOG_FILE, '')
} catch {}
log(`server start, dir ${DIR}`)
process.on('uncaughtException', err => {
  log(`uncaught: ${err?.stack ?? err}`)
  close('crashed')
})
process.on('exit', code => log(`exit ${code}`))

/** One line to the mod: a word, then JSON. */
const say = (word, data) => process.stdout.write(`${word} ${JSON.stringify(data)}\n`)

const clients = new Set()
let lastMtime = 0
let lastText = ''
let lastWriteSeen = Date.now()
let browser = null
let isClosing = false

function close(reason) {
  if (isClosing) return
  isClosing = true
  log(`close: ${reason}`)
  say('CLOSED', { reason })
  // First, so the mod sees the link is over at once.
  try {
    rmSync(READY_FILE, { force: true })
  } catch {}
  // A connected page closes its own window on this event; a window that never connected is ended by its process.
  for (const res of clients) {
    try {
      res.write('event: close\ndata: {}\n\n')
    } catch {}
    res.end()
  }
  if (!everConnected) closeBrowser()
  server.close()
  // The folder may be held a moment longer: try it a few times.
  let tries = 0
  const sweep = setInterval(() => {
    tries += 1
    try {
      rmSync(DIR, { recursive: true, force: true })
    } catch {}
    if (!existsSync(DIR) || tries >= 10) {
      clearInterval(sweep)
      process.exit(0)
    }
  }, 300)
}

/**
 * Ends the browser process started here, with its children. Only for a window
 * whose page never connected: a connected page closes itself on the `close`
 * event, which leaves other windows on the same profile (another session's)
 * alone. If the browser handed off to a running instance, the process started
 * here is already gone and this does nothing.
 */
function closeBrowser() {
  if (browser === null || browser.exitCode !== null) return
  try {
    if (process.platform === 'win32') spawnSync('taskkill', ['/PID', String(browser.pid), '/T', '/F'], { windowsHide: true, timeout: 10000 })
    else browser.kill()
  } catch (err) {
    log(`closing the browser failed: ${err?.message ?? err}`)
  }
}

// The window is judged by its page, not its process: open while the page holds its event stream.
const START_AT = Date.now()
const NEVER_CONNECTED_MS = 60000
const GONE_MS = 8000
let everConnected = false
let lastClientAt = Date.now()
setInterval(() => {
  if (clients.size > 0) {
    everConnected = true
    lastClientAt = Date.now()
  } else if (everConnected && Date.now() - lastClientAt > GONE_MS) close('the game window closed')
  else if (!everConnected && Date.now() - START_AT > NEVER_CONNECTED_MS) close('the game window never connected')
}, 500)

function push(res, text) {
  res.write(`data: ${text.replace(/\n/g, '')}\n\n`)
}

// The state file, read when its mtime moves, pushed to every page.
setInterval(() => {
  let st
  try {
    st = statSync(STATE_FILE)
  } catch {
    if (Date.now() - lastWriteSeen > STALE_MS) close('the mod stopped writing')
    return
  }
  if (st.mtimeMs !== lastMtime) {
    lastMtime = st.mtimeMs
    if (lastMtime === 0 || lastText === '') log('state from the mod seen')
    lastWriteSeen = Date.now()
    let text
    let parsed
    try {
      text = readFileSync(STATE_FILE, 'utf8')
      parsed = JSON.parse(text)
    } catch {
      return // half-written; the next poll reads it whole
    }
    if (parsed?.close === true) {
      close('closed from Claude Code')
      return
    }
    if (text !== lastText) {
      lastText = text
      for (const res of clients) push(res, text)
    }
  } else if (Date.now() - lastWriteSeen > STALE_MS) close('the mod stopped writing')
}, POLL_MS)

// Every SSE stream gets a comment now and then so proxies and sleep do not drop it.
setInterval(() => {
  for (const res of clients) res.write(': ping\n\n')
}, 10000)

const COMMANDS = new Set(['select', 'send', 'hello', 'arcade', 'design', 'kanban', 'escape'])
const ARCADE_ACTIONS = new Set(['seat', 'leave', 'move', 'reset', 'retry'])
const ARCADE_EFFORTS = new Set(['low', 'medium', 'high', 'xhigh', 'max'])

/** An arcade command, exactly: the game, the action, and only the fields that action takes, each bounded. */
function checkArcade(body) {
  // The game's key: letters and digits; the mod checks it against the games it has.
  if (typeof body.game !== 'string' || !/^[a-z0-9]{1,16}$/.test(body.game) || !ARCADE_ACTIONS.has(body.action)) return null
  const out = { type: 'arcade', game: body.game, action: body.action }
  if (body.action === 'seat' || body.action === 'leave') {
    if (body.side !== 'a' && body.side !== 'b') return null
    out.side = body.side
  }
  if (body.action === 'seat') {
    const s = body.seat
    if (typeof s !== 'object' || s === null) return null
    if (s.kind === 'human') out.seat = { kind: 'human' }
    else if (s.kind === 'agent' && typeof s.model === 'string' && s.model.length <= 60 && ARCADE_EFFORTS.has(s.effort))
      out.seat = { kind: 'agent', model: s.model, effort: s.effort, name: typeof s.name === 'string' ? s.name.slice(0, 40) : '' }
    else return null
  }
  if (body.action === 'move') {
    if (typeof body.move !== 'string' || body.move.trim() === '' || body.move.length > 24) return null
    out.move = body.move.trim()
  }
  return out
}

const DESIGN_ACTIONS = new Set(['request', 'apply', 'cancel', 'undo', 'reset', 'remove'])
const KANBAN_ACTIONS = new Set(['toggle', 'move', 'add', 'edit', 'remove', 'reload'])
const ESCAPE_ACTIONS = new Set(['enter', 'leave', 'inspect', 'try', 'say', 'teammate', 'unseat'])
const ESCAPE_FIELDS = { roomId: 40, objectId: 40, puzzleId: 40, text: 400, model: 60, effort: 10 }
const line = (v, max) => (typeof v === 'string' && v.trim() !== '' && v.length <= max && !/[\r\n]/.test(v) ? v.trim() : null)

/** A world-editor command: the action, and only the field that action takes. The mod checks it all again. */
function checkDesign(body) {
  if (!DESIGN_ACTIONS.has(body.action)) return null
  const out = { type: 'design', action: body.action }
  if (body.action === 'request') {
    out.text = line(body.text, 400)
    if (out.text === null) return null
  }
  if (body.action === 'remove') {
    if (typeof body.id !== 'string' || !/^[a-z0-9_-]{1,32}$/.test(body.id)) return null
    out.id = body.id
  }
  return out
}

/** A kanban command: the action, the card id, the column and the text, each bounded as the board module bounds them. */
function checkKanban(body) {
  if (!KANBAN_ACTIONS.has(body.action)) return null
  const out = { type: 'kanban', action: body.action }
  if (['toggle', 'move', 'edit', 'remove'].includes(body.action)) {
    if (typeof body.id !== 'string' || !/^[0-9a-f]{8}(-\d+)?$/.test(body.id)) return null
    out.id = body.id
  }
  if (body.action === 'move' || body.action === 'add') {
    out.column = line(body.column, 80)
    if (out.column === null) return null
  }
  if (body.action === 'edit' || body.action === 'add') {
    out.text = line(body.text, 300)
    if (out.text === null) return null
  }
  return out
}

/** An escape-room command: the action and its named fields, each one bounded line; the mod checks the ids against the room. */
function checkEscape(body) {
  if (!ESCAPE_ACTIONS.has(body.action)) return null
  const out = { type: 'escape', action: body.action }
  for (const [k, max] of Object.entries(ESCAPE_FIELDS)) {
    if (body[k] === undefined || body[k] === null) continue
    const v = line(body[k], max)
    if (v === null) return null
    out[k] = v
  }
  return out
}

/** A command the page may post, exactly; anything else is refused whole. */
function checkCommand(body) {
  if (typeof body !== 'object' || body === null || Array.isArray(body)) return null
  if (!COMMANDS.has(body.type)) return null
  if (body.type === 'hello') return { type: 'hello' }
  if (body.type === 'arcade') return checkArcade(body)
  if (body.type === 'design') return checkDesign(body)
  if (body.type === 'kanban') return checkKanban(body)
  if (body.type === 'escape') return checkEscape(body)
  if (typeof body.key !== 'string' || body.key.length === 0 || body.key.length > 200) return null
  if (body.type === 'select') return { type: 'select', key: body.key }
  if (typeof body.text !== 'string' || body.text.trim() === '' || body.text.length > 2000) return null
  return { type: 'send', key: body.key, text: body.text }
}

const server = createServer((req, res) => {
  const host = req.headers.host ?? ''
  const port = server.address()?.port
  if (host !== `127.0.0.1:${port}`) {
    res.writeHead(403).end()
    return
  }
  const url = new URL(req.url ?? '/', `http://${host}`)
  const isAuthed = url.searchParams.get('t') === TOKEN
  res.setHeader('Cache-Control', 'no-store')
  res.setHeader('X-Content-Type-Options', 'nosniff')

  if (url.pathname === '/favicon.ico') {
    res.writeHead(204).end()
    return
  }
  // The page's own modules: the board drawers under game/boards and the feature modules beside game.js, by a strict name.
  const mod = /^\/(boards\/[a-z0-9]+|[a-z0-9]+)\.js$/.exec(url.pathname)
  if (req.method === 'GET' && mod !== null && url.pathname !== '/game.js') {
    const file = join(HERE, ...url.pathname.slice(1).split('/'))
    if (!existsSync(file)) {
      res.writeHead(404).end()
      return
    }
    res.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8' })
    res.end(readFileSync(file))
    return
  }
  if (req.method === 'GET' && url.pathname in STATIC) {
    if (url.pathname === '/' && !isAuthed) {
      res.writeHead(403).end('This window must be opened by /office3d full.')
      return
    }
    const s = STATIC[url.pathname]
    res.writeHead(200, { 'Content-Type': s.type })
    res.end(readFileSync(join(HERE, s.file)))
    return
  }
  if (!isAuthed) {
    res.writeHead(403).end()
    return
  }
  if (req.method === 'GET' && url.pathname === '/events') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', Connection: 'keep-alive' })
    clients.add(res)
    if (lastText !== '') push(res, lastText)
    req.on('close', () => clients.delete(res))
    return
  }
  if (req.method === 'POST' && url.pathname === '/cmd') {
    const origin = req.headers.origin
    if (origin !== undefined && origin !== `http://127.0.0.1:${port}`) {
      res.writeHead(403).end()
      return
    }
    let size = 0
    const parts = []
    req.on('data', chunk => {
      size += chunk.length
      if (size > MAX_BODY) req.destroy()
      else parts.push(chunk)
    })
    req.on('end', () => {
      let cmd = null
      try {
        cmd = checkCommand(JSON.parse(Buffer.concat(parts).toString('utf8')))
      } catch {}
      if (cmd === null) {
        res.writeHead(400).end()
        return
      }
      try {
        appendFileSync(CMD_FILE, `${JSON.stringify(cmd)}\n`)
      } catch {
        res.writeHead(500).end()
        return
      }
      say('CMD', cmd)
      res.writeHead(204).end()
    })
    return
  }
  res.writeHead(404).end()
})

// Chrome before Edge: in app mode with its own profile Chrome shows nothing but the page, while Edge adds promos.
const BROWSERS = [
  join(process.env.ProgramFiles ?? 'C:\\Program Files', 'Google', 'Chrome', 'Application', 'chrome.exe'),
  join(process.env['ProgramFiles(x86)'] ?? 'C:\\Program Files (x86)', 'Google', 'Chrome', 'Application', 'chrome.exe'),
  join(process.env.LOCALAPPDATA ?? '', 'Google', 'Chrome', 'Application', 'chrome.exe'),
  join(process.env['ProgramFiles(x86)'] ?? 'C:\\Program Files (x86)', 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
  join(process.env.ProgramFiles ?? 'C:\\Program Files', 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
]

const BROWSER_EXE = NO_BROWSER ? undefined : BROWSERS.find(p => p !== '' && existsSync(p))

/**
 * The window's browser profile: one per browser, kept between launches (under
 * the person's home, beside Claude Code's own files), so whatever the browser
 * asks on a first run is asked once, and a prompt dismissed stays dismissed.
 * Nothing of the person's own browser profile is used.
 */
const PROFILE = join(homedir(), '.claude', 'agent-office-3d', `browser-profile-${basename(BROWSER_EXE ?? 'none', '.exe').toLowerCase()}`)

function openBrowser(url) {
  const exe = BROWSER_EXE
  if (exe === undefined) return
  mkdirSync(PROFILE, { recursive: true })
  browser = spawn(
    exe,
    [
      `--app=${url}`,
      '--start-fullscreen',
      '--start-maximized',
      `--user-data-dir=${PROFILE}`,
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-extensions',
      '--disable-component-extensions-with-background-pages',
      '--disable-default-apps',
      '--disable-sync',
      '--disable-background-networking',
      '--no-service-autorun',
      '--disable-features=Translate,msEdgeSidebar,msHubApps,msShoppingTrigger,msEdgeDiscoverButton',
      '--autoplay-policy=no-user-gesture-required',
    ],
    { stdio: 'ignore' },
  )
  log(`browser started: ${exe} pid ${browser.pid}`)
  // Not a close: Edge may hand off to a fresh process and exit at once. The page's event stream says when the window is gone.
  browser.on('exit', code => log(`browser launcher exited (${code})`))
  browser.on('error', err => log(`browser failed to start: ${err?.message ?? err}`))
}

server.listen(0, '127.0.0.1', () => {
  const { port } = server.address()
  const url = `http://127.0.0.1:${port}/?t=${TOKEN}`
  const ready = { port, url, dir: DIR, stateFile: STATE_FILE, cmdFile: CMD_FILE, readyFile: READY_FILE, hasBrowser: BROWSER_EXE !== undefined }
  // Written whole, then renamed: the launcher never reads half a file.
  writeFileSync(`${READY_FILE}.tmp`, JSON.stringify(ready))
  renameSync(`${READY_FILE}.tmp`, READY_FILE)
  say('READY', ready)
  openBrowser(url)
})

process.on('SIGTERM', () => close('stopped'))
process.on('SIGINT', () => close('stopped'))
}
