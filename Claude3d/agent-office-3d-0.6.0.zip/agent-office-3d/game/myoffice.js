// Your own office in the fullscreen window: a room of your own off the
// hallway with one big desk, your chair, and a wide monitor. The monitor shows
// a still desktop until you sit down and share a window: then the browser's
// own picker (the same one video calls use) lets you choose a window, a tab or
// a screen, and its pixels go onto the monitor as a video texture.
//
// What that means for privacy: the picture never leaves this page. Nothing is
// posted to the mod, the server or any session; no browser profile, bookmark,
// cookie or password is read (your real browser keeps all of that, and you
// pick what to show each time). Sharing stops when you click Stop sharing
// here, or Stop in the browser's own banner, or stand up and close the window.
//
// No imports: the host (game.js) hands in THREE and its own helpers, wires the
// seat into its targeting like an arcade chair, and listens on the panel.

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])

const SCREEN = { w: 1.5, h: 0.84 } // metres: a wide monitor you can read from the chair
const CANVAS = { w: 1024, h: 576 }

/** The still desktop drawn on the monitor when nothing is shared. */
function paintIdle(canvas, note) {
  const g = canvas.getContext('2d')
  const { width: W, height: H } = canvas
  const sky = g.createLinearGradient(0, 0, 0, H)
  sky.addColorStop(0, '#1b2a4a')
  sky.addColorStop(0.6, '#2d4a7a')
  sky.addColorStop(1, '#0f1a30')
  g.fillStyle = sky
  g.fillRect(0, 0, W, H)
  // A few soft hills, as a wallpaper would have.
  for (const [y, c] of [[0.62, '#223d5f'], [0.7, '#1a3050'], [0.8, '#122440']]) {
    g.fillStyle = c
    g.beginPath()
    g.moveTo(0, H)
    for (let x = 0; x <= W; x += 32) g.lineTo(x, H * y + Math.sin(x / 90 + y * 9) * 14 + Math.sin(x / 37) * 5)
    g.lineTo(W, H)
    g.closePath()
    g.fill()
  }
  // The taskbar.
  g.fillStyle = 'rgba(8,12,20,0.85)'
  g.fillRect(0, H - 44, W, 44)
  g.fillStyle = '#9fb3cc'
  g.font = '20px system-ui, sans-serif'
  g.textBaseline = 'middle'
  g.textAlign = 'left'
  g.fillText('◼  ⌕  ▣  ◉  ✉', 18, H - 22)
  g.textAlign = 'right'
  const now = new Date()
  g.fillText(`${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`, W - 18, H - 22)
  // The note in the middle.
  g.textAlign = 'center'
  g.fillStyle = 'rgba(255,255,255,0.92)'
  g.font = '600 34px system-ui, sans-serif'
  g.fillText('Your monitor', W / 2, H * 0.36)
  g.font = '22px system-ui, sans-serif'
  g.fillStyle = 'rgba(255,255,255,0.72)'
  const lines = note.split('\n')
  lines.forEach((l, i) => g.fillText(l, W / 2, H * 0.46 + i * 30))
}

/**
 * Builds the office inside the room whose near-left corner (hallway side) is
 * `origin` ({ x, z, width, depth }): the desk across the middle facing the
 * door, your chair behind it, the monitor on it, and a few things of your
 * own. Answers `{ group, seat, setStream, isSharing }`: `seat` is a seat
 * descriptor like the arcade's (`{ kind: 'monitor', pos, stand, yaw, number }`),
 * `setStream(stream | null)` puts a MediaStream on the monitor or takes it off.
 */
export function buildMyOffice(THREE, helpers, parent, origin) {
  const { box, mat, textSprite, chair, plant, cabinet, deskWood, metal, solid } = helpers
  const x0 = origin.x
  const z0 = origin.z
  const W = origin.width
  const D = origin.depth
  const cx = x0 + W / 2
  const cz = z0 + D * 0.52 // the desk's centre line
  const g = new THREE.Group()
  parent.add(g)

  // A rug under the desk, and the desk: a wide top on two pedestals, facing the door (you sit on the window side, looking -z).
  const rug = new THREE.Mesh(new THREE.PlaneGeometry(4.2, 3.2), mat(0x5a4a62, { roughness: 0.95 }))
  rug.rotation.x = -Math.PI / 2
  rug.position.set(cx, 0.004, cz + 0.3)
  rug.receiveShadow = true
  g.add(rug)
  const top = box(2.0, 0.05, 0.9, deskWood, cx, 0.74, cz, g)
  top.castShadow = true
  box(0.5, 0.7, 0.8, mat(0x33383f, { roughness: 0.6 }), cx - 0.7, 0.355, cz, g)
  box(0.5, 0.7, 0.8, mat(0x33383f, { roughness: 0.6 }), cx + 0.7, 0.355, cz, g)
  box(0.2, 0.02, 0.12, metal, cx - 0.7, 0.5, cz - 0.41, g) // drawer handles
  box(0.2, 0.02, 0.12, metal, cx - 0.7, 0.25, cz - 0.41, g)
  solid(cx, cz, 2.0, 0.9)

  // The monitor: on the far side of the desk from you, its face toward the chair (+z), on a stand.
  const canvas = document.createElement('canvas')
  canvas.width = CANVAS.w
  canvas.height = CANVAS.h
  paintIdle(canvas, 'Sit here (E) and share a window\nto see it live on this screen')
  const idleTex = new THREE.CanvasTexture(canvas)
  idleTex.colorSpace = THREE.SRGBColorSpace
  const screenMat = new THREE.MeshBasicMaterial({ map: idleTex })
  const monitor = new THREE.Group()
  monitor.position.set(cx, 0.765, cz - 0.32)
  g.add(monitor)
  box(SCREEN.w + 0.05, SCREEN.h + 0.05, 0.035, metal, 0, 0.22 + SCREEN.h / 2, 0, monitor)
  const screen = new THREE.Mesh(new THREE.PlaneGeometry(SCREEN.w, SCREEN.h), screenMat)
  screen.position.set(0, 0.22 + SCREEN.h / 2, 0.019)
  monitor.add(screen)
  box(0.06, 0.22, 0.05, metal, 0, 0.11, 0, monitor)
  box(0.42, 0.015, 0.2, metal, 0, 0.0075, 0.02, monitor)
  // Keyboard, mouse, a lamp and a mug on your side.
  box(0.44, 0.015, 0.14, mat(0x1f242c, { roughness: 0.6 }), cx, 0.775, cz + 0.12, g)
  box(0.06, 0.02, 0.1, mat(0x1f242c, { roughness: 0.5 }), cx + 0.36, 0.775, cz + 0.1, g)
  const mug = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.035, 0.09, 14), mat(0xd9534f))
  mug.position.set(cx - 0.55, 0.81, cz + 0.2)
  mug.castShadow = true
  g.add(mug)
  // A desk lamp at the far left corner of the desk, leaning in over it.
  box(0.16, 0.02, 0.16, metal, cx - 0.86, 0.775, cz - 0.32, g)
  const lampArm = box(0.025, 0.46, 0.025, metal, cx - 0.82, 0.99, cz - 0.32, g)
  lampArm.rotation.z = -0.2
  const shade = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.13, 18, 1, true), mat(0x2b303a, { metalness: 0.5, roughness: 0.4, side: THREE.DoubleSide }))
  shade.position.set(cx - 0.74, 1.2, cz - 0.32)
  shade.rotation.z = 0.45
  g.add(shade)
  const lamp = new THREE.PointLight(0xffd9a0, 2.0, 3.0, 2)
  lamp.position.set(cx - 0.74, 1.14, cz - 0.32)
  g.add(lamp)

  // Your chair, behind the desk, and two for visitors in front of it.
  chair(g, cx, cz + 0.72, Math.PI)
  chair(g, cx - 0.5, cz - 1.25, 0.25)
  chair(g, cx + 0.5, cz - 1.25, -0.25)
  solid(cx, cz + 0.72, 0.5, 0.5)
  solid(cx - 0.5, cz - 1.25, 0.5, 0.5)
  solid(cx + 0.5, cz - 1.25, 0.5, 0.5)

  // Things along the walls: shelves of books on the left, a cabinet and plants.
  const shelfX = x0 + 0.35
  for (let s = 0; s < 4; s++) {
    box(0.3, 0.03, 2.2, mat(0x6b4a2a, { roughness: 0.7 }), shelfX, 0.4 + s * 0.45, cz + 0.6, g)
    let zz = cz - 0.4
    let i = 0
    while (zz < cz + 1.6) {
      const w = 0.04 + ((s * 7 + i * 3) % 5) * 0.01
      const h = 0.22 + ((s * 5 + i * 11) % 4) * 0.03
      box(0.22, h, w, mat([0x8a3b3b, 0x2f5a8a, 0x3a7a4a, 0xa88a3a, 0x5a3a7a, 0xd8d0c0][(s + i) % 6], { roughness: 0.8 }), shelfX, 0.4 + s * 0.45 + 0.015 + h / 2, zz + w / 2, g)
      zz += w + 0.008
      i++
    }
  }
  box(0.3, 0.03, 2.2, mat(0x6b4a2a, { roughness: 0.7 }), shelfX, 0.4 + 4 * 0.45, cz + 0.6, g)
  box(0.03, 1.9, 2.2, mat(0x6b4a2a, { roughness: 0.7 }), shelfX - 0.14, 1.3, cz + 0.6, g)
  solid(shelfX, cz + 0.6, 0.34, 2.3)
  cabinet(g, x0 + W - 0.5, z0 + 2.0, -Math.PI / 2)
  plant(g, x0 + W - 0.7, cz + 2.0, 31)
  // A nameplate on the desk and a sign on the wall behind you.
  const plate = textSprite(['Your desk'], { width: 300, height: 96, scale: 0.28 })
  plate.position.set(cx + 0.72, 0.86, cz - 0.3)
  g.add(plate)
  const sign = textSprite(['My Office', 'sit down · share a window to your monitor'], { width: 800, height: 150, scale: 0.9 })
  sign.position.set(cx, 2.5, z0 + D - 0.5)
  g.add(sign)

  // The seat, as the host's targeting expects it.
  const seat = {
    kind: 'monitor',
    number: 'monitor',
    pos: new THREE.Vector3(cx, 0, cz + 0.72),
    stand: new THREE.Vector3(cx, 0, cz + 1.55),
    yaw: 0, // facing -z: the monitor, and the door beyond
    x: cx,
    z: cz + 0.72,
  }

  let video = null
  let videoTex = null
  const setStream = stream => {
    if (videoTex) {
      videoTex.dispose()
      videoTex = null
    }
    if (video) {
      video.pause()
      video.srcObject = null
      video = null
    }
    if (stream === null) {
      screenMat.map = idleTex
      screenMat.needsUpdate = true
      return
    }
    video = document.createElement('video')
    video.muted = true
    video.playsInline = true
    video.autoplay = true
    video.srcObject = stream
    void video.play().catch(() => {})
    videoTex = new THREE.VideoTexture(video)
    videoTex.colorSpace = THREE.SRGBColorSpace
    screenMat.map = videoTex
    screenMat.needsUpdate = true
  }
  return { group: g, seat, screen, setStream, isSharing: () => video !== null }
}

/**
 * The panel while you sit at your desk: share, stop, what it means. Every
 * button carries `data-monitor` (the action); the host listens.
 */
export function myOfficePanel({ sharing, error, supported, label }) {
  const status = !supported
    ? '<div class="status err">This browser cannot share a window here.</div>'
    : sharing
      ? `<div class="status">Showing ${esc(label || 'a shared window')} on your monitor.</div>`
      : '<div class="status">Your monitor is idle. Share a window to see it here, live.</div>'
  return (
    '<h3>Your desk</h3>' +
    status +
    (error ? `<div class="error">${esc(error)}</div>` : '') +
    `<div class="row">${sharing ? '<button data-monitor="stop">Stop sharing</button><button data-monitor="share">Share another</button>' : supported ? '<button data-monitor="share">Share a window…</button>' : ''}<span class="dim">Esc stands up</span></div>` +
    '<div class="dim" style="margin-top:10px;line-height:1.5">The browser\'s own picker chooses a window, a tab or a screen, and its picture goes onto this monitor and nowhere else: nothing is sent to the mod, a session or a file. ' +
    'Your real browser keeps its sign-ins, bookmarks and passwords; none of them are read. Sharing stops here, in the browser\'s own Stop bar, or when the window closes.</div>'
  )
}
