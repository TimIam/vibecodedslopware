// The Bones (Knucklebones) board for the window: two grids of three columns
// on a square canvas texture, side a's in the image's top half and side b's
// in the bottom half, each drawn in its own sitter's frame (the image's top
// edge lies at side a's edge of the table, so a's half is turned 180° and
// reads the right way up from a's chair; b's half is upright). The game `g`
// is what out(s) gives (grids bottom-first, scores, columnScores, roll,
// lastMove, removed) plus seats, turn, status, legal and sides.

const COLUMNS = 'abc'
const SLOTS = 3
const SIZE = 768

/** Where things sit in one half, in that sitter's frame: a box `W` wide and `H` tall with the sitter at the bottom edge. */
function layout(S) {
  const W = S
  const H = S / 2
  const pitch = Math.round(S * 0.1276) // 98 at 768
  const cell = Math.round(pitch * 0.9)
  const gridX = (W - 3 * pitch) / 2
  const slotTop = Math.round(H * 0.11) // the top (far) slot's edge
  return {
    W, H, pitch, cell, gridX,
    slotY: k => slotTop + (SLOTS - 1 - k) * pitch, // slot k, 0 nearest the sitter
    scoreY: slotTop * 0.5, // the column scores, beyond the far slot
    letterY: slotTop + SLOTS * pitch + (H - slotTop - SLOTS * pitch) / 2, // the letters, nearest the sitter
    rolledX: W - (W - gridX - 3 * pitch) / 2, // the big die, right of the grid
    rolledY: H * 0.5,
    rolledSize: Math.round(S * 0.15),
    panelX: gridX / 2, // the name and total, left of the grid
  }
}

const PIPS = {
  1: [[0.5, 0.5]],
  2: [[0.27, 0.27], [0.73, 0.73]],
  3: [[0.27, 0.27], [0.5, 0.5], [0.73, 0.73]],
  4: [[0.27, 0.27], [0.73, 0.27], [0.27, 0.73], [0.73, 0.73]],
  5: [[0.27, 0.27], [0.73, 0.27], [0.5, 0.5], [0.27, 0.73], [0.73, 0.73]],
  6: [[0.27, 0.25], [0.73, 0.25], [0.27, 0.5], [0.73, 0.5], [0.27, 0.75], [0.73, 0.75]],
}

function roundRect(c, x, y, w, h, r) {
  c.beginPath()
  c.moveTo(x + r, y)
  c.lineTo(x + w - r, y)
  c.quadraticCurveTo(x + w, y, x + w, y + r)
  c.lineTo(x + w, y + h - r)
  c.quadraticCurveTo(x + w, y + h, x + w - r, y + h)
  c.lineTo(x + r, y + h)
  c.quadraticCurveTo(x, y + h, x, y + h - r)
  c.lineTo(x, y + r)
  c.quadraticCurveTo(x, y, x + r, y)
  c.closePath()
}

/** A die of side `size` with its top-left corner at (x, y); `ghost` draws it faint, for a die that was knocked out. */
function die(c, x, y, size, value, ghost = false) {
  const r = size * 0.16
  roundRect(c, x, y, size, size, r)
  if (ghost) {
    c.fillStyle = 'rgba(214, 70, 60, 0.12)'
    c.fill()
    c.lineWidth = Math.max(1, size * 0.03)
    c.strokeStyle = 'rgba(214, 70, 60, 0.55)'
    c.setLineDash([size * 0.08, size * 0.06])
    c.stroke()
    c.setLineDash([])
  } else {
    const grad = c.createLinearGradient(x, y, x + size, y + size)
    grad.addColorStop(0, '#fbf5e6')
    grad.addColorStop(1, '#e6d9bc')
    c.fillStyle = grad
    c.fill()
    c.lineWidth = Math.max(1, size * 0.035)
    c.strokeStyle = '#8d7a56'
    c.stroke()
  }
  const pips = PIPS[value] ?? []
  const pr = size * 0.085
  c.fillStyle = ghost ? 'rgba(214, 70, 60, 0.55)' : '#2a2118'
  for (const [px, py] of pips) {
    c.beginPath()
    c.arc(x + px * size, y + py * size, pr, 0, Math.PI * 2)
    c.fill()
  }
}

function text(c, str, x, y, px, color, align = 'center', weight = 'bold') {
  c.font = `${weight} ${px}px "Segoe UI", sans-serif`
  c.textAlign = align
  c.textBaseline = 'middle'
  c.fillStyle = color
  c.fillText(str, x, y)
}

const other = side => (side === 'a' ? 'b' : 'a')

/**
 * One side's half, drawn in the sitter's frame: the context is already
 * transformed so (0, 0) is the sitter's far-left corner and (W, H) the near-right.
 */
function drawHalf(c, S, side, g) {
  const L = layout(S)
  const grid = g?.grids?.[side] ?? [[], [], []]
  const colScores = g?.columnScores?.[side] ?? [0, 0, 0]
  const total = g?.scores?.[side] ?? 0
  const over = g?.status === 'over' // the arcade's statuses: waiting, playing, stuck, over
  const toMove = !!g && g.turn === side && g.roll !== null && !over
  const legal = new Set(toMove ? g.legal ?? [] : [])
  const last = g?.lastMove ?? null
  const removed = g?.removed ?? null
  const name = g?.sides?.[side] ?? (side === 'a' ? 'Player 1' : 'Player 2')

  // The felt of this half, a touch brighter for the side to move.
  c.fillStyle = toMove ? (side === 'a' ? '#355542' : '#334a5c') : side === 'a' ? '#2d4737' : '#2b3e4d'
  c.fillRect(0, 0, L.W, L.H)

  for (let i = 0; i < 3; i++) {
    const letter = COLUMNS[i]
    const x = L.gridX + i * L.pitch
    const colTop = L.slotY(SLOTS - 1)
    const colBottom = L.slotY(0) + L.cell
    // The column's tray, highlighted when it can be played this turn.
    roundRect(c, x - L.pitch * 0.05, colTop - L.pitch * 0.06, L.cell + L.pitch * 0.1, colBottom - colTop + L.pitch * 0.12, L.pitch * 0.1)
    c.fillStyle = legal.has(letter) ? 'rgba(255, 232, 150, 0.26)' : 'rgba(0, 0, 0, 0.18)'
    c.fill()
    if (legal.has(letter)) {
      c.lineWidth = Math.max(1, S * 0.004)
      c.strokeStyle = 'rgba(255, 232, 150, 0.7)'
      c.stroke()
    }
    // The slots, empty ones as faint insets.
    const dice = grid[i] ?? []
    for (let k = 0; k < SLOTS; k++) {
      const y = L.slotY(k)
      if (k < dice.length) {
        die(c, x, y, L.cell, dice[k])
        if (last && last.side === side && last.column === letter && k === dice.length - 1) {
          roundRect(c, x - L.cell * 0.05, y - L.cell * 0.05, L.cell * 1.1, L.cell * 1.1, L.cell * 0.2)
          c.lineWidth = Math.max(2, L.cell * 0.06)
          c.strokeStyle = '#f0b429'
          c.stroke()
        }
      } else {
        roundRect(c, x + L.cell * 0.08, y + L.cell * 0.08, L.cell * 0.84, L.cell * 0.84, L.cell * 0.14)
        c.fillStyle = 'rgba(0, 0, 0, 0.14)'
        c.fill()
      }
    }
    // The dice the last placement knocked out of this column, as ghosts in its free slots.
    if (removed && last && other(last.side) === side && removed.column === letter) {
      removed.values.forEach((v, j) => {
        const k = dice.length + j
        if (k < SLOTS) die(c, x, L.slotY(k), L.cell, v, true)
      })
    }
    // The column's score beyond its far end, and its letter at the near end.
    text(c, String(colScores[i] ?? 0), x + L.cell / 2, L.scoreY, L.pitch * 0.3, colScores[i] > 0 ? '#f6efdd' : 'rgba(246, 239, 221, 0.45)')
    text(c, letter, x + L.cell / 2, L.letterY, L.pitch * 0.32, legal.has(letter) ? '#ffe89a' : 'rgba(246, 239, 221, 0.6)')
  }

  // The name and the total, left of the grid.
  text(c, name, L.panelX, L.H * 0.2, S * 0.034, '#f6efdd')
  text(c, 'total', L.panelX, L.H * 0.36, S * 0.022, 'rgba(246, 239, 221, 0.6)', 'center', 'normal')
  text(c, String(total), L.panelX, L.H * 0.56, S * 0.09, '#ffffff')
  if (over) {
    const a = g?.scores?.a ?? 0
    const b = g?.scores?.b ?? 0
    const verdict = a === b ? 'draw' : (a > b ? 'a' : 'b') === side ? 'winner' : ''
    if (verdict) text(c, verdict, L.panelX, L.H * 0.78, S * 0.028, verdict === 'winner' ? '#ffe89a' : '#f6efdd')
  } else if (toMove) {
    text(c, 'your turn', L.panelX, L.H * 0.78, S * 0.024, '#ffe89a', 'center', 'normal')
  }

  // The die just rolled, large, right of the grid of the side to move.
  if (toMove) {
    const d = L.rolledSize
    const x = L.rolledX - d / 2
    const y = L.rolledY - d / 2
    c.save()
    c.shadowColor = 'rgba(255, 232, 150, 0.8)'
    c.shadowBlur = d * 0.35
    die(c, x, y, d, g.roll)
    c.restore()
    die(c, x, y, d, g.roll)
    text(c, 'rolled', L.rolledX, y - d * 0.22, S * 0.022, 'rgba(246, 239, 221, 0.7)', 'center', 'normal')
    text(c, 'place it in a column', L.rolledX, y + d * 1.2, S * 0.018, 'rgba(246, 239, 221, 0.6)', 'center', 'normal')
  } else if (g && !over && g.roll !== null) {
    text(c, 'waiting', L.rolledX, L.rolledY, S * 0.022, 'rgba(246, 239, 221, 0.4)', 'center', 'normal')
  }
}

/** The column index a local x (in the sitter's frame) falls in, or -1. */
function columnAt(S, localX) {
  const L = layout(S)
  const i = Math.floor((localX - L.gridX) / L.pitch)
  if (i < 0 || i >= 3) return -1
  return localX - (L.gridX + i * L.pitch) <= L.cell + L.pitch * 0.05 ? i : -1
}

export default {
  kind: 'bones',
  size: SIZE,

  draw(canvas, g, _selected) {
    const c = canvas.getContext('2d')
    const S = canvas.width
    c.setTransform(1, 0, 0, 1, 0, 0)
    c.fillStyle = '#1d2a22'
    c.fillRect(0, 0, S, S)

    // Side a's half: the image's top, turned so it reads from a's chair at the image's top edge.
    c.save()
    c.translate(S, S / 2)
    c.rotate(Math.PI)
    drawHalf(c, S, 'a', g)
    c.restore()

    // Side b's half: the image's bottom, upright.
    c.save()
    c.translate(0, S / 2)
    drawHalf(c, S, 'b', g)
    c.restore()

    // The divider between the two grids.
    c.fillStyle = '#120f0c'
    c.fillRect(0, S / 2 - S * 0.006, S, S * 0.012)
    c.fillStyle = 'rgba(255, 255, 255, 0.08)'
    c.fillRect(0, S / 2 - S * 0.012, S, S * 0.006)
    c.fillRect(0, S / 2 + S * 0.006, S, S * 0.006)
  },

  /**
   * A click in the side to move's half plays the column it lands in, when that
   * column is legal; clicks in the other half, outside the columns, or when no
   * move is on are nothing.
   */
  click(u, v, g, _selected) {
    if (!g || !Array.isArray(g.legal) || g.legal.length === 0) return null
    if (u < 0 || u > 1 || v < 0 || v > 1) return null
    const S = SIZE
    const side = v > 0.5 ? 'a' : 'b' // v = 1 is the image's top, side a's edge
    if (g.turn !== side) return null
    const localX = side === 'a' ? S - u * S : u * S
    const i = columnAt(S, localX)
    if (i < 0) return null
    const letter = COLUMNS[i]
    return g.legal.includes(letter) ? { move: letter } : null
  },
}
