// The checkers board on an arcade table, for the window: drawn flat on a
// canvas in the chess convention (rank 1 at the image's top, the h-file at its
// left, so side a's sitter sees rank 1 at their edge with the a-file on their
// left), and a click mapped back to a square the same way. Plain canvas 2D,
// no imports. `g` is the game as the window receives it: `cells` (64, a1 = 0,
// `a`/`b` men, `A`/`B` kings), `lastMove`, `mustCapture`, `seats`, `turn`,
// `status`, `legal` (the legal move strings) and `sides`.

const FILES = 'abcdefgh'
const index = name => FILES.indexOf(name[0]) + (Number(name[1]) - 1) * 8
const squares = move => move.split(/[-x]/)
const last = xs => xs[xs.length - 1]

const COLOR = {
  dark: '#5e4634',
  light: '#e9dcc0',
  darkMoved: '#7a8a4c',
  lightMoved: '#c9d882',
  select: '#f0c330',
  dot: 'rgba(240, 195, 48, 0.9)',
  black: '#1c1713',
  blackRim: '#8a7a6a',
  red: '#b8312f',
  redRim: '#f3c3b4',
  crown: '#f0c330',
}

function crown(c, cx, cy, q) {
  const w = q * 0.2
  const h = q * 0.13
  c.beginPath()
  c.moveTo(cx - w, cy + h)
  c.lineTo(cx - w, cy - h)
  c.lineTo(cx - w / 2, cy)
  c.lineTo(cx, cy - h * 1.3)
  c.lineTo(cx + w / 2, cy)
  c.lineTo(cx + w, cy - h)
  c.lineTo(cx + w, cy + h)
  c.closePath()
  c.fillStyle = COLOR.crown
  c.fill()
}

function disc(c, cx, cy, q, piece) {
  const red = piece.toLowerCase() === 'b'
  c.beginPath()
  c.arc(cx, cy, q * 0.4, 0, Math.PI * 2)
  c.fillStyle = red ? COLOR.red : COLOR.black
  c.fill()
  c.lineWidth = q * 0.035
  c.strokeStyle = red ? COLOR.redRim : COLOR.blackRim
  c.stroke()
  // The ridge a wooden piece has, a little way in from the rim.
  c.beginPath()
  c.arc(cx, cy, q * 0.3, 0, Math.PI * 2)
  c.lineWidth = q * 0.02
  c.stroke()
  if (piece === 'A' || piece === 'B') crown(c, cx, cy, q)
}

export default {
  kind: 'checkers',
  size: 1024,

  draw(canvas, g, selected) {
    const c = canvas.getContext('2d')
    const S = canvas.width
    const q = S / 8
    const legal = g?.legal ?? []
    const moved = new Set(g?.lastMove ? squares(g.lastMove) : [])
    const targets = new Set(selected ? legal.filter(m => squares(m)[0] === selected).map(m => last(squares(m))) : [])
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const rank = row + 1
        const fileIndex = 7 - col
        const name = `${FILES[fileIndex]}${rank}`
        const dark = (fileIndex + rank - 1) % 2 === 0
        const x = col * q
        const y = row * q
        c.fillStyle = moved.has(name) ? (dark ? COLOR.darkMoved : COLOR.lightMoved) : dark ? COLOR.dark : COLOR.light
        c.fillRect(x, y, q, q)
        c.font = `${q * 0.2}px "Segoe UI", sans-serif`
        c.fillStyle = dark ? COLOR.light : COLOR.dark
        if (col === 0) {
          c.textAlign = 'left'
          c.textBaseline = 'top'
          c.fillText(String(rank), x + 4, y + 3)
        }
        if (row === 7) {
          c.textAlign = 'right'
          c.textBaseline = 'bottom'
          c.fillText(FILES[fileIndex], x + q - 4, y + q - 3)
        }
        const piece = g?.cells?.[(rank - 1) * 8 + fileIndex] ?? null
        if (piece) disc(c, x + q / 2, y + q / 2, q, piece)
        if (targets.has(name)) {
          c.beginPath()
          c.arc(x + q / 2, y + q / 2, q * 0.12, 0, Math.PI * 2)
          c.fillStyle = COLOR.dot
          c.fill()
        }
        if (selected === name) {
          c.lineWidth = q * 0.06
          c.strokeStyle = COLOR.select
          c.strokeRect(x + c.lineWidth / 2, y + c.lineWidth / 2, q - c.lineWidth, q - c.lineWidth)
        }
      }
    }
  },

  click(u, v, g, selected) {
    if (!g) return null
    const fileIndex = Math.min(7, Math.max(0, 7 - Math.floor(u * 8)))
    const rank = Math.min(8, Math.max(1, Math.floor((1 - v) * 8) + 1))
    const name = `${FILES[fileIndex]}${rank}`
    const legal = g.legal ?? []
    if (selected) {
      // Every legal move from the selected square to the clicked one; the longest sequence wins.
      const found = legal
        .filter(m => squares(m)[0] === selected && last(squares(m)) === name)
        .sort((a, b) => squares(b).length - squares(a).length)
      if (found.length > 0) return { move: found[0] }
    }
    const piece = g.cells?.[index(name)] ?? null
    if (piece && piece.toLowerCase() === g.turn) return { select: name }
    return null
  },
}
