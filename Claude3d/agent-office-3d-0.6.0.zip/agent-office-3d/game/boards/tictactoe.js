// The tic-tac-toe board for the arcade table: row 3 at the top (X's edge),
// columns c, b, a left to right, as the chess board is laid. A click takes a
// free square.

export default {
  kind: 'tictactoe',
  size: 384,
  draw(canvas, g) {
    const c = canvas.getContext('2d')
    const S = canvas.width
    const q = S / 3
    c.fillStyle = '#efe6d2'
    c.fillRect(0, 0, S, S)
    c.strokeStyle = '#3a2e24'
    c.lineWidth = S * 0.02
    for (let i = 1; i < 3; i++) {
      c.beginPath()
      c.moveTo(i * q, S * 0.04)
      c.lineTo(i * q, S * 0.96)
      c.moveTo(S * 0.04, i * q)
      c.lineTo(S * 0.96, i * q)
      c.stroke()
    }
    const last = g?.lastMove ? NAMES.indexOf(g.lastMove) : -1
    for (let i = 0; i < 9; i++) {
      const row = Math.floor(i / 3)
      const col = 2 - (i % 3)
      const mark = g?.cells?.[i] ?? null
      if (i === last) {
        c.fillStyle = 'rgba(138,160,90,0.45)'
        c.fillRect(col * q + S * 0.01, row * q + S * 0.01, q - S * 0.02, q - S * 0.02)
      }
      if (mark === null) continue
      c.lineWidth = S * 0.035
      c.lineCap = 'round'
      const cx = col * q + q / 2
      const cy = row * q + q / 2
      const r = q * 0.3
      if (mark === 'x') {
        c.strokeStyle = '#1f6fd0'
        c.beginPath()
        c.moveTo(cx - r, cy - r)
        c.lineTo(cx + r, cy + r)
        c.moveTo(cx + r, cy - r)
        c.lineTo(cx - r, cy + r)
        c.stroke()
      } else {
        c.strokeStyle = '#c0392b'
        c.beginPath()
        c.arc(cx, cy, r, 0, Math.PI * 2)
        c.stroke()
      }
    }
  },
  click(u, v, g) {
    const col = 2 - Math.floor(u * 3)
    const row = Math.floor((1 - v) * 3)
    const name = NAMES[row * 3 + col]
    return (g?.legal ?? []).includes(name) ? { move: name } : null
  },
}

/** Cell names, top-left first, row by row (row 3 at the top). */
const NAMES = ['a3', 'b3', 'c3', 'a2', 'b2', 'c2', 'a1', 'b1', 'c1']
