// The chess board for the arcade table, drawn with rank 1 at the top and the
// h-file at the left: laid flat on the table that puts rank 1 at White's edge
// with the a-file on White's left, and rank 8 at Black's with the a-file on
// Black's right. A click picks a piece's square, then its destination.

const GLYPH = { k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟' }
const FILES = 'abcdefgh'

export default {
  kind: 'chess',
  size: 1024,
  draw(canvas, g, selected) {
    const c = canvas.getContext('2d')
    const S = canvas.width
    const q = S / 8
    const last = g?.lastMove ?? null
    const marks = new Set([last?.slice(0, 2), last?.slice(2, 4), selected].filter(Boolean))
    const kingInCheck = g?.inCheck ? g.board.indexOf(g.turn === 'a' ? 'K' : 'k') : -1
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const rank = row + 1
        const fileIndex = 7 - col
        const sq = (rank - 1) * 8 + fileIndex
        const name = `${FILES[fileIndex]}${rank}`
        const dark = (rank + fileIndex) % 2 === 0
        c.fillStyle = sq === kingInCheck ? '#d9534f' : marks.has(name) ? (dark ? '#8aa05a' : '#c9d882') : dark ? '#7a6250' : '#e6d6b8'
        c.fillRect(col * q, row * q, q, q)
        c.font = `${q * 0.2}px "Segoe UI", sans-serif`
        c.fillStyle = dark ? '#e6d6b8' : '#7a6250'
        if (col === 0) {
          c.textAlign = 'left'
          c.textBaseline = 'top'
          c.fillText(String(rank), col * q + 4, row * q + 3)
        }
        if (row === 7) {
          c.textAlign = 'right'
          c.textBaseline = 'bottom'
          c.fillText(FILES[fileIndex], col * q + q - 4, row * q + q - 3)
        }
        const piece = g?.board?.[sq] ?? null
        if (!piece) continue
        const isWhite = piece === piece.toUpperCase()
        const cx = col * q + q / 2
        const cy = row * q + q / 2
        c.beginPath()
        c.arc(cx, cy, q * 0.4, 0, Math.PI * 2)
        c.fillStyle = isWhite ? '#f7f3ea' : '#1c1713'
        c.fill()
        c.lineWidth = q * 0.035
        c.strokeStyle = isWhite ? '#5a4a3a' : '#d8cfbf'
        c.stroke()
        c.font = `${q * 0.6}px "Segoe UI Symbol", "Segoe UI", sans-serif`
        c.textAlign = 'center'
        c.textBaseline = 'middle'
        c.fillStyle = isWhite ? '#1c1713' : '#f7f3ea'
        c.fillText(GLYPH[piece.toLowerCase()], cx, cy + q * 0.04)
      }
    }
  },
  click(u, v, g, selected) {
    const fileIndex = 7 - Math.floor(u * 8)
    const rank = Math.floor((1 - v) * 8) + 1
    const name = `${FILES[fileIndex]}${rank}`
    if (selected === null || selected === name) return { select: selected === name ? null : name }
    const uci = `${selected}${name}`
    if ((g?.legal ?? []).some(m => m.startsWith(uci))) return { move: uci } // a promotion without its piece is a queen
    return { select: name }
  },
}
