// The Connect Four board for the window: an upright blue grid, column a at
// the left and row 1 at the bottom, drawn on a square canvas texture. The
// game `g` is what out(s) gives (cols, rows, cells bottom row first,
// lastMove, winningLine) plus seats, turn, status, legal and sides.

const COLUMNS = 'abcdefg'
const COLS = 7
const ROWS = 6

/** Where the cells sit on a canvas of side `S`: square cells, the letters in the strip below. */
function layout(S) {
  const q = S / COLS
  return { q, top: 0, boardBottom: q * ROWS, stripMid: q * ROWS + (S - q * ROWS) / 2 }
}

/** The row (from the bottom, 0-based) of the last disc in column `col`, or -1. */
function topDisc(cells, col) {
  for (let row = ROWS - 1; row >= 0; row--) if (cells[row * COLS + col]) return row
  return -1
}

function disc(c, cx, cy, r, side) {
  const base = side === 'a' ? '#d8312b' : '#f2c230'
  const rim = side === 'a' ? '#9a1f1b' : '#b98a12'
  const shine = side === 'a' ? '#f0655f' : '#fbe07a'
  const grad = c.createRadialGradient(cx - r * 0.35, cy - r * 0.35, r * 0.1, cx, cy, r)
  grad.addColorStop(0, shine)
  grad.addColorStop(0.6, base)
  grad.addColorStop(1, rim)
  c.beginPath()
  c.arc(cx, cy, r, 0, Math.PI * 2)
  c.fillStyle = grad
  c.fill()
  // The pressed ring a real disc has.
  c.beginPath()
  c.arc(cx, cy, r * 0.68, 0, Math.PI * 2)
  c.lineWidth = r * 0.07
  c.strokeStyle = rim
  c.stroke()
}

export default {
  kind: 'connect4',
  size: 512,

  draw(canvas, g, _selected) {
    const c = canvas.getContext('2d')
    const S = canvas.width
    const { q, boardBottom, stripMid } = layout(S)
    const cells = g?.cells ?? new Array(COLS * ROWS).fill(null)
    const r = q * 0.4

    // The board: blue, with a darker frame and a lighter face.
    c.fillStyle = '#0f3f8a'
    c.fillRect(0, 0, S, S)
    const face = c.createLinearGradient(0, 0, 0, S)
    face.addColorStop(0, '#2a6fd6')
    face.addColorStop(1, '#1d59b8')
    c.fillStyle = face
    c.fillRect(0, 0, S, boardBottom)
    c.lineWidth = S * 0.012
    c.strokeStyle = '#0b2f68'
    c.strokeRect(c.lineWidth / 2, c.lineWidth / 2, S - c.lineWidth, boardBottom - c.lineWidth)

    // The winning four, if any, as a glow behind their holes.
    const winning = new Set(g?.winningLine ?? [])
    const lastCol = g?.lastMove ? COLUMNS.indexOf(g.lastMove) : -1
    const lastRow = lastCol >= 0 ? topDisc(cells, lastCol) : -1

    for (let row = 0; row < ROWS; row++) {
      for (let col = 0; col < COLS; col++) {
        const i = row * COLS + col
        const cx = col * q + q / 2
        const cy = (ROWS - 1 - row) * q + q / 2
        if (winning.has(i)) {
          c.beginPath()
          c.arc(cx, cy, r * 1.22, 0, Math.PI * 2)
          c.fillStyle = '#9be37a'
          c.fill()
        }
        // The hole: dark, with a thin inner shadow so it reads as a hole.
        c.beginPath()
        c.arc(cx, cy, r * 1.04, 0, Math.PI * 2)
        c.fillStyle = '#0a2452'
        c.fill()
        c.beginPath()
        c.arc(cx, cy, r, 0, Math.PI * 2)
        c.fillStyle = '#132d5c'
        c.fill()
        const side = cells[i]
        if (!side) continue
        disc(c, cx, cy, r, side)
        if (row === lastRow && col === lastCol) {
          c.beginPath()
          c.arc(cx, cy, r * 0.88, 0, Math.PI * 2)
          c.lineWidth = r * 0.12
          c.strokeStyle = '#ffffff'
          c.stroke()
        }
        if (winning.has(i)) {
          c.beginPath()
          c.arc(cx, cy, r * 1.08, 0, Math.PI * 2)
          c.lineWidth = r * 0.14
          c.strokeStyle = '#eafbd8'
          c.stroke()
        }
      }
    }

    // A line through the winning four.
    if (winning.size === 4) {
      const pts = [...winning].sort((x, y) => x - y).map(i => [(i % COLS) * q + q / 2, (ROWS - 1 - Math.floor(i / COLS)) * q + q / 2])
      c.beginPath()
      c.moveTo(pts[0][0], pts[0][1])
      c.lineTo(pts[3][0], pts[3][1])
      c.lineWidth = r * 0.16
      c.lineCap = 'round'
      c.strokeStyle = 'rgba(234,251,216,0.85)'
      c.stroke()
    }

    // The column letters along the bottom edge, dimmed for columns that cannot be played.
    const legal = new Set(g?.legal ?? COLUMNS.split(''))
    c.font = `bold ${q * 0.42}px "Segoe UI", sans-serif`
    c.textAlign = 'center'
    c.textBaseline = 'middle'
    for (let col = 0; col < COLS; col++) {
      const letter = COLUMNS[col]
      c.fillStyle = legal.has(letter) ? '#eaf1ff' : 'rgba(234,241,255,0.35)'
      c.fillText(letter, col * q + q / 2, stripMid)
    }
  },

  /** A click anywhere in a column (holes or its letter) plays that column when it is legal. */
  click(u, v, g, _selected) {
    if (u < 0 || u >= 1 || v < 0 || v > 1) return null
    const col = Math.min(COLS - 1, Math.floor(u * COLS))
    const letter = COLUMNS[col]
    return g?.legal?.includes(letter) ? { move: letter } : null
  },
}
