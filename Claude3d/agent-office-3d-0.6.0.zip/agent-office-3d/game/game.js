// Agent Office fullscreen: the game window. A three.js office drawn from the
// state the mod writes (see hooks/fullscreen.ts), walked with first-person
// controls. The page only shows what the mod sends and posts two commands
// back: `select` (which worker you look at) and `send` (a message you typed
// and confirmed with Enter). It never answers, approves or denies anything.

import * as THREE from 'three'
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js'
import chessBoard from './boards/chess.js'
import tttBoard from './boards/tictactoe.js'
import connect4Board from './boards/connect4.js'
import checkersBoard from './boards/checkers.js'
import bonesBoard from './boards/bones.js'
import { buildMyOffice, myOfficePanel } from './myoffice.js'
import { applyDesign, designPanel } from './design.js'
import { buildKanbanWall, kanbanPanel, kanbanCommandFor } from './kanban.js'
import { buildEscapeRoom, escapePanel } from './escape.js'

const TOKEN = new URLSearchParams(location.search).get('t') ?? ''
const CM = 0.01

// ─── Tunables ───────────────────────────────────────────────────────────────
const WALK = 3.0 // m/s
const RUN = 5.6
const ACCEL = 38
const FRICTION = 12
const GRAVITY = 22
const JUMP = 5.2
const RADIUS = 0.26
const EYE = 1.6
const EYE_SEATED = 1.18
const LOOK_SENS = 0.0022
const TARGET_RANGE = 2.6
const TARGET_CONE = Math.cos((26 * Math.PI) / 180)

const LIGHT = { green: 0x3ddc84, yellow: 0xffc93c, red: 0xff5a5a, off: 0x6b7280 }
const ROLE_SHELL = { main: 0xe8edf3, subagent: 0xcfe3f7, teammate: 0xcfe3f7, peer: 0xf3e2cf }
/** Half the angle the face cap covers, from the front of the head: the disc the flat panel had was about 46°. */
const FACE_SPAN = (48 * Math.PI) / 180
const GLYPH = { working: '⚙', 'needs-user': '✋', 'waiting-external': '⧗', failed: '✕', completed: '✓', idle: '…', unknown: '?' }

// ─── DOM ───────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id)
const ui = {
  status: $('status'),
  crosshair: $('crosshair'),
  target: $('target'),
  convo: $('convo'),
  notice: $('notice'),
  chat: $('chat'),
  chatTo: document.querySelector('#chat .to'),
  chatText: document.querySelector('#chat textarea'),
  chatCount: document.querySelector('#chat .count'),
  chatHint: document.querySelector('#chat .hint'),
  chatStand: document.querySelector('#chat .stand'),
  arcade: $('arcade'),
  monitor: $('monitor'),
  design: $('design'),
  kanban: $('kanban'),
  escape: $('escape'),
  overlay: $('overlay'),
  play: $('play'),
  quit: $('quit'),
}
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])

// ─── Renderer, scene, camera ───────────────────────────────────────────────
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' })
renderer.setPixelRatio(Math.min(devicePixelRatio, 2))
renderer.setSize(innerWidth, innerHeight)
renderer.shadowMap.enabled = true
renderer.shadowMap.type = THREE.PCFSoftShadowMap
renderer.outputColorSpace = THREE.SRGBColorSpace
renderer.toneMapping = THREE.ACESFilmicToneMapping
renderer.toneMappingExposure = 1.05
/** `&dbg=a,b` switches for development: `autoshadow`, `nowrap`. */
const DBG = new Set((new URLSearchParams(location.search).get('dbg') ?? '').split(',').filter(Boolean))
renderer.autoClear = false // the frame draws the world more than once across the hallway's seam
renderer.shadowMap.autoUpdate = DBG.has('autoshadow')
document.body.prepend(renderer.domElement)
/** How far from an end of the hallway the far end is drawn across the seam (metres). */
const WRAP_VIEW = 45

const scene = new THREE.Scene()
// No scene background: a background colour makes every render pass clear the frame, and the frame is drawn in
// more than one pass across the hallway's seam. The frame clears itself once, to this colour.
scene.background = null
renderer.setClearColor(0x1a2130, 1)
scene.fog = new THREE.Fog(0x2a3140, 28, 70)
// A neutral studio environment for reflections on plastics, metal and glass; the lights below do the real lighting.
scene.environment = new THREE.PMREMGenerator(renderer).fromScene(new RoomEnvironment(), 0.04).texture
scene.environmentIntensity = 0.45

const camera = new THREE.PerspectiveCamera(72, innerWidth / innerHeight, 0.05, 80)
camera.rotation.order = 'YXZ'
addEventListener('resize', () => {
  camera.aspect = innerWidth / innerHeight
  camera.updateProjectionMatrix()
  renderer.setSize(innerWidth, innerHeight)
})

scene.add(new THREE.HemisphereLight(0xdfe9ff, 0x4a3b2d, 0.55))
scene.add(new THREE.AmbientLight(0xffffff, 0.12))
// Daylight through the back windows: low and warm, casting the long soft shadows.
const sun = new THREE.DirectionalLight(0xfff1dc, 1.3)
sun.position.set(7, 8, 21)
sun.castShadow = true
sun.shadow.mapSize.set(2048, 2048)
sun.shadow.radius = 4
sun.shadow.bias = -0.0004
Object.assign(sun.shadow.camera, { left: -14, right: 14, top: 14, bottom: -14, near: 1, far: 50 })
scene.add(sun)
scene.add(sun.target)

// ─── Helpers ───────────────────────────────────────────────────────────────
const mat = (color, opts = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.6, metalness: 0.05, ...opts })
function box(w, h, d, material, x = 0, y = 0, z = 0, parent = scene) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material)
  m.position.set(x, y, z)
  m.castShadow = true
  m.receiveShadow = true
  parent.add(m)
  return m
}
/** World cm (x right, y into the room, z up) to three.js metres (x, y up, z). */
const w2t = (x, y, z = 0) => new THREE.Vector3(x * CM, z * CM, y * CM)

function textSprite(lines, { width = 512, height = 160, bg = 'rgba(14,18,26,0.82)', scale = 1 } = {}) {
  const canvas = document.createElement('canvas')
  canvas.width = width
  canvas.height = height
  const tex = new THREE.CanvasTexture(canvas)
  tex.colorSpace = THREE.SRGBColorSpace
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: true, transparent: true }))
  sprite.scale.set((width / height) * 0.36 * scale, 0.36 * scale, 1)
  sprite.userData.draw = (ls, accent) => {
    const g = canvas.getContext('2d')
    g.clearRect(0, 0, width, height)
    g.fillStyle = bg
    const r = 26
    g.beginPath()
    g.roundRect(4, 4, width - 8, height - 8, r)
    g.fill()
    if (accent) {
      g.fillStyle = accent
      g.beginPath()
      g.arc(42, 52, 14, 0, Math.PI * 2)
      g.fill()
    }
    ls.forEach((l, i) => {
      g.fillStyle = i === 0 ? '#eef2f7' : '#a9b4c2'
      g.font = i === 0 ? '600 40px Segoe UI, sans-serif' : '30px Segoe UI, sans-serif'
      g.fillText(String(l).slice(0, 34), accent && i === 0 ? 68 : 28, 66 + i * 52)
    })
    tex.needsUpdate = true
  }
  sprite.userData.draw(lines)
  return sprite
}

function faceTexture() {
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = 128
  const tex = new THREE.CanvasTexture(canvas)
  tex.colorSpace = THREE.SRGBColorSpace
  // The whole panel is the status light: a disc in the status color, the glyph dark on it, clear around it.
  tex.userData.draw = (glyph, color) => {
    const g = canvas.getContext('2d')
    g.clearRect(0, 0, 128, 128)
    g.fillStyle = color
    g.beginPath()
    g.arc(64, 64, 62, 0, Math.PI * 2)
    g.fill()
    g.fillStyle = 'rgba(10, 14, 20, 0.85)'
    g.shadowColor = 'rgba(0, 0, 0, 0.35)'
    g.shadowBlur = 6
    g.font = '600 76px Segoe UI Symbol, Segoe UI, sans-serif'
    g.textAlign = 'center'
    g.textBaseline = 'middle'
    g.fillText(glyph, 64, 70)
    tex.needsUpdate = true
  }
  return tex
}

const hex = n => `#${n.toString(16).padStart(6, '0')}`

// ─── The room ──────────────────────────────────────────────────────────────
let room = null
let solids = [] // { minX, maxX, minZ, maxZ } in metres
const deskObjects = new Map() // desk number -> { group, screen, number, x, z, seat, stand }
const roomGroup = new THREE.Group()
scene.add(roomGroup)

// ─── Procedural textures (no image files: every surface is drawn once on a canvas) ───
function seeded(seed) {
  let s = seed >>> 0
  return () => {
    s = (s + 0x6d2b79f5) >>> 0
    let t = s
    t = Math.imul(t ^ (t >>> 15), t | 1)
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function canvasTexture(w, h, draw, repeatX = 1, repeatY = 1) {
  const c = document.createElement('canvas')
  c.width = w
  c.height = h
  draw(c.getContext('2d'), w, h)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  t.wrapS = t.wrapT = THREE.RepeatWrapping
  t.repeat.set(repeatX, repeatY)
  t.anisotropy = renderer.capabilities.getMaxAnisotropy()
  return t
}

/** A carpet: a base color with a dense speckle and a faint weave. One texture covers 1 m. */
function carpetTexture(base) {
  const rnd = seeded(7)
  return canvasTexture(256, 256, (g, w, h) => {
    g.fillStyle = base
    g.fillRect(0, 0, w, h)
    for (let i = 0; i < 9000; i++) {
      const v = rnd()
      g.fillStyle = v < 0.5 ? 'rgba(255,255,255,0.07)' : 'rgba(0,0,0,0.12)'
      g.fillRect(rnd() * w, rnd() * h, 1.5, 1.5)
    }
    g.strokeStyle = 'rgba(0,0,0,0.05)'
    g.lineWidth = 1
    for (let y = 0; y < h; y += 4) {
      g.beginPath()
      g.moveTo(0, y)
      g.lineTo(w, y)
      g.stroke()
    }
  })
}

/** Wood: long grain streaks over a base, a few darker lines. One texture covers 1 m along the grain. */
function woodTexture(base, dark) {
  const rnd = seeded(11)
  return canvasTexture(512, 128, (g, w, h) => {
    g.fillStyle = base
    g.fillRect(0, 0, w, h)
    for (let i = 0; i < 160; i++) {
      const y = rnd() * h
      const len = 60 + rnd() * 400
      const x = rnd() * w
      g.strokeStyle = `rgba(0,0,0,${0.03 + rnd() * 0.09})`
      g.lineWidth = 0.6 + rnd() * 1.8
      g.beginPath()
      g.moveTo(x, y)
      g.bezierCurveTo(x + len * 0.3, y + (rnd() - 0.5) * 6, x + len * 0.7, y + (rnd() - 0.5) * 6, x + len, y + (rnd() - 0.5) * 3)
      g.stroke()
    }
    for (let i = 0; i < 6; i++) {
      g.strokeStyle = dark
      g.globalAlpha = 0.18
      g.lineWidth = 2
      const y = rnd() * h
      g.beginPath()
      g.moveTo(0, y)
      g.lineTo(w, y + (rnd() - 0.5) * 10)
      g.stroke()
      g.globalAlpha = 1
    }
  })
}

/** Painted wall: an off-white with a fine grain so it is not flat. One texture covers 2 m. */
function wallTexture(base) {
  const rnd = seeded(23)
  return canvasTexture(256, 256, (g, w, h) => {
    g.fillStyle = base
    g.fillRect(0, 0, w, h)
    for (let i = 0; i < 5000; i++) {
      g.fillStyle = rnd() < 0.5 ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.04)'
      g.fillRect(rnd() * w, rnd() * h, 2, 2)
    }
  })
}

/** Acoustic ceiling tiles: a 2 × 2 tile grid per texture, so each tile is 0.6 m when repeated every 1.2 m. */
function ceilingTexture() {
  const rnd = seeded(5)
  return canvasTexture(256, 256, (g, w, h) => {
    g.fillStyle = '#eef0f3'
    g.fillRect(0, 0, w, h)
    for (let i = 0; i < 3000; i++) {
      g.fillStyle = 'rgba(0,0,0,0.05)'
      g.fillRect(rnd() * w, rnd() * h, 1.5, 1.5)
    }
    g.strokeStyle = '#c9ced6'
    g.lineWidth = 3
    g.strokeRect(0, 0, w / 2, h / 2)
    g.strokeRect(w / 2, 0, w / 2, h / 2)
    g.strokeRect(0, h / 2, w / 2, h / 2)
    g.strokeRect(w / 2, h / 2, w / 2, h / 2)
  })
}

/** What a window shows: a sky, a far skyline, a low sun. */
function skyTexture() {
  const rnd = seeded(31)
  return canvasTexture(512, 320, (g, w, h) => {
    const sky = g.createLinearGradient(0, 0, 0, h)
    sky.addColorStop(0, '#6fa7e6')
    sky.addColorStop(0.55, '#c6dcf2')
    sky.addColorStop(1, '#f1e4cf')
    g.fillStyle = sky
    g.fillRect(0, 0, w, h)
    const glow = g.createRadialGradient(400, 150, 10, 400, 150, 150)
    glow.addColorStop(0, 'rgba(255,245,220,0.9)')
    glow.addColorStop(1, 'rgba(255,245,220,0)')
    g.fillStyle = glow
    g.fillRect(0, 0, w, h)
    g.fillStyle = '#8fa3b8'
    for (let x = 0; x < w; x += 18 + rnd() * 24) {
      const bh = 40 + rnd() * 110
      g.fillRect(x, h - bh, 14 + rnd() * 22, bh)
    }
    g.fillStyle = '#6b7d91'
    for (let x = 0; x < w; x += 10 + rnd() * 20) {
      const bh = 20 + rnd() * 60
      g.fillRect(x, h - bh, 8 + rnd() * 16, bh)
    }
  })
}

/** A monitor's picture: lines of "code" in a dark editor. Working screens scroll it. */
function screenTexture() {
  const rnd = seeded(43)
  const colors = ['#7cc4ff', '#c3e88d', '#ffcb6b', '#c792ea', '#89ddff', '#eef2f7']
  const t = canvasTexture(256, 512, (g, w, h) => {
    g.fillStyle = '#121923'
    g.fillRect(0, 0, w, h)
    g.fillStyle = '#1b2531'
    g.fillRect(0, 0, 26, h)
    for (let y = 8; y < h; y += 11) {
      let x = 34 + Math.floor(rnd() * 4) * 12
      const n = 1 + Math.floor(rnd() * 5)
      for (let i = 0; i < n; i++) {
        const len = 10 + rnd() * 50
        g.fillStyle = colors[Math.floor(rnd() * colors.length)]
        g.globalAlpha = 0.85
        g.fillRect(x, y, len, 5)
        x += len + 6
        if (x > w - 20) break
      }
      g.globalAlpha = 1
    }
  })
  t.wrapS = THREE.ClampToEdgeWrapping
  return t
}

const TEX = {
  carpetSession: carpetTexture('#34506b'),
  carpetPeers: carpetTexture('#5b4566'),
  floor: woodTexture('#8a6f55', '#4a3826'),
  desk: woodTexture('#b08a62', '#6b4d2e'),
  wall: wallTexture('#dfe3ea'),
  ceiling: ceilingTexture(),
  sky: skyTexture(),
  screen: screenTexture(),
}


const solid = (x, z, w, d) => solids.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2 })

// ─── Props ─────────────────────────────────────────────────────────────────
const potMat = mat(0xa8664a, { roughness: 0.8 })
const soilMat = mat(0x2d2117, { roughness: 1 })
const leafMats = [mat(0x2f6b3a, { roughness: 0.7 }), mat(0x3f8a47, { roughness: 0.7 }), mat(0x27592f, { roughness: 0.7 })]

function plant(parent, x, z, seed) {
  const rnd = seeded(seed)
  const g = new THREE.Group()
  g.position.set(x, 0, z)
  const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.13, 0.32, 20), potMat)
  pot.position.y = 0.16
  pot.castShadow = pot.receiveShadow = true
  g.add(pot)
  const soil = new THREE.Mesh(new THREE.CylinderGeometry(0.155, 0.155, 0.02, 20), soilMat)
  soil.position.y = 0.33 // at the rim
  g.add(soil)
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.03, 0.5, 8), mat(0x5a4030))
  trunk.position.y = 0.55
  g.add(trunk)
  for (let i = 0; i < 7; i++) {
    const r = 0.16 + rnd() * 0.12
    const leaf = new THREE.Mesh(new THREE.SphereGeometry(r, 12, 10), leafMats[i % 3])
    leaf.position.set((rnd() - 0.5) * 0.35, 0.75 + rnd() * 0.35, (rnd() - 0.5) * 0.35)
    leaf.scale.set(1, 0.8 + rnd() * 0.4, 1)
    leaf.castShadow = true
    g.add(leaf)
  }
  parent.add(g)
  solid(x, z, 0.4, 0.4)
}

function cabinet(parent, x, z, rotY = 0) {
  const g = new THREE.Group()
  g.position.set(x, 0, z)
  g.rotation.y = rotY
  const body = mat(0x9aa0aa, { metalness: 0.4, roughness: 0.45 })
  box(0.45, 1.02, 0.6, body, 0, 0.51, 0, g)
  for (let i = 0; i < 3; i++) {
    box(0.4, 0.3, 0.01, mat(0x8a909a, { metalness: 0.4, roughness: 0.5 }), 0, 0.2 + i * 0.32, -0.305, g)
    box(0.12, 0.02, 0.02, metal, 0, 0.32 + i * 0.32, -0.32, g)
  }
  parent.add(g)
  const isTurned = Math.abs(Math.sin(rotY)) > 0.5 // a quarter turn swaps the footprint's sides
  solid(x, z, isTurned ? 0.6 : 0.45, isTurned ? 0.45 : 0.6)
}

function waterCooler(parent, x, z) {
  const g = new THREE.Group()
  g.position.set(x, 0, z)
  box(0.34, 0.95, 0.34, mat(0xe6e9ee, { roughness: 0.5 }), 0, 0.475, 0, g)
  box(0.3, 0.02, 0.3, metal, 0, 0.96, 0, g)
  const bottle = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.15, 0.42, 20), new THREE.MeshPhysicalMaterial({ color: 0x9fd3ff, transparent: true, opacity: 0.6, roughness: 0.1, transmission: 0.3 }))
  bottle.position.y = 1.18
  g.add(bottle)
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.06, 12), mat(0x9fd3ff))
  neck.position.y = 1.42
  g.add(neck)
  box(0.05, 0.05, 0.04, mat(0x3a7bd5), 0.1, 0.78, -0.18, g)
  box(0.05, 0.05, 0.04, mat(0xd53a3a), -0.1, 0.78, -0.18, g)
  parent.add(g)
  solid(x, z, 0.36, 0.36)
}

function whiteboard(parent, x, z, rotY) {
  const g = new THREE.Group()
  g.position.set(x, 0, z)
  g.rotation.y = rotY
  const rnd = seeded(77)
  const boardTex = canvasTexture(512, 320, (gc, w, h) => {
    gc.fillStyle = '#f7f9fb'
    gc.fillRect(0, 0, w, h)
    const inks = ['#2b6cb0', '#c53030', '#2f855a', '#1a202c']
    for (let i = 0; i < 9; i++) {
      gc.strokeStyle = inks[i % inks.length]
      gc.lineWidth = 2 + rnd() * 2
      gc.beginPath()
      const y = 30 + rnd() * (h - 60)
      const x0 = 30 + rnd() * 120
      gc.moveTo(x0, y)
      for (let k = 1; k <= 6; k++) gc.lineTo(x0 + k * (20 + rnd() * 40), y + (rnd() - 0.5) * 24)
      gc.stroke()
    }
    gc.strokeStyle = '#2b6cb0'
    gc.lineWidth = 3
    gc.strokeRect(330, 60, 120, 80)
    gc.strokeRect(80, 180, 90, 60)
    gc.beginPath()
    gc.moveTo(170, 210)
    gc.lineTo(330, 100)
    gc.stroke()
  })
  const board = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 1.12), new THREE.MeshStandardMaterial({ map: boardTex, roughness: 0.35 }))
  board.position.set(0, 1.5, 0.02)
  g.add(board)
  box(1.86, 1.18, 0.02, mat(0xb9bec8, { metalness: 0.5, roughness: 0.4 }), 0, 1.5, 0.005, g)
  box(1.2, 0.03, 0.08, mat(0xb9bec8, { metalness: 0.5, roughness: 0.4 }), 0, 0.93, 0.05, g)
  box(0.12, 0.025, 0.025, mat(0x2b6cb0), -0.3, 0.955, 0.05, g)
  box(0.12, 0.025, 0.025, mat(0xc53030), 0.0, 0.955, 0.05, g)
  parent.add(g)
}

function wallClock(parent, x, y, z, rotY) {
  const g = new THREE.Group()
  g.position.set(x, y, z)
  g.rotation.y = rotY
  const faceTex = canvasTexture(128, 128, (gc, w, h) => {
    gc.fillStyle = '#ffffff'
    gc.beginPath()
    gc.arc(64, 64, 62, 0, Math.PI * 2)
    gc.fill()
    gc.fillStyle = '#1a202c'
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2
      gc.fillRect(64 + Math.cos(a) * 52 - 2, 64 + Math.sin(a) * 52 - 2, 4, 4)
    }
    gc.strokeStyle = '#1a202c'
    gc.lineWidth = 4
    gc.beginPath()
    gc.moveTo(64, 64)
    gc.lineTo(64, 30)
    gc.moveTo(64, 64)
    gc.lineTo(90, 72)
    gc.stroke()
  })
  const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.2, 0.04, 32), mat(0x2d3340, { metalness: 0.5, roughness: 0.4 }))
  rim.rotation.x = Math.PI / 2
  g.add(rim)
  const face = new THREE.Mesh(new THREE.CircleGeometry(0.18, 32), new THREE.MeshBasicMaterial({ map: faceTex }))
  face.position.z = 0.021
  g.add(face)
  parent.add(g)
}

// ─── The room ──────────────────────────────────────────────────────────────
// ─── The Agent Arcade ──────────────────────────────────────────────────────
// Room 1 of the hallway, always there: a table per game the mod offers, each
// with two chairs. Sit in a chair to take or give that seat (yourself, or an
// agent: a model and how hard it thinks), move by typing or by clicking the
// board, and watch the agent's move and its reason. The rules live in the mod:
// nothing illegal gets through, whoever proposes it. Each board is a module
// under game/boards (BOARDS): how it is drawn, and how a click on it reads.
const ARCADE_PROJECT = '\u0001agent-arcade' // never a folder name
const BOARDS = Object.fromEntries([chessBoard, tttBoard, connect4Board, checkersBoard, bonesBoard].map(b => [b.kind, b]))
const arcadeTables = new Map() // kind -> { group, board, canvas, tex, seats: { a, b }, x, z, kind, title, drawn, sign, plateA, plateB }
let arcadeSelected = null // a square picked by clicking, awaiting its destination (boards that take two clicks)

function boardCanvasTexture(size) {
  const canvas = document.createElement('canvas')
  canvas.width = canvas.height = size
  const tex = new THREE.CanvasTexture(canvas)
  tex.colorSpace = THREE.SRGBColorSpace
  tex.anisotropy = renderer.capabilities.getMaxAnisotropy()
  return { canvas, tex }
}

function buildArcadeTable(parent, kind, x, z) {
  const board = BOARDS[kind]
  const g = new THREE.Group()
  g.position.set(x, 0, z)
  parent.add(g)
  box(1.4, 0.05, 1.4, deskWood, 0, 0.74, 0, g)
  for (const [lx, lz] of [[-0.6, -0.6], [0.6, -0.6], [-0.6, 0.6], [0.6, 0.6]]) box(0.06, 0.72, 0.06, metal, lx, 0.36, lz, g)
  const { canvas, tex } = boardCanvasTexture(board.size)
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 1.0), new THREE.MeshStandardMaterial({ map: tex, roughness: 0.55 }))
  mesh.rotation.x = -Math.PI / 2
  mesh.position.set(0, 0.7665, 0)
  mesh.receiveShadow = true
  g.add(mesh)
  const frame = mat(0x3a2e24, { roughness: 0.5 })
  box(1.1, 0.015, 0.05, frame, 0, 0.772, -0.525, g)
  box(1.1, 0.015, 0.05, frame, 0, 0.772, 0.525, g)
  box(0.05, 0.015, 1.1, frame, -0.525, 0.772, 0, g)
  box(0.05, 0.015, 1.1, frame, 0.525, 0.772, 0, g)
  // The chairs: side a at the near (-z) edge facing the table, side b across.
  chair(g, 0, -1.05, Math.PI)
  chair(g, 0, 1.05, 0)
  // Side plates at the table's far corners from each chair, out of the sitter's view of the board.
  const plateA = textSprite(['a'], { width: 300, height: 96, scale: 0.2 })
  plateA.position.set(0.74, 0.84, -0.74)
  g.add(plateA)
  const plateB = textSprite(['b'], { width: 300, height: 96, scale: 0.2 })
  plateB.position.set(-0.74, 0.84, 0.74)
  g.add(plateB)
  const sign = textSprite([kind, 'sit at a chair to play'], { width: 640, height: 150, scale: 0.8 })
  sign.position.set(0, 2.1, 0)
  g.add(sign)
  solid(x, z, 1.45, 1.45)
  solid(x, z - 1.05, 0.5, 0.5)
  solid(x, z + 1.05, 0.5, 0.5)
  const seats = {
    a: { kind: 'arcade', game: kind, side: 'a', pos: new THREE.Vector3(x, 0, z - 1.05), stand: new THREE.Vector3(x, 0, z - 1.8), yaw: Math.PI, number: 'arcade:' + kind + ':a' },
    b: { kind: 'arcade', game: kind, side: 'b', pos: new THREE.Vector3(x, 0, z + 1.05), stand: new THREE.Vector3(x, 0, z + 1.8), yaw: 0, number: 'arcade:' + kind + ':b' },
  }
  const table = { group: g, board: mesh, canvas, tex, seats, x, z, kind, title: '', drawn: '', sign, plateA, plateB }
  arcadeTables.set(kind, table)
  board.draw(canvas, null, null)
  tex.needsUpdate = true
  return table
}

function buildArcadeRoom(parent, r) {
  const x0 = roomX0(r.index)
  const z0 = HALL.depth
  // Tables in rows of three across the room, the first row nearest the door.
  const cols = Math.max(1, Math.floor((roomW(r) - 1.4) / 4.4))
  Object.keys(BOARDS).forEach((kind, i) => {
    const col = i % cols
    const row = Math.floor(i / cols)
    buildArcadeTable(parent, kind, x0 + 2.6 + col * 4.4, z0 + 4.6 + row * 5.4)
  })
  const rules = textSprite(['Agent Arcade', 'pick a chair · choose yourself or an agent · the rules are enforced'], { width: 900, height: 150, scale: 1.0 })
  rules.position.set(x0 + roomW(r) / 2, 2.6, z0 + roomD(r) - 0.6)
  parent.add(rules)
}

/** Redraws the boards the state changed (and their signs the first time), and the panel if you are seated. */
function drawArcade() {
  const a = state?.arcade
  if (!a) return
  for (const [kind, table] of arcadeTables) {
    const g = a[kind]
    if (!g) continue
    if (table.title !== (g.title ?? kind)) {
      table.title = g.title ?? kind
      table.sign.userData.draw([table.title, 'sit at a chair to play'])
      table.plateA.userData.draw([g.sides?.a ?? 'a'])
      table.plateB.userData.draw([g.sides?.b ?? 'b'])
    }
    const key = JSON.stringify([{ ...g, updatedAt: 0, thinking: 0, seats: 0, models: 0, efforts: 0, lastReply: 0, error: 0 }, arcadeSelected])
    if (key === table.drawn) continue
    table.drawn = key
    BOARDS[kind].draw(table.canvas, g, arcadeSelected)
    table.tex.needsUpdate = true
  }
  drawArcadePanel()
}

const seatText = s => (s === null ? 'empty' : s.kind === 'human' ? 'you' : esc(s.name))

function drawArcadePanel() {
  const at = player.arcadeSeat
  if (at === null || !state?.arcade) {
    ui.arcade.style.display = 'none'
    return
  }
  const g = state.arcade[at.game]
  const me = at.side
  const other = me === 'a' ? 'b' : 'a'
  const mine = g.seats[me]
  const theirs = g.seats[other]
  const isMyTurn = g.status === 'playing' && g.turn === me && mine?.kind === 'human'
  const whose = s => (g.seats[s] === null ? `${g.sides[s]} (empty seat)` : g.seats[s].kind === 'human' ? `${g.sides[s]} (you)` : `${g.sides[s]} (${esc(g.seats[s].name)})`)
  let status
  if (g.status === 'over') status = g.winner === null ? `Draw: ${esc(g.result)}.` : `${esc(g.result)}: ${whose(g.winner)} wins.`
  else if (g.status === 'stuck') status = 'Paused: the agent gave no legal move. Retry, or seat someone else.'
  else if (g.status === 'waiting') status = 'Waiting for both seats to be taken.'
  else if (g.thinking !== null) status = `${whose(g.thinking)} is thinking…`
  else status = isMyTurn ? 'Your move.' : `${whose(g.turn)} to move.`
  const models = g.models.map(m => `<option value="${esc(m.id)}">${esc(m.name)}</option>`).join('')
  const efforts = g.efforts.map(e => `<option value="${e}"${e === 'high' ? ' selected' : ''}>${e}</option>`).join('')
  const seatBox = (side, label) => {
    const s = g.seats[side]
    const head = `<div class="seat-head"><b>${label}</b> · ${esc(g.sides[side])} · ${seatText(s)}</div>`
    const form =
      `<div class="seat-form"><select data-model="${side}">${models}</select><select data-effort="${side}">${efforts}</select>` +
      `<button data-act="agent" data-side="${side}">Seat an agent</button></div>`
    if (s === null) return `${head}<div class="seat-row"><button data-act="me" data-side="${side}">Sit here myself</button></div>${form}`
    return `${head}<div class="seat-row"><button data-act="leave" data-side="${side}">Empty the seat</button>${s.kind === 'agent' ? `<button data-act="me" data-side="${side}">Take over myself</button>` : ''}</div>${s.kind === 'human' ? form : ''}`
  }
  const history = g.history.map((h, i) => (at.game === 'chess' ? (i % 2 === 0 ? `${i / 2 + 1}. ${esc(h)}` : esc(h)) : esc(h))).join(' ')
  ui.arcade.innerHTML =
    `<h3>${esc(g.title ?? at.game)} · ${esc(g.sides[me])} seat</h3>` +
    `<div class="status${g.status === 'stuck' ? ' err' : ''}">${status}</div>` +
    `<div class="seat">${seatBox(me, 'This seat')}</div>` +
    `<div class="seat">${seatBox(other, 'Across the table')}</div>` +
    (isMyTurn
      ? `<div class="move"><input data-move placeholder="${at.game === 'chess' ? 'e4, Nf3, O-O, e8=Q — or click a piece, then a square' : 'type a move, or click the board'}" maxlength="24"><button data-act="play">Play</button></div>`
      : '') +
    (g.lastReply && g.seats[g.turn === 'a' ? 'b' : 'a']?.kind === 'agent'
      ? `<div class="reply"><b>${esc(g.seats[g.turn === 'a' ? 'b' : 'a'].name)}:</b> ${esc(g.lastReply)}</div>`
      : '') +
    (g.error ? `<div class="error">${esc(g.error)}</div>` : '') +
    `<div class="row"><button data-act="reset">New game</button>${g.status === 'stuck' ? '<button data-act="retry">Retry the agent</button>' : ''}<span class="dim">Esc stands up</span></div>` +
    `<div class="history">${history || '<span class="dim">No moves yet.</span>'}</div>`
  const input = ui.arcade.querySelector('[data-move]')
  if (input && document.activeElement !== input) input.focus()
}

function arcadePost(cmd) {
  const at = player.arcadeSeat
  if (at === null) return
  void post({ type: 'arcade', game: at.game, ...cmd })
}

function arcadeAct(act, side) {
  const at = player.arcadeSeat
  if (at === null) return
  if (act === 'me') arcadePost({ action: 'seat', side, seat: { kind: 'human' } })
  else if (act === 'agent') {
    const model = ui.arcade.querySelector(`[data-model="${side}"]`)?.value
    const effort = ui.arcade.querySelector(`[data-effort="${side}"]`)?.value
    if (model && effort) arcadePost({ action: 'seat', side, seat: { kind: 'agent', model, effort } })
  } else if (act === 'leave') arcadePost({ action: 'leave', side })
  else if (act === 'reset') {
    arcadeSelected = null
    arcadePost({ action: 'reset' })
  } else if (act === 'retry') arcadePost({ action: 'retry' })
  else if (act === 'play') {
    const input = ui.arcade.querySelector('[data-move]')
    const move = input?.value.trim() ?? ''
    if (move === '') return
    arcadeSelected = null
    arcadePost({ action: 'move', move })
    if (input) input.value = ''
  }
}

function sitArcade(seat) {
  player.arcadeSeat = { game: seat.game, side: seat.side }
  player.pos.copy(seat.pos)
  player.vel.set(0, 0, 0)
  player.yaw = seat.yaw
  player.pitch = -0.62
  arcadeSelected = null
  isChatting = true
  keys.clear()
  document.exitPointerLock()
  ui.overlay.style.display = 'none'
  ui.arcade.style.display = 'block'
  drawTarget()
  drawArcade()
}

function standUpArcade() {
  const at = player.arcadeSeat
  if (at === null) return
  const seat = arcadeTables.get(at.game)?.seats[at.side]
  player.arcadeSeat = null
  arcadeSelected = null
  if (seat) player.pos.copy(seat.stand)
  isChatting = false
  ui.arcade.style.display = 'none'
  lock()
  drawTarget()
}

/** A click on the board while seated: the board module says what it means (a move, or a square to remember). */
function arcadeBoardClick(e) {
  const at = player.arcadeSeat
  if (at === null) return
  const table = arcadeTables.get(at.game)
  const g = state?.arcade?.[at.game]
  const board = BOARDS[at.game]
  if (!table || !g || !board) return
  const ndc = new THREE.Vector2((e.clientX / innerWidth) * 2 - 1, -(e.clientY / innerHeight) * 2 + 1)
  const ray = new THREE.Raycaster()
  ray.setFromCamera(ndc, camera)
  const hit = ray.intersectObject(table.board, false)[0]
  if (!hit?.uv) return
  const r = board.click(hit.uv.x, hit.uv.y, g, arcadeSelected)
  if (!r) return
  if (r.move !== undefined) {
    arcadePost({ action: 'move', move: r.move })
    arcadeSelected = null
  } else if (r.select !== undefined) arcadeSelected = r.select
  table.drawn = ''
  drawArcade()
}


// ─── Your own office ───────────────────────────────────────────────────────
// A room of your own, always room 2: your desk, your chair and a wide monitor.
// Sit down and share a window (the browser's own picker) to see it on the
// monitor, live. The picture stays in this page: nothing of it is posted.
const PERSONAL_PROJECT = '\u0001my-office' // never a folder name
let myOffice = null // what buildMyOffice answered; rebuilt with the world
let myStream = null // the MediaStream on your monitor, kept across rebuilds
let monitorError = null
const canShare = () => typeof navigator.mediaDevices?.getDisplayMedia === 'function'

function buildPersonalRoom(parent, r) {
  myOffice = buildMyOffice(THREE, { box, mat, textSprite, chair, plant, cabinet, deskWood, metal, solid }, parent, { x: roomX0(r.index), z: HALL.depth, width: roomW(r), depth: roomD(r) })
  if (myStream !== null) myOffice.setStream(myStream)
}

function drawMonitorPanel() {
  if (!player.ownSeat) {
    ui.monitor.style.display = 'none'
    return
  }
  const track = myStream?.getVideoTracks()[0]
  ui.monitor.innerHTML = myOfficePanel({ sharing: myStream !== null, error: monitorError, supported: canShare(), label: track?.label ?? '' })
  ui.monitor.style.display = 'block'
  ui.monitor.querySelector('button')?.focus()
}

function stopSharing() {
  if (myStream === null) return
  for (const t of myStream.getTracks()) t.stop()
  myStream = null
  myOffice?.setStream(null)
}

async function shareWindow() {
  monitorError = null
  if (!canShare()) {
    drawMonitorPanel()
    return
  }
  let stream
  try {
    stream = await navigator.mediaDevices.getDisplayMedia({ video: { displaySurface: 'window' }, audio: false, selfBrowserSurface: 'exclude' })
  } catch (err) {
    monitorError = err?.name === 'NotAllowedError' ? 'Nothing was shared.' : `Could not share: ${err?.message ?? err}`
    drawMonitorPanel()
    return
  }
  stopSharing()
  myStream = stream
  myOffice?.setStream(stream)
  // The browser's own Stop sharing bar ends the track: the monitor goes idle with it.
  stream.getVideoTracks()[0]?.addEventListener('ended', () => {
    if (myStream !== stream) return
    myStream = null
    myOffice?.setStream(null)
    drawMonitorPanel()
  })
  drawMonitorPanel()
}

function sitOwn() {
  if (!myOffice) return
  const seat = myOffice.seat
  player.ownSeat = true
  player.pos.copy(seat.pos)
  player.vel.set(0, 0, 0)
  player.yaw = seat.yaw
  player.pitch = -0.12
  isChatting = true
  keys.clear()
  document.exitPointerLock()
  ui.overlay.style.display = 'none'
  drawTarget()
  drawMonitorPanel()
}

function standUpOwn() {
  if (!player.ownSeat) return
  player.ownSeat = false
  if (myOffice) player.pos.copy(myOffice.seat.stand)
  isChatting = false
  ui.monitor.style.display = 'none'
  lock()
  drawTarget()
}

// ─── The escape room ───────────────────────────────────────────────────────
// Room 3, off the hallway next to your office: a themed room (game/escape.js)
// with a console you sit at to pick a room, inspect its objects, try its locks
// and talk to an AI teammate who knows only what you have found (hooks/escape.ts).
const ESCAPE_PROJECT = '\u0001escape-room' // never a folder name
let escapeRoom = null // what buildEscapeRoom answered; rebuilt with the world
let escapeTheme = ''
let escapeDrawn = ''

function ensureEscapeRoom() {
  if (roomOf.has(ESCAPE_PROJECT)) return false
  const r = { index: rooms.length, project: ESCAPE_PROJECT, title: 'Escape Room', isArcade: false, isPersonal: false, isEscape: true, sessions: new Set(), sign: null }
  rooms.push(r)
  roomOf.set(ESCAPE_PROJECT, r)
  return true
}

/** The room's theme follows the room entered; the panel repaints while you sit at the console. */
function drawEscape() {
  const e = state?.escape
  if (!e) return
  const theme = e.room?.id ?? ''
  if (escapeRoom && theme !== escapeTheme) {
    escapeTheme = theme
    escapeRoom.setTheme(e.room?.id ?? null)
  }
  if (!player.escapeSeat) return
  const key = JSON.stringify(e)
  if (key === escapeDrawn) return
  escapeDrawn = key
  const typed = ui.escape.querySelector('[data-escape-say]')?.value ?? ''
  ui.escape.innerHTML = escapePanel(e)
  const say = ui.escape.querySelector('[data-escape-say]')
  if (say) say.value = typed
}

function sitEscape() {
  if (!escapeRoom) return
  const seat = escapeRoom.seat
  player.escapeSeat = true
  player.pos.copy(seat.pos)
  player.vel.set(0, 0, 0)
  player.yaw = seat.yaw
  player.pitch = -0.15
  isChatting = true
  keys.clear()
  document.exitPointerLock()
  ui.overlay.style.display = 'none'
  ui.escape.style.display = 'block'
  escapeDrawn = ''
  drawTarget()
  drawEscape()
  ui.escape.querySelector('input, button')?.focus()
}

function standUpEscape() {
  if (!player.escapeSeat) return
  player.escapeSeat = false
  if (escapeRoom) player.pos.copy(escapeRoom.seat.stand)
  isChatting = false
  ui.escape.style.display = 'none'
  lock()
  drawTarget()
}

/** A click on the console's panel: the button's action and the inputs it takes, as docs/ESCAPE.md lists them. */
function escapeAct(b) {
  const action = b.dataset.escape
  const id = b.dataset.id
  const cmd = { type: 'escape', action }
  if (action === 'enter' && id) cmd.roomId = id
  else if (action === 'inspect') cmd.objectId = id
  else if (action === 'try') {
    const input = ui.escape.querySelector(`[data-escape-input="${CSS.escape(id ?? '')}"]`)
    const text = input?.value.trim() ?? ''
    if (text === '') return
    cmd.puzzleId = id
    cmd.text = text
    if (input) input.value = ''
  } else if (action === 'say') {
    const input = ui.escape.querySelector('[data-escape-say]')
    const text = input?.value.trim() ?? ''
    if (text === '') return
    cmd.text = text
    if (input) input.value = ''
  } else if (action === 'teammate') {
    cmd.model = ui.escape.querySelector('[data-escape-model]')?.value
    cmd.effort = ui.escape.querySelector('[data-escape-effort]')?.value
    if (!cmd.model || !cmd.effort) return
  }
  void post(cmd)
}

// ─── The world: a hallway of project rooms ─────────────────────────────────
// The hallway runs along x, between the outer wall at z 0 and the rooms' front
// wall at z HALL.depth. Rooms open off it, one per project (a session's working
// folder), in the order projects first appear; a room keeps its place for the
// window's life, so you can leave it and come back. Inside, each session has a
// bay: its lead desk at the front, its agents in rows behind, a divider between
// bays. Desks exist only for workers that exist.
const HALL = { depth: 4, height: 3 }
const ROOM = { width: 14, depth: 14, pitch: 15, door: 1.4 }
const BAY = { width: 4.6, count: 3, leadZ: 1.8, cols: 2, dx: 2.0, dz: 2.6 }

const rooms = [] // { index, project, sessions: Set<id>, sign }
const roomOf = new Map() // project -> room
const bayOf = new Map() // session id -> { room, bay, sign }
const seatOf = new Map() // worker key -> { sessionId, slot }  (slot -1: the lead)
const worldGroup = new THREE.Group()
scene.add(worldGroup)
let staticSolids = []
let nextDeskNumber = 1

// The hallway is a loop: past x = hallLength() you are at x = 0 again, with a 1 m strip of wall across the seam
// (half at each end). Its length is a whole number of metres, so the floor and carpet patterns meet at the seam.
// Each room is as wide as the design says (ROOM.width unless styled), with a 1 m strip of wall between rooms.
const roomX0 = i => {
  let x = 0.5
  for (let j = 0; j < i; j++) x += (rooms[j] ? roomW(rooms[j]) : ROOM.width) + 1
  return x
}
const hallLength = () => roomX0(Math.max(2, rooms.length)) + 0.5
const roomDoorX = r => roomX0(r.index) + roomW(r) / 2

// ─── The world editor and the kanban wall ──────────────────────────────────
// The editor's scene (hooks/design.ts) reaches the window as validated data:
// props are drawn by design.js in a group of its own; the theme, the styled
// rooms and the resized desks are applied here, where those meshes are built.
let designStyle = { theme: {}, rooms: {}, desks: {} } // what the world is built with now
let designStyleKey = ''
let designDirty = false // the world must be rebuilt for a theme or room change
const groups = {} // design.js keeps its group under groups.design
let designDrawn = ''
let designOpen = false
let wallDefault = null
let ceilingMat = null
let kanbanWall = null // this session's room's board, rebuilt with the world
let kanbanOpen = false
let kanbanDrawn = ''
let selfProject = null

/** A room's key in the design's `rooms` (the arcade and your office by their names, projects by theirs). */
const designKey = r => (r.isArcade ? 'arcade' : r.isPersonal ? 'my-office' : r.project)
const roomW = r => Math.round(designStyle.rooms[designKey(r)]?.width ?? ROOM.width)
const roomD = r => Math.round(designStyle.rooms[designKey(r)]?.depth ?? ROOM.depth)

/** Takes the theme, the rooms and the desk sizes from the state; a theme or room change rebuilds the world on the next sync. */
function applyDesignStyles(design) {
  const doc = design?.doc
  const next = { theme: doc?.theme ?? {}, rooms: doc?.rooms ?? {}, desks: doc?.desks ?? {} }
  const key = JSON.stringify([next.theme, next.rooms])
  designStyle = next
  if (key !== designStyleKey) {
    designStyleKey = key
    designDirty = true
    if (wallDefault === null) wallDefault = wallBoxMat.color.getHex()
    wallBoxMat.color.set(next.theme.walls ?? wallDefault)
    deskWood.color.set(next.theme.deskWood ?? 0xffffff)
  }
  // A desk whose size changed is rebuilt by the next sync (its seat is freed, so it is placed again).
  for (const d of [...deskObjects.values()]) {
    const sizeKey = JSON.stringify(next.desks[d.key] ?? null)
    if (sizeKey === d.sizeKey) continue
    removeDesk(d)
    seatOf.delete(d.key)
  }
}

const designCtx = () => ({
  deskPosition: key => {
    const d = deskByKey(key)
    return d ? { x: d.x, z: d.z + d.topZ, yaw: 0 } : null // the desk top's centre; desks are built unturned
  },
  roomRect: project => {
    const r = project === 'arcade' ? roomOf.get(ARCADE_PROJECT) : project === 'my-office' ? roomOf.get(PERSONAL_PROJECT) : roomOf.get(project)
    return r ? { x0: roomX0(r.index), z0: HALL.depth, x1: roomX0(r.index) + roomW(r), z1: HALL.depth + roomD(r) } : null
  },
  hallway: { x0: 0, z0: 0, x1: hallLength(), z1: HALL.depth },
})

/** Draws the scene's props and, while the editor is open, its panel (the request box keeps what you were typing). */
function drawDesign() {
  const design = state?.design
  if (!design) return
  applyDesign(THREE, scene, groups, design, designCtx())
  if (!designOpen) return
  const key = JSON.stringify(design)
  if (key === designDrawn) return
  designDrawn = key
  const typed = ui.design.querySelector('[data-design-text]')?.value ?? ''
  ui.design.innerHTML = designPanel(design)
  const input = ui.design.querySelector('[data-design-text]')
  if (input) {
    input.value = typed
    if (!design.busy) input.focus()
  }
}

function openDesign() {
  if (designOpen) return
  designOpen = true
  designDrawn = ''
  isChatting = true
  keys.clear()
  document.exitPointerLock()
  ui.overlay.style.display = 'none'
  ui.design.style.display = 'block'
  drawDesign()
  ui.design.querySelector('[data-design-text]')?.focus()
}

function closeDesign() {
  if (!designOpen) return
  designOpen = false
  isChatting = false
  ui.design.style.display = 'none'
  lock()
}

function designAct(el) {
  const action = el.dataset.design
  const cmd = { type: 'design', action }
  if (action === 'request') {
    const text = ui.design.querySelector('[data-design-text]')?.value.trim() ?? ''
    if (text === '') return
    cmd.text = text
  }
  if (action === 'remove') cmd.id = el.dataset.id
  void post(cmd)
}

/** The board on the wall and, while it is open, the panel; both repaint only on a change. */
function drawKanban() {
  const board = state?.kanban ?? null
  if (kanbanWall) kanbanWall.draw(board)
  if (!kanbanOpen) return
  const key = JSON.stringify(board)
  if (key === kanbanDrawn) return
  kanbanDrawn = key
  ui.kanban.innerHTML = kanbanPanel(board)
}

function openKanban() {
  if (kanbanOpen) return
  kanbanOpen = true
  kanbanDrawn = ''
  isChatting = true
  keys.clear()
  document.exitPointerLock()
  ui.overlay.style.display = 'none'
  ui.kanban.style.display = 'block'
  drawKanban()
  ui.kanban.querySelector('button, input')?.focus()
}

function closeKanban() {
  if (!kanbanOpen) return
  kanbanOpen = false
  isChatting = false
  ui.kanban.style.display = 'none'
  lock()
}
const bayOrigin = (r, bay) => ({ x: roomX0(r.index) + 0.1 + Math.min(bay, BAY.count - 1) * BAY.width, z: HALL.depth })
function leadSpot(r, bay) {
  const o = bayOrigin(r, bay)
  return { x: o.x + BAY.width / 2, z: o.z + BAY.leadZ }
}
function agentSpot(r, bay, slot) {
  const o = bayOrigin(r, bay)
  const col = slot % BAY.cols
  const row = Math.floor(slot / BAY.cols)
  return { x: o.x + BAY.width / 2 + (col - (BAY.cols - 1) / 2) * BAY.dx, z: Math.min(o.z + BAY.leadZ + (row + 1) * BAY.dz, HALL.depth + roomD(r) - 1.3) }
}

/** A carpet tint for a project, the same every time that name comes up. */
function projectHue(name) {
  let h = 0
  for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) >>> 0
  return (h % 360) / 360
}

const wallBoxMat = new THREE.MeshStandardMaterial({ map: TEX.wall, roughness: 0.9 })
/** A wall as a box (both faces, and a collision box), from (x0,z0) to (x1,z1) along one axis. */
function wallRun(parent, x0, z0, x1, z1, height = HALL.height, thickness = 0.12) {
  const w = Math.abs(x1 - x0)
  const d = Math.abs(z1 - z0)
  const m = box(Math.max(w, thickness), height, Math.max(d, thickness), wallBoxMat, (x0 + x1) / 2, height / 2, (z0 + z1) / 2, parent)
  m.castShadow = false
  const t = thickness / 2
  solids.push({ minX: Math.min(x0, x1) - t, maxX: Math.max(x0, x1) + t, minZ: Math.min(z0, z1) - t, maxZ: Math.max(z0, z1) + t })
  return m
}

function carpet(parent, x0, z0, x1, z1, tex, tint) {
  const t = tex.clone()
  t.repeat.set(x1 - x0, z1 - z0)
  t.needsUpdate = true
  const c = new THREE.Mesh(new THREE.PlaneGeometry(x1 - x0, z1 - z0), new THREE.MeshStandardMaterial({ map: t, color: tint ?? 0xffffff, roughness: 0.98 }))
  c.rotation.x = -Math.PI / 2
  c.position.set((x0 + x1) / 2, 0.006, (z0 + z1) / 2)
  c.receiveShadow = true
  parent.add(c)
}

function lightPanel(parent, x, z) {
  const diffuser = new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xfff6e8, emissiveIntensity: 1.6, roughness: 0.9 })
  box(1.3, 0.04, 0.7, mat(0xd8dde4), x, HALL.height - 0.02, z, parent)
  const p = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.6), diffuser)
  p.rotation.x = Math.PI / 2
  p.position.set(x, HALL.height - 0.045, z)
  parent.add(p)
}

function pointLight(parent, x, z, intensity, distance) {
  const l = new THREE.PointLight(0xfff4e0, intensity, distance, 1.5)
  l.position.set(x, HALL.height - 0.35, z)
  parent.add(l)
}

/** Builds one project room's walls, carpet, windows, dividers and furnishings off the hallway. */
function buildRoomShell(parent, r) {
  const x0 = roomX0(r.index)
  if (r.isEscape) {
    escapeRoom = buildEscapeRoom(THREE, { box, mat, textSprite, solid }, parent, { x: x0, z: HALL.depth, width: roomW(r), depth: roomD(r) })
    escapeTheme = ''
    r.sign = escapeRoom.sign
    return
  }
  const W = roomW(r)
  const D = roomD(r)
  const x1 = x0 + W
  const z0 = HALL.depth
  const z1 = HALL.depth + D
  const doorX = roomDoorX(r)
  const carpetTint = designStyle.rooms[designKey(r)]?.carpet ?? designStyle.theme.carpet ?? new THREE.Color().setHSL(projectHue(r.project), 0.35, 0.72)
  carpet(parent, x0, z0, x1, z1, TEX.carpetSession, carpetTint)
  // Front wall with the doorway, side walls, back wall.
  wallRun(parent, x0, z0, doorX - ROOM.door / 2, z0)
  wallRun(parent, doorX + ROOM.door / 2, z0, x1, z0)
  box(ROOM.door, HALL.height - 2.1, 0.12, wallBoxMat, doorX, 2.1 + (HALL.height - 2.1) / 2, z0, parent) // over the door
  box(ROOM.door + 0.1, 0.06, 0.16, metal, doorX, 2.1, z0, parent) // lintel
  wallRun(parent, x0, z0, x0, z1)
  wallRun(parent, x1, z0, x1, z1)
  wallRun(parent, x0, z1, x1, z1)
  // Windows on the back wall: a sky outside, frames, sills, blinds.
  const frameMat = mat(0x3d4452, { metalness: 0.3, roughness: 0.5 })
  const nWin = Math.max(1, Math.round(W / 4.7))
  for (let k = 0; k < nWin; k++) {
    const x = x0 + (k + 0.5) * (W / nWin)
    const win = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 1.2), new THREE.MeshBasicMaterial({ map: TEX.sky }))
    win.position.set(x, 1.7, z1 - 0.075)
    win.rotation.y = Math.PI
    parent.add(win)
    box(1.7, 0.05, 0.06, frameMat, x, 1.105, z1 - 0.09, parent)
    box(1.7, 0.05, 0.03, frameMat, x, 2.32, z1 - 0.075, parent)
    box(0.05, 1.3, 0.03, frameMat, x - 0.825, 1.7, z1 - 0.075, parent)
    box(0.05, 1.3, 0.03, frameMat, x + 0.825, 1.7, z1 - 0.075, parent)
    box(0.03, 1.2, 0.02, frameMat, x, 1.7, z1 - 0.072, parent)
    box(1.9, 0.04, 0.16, mat(0xf2f4f7), x, 1.06, z1 - 0.14, parent)
    for (let b = 0; b < 7; b++) box(1.62, 0.02, 0.03, mat(0xe8ebef, { roughness: 0.6 }), x, 2.28 - b * 0.055, z1 - 0.11, parent)
  }
  // Dividers between bays: half-height partitions, open at both ends so you can walk round. The arcade has tables instead.
  if (r.isArcade) buildArcadeRoom(parent, r)
  if (r.isPersonal) buildPersonalRoom(parent, r)
  for (let b = 1; b < BAY.count && !r.isArcade && !r.isPersonal; b++) {
    const x = x0 + 0.1 + b * BAY.width
    const d = box(0.08, 1.4, D - 3.0, mat(0xb9c0cc, { roughness: 0.7 }), x, 0.7, z0 + D / 2, parent)
    d.castShadow = true
    box(0.1, 0.05, D - 3.0, metal, x, 1.42, z0 + D / 2, parent)
    solids.push({ minX: x - 0.05, maxX: x + 0.05, minZ: z0 + 1.5, maxZ: z1 - 1.5 })
  }
  // Furnishings.
  plant(parent, x0 + 0.6, z1 - 0.75, r.index * 7 + 1)
  plant(parent, x1 - 0.6, z1 - 0.75, r.index * 7 + 2)
  if (!r.isPersonal) {
    cabinet(parent, x0 + 0.5, z0 + 2.0, Math.PI / 2)
    whiteboard(parent, x0 + 0.08, z0 + 6.5, Math.PI / 2)
  }
  // This session's room has its project's kanban board on the wall across from the whiteboard.
  if (r.project === selfProject && !r.isArcade && !r.isPersonal) {
    kanbanWall = buildKanbanWall(THREE, { box, mat, textSprite }, parent, { x: x1 - 0.08, z: z0 + 6.5, rotY: -Math.PI / 2 })
    kanbanWall.target = { kind: 'kanban', number: 'kanban', x: x1 - 0.08, z: z0 + 6.5, stand: new THREE.Vector3(x1 - 1.3, 0, z0 + 6.5) }
    if (state?.kanban) kanbanWall.draw(state.kanban)
  }
  wallClock(parent, doorX, 2.5, z0 + 0.09, 0)
  // Lights and ceiling panels.
  pointLight(parent, x0 + W / 2, z0 + D / 2, 22, 16)
  for (let x = x0 + 2.4; x < x1 - 1; x += 4.7) for (let z = z0 + 2.6; z < z1 - 1; z += 4.4) lightPanel(parent, x, z)
  // The sign over the door, read from the hallway.
  r.sign = textSprite([r.title, r.isArcade ? `games · room ${r.index + 1}` : r.isPersonal ? `yours · room ${r.index + 1}` : `project · room ${r.index + 1}`], { width: 640, height: 150, scale: 1.1 })
  r.sign.position.set(doorX, 2.75, z0 - 0.35)
  parent.add(r.sign)
}

/** Rebuilds the static world (hallway and every room) for the rooms known now; desks live in their own group. */
function buildWorld() {
  worldGroup.clear()
  solids = []
  kanbanWall = null
  escapeRoom = null
  const L = hallLength()
  const D = HALL.depth + Math.max(ROOM.depth, ...rooms.map(roomD))
  room = { width: L * 100, depth: D * 100, height: HALL.height * 100 } // the footprint the player is clamped to
  // Floor and ceiling over the whole footprint.
  TEX.floor.repeat.set(L / 2, D / 0.5)
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(L, D), new THREE.MeshStandardMaterial({ map: TEX.floor, roughness: 0.6, metalness: 0.02 }))
  floor.rotation.x = -Math.PI / 2
  floor.position.set(L / 2, 0, D / 2)
  floor.receiveShadow = true
  worldGroup.add(floor)
  carpet(worldGroup, 0, 0.3, L, HALL.depth - 0.1, TEX.carpetPeers, 0xd9d4cc)
  TEX.ceiling.repeat.set(Math.round(L / 1.2), D / 1.2)
  ceilingMat = new THREE.MeshStandardMaterial({ map: TEX.ceiling, roughness: 0.95, color: designStyle.theme.ceiling ?? 0xffffff })
  const ceiling = new THREE.Mesh(new THREE.PlaneGeometry(L, D), ceilingMat)
  ceiling.rotation.x = Math.PI / 2
  ceiling.position.set(L / 2, HALL.height, D / 2)
  worldGroup.add(ceiling)
  // The hallway: outer wall with the entrance, end walls, and the front walls of rooms that do not exist yet.
  const entranceX = 2
  wallRun(worldGroup, 0, 0, entranceX - 0.6, 0)
  wallRun(worldGroup, entranceX + 0.6, 0, L, 0)
  box(1.2, HALL.height - 2.1, 0.12, wallBoxMat, entranceX, 2.1 + (HALL.height - 2.1) / 2, 0, worldGroup)
  const door = box(1.14, 2.06, 0.05, new THREE.MeshStandardMaterial({ map: TEX.desk, color: 0x8a7560, roughness: 0.5 }), entranceX, 1.03, 0.03, worldGroup)
  door.castShadow = false
  box(0.03, 2.1, 0.1, metal, entranceX - 0.585, 1.05, 0, worldGroup)
  box(0.03, 2.1, 0.1, metal, entranceX + 0.585, 1.05, 0, worldGroup)
  solids.push({ minX: entranceX - 0.6, maxX: entranceX + 0.6, minZ: -0.1, maxZ: 0.08 })
  // No end walls: the hallway continues across the seam. The wall strip between rooms is split across it.
  for (let i = rooms.length; i < Math.max(2, rooms.length); i++) wallRun(worldGroup, roomX0(i), HALL.depth, roomX0(i) + ROOM.width, HALL.depth)
  // The strip of wall between rooms, and the back of that strip.
  for (let i = 0; i <= rooms.length; i++) {
    const xa = i === 0 ? 0 : roomX0(i - 1) + roomW(rooms[i - 1])
    const xb = i === rooms.length ? L : roomX0(i)
    if (xb > xa) {
      wallRun(worldGroup, xa, HALL.depth, xb, HALL.depth)
      wallRun(worldGroup, xa, D, xb, D)
    }
  }
  // Hallway lights, panels and a few things along it.
  for (let x = 3; x < L; x += 7.5) {
    pointLight(worldGroup, x, HALL.depth / 2, 9, 9)
    lightPanel(worldGroup, x, HALL.depth / 2)
  }
  waterCooler(worldGroup, entranceX + 1.6, 0.4)
  wallClock(worldGroup, entranceX + 3.2, 2.4, 0.09, 0)
  for (const r of rooms) buildRoomShell(worldGroup, r)
  if (rooms.length <= 3) {
    const s = textSprite(['No project rooms yet', 'a room opens when a session appears'], { width: 640, height: 150, scale: 1.0 })
    s.position.set(roomX0(rooms.length) + ROOM.width / 2, 2.4, HALL.depth - 0.35)
    worldGroup.add(s)
  }
  staticSolids = solids.slice()
  // Daylight covers the whole footprint.
  sun.target.position.set(L / 2, 0, D / 2)
  sun.position.set(L / 2 + 6, 9, D + 8)
  const half = Math.max(L, D) / 2 + 6
  Object.assign(sun.shadow.camera, { left: -half, right: half, top: half, bottom: -half })
  sun.shadow.camera.updateProjectionMatrix()
}

function rebuildSolids() {
  solids = [...staticSolids]
  for (const d of deskObjects.values()) solids.push(...d.solids)
}

function removeDesk(d) {
  roomGroup.remove(d.group)
  d.screenTex.dispose()
  deskObjects.delete(d.number)
  if (player.seatedAt === d.number) standUp()
  if (walkTo === d) walkTo = null
}

const deskByKey = key => [...deskObjects.values()].find(d => d.key === key)

/** The Agent Arcade is room 1, whatever else exists. Answers whether it was just added. */
function ensureArcadeRoom() {
  if (roomOf.has(ARCADE_PROJECT)) return false
  const r = { index: rooms.length, project: ARCADE_PROJECT, title: 'Agent Arcade', isArcade: true, sessions: new Set(), sign: null }
  rooms.push(r)
  roomOf.set(ARCADE_PROJECT, r)
  return true
}

/** Your own office is room 2, whatever else exists. Answers whether it was just added. */
function ensurePersonalRoom() {
  if (roomOf.has(PERSONAL_PROJECT)) return false
  const r = { index: rooms.length, project: PERSONAL_PROJECT, title: 'My Office', isArcade: false, isPersonal: true, sessions: new Set(), sign: null }
  rooms.push(r)
  roomOf.set(PERSONAL_PROJECT, r)
  return true
}

/**
 * Rooms, bays and desks for the sessions and workers in `next`: a room per
 * project and a bay per session, each kept where it first went; a desk per
 * worker, built when it appears and removed when it goes.
 */
function syncWorld(next) {
  const workers = next.workers
  const byKey = new Map(workers.map(w => [w.key, w]))
  // Sessions as the mod lists them, plus a session of its own for any peer the list does not cover (fixtures).
  const sessions = [...(next.sessions ?? [])]
  const covered = new Set(sessions.flatMap(s => [s.lead, ...s.agents]))
  for (const w of workers) {
    if (covered.has(w.key)) continue
    if (w.kind === 'peer') sessions.push({ id: w.key, project: 'other sessions', label: w.name, isSelf: false, lead: w.key, agents: [] })
    else if (w.kind === 'main') sessions.push({ id: 'self', project: 'this project', label: 'This session', isSelf: true, lead: w.key, agents: [] })
    else {
      const own = sessions.find(s => s.isSelf)
      if (own) own.agents.push(w.key)
    }
    covered.add(w.key)
  }
  // Rooms: the arcade, then your office, then one per project, in order of first sight.
  const isArcadeNew = ensureArcadeRoom()
  const isPersonalNew = ensurePersonalRoom()
  let isDirty = ensureEscapeRoom() || isPersonalNew || isArcadeNew || designDirty
  designDirty = false
  const nextSelf = sessions.find(s => s.isSelf)?.project ?? null
  if (nextSelf !== selfProject) {
    selfProject = nextSelf
    isDirty = true // the kanban wall goes up in this session's room
  }
  for (const s of sessions) {
    if (roomOf.has(s.project)) continue
    const r = { index: rooms.length, project: s.project, title: s.project, isArcade: false, sessions: new Set(), sign: null }
    rooms.push(r)
    roomOf.set(s.project, r)
    isDirty = true
  }
  // Bays: one per session in its project's room, the lowest free one.
  const live = new Set(sessions.map(s => s.id))
  for (const [id, b] of [...bayOf]) {
    if (live.has(id)) continue
    b.room.sessions.delete(id)
    if (b.sign) worldGroup.remove(b.sign)
    bayOf.delete(id)
  }
  for (const s of sessions) {
    const r = roomOf.get(s.project)
    let b = bayOf.get(s.id)
    if (b === undefined) {
      const taken = new Set([...bayOf.values()].filter(v => v.room === r).map(v => v.bay))
      // The middle bay first (straight ahead through the door), then left, then right.
      let bay = [1, 0, 2].find(i => !taken.has(i))
      if (bay === undefined) {
        bay = BAY.count
        while (taken.has(bay)) bay += 1
      }
      b = { room: r, bay, sign: null, label: '' }
      bayOf.set(s.id, b)
      r.sessions.add(s.id)
    }
    const label = s.isSelf ? 'This session' : s.label
    if (b.label !== label || b.sign === null) {
      if (b.sign) worldGroup.remove(b.sign)
      const spot = leadSpot(r, b.bay)
      b.sign = textSprite([label, s.isSelf ? 'you are here' : 'enrolled session'], { width: 640, height: 150, scale: 0.75 })
      b.sign.position.set(spot.x, 2.35, spot.z - 1.2)
      b.label = label
      if (isDirty) b.sign = null // placed after the rebuild below
      else worldGroup.add(b.sign)
    }
  }
  if (isDirty) {
    buildWorld()
    for (const [id, b] of bayOf) {
      const s = sessions.find(x => x.id === id)
      if (!s) continue
      const spot = leadSpot(b.room, b.bay)
      b.sign = textSprite([b.label, s.isSelf ? 'you are here' : 'enrolled session'], { width: 640, height: 150, scale: 0.75 })
      b.sign.position.set(spot.x, 2.35, spot.z - 1.2)
      worldGroup.add(b.sign)
    }
  }
  // Desks: the lead at the bay's front, agents in its rows; gone workers lose their desks and seats.
  for (const [key, seat] of [...seatOf]) {
    if (byKey.has(key) && live.has(seat.sessionId)) continue
    const d = deskByKey(key)
    if (d) removeDesk(d)
    seatOf.delete(key)
  }
  for (const s of sessions) {
    const b = bayOf.get(s.id)
    const place = (key, slot, spot, label) => {
      if (seatOf.has(key) && deskByKey(key)) return
      seatOf.set(key, { sessionId: s.id, slot })
      buildDesk({ number: nextDeskNumber++, x: spot.x / CM, y: spot.z / CM, zone: s.isSelf ? 'session' : 'peers', key, label, sessionId: s.id })
    }
    if (byKey.has(s.lead)) place(s.lead, -1, leadSpot(b.room, b.bay), 'Lead')
    const taken = new Set([...seatOf.entries()].filter(([, v]) => v.sessionId === s.id && v.slot >= 0).map(([, v]) => v.slot))
    for (const key of s.agents) {
      if (!byKey.has(key)) continue
      if (seatOf.has(key) && deskByKey(key)) continue
      let slot = 0
      while (taken.has(slot)) slot += 1
      taken.add(slot)
      place(key, slot, agentSpot(b.room, b.bay, slot), `Agent ${slot + 1}`)
    }
  }
  rebuildSolids()
}

/** Walks you to room n's doorway, facing in. */
function goToRoom(n) {
  const r = rooms[n - 1]
  if (!r) {
    flash(`There is no room ${n} yet.`)
    return
  }
  standUp()
  walkTo = { stand: new THREE.Vector3(roomDoorX(r), 0, HALL.depth - 1.1) }
  flash(`Walking to ${r.title} (room ${n})…`)
}

const deskWood = new THREE.MeshStandardMaterial({ map: TEX.desk, roughness: 0.45, metalness: 0.03 })
const metal = mat(0x2b303a, { metalness: 0.6, roughness: 0.35 })
const chairMat = mat(0x22262e, { roughness: 0.75 })
const mugMats = [mat(0xd9534f), mat(0x3a7bd5), mat(0xf2f4f7), mat(0x2f855a)]

function chair(parent, x, z, facing) {
  const g = new THREE.Group()
  g.position.set(x, 0, z)
  g.rotation.y = facing
  // Seat and back are rounded a little; a padded look with a lighter top.
  const seat = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.08, 0.46), chairMat)
  seat.position.set(0, 0.46, 0)
  seat.castShadow = seat.receiveShadow = true
  g.add(seat)
  box(0.44, 0.02, 0.44, mat(0x2d323b, { roughness: 0.9 }), 0, 0.51, 0, g) // pad on the seat
  box(0.46, 0.5, 0.06, chairMat, 0, 0.75, 0.21, g)
  box(0.42, 0.44, 0.015, mat(0x2d323b, { roughness: 0.9 }), 0, 0.75, 0.172, g) // pad on the back
  // Armrests, a gas lift and a five-star base with casters.
  for (const s of [-1, 1]) {
    box(0.04, 0.02, 0.26, metal, s * 0.24, 0.66, 0.02, g)
    box(0.04, 0.2, 0.04, metal, s * 0.24, 0.56, 0.12, g)
  }
  const lift = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.03, 0.4, 12), metal)
  lift.position.y = 0.22
  g.add(lift)
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2
    const arm = box(0.28, 0.025, 0.04, metal, Math.cos(a) * 0.13, 0.03, Math.sin(a) * 0.13, g)
    arm.rotation.y = -a
    const caster = new THREE.Mesh(new THREE.SphereGeometry(0.025, 8, 8), chairMat)
    caster.position.set(Math.cos(a) * 0.27, 0.025, Math.sin(a) * 0.27)
    g.add(caster)
  }
  parent.add(g)
  return g
}

function buildDesk(d) {
  // Station frame: the android sits at the origin facing -y; the desk is in front (y -85..-25), the visitor beyond.
  const x = d.x * CM
  const z = d.y * CM
  const g = new THREE.Group()
  g.position.set(x, 0, z)
  roomGroup.add(g)
  // The top is the size the design gives this desk (0.9 by 0.6 unless resized); its near edge stays at the android's knees.
  const size = designStyle.desks[d.key] ?? { w: 0.9, d: 0.6 }
  const dw = size.w
  const dd = size.d
  const zc = -0.25 - dd / 2
  const top = box(dw, 0.04, dd, deskWood, 0, 0.72, zc, g)
  top.material = deskWood
  const lx = dw / 2 - 0.03
  const lz = dd / 2 - 0.03
  for (const [px, pz] of [[-lx, zc - lz], [lx, zc - lz], [-lx, zc + lz], [lx, zc + lz]]) box(0.04, 0.7, 0.04, metal, px, 0.35, pz, g)
  box(dw - 0.06, 0.03, 0.03, metal, 0, 0.1, zc - lz, g)
  box(dw - 0.06, 0.03, 0.03, metal, 0, 0.1, zc + lz, g)
  // Monitor faces the android (+z in the station frame after the turn: the android looks -z).
  const monitor = new THREE.Group()
  monitor.position.set(0, 0.74, zc - dd / 2 + 0.17)
  g.add(monitor)
  box(0.56, 0.34, 0.03, metal, 0, 0.3, 0, monitor)
  const screenTex = TEX.screen.clone()
  screenTex.needsUpdate = true
  const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.52, 0.3), new THREE.MeshBasicMaterial({ map: screenTex, color: 0x5a6675 }))
  screen.position.set(0, 0.3, 0.017)
  monitor.add(screen)
  box(0.04, 0.14, 0.04, metal, 0, 0.07, 0, monitor)
  box(0.18, 0.015, 0.12, metal, 0, 0.0075, 0, monitor) // base plate on the desk top
  box(0.36, 0.015, 0.12, mat(0x1f242c, { roughness: 0.6 }), 0, 0.75, -0.45, g) // keyboard
  box(0.06, 0.02, 0.1, mat(0x1f242c, { roughness: 0.5 }), 0.36, 0.75, -0.47, g) // mouse, beside the resting hand
  // A mug and a few papers, placed a little differently at each desk.
  const rnd = seeded(100 + d.number)
  const mug = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.035, 0.09, 14), mugMats[d.number % mugMats.length])
  mug.position.set(-dw * 0.36 + rnd() * 0.06, 0.785, zc - 0.07 + rnd() * 0.08)
  mug.castShadow = true
  g.add(mug)
  const papers = box(0.21, 0.008, 0.29, mat(0xf7f9fb, { roughness: 0.9 }), dw * 0.33, 0.745, zc - 0.15, g)
  papers.rotation.y = (rnd() - 0.5) * 0.5
  // Desk number plate toward the visitor.
  const plate = textSprite([d.label ?? `Desk ${d.number}`], { width: 300, height: 96, scale: 0.28 })
  plate.position.set(0, 0.84, zc - dd / 2 - 0.03)
  g.add(plate)
  chair(g, 0, 0.06, 0) // the android's: its back clear of the chest even leaning back
  const vz = zc - dd / 2 - 0.67 // the visitor's chair, across the desk
  chair(g, 0, vz, Math.PI)
  const deskSolids = [
    { minX: -dw * 50, maxX: dw * 50, minY: (zc - dd / 2) * 100, maxY: (zc + dd / 2) * 100 },
    { minX: -30, maxX: 30, minY: -25, maxY: 30 },
    { minX: -25, maxX: 25, minY: (vz - 0.26) * 100, maxY: (vz + 0.27) * 100 },
  ].map(s => ({ minX: x + s.minX * CM, maxX: x + s.maxX * CM, minZ: z + s.minY * CM, maxZ: z + s.maxY * CM }))
  deskObjects.set(d.number, {
    group: g,
    screen,
    screenTex,
    solids: deskSolids,
    key: d.key ?? null,
    number: d.number,
    zone: d.zone,
    x,
    z,
    topZ: zc,
    sizeKey: JSON.stringify(designStyle.desks[d.key] ?? null),
    seat: new THREE.Vector3(x, 0, z + vz + 0.02),
    stand: new THREE.Vector3(x, 0, z + vz - 0.53),
    worker: null,
    android: null,
  })
}

// ─── Androids ──────────────────────────────────────────────────────────────
function makeAndroid(worker) {
  const g = new THREE.Group()
  const shell = mat(ROLE_SHELL[worker.kind] ?? 0xe8edf3, { roughness: 0.35, metalness: 0.15 })
  const joint = mat(0x3a4150, { roughness: 0.5, metalness: 0.4 })
  const parts = {}
  // Seated on the chair's pad (top at 0.52): hips and thighs rest on it, shins reach the floor, feet on it.
  parts.hips = box(0.34, 0.12, 0.28, joint, 0, 0.585, 0, g)
  for (const s of [-1, 1]) {
    box(0.12, 0.1, 0.42, shell, s * 0.1, 0.57, -0.2, g)
    box(0.1, 0.46, 0.1, shell, s * 0.1, 0.29, -0.4, g)
    box(0.12, 0.05, 0.18, joint, s * 0.1, 0.035, -0.46, g)
  }
  const torso = new THREE.Group()
  torso.position.set(0, 0.65, 0)
  g.add(torso)
  parts.torso = torso
  // Chest, neck ring and head stack without burying one in the next: chest top 0.53, ring 0.533–0.577, head bottom 0.583.
  const chest = new THREE.Mesh(new THREE.CapsuleGeometry(0.17, 0.22, 6, 16), shell)
  chest.position.y = 0.25
  chest.scale.set(1.1, 1, 0.8)
  chest.castShadow = true
  torso.add(chest)
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.1, 0.022, 10, 32), new THREE.MeshStandardMaterial({ color: 0x222222, emissive: LIGHT.off, emissiveIntensity: 1.6 }))
  ring.rotation.x = Math.PI / 2
  ring.position.y = 0.555
  torso.add(ring)
  parts.ring = ring
  const head = new THREE.Group()
  head.position.y = 0.735
  torso.add(head)
  parts.head = head
  const skull = new THREE.Mesh(new THREE.SphereGeometry(0.16, 24, 18), shell)
  skull.scale.set(1.05, 0.95, 1)
  skull.castShadow = true
  head.add(skull)
  // The face: a cap of a slightly larger sphere, scaled like the skull, so it lies on the skull's surface and the
  // skull never shows through. The cap spans ±FACE_SPAN around the front (-z); its texture is a disc, clear outside.
  const face = faceTexture()
  const cap = new THREE.Mesh(
    new THREE.SphereGeometry(0.1625, 32, 24, Math.PI * 1.5 - FACE_SPAN, FACE_SPAN * 2, Math.PI / 2 - FACE_SPAN, FACE_SPAN * 2),
    new THREE.MeshBasicMaterial({ map: face, transparent: true, alphaTest: 0.5 }),
  )
  cap.scale.copy(skull.scale)
  head.add(cap)
  parts.face = face
  for (const s of [-1, 1]) {
    const ear = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.04, 16), joint)
    ear.rotation.z = Math.PI / 2
    ear.position.set(s * 0.165, 0, 0)
    head.add(ear)
  }
  // Arms: shoulder pivots; forearms reach to the keyboard.
  parts.arms = [-1, 1].map(s => {
    const shoulder = new THREE.Group()
    shoulder.position.set(s * 0.24, 0.42, 0)
    torso.add(shoulder)
    box(0.09, 0.3, 0.09, shell, 0, -0.15, 0, shoulder)
    const elbow = new THREE.Group()
    elbow.position.set(0, -0.3, 0)
    shoulder.add(elbow)
    box(0.08, 0.28, 0.08, shell, 0, -0.14, 0, elbow)
    box(0.08, 0.08, 0.1, joint, 0, -0.3, 0, elbow)
    return { shoulder, elbow }
  })
  // The hand-raised marker.
  const markCanvas = document.createElement('canvas')
  markCanvas.width = markCanvas.height = 128
  const mg = markCanvas.getContext('2d')
  mg.fillStyle = '#ffc93c'
  mg.beginPath()
  mg.arc(64, 64, 58, 0, Math.PI * 2)
  mg.fill()
  mg.fillStyle = '#1b1405'
  mg.font = '700 84px Segoe UI, sans-serif'
  mg.textAlign = 'center'
  mg.textBaseline = 'middle'
  mg.fillText('!', 64, 70)
  const markTex = new THREE.CanvasTexture(markCanvas)
  markTex.colorSpace = THREE.SRGBColorSpace
  const mark = new THREE.Sprite(new THREE.SpriteMaterial({ map: markTex, depthTest: false, transparent: true }))
  mark.scale.set(0.22, 0.22, 1)
  mark.position.set(0.24, 2.05, 0)
  mark.visible = false
  g.add(mark)
  parts.mark = mark
  const tag = textSprite([worker.name, worker.stateLabel], { width: 640, height: 150, scale: 0.62 })
  tag.position.set(0, 1.77, 0)
  g.add(tag)
  parts.tag = tag
  g.userData = { parts, key: worker.key, phase: Math.random() * 10 }
  g.rotation.y = 0 // the station frame already faces -z
  return g
}

function styleAndroid(android, w) {
  const { parts } = android.userData
  const color = LIGHT[w.light] ?? LIGHT.off
  parts.ring.material.emissive.setHex(color)
  parts.face.userData.draw(GLYPH[w.state] ?? '?', hex(color))
  parts.tag.userData.draw([w.name, w.stateLabel])
  parts.mark.visible = w.hand !== null
  android.userData.worker = w
}

function animateAndroid(android, t) {
  const { parts, worker: w, phase } = android.userData
  if (!w) return
  const s = w.state
  const k = t + phase
  parts.torso.rotation.set(0, 0, 0)
  parts.head.rotation.set(0, 0, 0)
  // Arm angles are worked out from the chain (shoulder at y 1.07, upper arm 0.3, forearm 0.36, desk top 0.70–0.74
  // from z -0.25, keyboard top at 0.76): RESTING lays the forearms flat on the desk, TYPING holds the hands just over
  // the keys, LAP hangs them beside the knees under the desk's front edge. Nothing reaches into the desk, the keys,
  // the monitor or the seat.
  const RESTING = { sx: 0.45, ex: 1.12 }
  const LAP = { sx: 0.3, ex: 0.6 }
  let armL = RESTING
  let armR = RESTING
  if (s === 'working') {
    armL = { sx: 0.6 + Math.sin(k * 14) * 0.04, ex: 0.97 }
    armR = { sx: 0.6 + Math.sin(k * 14 + 1.7) * 0.04, ex: 0.97 }
    parts.head.rotation.x = 0.18 + Math.sin(k * 1.3) * 0.03
  } else if (s === 'idle' || s === 'unknown') {
    parts.torso.rotation.x = Math.sin(k * 1.2) * 0.02
    parts.head.rotation.y = Math.sin(k * 0.4) * 0.35
  } else if (s === 'completed') {
    parts.torso.rotation.x = -0.1
    armL = armR = LAP
  } else if (s === 'failed') {
    // Slumped, but not so far that the head sinks into the chest.
    parts.torso.rotation.x = 0.2
    parts.head.rotation.x = 0.32
    armL = armR = { sx: 0.25, ex: 0.7 }
  } else if (s === 'waiting-external') {
    parts.head.rotation.y = Math.sin(k * 0.8) * 0.5
  }
  if (w.hand !== null) {
    armR = { sx: Math.PI * 0.92, ex: -0.15 + Math.sin(k * 6) * 0.15 }
    parts.mark.position.y = 2.05 + Math.sin(k * 4) * 0.05
  }
  // The values above read "positive = forward/down toward the desk"; the android faces -z.
  // A torso or head tipped by +x leans back / looks up, so those flip. A hanging arm turned by +x swings
  // toward -z (forward), so arm values apply as they are.
  parts.torso.rotation.x = -parts.torso.rotation.x
  parts.head.rotation.x = -parts.head.rotation.x
  parts.arms[0].shoulder.rotation.x = armL.sx
  parts.arms[0].elbow.rotation.x = armL.ex
  parts.arms[1].shoulder.rotation.x = armR.sx
  parts.arms[1].elbow.rotation.x = armR.ex
  const ringPulse = s === 'working' ? 1.4 + Math.sin(k * 5) * 0.6 : w.hand ? 1.4 + Math.sin(k * 8) * 0.9 : 1.2
  parts.ring.material.emissiveIntensity = ringPulse
}

// ─── State from the mod ────────────────────────────────────────────────────
let state = null
let connected = false

function applyState(next) {
  state = next
  if (!player.placed) spawnPlayer()
  applyDesignStyles(next.design)
  // The world is the window's own; the mod's fixed desk grid (for its pane) is not used here.
  syncWorld(next)
  const byKey = new Map(next.workers.map(w => [w.key, w]))
  for (const d of deskObjects.values()) {
    const w = byKey.get(d.key) ?? null
    if (w === null) {
      if (d.android) d.group.remove(d.android)
      d.android = null
      d.worker = null
      d.screen.material.color.setHex(0x161b22) // nobody here: the screen is dark
      continue
    }
    if (d.android === null || d.android.userData.key !== w.key) {
      if (d.android) d.group.remove(d.android)
      d.android = makeAndroid(w)
      d.group.add(d.android)
    }
    d.worker = w
    styleAndroid(d.android, w)
    // The screen's picture: bright and scrolling while working, red-tinted after a failure, dim otherwise.
    d.screen.material.color.setHex(w.state === 'working' ? 0xffffff : w.state === 'failed' ? 0xc07a7a : 0x6a7684)
  }
  drawStatus()
  drawNotice()
  drawConvo()
  drawTarget()
  drawChatHeader()
  drawArcade()
  drawDesign()
  drawKanban()
  drawEscape()
  // `&sit=chess,a` (with `shot`): sit at that arcade seat once the first state is in, for screenshots while developing.
  if (SIT !== null && player.arcadeSeat === null && arcadeTables.has(SIT[0])) {
    const seat = arcadeTables.get(SIT[0]).seats[SIT[1]]
    if (seat) sitArcade(seat)
  }
  // `&sit=monitor` sits you at your own desk.
  if (SIT !== null && SIT[0] === 'monitor' && !player.ownSeat && myOffice !== null) sitOwn()
  // `&sit=kanban` and `&sit=design` open those panels where you stand.
  if (SIT !== null && SIT[0] === 'kanban' && !kanbanOpen) openKanban()
  if (SIT !== null && SIT[0] === 'escape' && !player.escapeSeat && escapeRoom !== null) sitEscape()
  if (SIT !== null && SIT[0] === 'design' && !designOpen) openDesign()
}

function drawStatus() {
  const n = state?.workers.length ?? 0
  const hands = state?.workers.filter(w => w.hand !== null).length ?? 0
  const sessions = bayOf.size
  const color = connected ? 'var(--green)' : 'var(--red)'
  ui.status.innerHTML =
    `<span class="dot" style="background:${color}"></span><b>${connected ? 'Live' : 'Disconnected'}</b>` +
    ` · ${rooms.length} room${rooms.length === 1 ? '' : 's'} · ${sessions} session${sessions === 1 ? '' : 's'} · ${n} worker${n === 1 ? '' : 's'}` +
    (hands > 0 ? ` · <span style="color:var(--yellow)">✋ ${hands} waiting for you</span>` : '')
}

let noticeShownAt = 0
let lastNoticeText = ''
function drawNotice() {
  const n = state?.notice
  if (!n || n.text === lastNoticeText) return
  lastNoticeText = n.text
  noticeShownAt = performance.now()
  ui.notice.textContent = n.text
  ui.notice.className = `hud${n.isError ? ' err' : ''}`
  ui.notice.style.display = 'block'
}

function connect() {
  const es = new EventSource(`/events?t=${encodeURIComponent(TOKEN)}`)
  es.onopen = () => {
    connected = true
    drawStatus()
    post({ type: 'hello' })
  }
  es.onmessage = ev => {
    try {
      applyState(JSON.parse(ev.data))
    } catch (err) {
      console.error(err)
    }
  }
  // The bridge is closing on purpose (/3d close, or the session ended): this window closes itself.
  es.addEventListener('close', () => {
    connected = false
    es.close()
    document.exitPointerLock?.()
    ui.overlay.style.display = 'flex'
    ui.overlay.querySelector('.card').innerHTML = '<h1>Office closed</h1><p>Closed from Claude Code. Run <b>/3d full</b> to reopen it.</p>'
    setTimeout(() => window.close(), 400)
  })
  es.onerror = () => {
    connected = false
    drawStatus()
    // The bridge is gone for good (Claude Code closed it, or the session ended): say so and close the window.
    setTimeout(() => {
      if (connected) return
      es.close()
      document.exitPointerLock?.()
      ui.overlay.style.display = 'flex'
      ui.overlay.querySelector('.card').innerHTML =
        '<h1>Link ended</h1><p>This window is no longer linked to Claude Code. Run <b>/3d full</b> again to reopen it.</p><button onclick="window.close()">Close window</button>'
      setTimeout(() => window.close(), 4000)
    }, 6000)
  }
}

async function post(cmd) {
  try {
    const res = await fetch(`/cmd?t=${encodeURIComponent(TOKEN)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cmd),
    })
    return res.ok
  } catch {
    return false
  }
}

// ─── The player ────────────────────────────────────────────────────────────
const player = {
  pos: new THREE.Vector3(),
  vel: new THREE.Vector3(),
  yaw: Math.PI,
  pitch: -0.05,
  onGround: true,
  seatedAt: null, // desk number
  arcadeSeat: null, // { game, side } at an arcade table
  ownSeat: false, // at your own desk
  escapeSeat: false, // at the escape room's console
  placed: false,
  eye: EYE,
  bob: 0,
}

// `&shot=x,z,yawDeg,pitchDeg` (metres, degrees) starts there with no start card: for screenshots while developing.
const SHOT = new URLSearchParams(location.search).get('shot')?.split(',').map(Number) ?? null
const SIT = SHOT !== null ? (new URLSearchParams(location.search).get('sit')?.split(',') ?? null) : null
// With `shot`, the scene is reachable for a development audit (overlaps, collision boxes); never otherwise.
if (SHOT !== null) window.__office = { THREE, scene, get solids() { return solids }, get room() { return room }, deskObjects, player, arcadeTables, get myOffice() { return myOffice } }

function spawnPlayer() {
  // Just inside the hallway's entrance, looking down the hallway (+x).
  player.pos.set(2, 0, 1.4)
  player.yaw = -Math.PI / 2
  player.pitch = -0.05
  player.placed = true
  if (SHOT !== null && SHOT.length === 4 && SHOT.every(Number.isFinite)) {
    player.pos.set(SHOT[0], 0, SHOT[1])
    player.yaw = (SHOT[2] * Math.PI) / 180
    player.pitch = (SHOT[3] * Math.PI) / 180
    ui.overlay.style.display = 'none'
  }
}

const keys = new Set()
let isLocked = false
let isChatting = false
let showConvo = false

addEventListener('keydown', e => {
  if (isChatting) return
  keys.add(e.code)
  if (e.code === 'Tab') {
    e.preventDefault()
    showConvo = !showConvo
    drawConvo()
  }
  if (!isLocked) return
  if (e.code === 'KeyE') toggleSit()
  else if (e.code === 'KeyT' || e.code === 'Enter') openChat()
  else if (e.code === 'KeyF') toggleFullscreen()
  else if (e.code === 'KeyG') openDesign()
  else if (/^Digit[1-9]$/.test(e.code)) goToRoom(Number(e.code.slice(5)))
  else if (e.code === 'Digit0') {
    standUp()
    spawnPlayer()
  } else if (e.code === 'Space' && player.seatedAt === null && player.arcadeSeat === null && !player.ownSeat && !player.escapeSeat && player.onGround) {
    player.vel.y = JUMP
    player.onGround = false
  }
})
addEventListener('keyup', e => keys.delete(e.code))
addEventListener('blur', () => keys.clear())

document.addEventListener('mousemove', e => {
  if (!isLocked) return
  player.yaw -= e.movementX * LOOK_SENS
  player.pitch = Math.max(-1.45, Math.min(1.45, player.pitch - e.movementY * LOOK_SENS))
})

function lock() {
  renderer.domElement.requestPointerLock?.({ unadjustedMovement: true })?.catch?.(() => renderer.domElement.requestPointerLock())
}
document.addEventListener('pointerlockchange', () => {
  isLocked = document.pointerLockElement === renderer.domElement
  ui.overlay.style.display = isLocked || isChatting ? 'none' : 'flex'
  ui.play.textContent = player.placed ? 'Click to resume' : 'Click to enter'
  keys.clear()
})
ui.play.addEventListener('click', () => {
  if (!document.fullscreenElement) document.documentElement.requestFullscreen?.().catch(() => {})
  lock()
})
ui.quit.addEventListener('click', () => window.close())
renderer.domElement.addEventListener('click', e => {
  if (player.arcadeSeat !== null) arcadeBoardClick(e)
  else if (!isLocked && !isChatting) lock()
})
// The arcade panel: its buttons by their data-act, Enter plays the typed move, Esc stands up.
// The world editor's panel: its buttons post design commands; Enter in the box asks; Esc closes.
ui.design.addEventListener('click', e => {
  const b = e.target.closest('[data-design]')
  if (b && !b.disabled) designAct(b)
})
ui.design.addEventListener('keydown', e => {
  e.stopPropagation()
  if (e.key === 'Escape') {
    e.preventDefault()
    closeDesign()
  } else if (e.key === 'Enter' && e.target.matches('[data-design-text]')) {
    e.preventDefault()
    const b = ui.design.querySelector('[data-design="request"]')
    if (b && !b.disabled) designAct(b)
  }
})
// The kanban panel: a click or a change on a control posts the command the board module makes of it; Esc closes.
const kanbanAct = el => {
  const cmd = kanbanCommandFor(el, ui.kanban)
  if (cmd) void post(cmd)
}
ui.kanban.addEventListener('click', e => {
  const b = e.target.closest('button[data-kanban], input[type="checkbox"][data-kanban]')
  if (b) kanbanAct(b)
})
ui.kanban.addEventListener('change', e => {
  if (e.target.matches('select[data-kanban]')) kanbanAct(e.target)
})
ui.kanban.addEventListener('keydown', e => {
  e.stopPropagation()
  if (e.key === 'Escape') {
    e.preventDefault()
    closeKanban()
  } else if (e.key === 'Enter' && e.target.matches('[data-add-text]')) {
    e.preventDefault()
    const b = ui.kanban.querySelector(`[data-kanban="add"][data-column="${CSS.escape(e.target.dataset.addText)}"]`)
    if (b) kanbanAct(b)
  } else if (e.key === 'Enter' && e.target.matches('[data-edit-text]')) {
    e.preventDefault()
    const b = ui.kanban.querySelector(`[data-kanban="edit-save"][data-id="${CSS.escape(e.target.dataset.editText)}"]`)
    if (b) kanbanAct(b)
  }
})
// The escape console's panel: its buttons post escape commands; Enter in a box presses its button; Esc stands up.
ui.escape.addEventListener('click', e => {
  const b = e.target.closest('[data-escape]')
  if (b) escapeAct(b)
})
ui.escape.addEventListener('keydown', e => {
  e.stopPropagation()
  if (e.key === 'Escape') {
    e.preventDefault()
    standUpEscape()
  } else if (e.key === 'Enter' && e.target.matches('[data-escape-input]')) {
    e.preventDefault()
    const b = ui.escape.querySelector(`[data-escape="try"][data-id="${CSS.escape(e.target.dataset.escapeInput)}"]`)
    if (b) escapeAct(b)
  } else if (e.key === 'Enter' && e.target.matches('[data-escape-say]')) {
    e.preventDefault()
    const b = ui.escape.querySelector('[data-escape="say"]')
    if (b) escapeAct(b)
  }
})
// Your desk's panel: share or stop sharing a window; Esc stands up.
ui.monitor.addEventListener('click', e => {
  const b = e.target.closest('[data-monitor]')
  if (!b) return
  if (b.dataset.monitor === 'share') void shareWindow()
  else if (b.dataset.monitor === 'stop') {
    stopSharing()
    drawMonitorPanel()
  }
})
ui.monitor.addEventListener('keydown', e => {
  e.stopPropagation()
  if (e.key === 'Escape') {
    e.preventDefault()
    standUpOwn()
  }
})
ui.arcade.addEventListener('click', e => {
  const b = e.target.closest('[data-act]')
  if (b) arcadeAct(b.dataset.act, b.dataset.side)
})
ui.arcade.addEventListener('keydown', e => {
  e.stopPropagation()
  if (e.key === 'Escape') {
    e.preventDefault()
    standUpArcade()
  } else if (e.key === 'Enter' && e.target.matches('[data-move]')) {
    e.preventDefault()
    arcadeAct('play')
  }
})

function toggleFullscreen() {
  if (document.fullscreenElement) document.exitFullscreen()
  else document.documentElement.requestFullscreen().catch(() => {})
}

function collide(p) {
  if (!room) return
  const W = room.width * CM
  const D = room.depth * CM
  // The hallway loops: past one end you are at the other. Depth is bounded by the walls either way.
  if (p.x < 0) p.x += W
  else if (p.x >= W) p.x -= W
  p.z = Math.max(RADIUS, Math.min(D - RADIUS, p.z))
  for (const s of solids) {
    // Circle against box: push out along the shortest axis.
    const cx = Math.max(s.minX, Math.min(p.x, s.maxX))
    const cz = Math.max(s.minZ, Math.min(p.z, s.maxZ))
    const dx = p.x - cx
    const dz = p.z - cz
    const d2 = dx * dx + dz * dz
    if (d2 >= RADIUS * RADIUS) continue
    if (d2 > 1e-8) {
      const d = Math.sqrt(d2)
      p.x = cx + (dx / d) * RADIUS
      p.z = cz + (dz / d) * RADIUS
    } else {
      const pushes = [
        [p.x - s.minX + RADIUS, -1, 0],
        [s.maxX - p.x + RADIUS, 1, 0],
        [p.z - s.minZ + RADIUS, 0, -1],
        [s.maxZ - p.z + RADIUS, 0, 1],
      ].sort((a, b) => a[0] - b[0])[0]
      p.x += pushes[1] * pushes[0]
      p.z += pushes[2] * pushes[0]
    }
  }
}

// Desk you face: the nearest occupied desk whose android is in front of you, within range.
let target = null
function findTarget() {
  if (player.seatedAt !== null) return deskObjects.get(player.seatedAt) ?? null
  if (player.arcadeSeat !== null) return arcadeTables.get(player.arcadeSeat.game)?.seats[player.arcadeSeat.side] ?? null
  if (player.ownSeat) return myOffice?.seat ?? null
  if (player.escapeSeat) return escapeRoom?.seat ?? null
  const fwd = new THREE.Vector3(-Math.sin(player.yaw), 0, -Math.cos(player.yaw))
  let best = null
  let bestD = Infinity
  const consider = (candidate, x, z, range) => {
    const to = new THREE.Vector3(x - player.pos.x, 0, z - player.pos.z)
    const dist = to.length()
    if (dist > range || dist < 0.01) return
    if (to.normalize().dot(fwd) < TARGET_CONE) return
    if (dist < bestD) {
      best = candidate
      bestD = dist
    }
  }
  for (const d of deskObjects.values()) if (d.worker !== null) consider(d, d.x, d.z, TARGET_RANGE + 1.4)
  for (const t of arcadeTables.values()) for (const seat of [t.seats.a, t.seats.b]) consider(seat, seat.pos.x, seat.pos.z, 2.3)
  if (myOffice !== null) consider(myOffice.seat, myOffice.seat.x, myOffice.seat.z, 2.3)
  if (kanbanWall !== null) consider(kanbanWall.target, kanbanWall.target.x, kanbanWall.target.z, 2.6)
  if (escapeRoom !== null) consider(escapeRoom.seat, escapeRoom.seat.pos.x, escapeRoom.seat.pos.z, 2.3)
  return best
}

let selectTimer = 0
let selectedKey = null
function setTarget(next) {
  if (next === target) return
  target = next
  drawTarget()
  clearTimeout(selectTimer)
  const key = next?.worker?.key ?? null
  if (key !== null && key !== selectedKey) {
    selectTimer = setTimeout(() => {
      selectedKey = key
      post({ type: 'select', key })
    }, 250)
  }
}

function drawTarget() {
  ui.crosshair.className = `hud${target ? ' on' : ''}`
  if (target?.kind === 'escape' && !isChatting) {
    const e = state?.escape
    ui.target.innerHTML =
      '<div class="name">Escape room console</div>' +
      `<div class="meta">${e?.room ? `In ${esc(e.room.title)} · ${e.solved?.length ?? 0}/${e.room.puzzles?.length ?? 0} locks open` : 'No room chosen yet'}${e?.teammate ? ' · a teammate is seated' : ''}</div>` +
      '<div class="keys"><kbd>E</kbd> sit down: pick a room, seat a teammate, play</div>'
    ui.target.style.display = 'block'
    return
  }
  if (target?.kind === 'kanban' && !isChatting) {
    const k = state?.kanban
    ui.target.innerHTML =
      '<div class="name">Kanban board</div>' +
      `<div class="meta">${k?.file ? `${esc(k.file)} · ${k.columns?.length ?? 0} columns` : 'This project has no board file yet'}</div>` +
      '<div class="keys"><kbd>E</kbd> open the board</div>'
    ui.target.style.display = 'block'
    return
  }
  if (target?.kind === 'monitor' && !isChatting) {
    ui.target.innerHTML =
      '<div class="name">Your desk</div>' +
      `<div class="meta">Your monitor: ${myStream === null ? 'idle' : 'showing a shared window'}</div>` +
      '<div class="keys"><kbd>E</kbd> sit down; share a window to your monitor</div>'
    ui.target.style.display = 'block'
    return
  }
  if (target?.kind === 'arcade' && !isChatting) {
    const t = arcadeTables.get(target.game)
    const g = state?.arcade?.[target.game]
    const holder = g ? seatText(g.seats[target.side]) : 'empty'
    ui.target.innerHTML =
      `<div class="name">${esc(t?.title || target.game)} · ${esc(g?.sides?.[target.side] ?? target.side)} seat</div>` +
      `<div class="meta">This seat: ${holder}${g ? ` · ${esc(g.status)}` : ''}</div>` +
      '<div class="keys"><kbd>E</kbd> sit down and play, or seat an agent here</div>'
    ui.target.style.display = 'block'
    return
  }
  const w = target?.worker
  if (!w || isChatting) {
    ui.target.style.display = 'none'
    return
  }
  const color = hex(LIGHT[w.light] ?? LIGHT.off)
  const seated = player.seatedAt === target.number
  ui.target.innerHTML =
    `<div class="name">${esc(w.name)}</div>` +
    `<div class="meta">Desk ${target.number} · ${esc(w.kindLabel)} · <span style="color:${color}">${esc(w.stateLabel)}</span></div>` +
    `<div class="meta">${esc(w.evidence)}</div>` +
    (w.hand ? `<div class="hand">✋ ${w.hand.kind === 'question' ? 'Question' : 'Approval'}: ${esc(w.hand.text)}<br><span style="color:var(--dim)">Answer it in Claude; the office never answers for you.</span></div>` : '') +
    `<div class="keys">${seated ? '<kbd>E</kbd> stand up' : '<kbd>E</kbd> sit down'} · ` +
    (w.canSend ? '<kbd>T</kbd> message' : `<span title="${esc(w.noSendReason)}">no messaging</span>`) +
    ' · <kbd>Tab</kbd> conversation</div>'
  ui.target.style.display = 'block'
}

function drawConvo() {
  const ins = state?.inspect
  const w = target?.worker
  if (!showConvo || !w) {
    ui.convo.style.display = 'none'
    return
  }
  ui.convo.style.display = 'block'
  ui.convo.querySelector('h3').textContent = w.name
  const lines = ins && ins.key === w.key ? ins.lines : null
  ui.convo.querySelector('.note').textContent = lines === null ? 'Loading its conversation…' : ins.note
  const box = ui.convo.querySelector('.lines')
  const html = (lines ?? []).map(l => `<div class="line ${l.role === 'user' ? 'user' : 'assistant'}">${esc(l.text)}</div>`).join('')
  if (box.innerHTML !== html) {
    const keep = box.scrollTop
    box.innerHTML = html
    box.scrollTop = convoPinned ? keep : box.scrollHeight
  }
}

function toggleSit() {
  if (kanbanOpen) {
    closeKanban()
    return
  }
  if (player.seatedAt !== null || player.arcadeSeat !== null || player.ownSeat || player.escapeSeat) {
    standUp()
    return
  }
  if (!target) {
    flash('Face an occupied desk, or an arcade chair, to sit down.')
    return
  }
  if (target.kind === 'arcade') {
    sitArcade(target)
    return
  }
  if (target.kind === 'monitor') {
    sitOwn()
    return
  }
  if (target.kind === 'kanban') {
    openKanban()
    return
  }
  if (target.kind === 'escape') {
    sitEscape()
    return
  }
  player.seatedAt = target.number
  player.pos.copy(target.seat)
  player.vel.set(0, 0, 0)
  player.yaw = Math.PI
  player.pitch = -0.08
  showConvo = true
  drawTarget()
  drawConvo()
  // Sitting down is talking: the message box opens at once, with the conversation beside it.
  openChat({ seated: true })
}

function standUp() {
  if (player.arcadeSeat !== null) {
    standUpArcade()
    return
  }
  if (player.ownSeat) {
    standUpOwn()
    return
  }
  if (player.escapeSeat) {
    standUpEscape()
    return
  }
  if (player.seatedAt === null) return
  const d = deskObjects.get(player.seatedAt)
  player.seatedAt = null
  if (d) player.pos.copy(d.stand)
  if (isChatting) closeChat()
  drawTarget()
}

let walkTo = null

function flash(text, isError = false) {
  ui.notice.textContent = text
  ui.notice.className = `hud${isError ? ' err' : ''}`
  ui.notice.style.display = 'block'
  noticeShownAt = performance.now()
}

// ─── Messaging ─────────────────────────────────────────────────────────────
let chatKey = null
/**
 * Opens the message box and hands the keyboard and mouse to it: no avatar
 * control until it closes. Seated, it opens even at a desk that takes no
 * messages (the box then says why, read-only); standing (the T key), such a
 * desk only gets the reason as a notice.
 */
function openChat({ seated = false } = {}) {
  const w = target?.worker
  if (!w) {
    flash('Face a worker to message it.')
    return
  }
  if (!w.canSend && !seated) {
    flash(w.noSendReason ?? 'The office offers no messaging for this worker.', true)
    return
  }
  chatKey = w.key
  isChatting = true
  keys.clear()
  document.exitPointerLock()
  ui.chatText.readOnly = !w.canSend
  ui.chatText.placeholder = w.canSend
    ? w.kind === 'main'
      ? 'Type an instruction for this conversation and press Enter: it runs as your own prompt'
      : 'Type a message and press Enter to send it'
    : w.noSendReason ?? 'The office offers no messaging for this worker.'
  drawChatHeader()
  ui.chatText.value = ''
  ui.chatCount.textContent = ''
  ui.chat.style.display = 'block'
  ui.overlay.style.display = 'none'
  drawTarget()
  setTimeout(() => ui.chatText.focus(), 0)
}

/** The box's header: who you are talking to and how it is doing; redrawn as the state changes. */
function drawChatHeader() {
  const w = target?.worker
  if (!isChatting || !w) return
  const seated = player.seatedAt !== null
  const color = hex(LIGHT[w.light] ?? LIGHT.off)
  const who = w.kind === 'main' ? 'your own conversation' : esc(w.name)
  ui.chatTo.innerHTML =
    `<b>${seated ? 'Talking to' : 'To'} ${who}</b> · desk ${target.number} · <span style="color:${color}">${esc(w.stateLabel)}</span>` +
    (w.hand ? `<br><span style="color:var(--yellow)">✋ ${esc(w.hand.text)}</span> <span style="color:var(--dim)">— answer that in Claude itself</span>` : '')
  const leave = seated ? '<kbd>Esc</kbd> stands up' : '<kbd>Esc</kbd> cancels'
  ui.chatHint.innerHTML = !w.canSend
    ? `No messaging here · ${leave}`
    : w.kind === 'main'
      ? `<kbd>Enter</kbd> queues it as your prompt in this session · <kbd>Shift</kbd>+<kbd>Enter</kbd> new line · ${leave}`
      : `<kbd>Enter</kbd> sends · <kbd>Shift</kbd>+<kbd>Enter</kbd> new line · <kbd>Tab</kbd> conversation · ${leave}`
  ui.chatStand.textContent = seated ? 'Stand up' : 'Cancel'
}

function closeChat() {
  isChatting = false
  ui.chat.style.display = 'none'
  lock()
  drawTarget()
}
ui.chatStand.addEventListener('click', () => {
  if (player.seatedAt !== null) standUp()
  else closeChat()
})
// Scrolling or selecting in the conversation panel must not take the keyboard away from the message box.
ui.convo.addEventListener('mousedown', e => {
  if (isChatting && e.target.closest('.lines') === null) e.preventDefault()
})
ui.convo.addEventListener('mouseup', () => {
  if (isChatting && String(getSelection()).trim() === '') ui.chatText.focus()
})
// A conversation the person has scrolled up in stays put; one at the bottom follows new lines.
let convoPinned = false
ui.convo.querySelector('.lines').addEventListener('scroll', e => {
  const box = e.target
  convoPinned = box.scrollTop + box.clientHeight < box.scrollHeight - 24
})
ui.chatText.addEventListener('input', () => {
  ui.chatCount.textContent = `${ui.chatText.value.length}/2000`
})
ui.chatText.addEventListener('keydown', async e => {
  e.stopPropagation()
  if (e.key === 'Escape') {
    e.preventDefault()
    if (player.seatedAt !== null) standUp()
    else closeChat()
  } else if (e.key === 'Tab') {
    e.preventDefault()
    showConvo = !showConvo
    drawConvo()
  } else if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault()
    if (ui.chatText.readOnly) {
      flash(ui.chatText.placeholder, true)
      return
    }
    const text = ui.chatText.value.trim()
    if (text === '' || chatKey === null) return
    ui.chatText.value = ''
    ui.chatCount.textContent = ''
    const ok = await post({ type: 'send', key: chatKey, text })
    if (!ok) flash('The office could not take the message.', true)
    else if (target?.worker?.kind === 'main') flash('Queued as your prompt. It runs once the session is idle; the conversation panel shows it.')
    else if (player.seatedAt !== null) flash('Sent. Its reply shows in the conversation panel as it comes.')
    else flash('Handed to Claude Code to send…')
    // Seated, the box stays open for the next message; standing, one message is the whole visit.
    if (player.seatedAt === null) closeChat()
    else ui.chatText.focus()
  }
})

// ─── The loop ──────────────────────────────────────────────────────────────
const clock = new THREE.Clock()
function frame() {
  const dt = Math.min(clock.getDelta(), 0.05)
  const t = clock.elapsedTime

  if (room && player.placed) {
    const fwd = new THREE.Vector3(-Math.sin(player.yaw), 0, -Math.cos(player.yaw))
    const right = new THREE.Vector3(-fwd.z, 0, fwd.x)
    const wish = new THREE.Vector3()
    if (isLocked) {
      if (keys.has('KeyW') || keys.has('ArrowUp')) wish.add(fwd)
      if (keys.has('KeyS') || keys.has('ArrowDown')) wish.sub(fwd)
      if (keys.has('KeyD') || keys.has('ArrowRight')) wish.add(right)
      if (keys.has('KeyA') || keys.has('ArrowLeft')) wish.sub(right)
    }
    if (wish.lengthSq() > 0) {
      walkTo = null
      if (player.seatedAt !== null) standUp()
    }
    if (walkTo !== null) {
      const to = new THREE.Vector3(walkTo.stand.x - player.pos.x, 0, walkTo.stand.z - player.pos.z)
      if (to.length() < 0.12) {
        player.yaw = Math.PI
        walkTo = null
      } else {
        wish.copy(to.normalize())
        const want = Math.atan2(-wish.x, -wish.z)
        let dy = want - player.yaw
        dy = Math.atan2(Math.sin(dy), Math.cos(dy))
        player.yaw += dy * Math.min(1, dt * 8)
      }
    }
    if (player.seatedAt === null && player.arcadeSeat === null && !player.ownSeat && !player.escapeSeat) {
      const speed = keys.has('ShiftLeft') || keys.has('ShiftRight') || walkTo !== null ? RUN : WALK
      if (wish.lengthSq() > 0) wish.normalize().multiplyScalar(speed)
      const flat = new THREE.Vector3(player.vel.x, 0, player.vel.z)
      const accel = player.onGround ? ACCEL : ACCEL * 0.35
      flat.add(wish.clone().sub(flat).multiplyScalar(Math.min(1, (accel / Math.max(speed, 1)) * dt)))
      if (wish.lengthSq() === 0 && player.onGround) flat.multiplyScalar(Math.max(0, 1 - FRICTION * dt))
      player.vel.x = flat.x
      player.vel.z = flat.z
      player.vel.y -= GRAVITY * dt
      player.pos.addScaledVector(player.vel, dt)
      if (player.pos.y <= 0) {
        player.pos.y = 0
        player.vel.y = 0
        player.onGround = true
      }
      collide(player.pos)
      const moving = Math.hypot(player.vel.x, player.vel.z)
      player.bob += moving * dt * 2.4
      player.eye += (EYE - player.eye) * Math.min(1, dt * 10)
    } else {
      player.eye += (EYE_SEATED - player.eye) * Math.min(1, dt * 10)
    }
    const bobY = player.seatedAt === null && player.arcadeSeat === null && !player.ownSeat && !player.escapeSeat && player.onGround ? Math.sin(player.bob * Math.PI) * 0.035 * Math.min(1, Math.hypot(player.vel.x, player.vel.z) / WALK) : 0
    camera.position.set(player.pos.x, player.pos.y + player.eye + bobY, player.pos.z)
    camera.rotation.set(player.pitch, player.yaw, 0)
    setTarget(findTarget())
  }

  for (const d of deskObjects.values()) {
    if (d.android) animateAndroid(d.android, t)
    if (d.worker?.state === 'working') d.screenTex.offset.y = (d.screenTex.offset.y - dt * 0.12) % 1
  }
  if (ui.notice.style.display === 'block' && performance.now() - noticeShownAt > 5000) ui.notice.style.display = 'none'

  // The loop: the world is drawn again shifted by a hallway length on whichever side is near, so the seam
  // shows the far end continuing. Shadows are computed once per frame, not once per pass.
  const L = room.width * CM
  if (!DBG.has('autoshadow')) renderer.shadowMap.needsUpdate = true
  renderer.clear()
  renderer.render(scene, camera)
  if (!DBG.has('autoshadow')) renderer.shadowMap.needsUpdate = false
  const x = camera.position.x
  if (!DBG.has('nowrap')) {
    if (x < WRAP_VIEW) {
      camera.position.x = x + L
      renderer.render(scene, camera)
    }
    if (x > L - WRAP_VIEW) {
      camera.position.x = x - L
      renderer.render(scene, camera)
    }
  }
  camera.position.x = x
  requestAnimationFrame(frame)
}

// Before the first state arrives, show the empty office so the window is never blank; desks come with the workers.
ensureArcadeRoom()
ensurePersonalRoom()
ensureEscapeRoom()
buildWorld()
spawnPlayer()
player.placed = false
camera.position.set(2, EYE, 1.4)
camera.rotation.set(-0.05, -Math.PI / 2, 0)
connect()
requestAnimationFrame(frame)
