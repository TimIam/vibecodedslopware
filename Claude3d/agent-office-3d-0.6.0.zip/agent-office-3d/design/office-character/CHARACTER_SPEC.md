# Office android: canonical character (v0.1, design)

Status: **design reference; look and feel approved by Tim**, 2026-10-17. The approval was relayed by the Social Museum
coordinator session at Tim's request and covers design scope only. Nothing here is loaded by the mod, shipped or verified
in the native UI.
The numbers live in [`character.json`](character.json); this page explains them. The sheets and renders are drawn from that
file, so they cannot drift from it.

**Scope.** This character is for **Agent Office workers only**: this conversation's main loop, its subagents and
teammates, and enrolled peer sessions. **Museum gallery avatars stay human** and are being corrected separately. Nothing
here changes Museum code or the live gallery.

## At a glance

- A white android mannequin with a slender, rounded **cylindrical head**. The head has no eyes, mouth, hair or skin tone,
  and the figure has no clothing or gender cues.
- The **face panel is the status light**. It is a dark-bezelled rounded rectangle wrapped around the front of the
  cylinder, filled with the status color, and it carries a glyph in dark ink.
- A thin **status ring** round the base of the head repeats the color, so the state reads from behind and from above.
- **Ball joints** at the neck, shoulders, elbows, wrists, hips, knees and ankles read as "mannequin".
- **Role accent: shoulder joints only.** This conversation is graphite, a subagent or teammate is violet, and an
  enrolled peer is steel blue. The accents never use a status color.
- **Posture is a status cue** too: typing, a raised hand, leaning back, slumped, hands folded, or resting.

## Proportions and geometry (cm; the character faces −y, z is up)

| Part | Canonical value |
| --- | --- |
| Standing height | 180 = 7.2 head-heights (H = 25) |
| Head | Rounded cylinder Ø 15 × 25 with edge radius 4. Width to height is 0.6, which makes it slender. |
| Face panel | Wraps ±60° of the cylinder, from 6 to 20.5 above the head's base (14.5 tall). Corner radius 2.2, dark bezel 0.7. |
| Status ring | 3.8 above the head's base, 1.4 wide, all the way round |
| Neck | Ø 4.8 capsule, joint grey |
| Shoulders | Ball joints r 4.8 at ±17.5, in the role accent |
| Torso | Hull of spheres: two chest spheres r 7.5, two mid-chest spheres r 9, one waist sphere r 8. A pelvis hull sits below. |
| Limbs | Tapered capsules. Upper arm r 3.4→3.0, forearm 2.9→2.4, mitt hand 2.6→2.2, thigh 5.6→4.2, shin 4.0→2.9, foot 3.2→2.6. |
| Joints | Elbow 3.4, wrist 2.5, hip 5.0, knee 4.6, ankle 3.0: slightly larger than the limb ends, so each shows as a ring |

The poses (`stand`, `seat_rest`, `seat_type`, `seat_hand_up`, `seat_lean_back`, `seat_slump`, `seat_folded`) are joint
positions in `character.json`, with the head's own turn as `[yaw, nod, roll]`.

## Materials and palette

| Token | Value | Use |
| --- | --- | --- |
| shell hi / mid / lo / line | `#FFFFFF` / `#EEF1F4` / `#C3CBD4` / `#7D8896` | White plastic shell, its shading, and a thin outline so it holds on light floors |
| joint hi / lo / line | `#E2E6EB` / `#9AA4B0` / `#6E7987` | Ball joints and the neck |
| bezel | `#262D36` | Panel bezel; also separates the panel from the white shell |
| panelOff | `#1B222B` | Panel when the state is unknown or disconnected |
| ink / inkOnOff | `#0B1016` / `#A7B0BA` | Panel glyph on a lit panel / on an off panel |
| lights green / yellow / red / off | `#3FB950` / `#D29922` / `#F85149` / `#6E7681` | Same values as the current office's `LIGHT` table |
| role main / subagent / peer | `#3B4250` / `#8A7FB5` / `#5B7FA8` | Shoulder joints only |
| selection | `#D97757` | Floor ring under the selected desk; never a status |

Furniture and room colors for the dark and light themes are under `rooms` in `character.json`. The desks are mid-tone so
the white figures stand out.

## Status: face panel, ring, posture, words

The **evidence** for each state is unchanged and stays as `docs/OFFICE.md` defines it. This design only gives each state
its look.

| State (label) | Light | Panel glyph | Icon in text | Posture | Hand and badge |
| --- | --- | --- | --- | --- | --- |
| Working | green | gear | ⚙ | typing | none |
| Needs you: question | red | hand | ✋ | raised hand | `?` + "question" |
| Needs you: approval | red | hand | ✋ | raised hand | shield + "approval" |
| Waiting on `<tool>` | yellow | hourglass | ⏳ | leaning back | none |
| Failed | red, **hatched panel** | ✕ | ✕ | slumped, head down | none |
| Completed (also "· not listed" for a kept desk) | green | ✓ | ✓ | hands folded | none |
| Idle | yellow | ring of dots | ◌ | resting | none |
| Unknown / Held (reason not exposed) | off (dark panel) | ? | ? | resting | none |
| Disconnected (a peer that stopped refreshing) | off | ? | ? | resting, whole figure at 42 % opacity | none |

A hand goes up **only** for a real pending question or approval. That rule is unchanged, and the badge says which one,
in words.

## Accessibility

- **Four cues per state:** posture, panel glyph, written label and color. Rows 4 and 5 of the state sheet show the meaning
  survives in grayscale. That row is recolored by luminance, not filtered, so any renderer shows it the same way.
- **Red is shared** by "Needs you" and "Failed". They differ in glyph (hand vs ✕), posture (arm up vs slumped), panel
  texture (Failed is hatched), the badge and the words.
- **Contrast**, computed by `tools/gen_sheets.py` into `sheets/report.json`:

  | Pair | Green | Yellow | Red | Off |
  | --- | --- | --- | --- | --- |
  | Glyph on panel | 7.5 : 1 | 7.6 : 1 | 5.7 : 1 | 7.3 : 1 |
  | Panel on bezel | 5.5 : 1 | 5.5 : 1 | 4.2 : 1 | 1.2 : 1 (the off panel is meant to look dark; its glyph carries it) |
  | Bezel on white shell | 12.3 : 1 | | | |
  | Status chip on white plate | 2.5 : 1 | 2.5 : 1 | 3.4 : 1 | 4.6 : 1 |

  The green and yellow chips fall below 3 : 1 on a white plate, so every chip carries a 1.2 px dark outline. The glyph and
  the words carry the meaning.
- **Motion is never needed.** Every state is complete when static. Any optional animation needs `isInteractive`, which
  allows SMIL in a sandboxed frame but is unverified natively. It must stay at or below 1 Hz with no flashing, and it is
  never the only cue.
- **Text everywhere.** The `alt` text on the picture, the numbered worker buttons and the inspector repeat every state in
  words, as today.

## Sizes and level of detail

| Where | Size | What carries the state |
| --- | --- | --- |
| Inspector portrait (its own small `Svg`) | head about 80 px | Full panel glyph, ring, posture, words beside it |
| Office picture at 960 px wide | head about 15 px | Panel color, ring, posture and the desk tag; the glyph is not readable |
| Picture in a narrow pane (0.6×) | head about 9 px | Panel color and the desk tag; the buttons carry the words |

So the lean native form leaves the glyph off the desk-scale faces and draws it only in the inspector portrait (see
`NATIVE_DESIGN_PLAN.md`).

## Rules

- Office workers are androids. They stay **hairless and white**, with the status-face colors, and never get human faces,
  hair or skin. Museum avatars stay human; their hair and skin choices never apply to Office androids, and this file never
  applies to Museum avatars.
- One figure per actual identity, as the office already requires. No decorative or simulated workers. Every mockup is
  marked as sample data with illustrative states.
- No approve, deny or answer controls are drawn on the character or the desk. The inspector points to Claude's own
  question dialog and Claude Code's own permission prompt.
- Nothing in the art implies a message was sent, delivered or read. The send route stays held
  (`docs/SEND_ROUTE_REVIEW.md`). The denied A2 send is shown nowhere as anything else.

## For the Codex client design (coordination by reference)

The "Agent Office project planning" session reuses this direction for the Codex client. To keep **one** character and
avoid competing assets:

- **Reuse as-is:** `character.json` (proportions, poses, palette tokens, the state → light/glyph/icon/posture table, and
  the glyph strokes) and the rules above.
- **Free to adapt:** the rendering technique, lighting, resolution, the room around the figures and the client layout.
- **Change by editing this source:** a new state, color, glyph or proportion is made in `character.json` here, with the
  `version` bumped. Then both clients pick it up. Do not fork the figure or keep a second palette.
- **References:** `design/office-character/character.json`, this file, `sheets/*.svg` (vector, regenerable) and
  `renders/blender-*.png` (3D look reference). No runtime sends or task messages are part of this coordination.
