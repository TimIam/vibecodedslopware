# Design-reference handoff: Office android → Agent Office (Codex client)

Answers `/Users/tim/Documents/Codex/2026-10-16/task-6/agent-office/design/ANDROID-REFERENCE-REQUEST.md` (read
2026-10-17, together with its `status-tokens.json` 0.1.0-d1). This page hands over a **reference**: there is one canonical
character, described below. It is not a runtime integration and not a second character. Its look and feel were approved by Tim on 2026-10-17 (relayed; see section 1). Tim
relays the paths; no message was sent between sessions.

All paths are under `/Users/tim/Documents/Codex/2026-10-16/task-4/claude-session-museum/design/office-character/`.

## 1. Version and approval status

- **Reference version:** `office-android 0.1.0-design` (the `version` field in `character.json`).
- **Approval: the look and feel is approved by Tim** (2026-10-17). The approval was relayed to this session by the
  Social Museum coordinator session at Tim's request; this session did not receive it from Tim directly.
  - The approval covers design scope only. Office androids stay hairless and white and use the status-face colors.
    Museum human hair and skin choices never apply to them.
  - It grants no runtime, privilege, account, production, backend, security or deployment scope.
  - `character.json → approval` records it.
- **Still open:** questions Q2 to Q9 below. No model file exists yet (Q7), so Office's placement `PROXY` stays a proxy
  until a model is delivered.

| Preview | Path |
| --- | --- |
| Front | `renders/views/office-android-v0.1.0-front.png` |
| Three-quarter (camera 45° to the character's right) | `renders/views/office-android-v0.1.0-three-quarter.png` |
| Profile (the character's right side) | `renders/views/office-android-v0.1.0-profile-right.png` |
| Back | `renders/views/office-android-v0.1.0-back.png` |
| Five-view turnaround | `renders/blender-turnaround.png` |
| State lineup (9 face-panel states) | `renders/blender-states.png` |
| Vector sheets: turnaround with head detail, states, legibility, rooms, pane | `sheets/*.svg`, previews in `renders/preview/*.png` |

The four single views are 1000 × 1400 transparent PNGs at **one shared orthographic scale**: 206 cm of height fills
1400 px, with z = 91 cm at the image centre. They overlay exactly. All show the standing pose with the Working panel.

## 2. Format

- **Delivered:** the parametric source `character.json`, the explanation `CHARACTER_SPEC.md`, and two reproducible
  builders: `tools/gen_sheets.py` (stdlib Python, SVG) and `tools/blender_turnaround.py` (Blender 5.2.2, headless).
- **Not delivered:** a `.glb`. The Blender build is a reference renderer made of convex hulls and fine panel grids, not a
  ≤15k-triangle game asset. A `.glb` export from the same numbers is open question Q7 below. Until then, Office's
  placement proxy stays a proxy.
- **Axis conversion** from canonical (cm; x = character's left, −y = front, z = up) to glTF (m, Y-up, the asset faces +Z):
  `X = x / 100`, `Y = z / 100`, `Z = −y / 100`. This is a proper rotation, so handedness is preserved.

## 3. Material slots (proposed for an eventual export)

| Slot | Canonical value | Who drives it |
| --- | --- | --- |
| `Body` | white shell `#F2F4F7` (sheets shade it `#FFFFFF` → `#EEF1F4` → `#C3CBD4`) | fixed; Office never recolors it |
| `Joint` | grey `#AEB7C2` (sheets `#E2E6EB` → `#9AA4B0`); neck, elbows, wrists, hips, knees, ankles | fixed |
| `RoleAccent` | shoulder joints only: main `#3B4250`, subagent `#8A7FB5`, peer `#5B7FA8` | fixed per role; never a status color |
| `Bezel` | `#262D36`, a 0.7 cm rim round the panel | fixed |
| `FacePanel` | emissive status field; UVs span 0–1 over the panel's rounded-rectangle bounds | runtime: color, glyph, Failed hatch |
| `StatusRing` | emissive ring round the base of the head, the same color as `FacePanel` | runtime, same value as the panel |

The canonical panel construction is a **lit color field with a dark-ink glyph** (`ink #0B1016`) inside a dark bezel. When
the panel is off, it is dark glass `#1B222B` with a light glyph `#A7B0BA`.

## 4. Face-panel geometry (head-local, glTF metres, origin at the head centre)

- **Head:** a rounded cylinder about Y. Radius 0.075, height 0.25 (Y from −0.125 to +0.125), edge radius 0.04.
- **Panel:** on the cylinder surface (r = 0.075), azimuth ±60° about +Z (front). Y from −0.065 to +0.080 (14.5 cm tall),
  corner radius 0.022, bezel 0.007. Arc width 0.157 m.
- **Panel UV:** `U = (azimuth + 60°) / 120°` (U = 0.5 at the front). `V = (Y + 0.065) / 0.145`.
- **Glyph area:** canonical glyph strokes in `character.json → glyphs` use (u, v) ∈ [−1, 1]. On the panel:
  `U = 0.5 + 0.275 u` and `V = 0.5 + 0.31 v`. Stroke width is 1.15 cm, which is about 0.073 in U and 0.079 in V. Dot
  radius is 0.9 cm.
- **Status ring:** at Y = −0.087 (3.8 cm above the head's base), 0.014 wide, all the way round.

## 5. Proportions and root

| Measure | Canonical |
| --- | --- |
| Root | Floor contact at the origin, under the pelvis; the character faces +Z (glTF) |
| Standing height / head centre | 1.80 m / 1.675 m |
| **Seated head centre** (`seat_rest`, `seat_type`) | **1.215 m**, against Office's ≈1.25 m assumption (see Q9) |
| Seat top / hip joints | 0.47 m / 0.50 m |
| Desk (canonical scenes) | Top 0.74 m, 0.90 wide × 0.60 deep. Spans 0.22–0.82 m in front of the root (+Z). |
| Keyboard / monitor | Keyboard 0.36–0.46 m in front. A low monitor sits at the character's left front corner, turned toward it and kept below face height. |

## 6. Rig

There is no rig. Poses are joint positions in `character.json → poses`: `stand`, `seat_rest` (idle), `seat_type`
(typing), `seat_hand_up` (question or approval), `seat_lean_back` (waiting), `seat_slump` (failed) and `seat_folded`
(completed). Each pose also gives the head turn `[yaw, nod, roll]`.

The canonical poses span nod −12° (up) to +22° (down) and roll up to 8°. A look-at limit of yaw ±30° is a proposal, not
canonical. A static seated pose (`seat_rest`) is the canonical fallback.

## 7. License and provenance

- **Provenance:** original work, made in Tim's private repository `TimIam/claude-session-museum` by a Claude Code session
  at Tim's direction. Every shape is generated from `character.json` by the two builders above. There are no
  third-party models, textures or images. The render labels use Blender's bundled font, and those labels are not part of
  the character.
- **License, local use, distribution and attribution:** **not chosen.** These are Tim's decisions, and nothing here grants
  them.

## Answers to the request's questions

- **Glyph language: yes.** `character.json → glyphs` holds `gear`, `hand`, `hourglass`, `cross`, `check`, `dots`,
  `question` and `shield`. Each is a set of strokes or dots. Office should adopt them where a meaning matches (table
  below).
- **Status colors: yes, four lights.** Green `#3FB950`, yellow `#D29922` and red `#F85149`, plus off: panel `#1B222B`,
  chip `#6E7681`. Failed adds a dark-red hatch. Measured contrast:
  - glyph on lit panel: 5.7 to 7.6 : 1
  - lit panel on bezel: 4.2 to 5.5 : 1
  - off panel glyph: 7.3 : 1

  Every state differs without color, through glyph, posture, label and the Failed hatch. A grayscale proof is in
  `sheets/state-sheet.svg`, rows 4 and 5.
- **Expression: none.** No eyes or mouth. The panel shows color and one glyph, plus the hatch for Failed. Idle is the
  ring of dots.

### How Office's uiStates map onto the canonical set

This is a reference for reconciliation, not a decision made for Office. A **gap** means the canonical set has no
equivalent; filling it is the owner's job, through `character.json` and a version bump, after Tim decides.

| Office uiState (token now) | Canonical light · glyph · posture | Fit |
| --- | --- | --- |
| working (busy, blue) | green · gear · typing | match |
| needsApproval (approval, amber) | red · hand · raised hand + shield "approval" badge | match in meaning; color differs (Q3) |
| failed, systemError (failed) | red, hatched · cross · slumped | match |
| done (done) | green · check · hands folded | match |
| ready (ready) | yellow · dots · resting (Idle) | match |
| outcomeUnknown (unknown, pink) | off · question · resting | match in meaning; color differs (Q2) |
| offline (offline) | off · question · whole figure at 42 % (Disconnected) | match in meaning; Office's dash glyph is not canonical |
| stopped (stopped) | native office shows Stopped in the Failed family (red · cross) | open (Q5) |
| sending, stopping (busy) | none | gap (Q4) |
| connecting, signInNeeded, signingIn, sandboxSetup (setup) | none (key and setup glyphs are not canonical) | gap (Q4) |

Office's rules (label text on a neutral, never on the status field; a steady equivalent under reduced motion; a 3 : 1
minimum for non-text) are compatible with the canonical character. The canonical motion ceiling is lower; see Q6.

## Native limits of the canonical character (Claude Code 2.1.299 in Desktop)

These limits bind the **native mod's** drawing of this character, not the Codex client. They are listed so Office does
not assume anything about the native picture. Details are in `NATIVE_DESIGN_PLAN.md`.

- **Vector only.** The desktop pane has no image element, and each `Svg` holds at most 131,072 characters. The
  sheet-quality art is over budget (229,934 for 11 workers). The lean form is under it: 84,714 for 15 desks. Neither has
  been painted natively yet.
- At desk scale the native picture shows panel color, ring, posture and a text tag. The glyph is readable only in the
  inspector portrait.
- The picture cannot be clicked; selection uses native buttons. Motion, hover and tooltips need `isInteractive`
  (unverified). The theme signal is unverified.
- The approval hand depends on `classic.PermissionRequest` and is unverified natively.
- **Sends stay held.** The native direct send to A2 was denied by auto mode's classifier and **stays denied**. It is not
  retried, rerouted, prefilled or bypassed, and no runtime send, enrollment or grant is part of this handoff.

## Open design questions (for Tim)

- **Q1 Style acceptance:** resolved on 2026-10-17. Tim approved the white android look and feel (relayed). Details such
  as the torso's taper, the gear for Working and the 0.6 head ratio stay adjustable through `character.json`.
- **Q2 Palette:** keep the four canonical lights on the face panel, which is the recommended path to one character, or
  extend the canonical palette with Office hues through `character.json`.
- **Q3 Approval color:** canonical red, or Office's amber.
- **Q4 Codex-only states** (setup, sign-in, sending, stopping): add canonical glyphs such as key, arrow-up and square, or
  fold them into the Unknown and Working families with labels.
- **Q5 Stopped by the user:** the Failed family, as the native office does today, or a calmer canonical token.
- **Q6 Motion ceiling:** canonical ≤ 1 Hz and never the only cue, against Office's `maxPatternHz` 2.
- **Q7 Delivery format:** whether a `.glb` export (Y-up, metres, ≤ 15k triangles, the slots above) should be made from
  `character.json`, by whom and when, plus its license.
- **Q8 Role accent** for a single Office agent: graphite (main) as a constant, or none.
- **Q9 Seated head height:** Office adopts the canonical 1.215 m, or the canonical seat pose is raised to ≈1.25 m.
