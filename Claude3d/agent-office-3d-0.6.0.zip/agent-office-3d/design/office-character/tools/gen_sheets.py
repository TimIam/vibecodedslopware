#!/usr/bin/env python3
"""Design sheets for the Office android mannequin, drawn from one canonical geometry.

Reads ../character.json and writes SVG sheets to ../sheets/. Python standard
library only. This is a design reference: the mod does not load any of it, and
every sheet is marked as a mockup with sample data.

Every view is an orthographic projection of the same solids (spheres, tapered
capsules, hulls of spheres and a rounded-cylinder head), so the turnaround, the
state sheet and the office mockups cannot drift apart.
"""
import json
import math
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SHEETS = os.path.join(ROOT, 'sheets')
with open(os.path.join(ROOT, 'character.json'), encoding='utf-8') as f:
    C = json.load(f)

GEO = C['geometry']
RAD = GEO['radii']
PAL = C['palette']
LIGHTS = PAL['lights']
STATES = {s['id']: s for s in C['states']}
STATE_ORDER = [s['id'] for s in C['states']]
FONT = "-apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif"
DESK_TOP = 74.0
PREC = [1]  # decimals in emitted coordinates; the budget pass lowers it
UID = [0]
MARK = 'DESIGN MOCKUP · sample workers · illustrative states, not observed'


# ---------------------------------------------------------------- numbers
def add(a, b): return (a[0] + b[0], a[1] + b[1], a[2] + b[2])
def sub(a, b): return (a[0] - b[0], a[1] - b[1], a[2] - b[2])
def dot(a, b): return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
def cross(a, b): return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def rot_z(p, deg):
    a = math.radians(deg)
    c, s = math.cos(a), math.sin(a)
    return (p[0] * c - p[1] * s, p[0] * s + p[1] * c, p[2])


def rot_x(p, deg):
    a = math.radians(deg)
    c, s = math.cos(a), math.sin(a)
    return (p[0], p[1] * c - p[2] * s, p[1] * s + p[2] * c)


def rot_y(p, deg):
    a = math.radians(deg)
    c, s = math.cos(a), math.sin(a)
    return (p[0] * c + p[2] * s, p[1], -p[0] * s + p[2] * c)


def fmt(v):
    s = f'{v:.{PREC[0]}f}'
    if '.' in s:
        s = s.rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s


def uid(prefix):
    UID[0] += 1
    return f'{prefix}{UID[0]}'


def esc(s):
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


def path(pts, closed=True):
    if not pts:
        return ''
    d = 'M' + ' '.join(f'{fmt(x)},{fmt(y)}' for x, y in pts)
    return d + ('Z' if closed else '')


def hull(points):
    pts = sorted(set((round(x, 3), round(y, 3)) for x, y in points))
    if len(pts) < 3:
        return pts

    def half(seq):
        out = []
        for p in seq:
            while len(out) >= 2 and (out[-1][0] - out[-2][0]) * (p[1] - out[-2][1]) - (out[-1][1] - out[-2][1]) * (p[0] - out[-2][0]) <= 0:
                out.pop()
            out.append(p)
        return out

    lower = half(pts)
    upper = half(list(reversed(pts)))
    return lower[:-1] + upper[:-1]


def circles_hull(circles, k):
    pts = []
    for cx, cy, r in circles:
        for i in range(k):
            t = 2 * math.pi * i / k
            pts.append((cx + r * math.cos(t), cy + r * math.sin(t)))
    return hull(pts)


def text(x, y, s, size=12, fill='#1B1D22', weight=400, anchor='start', extra=''):
    return (f'<text x="{fmt(x)}" y="{fmt(y)}" font-size="{size}" font-weight="{"bold" if weight >= 600 else "normal"}" fill="{fill}" '
            f'text-anchor="{anchor}" {extra}>{esc(s)}</text>')


def mono(svg):
    """The same drawing in gray: every color replaced by its luminance (no filter needed)."""
    def gray(m):
        v = round(255 * luminance(m.group(0)) ** (1 / 2.2))
        return f'#{v:02X}{v:02X}{v:02X}'
    return re.sub(r'#[0-9A-Fa-f]{6}\b', gray, svg)


def luminance(hex_color):
    def lin(c):
        c /= 255
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    h = hex_color.lstrip('#')
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)


def contrast(a, b):
    la, lb = sorted((luminance(a), luminance(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


# ---------------------------------------------------------------- camera and scene
class Cam:
    """Orthographic camera. yaw 0 looks at the character's front (it faces -y)."""

    def __init__(self, yaw, elev, scale=1.0, ox=0.0, oy=0.0):
        y, e = math.radians(yaw), math.radians(elev)
        self.yaw, self.elev = yaw, elev
        self.f = (math.sin(y) * math.cos(e), math.cos(y) * math.cos(e), -math.sin(e))
        self.r = (math.cos(y), -math.sin(y), 0.0)
        self.u = cross(self.r, self.f)
        self.s, self.ox, self.oy = scale, ox, oy

    def p(self, q):
        return (self.ox + self.s * dot(q, self.r), self.oy - self.s * dot(q, self.u))

    def depth(self, q):
        return dot(q, self.f)

    def fitted(self, points, rect):
        """The same view, scaled and moved so `points` fill `rect` (x, y, w, h)."""
        raw = [(dot(q, self.r), -dot(q, self.u)) for q in points]
        x0, x1 = min(p[0] for p in raw), max(p[0] for p in raw)
        y0, y1 = min(p[1] for p in raw), max(p[1] for p in raw)
        rx, ry, rw, rh = rect
        s = min(rw / max(x1 - x0, 1e-6), rh / max(y1 - y0, 1e-6))
        return Cam(self.yaw, self.elev, s, rx + (rw - (x1 - x0) * s) / 2 - x0 * s, ry + (rh - (y1 - y0) * s) / 2 - y0 * s)


class Scene:
    def __init__(self, cam):
        self.cam = cam
        self.items = []
        self.ui = []

    def put(self, layer, depth, svg):
        self.items.append((layer, -depth, len(self.items), svg))

    def svg(self):
        return ''.join(t[3] for t in sorted(self.items, key=lambda t: (t[0], t[1], t[2])))


def centered(yaw, elev, scale, point, x, y):
    """A camera that draws `point` at (x, y)."""
    cam = Cam(yaw, elev, scale)
    px, py = cam.p(point)
    cam.ox, cam.oy = x - px, y - py
    return cam


# ---------------------------------------------------------------- the character
def pose(name):
    p = dict(C['poses'][name])
    if 'base' in p:
        b = pose(p.pop('base'))
        b.update(p)
        p = b
    return p


def body_parts(P):
    J = lambda n: tuple(P[n])
    parts = []
    for s in 'lr':
        parts += [
            ('shell', [(J('heel_' + s), RAD['foot'][0]), (J('toe_' + s), RAD['foot'][1])]),
            ('joint', [(J('ankle_' + s), RAD['ankle'])]),
            ('shell', [(J('knee_' + s), RAD['shin'][0]), (J('ankle_' + s), RAD['shin'][1])]),
            ('joint', [(J('knee_' + s), RAD['knee'])]),
            ('shell', [(J('hip_' + s), RAD['thigh'][0]), (J('knee_' + s), RAD['thigh'][1])]),
            ('joint', [(J('hip_' + s), RAD['hipJoint'])]),
            ('role', [(J('shoulder_' + s), RAD['shoulderJoint'])]),
            ('shell', [(J('shoulder_' + s), RAD['upperArm'][0]), (J('elbow_' + s), RAD['upperArm'][1])]),
            ('joint', [(J('elbow_' + s), RAD['elbow'])]),
            ('shell', [(J('elbow_' + s), RAD['forearm'][0]), (J('wrist_' + s), RAD['forearm'][1])]),
            ('joint', [(J('wrist_' + s), RAD['wrist'])]),
            ('shell', [(J('wrist_' + s), RAD['hand'][0]), (J('hand_' + s), RAD['hand'][1])]),
        ]
    pel = J('pelvis')
    parts.append(('shell', [(add(pel, (6.5, 0, -1)), RAD['pelvis'][0]), (add(pel, (-6.5, 0, -1)), RAD['pelvis'][0]),
                            (add(pel, (0, 0, 5)), RAD['pelvis'][1])]))
    top = tuple((a + b) / 2 for a, b in zip(J('chest_l'), J('chest_r')))
    mid = tuple(t + (w - t) * 0.4 for t, w in zip(top, J('waist')))
    parts.append(('shell', [(J('chest_l'), RAD['chest']), (J('chest_r'), RAD['chest']), (add(mid, (5, 0.5, 0)), RAD['chestMid']),
                            (add(mid, (-5, 0.5, 0)), RAD['chestMid']), (J('waist'), RAD['waist'])]))
    parts.append(('joint', [(J('neck_base'), RAD['neck']), (J('neck_top'), RAD['neck'])]))
    return parts


BUST = {'role', 'chest', 'neck'}


def light_of(st):
    return LIGHTS[st['light']]


def mannequin(sc, at=(0, 0, 0), yaw=0.0, pose_name='stand', state_id='working', role='main', lw=1.0, k=24,
              clip_below=None, glow=True, bust=False, head_only=False):
    """Put one character into the scene; returns the world position of its left hand tip."""
    P = pose(pose_name)
    st = STATES[state_id]
    ghost = st.get('ghost', False)

    def W(p):
        return add(rot_z(p, yaw), at)

    cam = sc.cam
    for mat, sph in body_parts(P):
        ws = [(W(c), r) for c, r in sph]
        zlow = min(c[2] for c, _ in ws) - at[2]
        if head_only:
            continue
        if bust and zlow < P['waist'][2] - 4:
            continue
        depth = sum(cam.depth(c) for c, _ in ws) / len(ws)
        zmin = min(c[2] - r for c, r in ws)
        fill = {'shell': 'url(#shell)', 'joint': 'url(#joint)', 'role': PAL['role'][role]}[mat]
        line = PAL['shell']['line'] if mat == 'shell' else PAL['joint']['line']
        d = path(circles_hull([(*cam.p(c), r * cam.s) for c, r in ws], k))
        svg = f'<path d="{d}" fill="{fill}" stroke="{line}" stroke-width="{fmt(lw)}" stroke-linejoin="round"/>'
        if clip_below and zmin < DESK_TOP - 0.3:
            svg = f'<g clip-path="url(#{clip_below})">{svg}</g>'
        if ghost:
            svg = f'<g opacity=".42">{svg}</g>'
        sc.put(4, depth + {'shell': 0, 'joint': 1.5, 'role': -1.0}[mat], svg)
    turn = P['headTurn']
    head(sc, W(tuple(P['head'])), yaw + turn[0], turn[1], turn[2], st, lw, k, glow)
    return W(tuple(P['hand_l']))


def frange(a, b, step):
    n = int(round((b - a) / step))
    return [a + (b - a) * i / n for i in range(n + 1)]


def densify(pts, step):
    out = [pts[0]]
    for a, b in zip(pts, pts[1:]):
        n = max(1, int(math.dist(a, b) / step))
        out += [(a[0] + (b[0] - a[0]) * i / n, a[1] + (b[1] - a[1]) * i / n) for i in range(1, n + 1)]
    return out


def head(sc, center, yaw, nod, roll, st, lw, k, glow):
    cam = sc.cam
    hg = GEO['head']
    Rh, H, e = hg['radius'], hg['height'], hg['edgeRound']

    def N(n):
        return rot_z(rot_x(rot_y(n, roll), nod), yaw)

    def T(p):
        return add(N(p), center)

    def cyl(phi, z, rad=Rh):
        a = math.radians(phi)
        return (rad * math.sin(a), -rad * math.cos(a), z)

    def facing(phi, lim=-0.06):
        a = math.radians(phi)
        return dot(N((math.sin(a), -math.cos(a), 0)), cam.f) < lim

    samples = []
    for i in range(7):
        t = math.pi / 2 * i / 6
        rr = Rh - e + e * math.sin(t)
        for zz in (-H / 2 + e - e * math.cos(t), H / 2 - e + e * math.cos(t)):
            for j in range(k):
                a = 2 * math.pi * j / k
                samples.append(T((rr * math.sin(a), -rr * math.cos(a), zz)))
    outline = path(hull([cam.p(q) for q in samples]))
    is_off = st['light'] == 'off'
    color = light_of(st)
    ghost = st.get('ghost', False)
    s = cam.s
    cid = uid('hc')
    out = [f'<clipPath id="{cid}"><path d="{outline}"/></clipPath>',
           f'<path d="{outline}" fill="url(#headgrad)" stroke="{PAL["shell"]["line"]}" stroke-width="{fmt(lw)}"/>',
           f'<g clip-path="url(#{cid})">']

    # Status ring round the base of the head: the state reads from behind too.
    ring = GEO['statusRing']
    zr = -H / 2 + ring['zFromHeadBottom']
    d = e - ring['zFromHeadBottom']
    rr = Rh - e + math.sqrt(max(e * e - d * d, 0)) if d > 0 else Rh
    phis = frange(0, 360, 5)
    vis = [facing(p, 0.0) for p in phis]
    if any(vis) and not all(vis):
        start = vis.index(False)
        phis = phis[start:] + phis[1:start + 1]
        vis = vis[start:] + vis[1:start + 1]
    runs, cur = [], []
    for p, v in zip(phis, vis):
        if v:
            cur.append(cam.p(T(cyl(p, zr, rr + 0.05))))
        elif cur:
            runs.append(cur)
            cur = []
    if cur:
        runs.append(cur)
    ring_color = '#4A525C' if is_off else color
    for r_ in runs:
        if len(r_) > 1:
            out.append(f'<path d="{path(r_, False)}" fill="none" stroke="{ring_color}" stroke-width="{fmt(ring["width"] * s)}" stroke-linecap="round"/>')

    # Face panel: a rounded rectangle wrapped on the cylinder.
    fp = GEO['facePanel']
    half = fp['halfAngleDeg']
    zb, zt = -H / 2 + fp['zFromHeadBottom'][0], -H / 2 + fp['zFromHeadBottom'][1]
    c = fp['cornerRadius']
    cdeg = math.degrees(c / Rh)
    visible = [p for p in frange(-half, half, 1.5) if facing(p)]
    if visible:
        lo, hi = max(min(visible), -half + cdeg), min(max(visible), half - cdeg)
        if hi - lo > 2:
            def band(z0, z1, rad):
                n = max(3, int((hi - lo) / 3) + 1)
                top = [cam.p(T(cyl(lo + (hi - lo) * i / (n - 1), z1, rad))) for i in range(n)]
                bot = [cam.p(T(cyl(hi - (hi - lo) * i / (n - 1), z0, rad))) for i in range(n)]
                return path(top + bot)
            panel = band(zb + c, zt - c, Rh + 0.1)
            fill = PAL['panelOff'] if is_off else color
            if glow and not is_off and not ghost and s <= 3:
                out.append(f'<path d="{panel}" fill="{color}" stroke="{color}" stroke-width="{fmt(2 * (c + 0.45) * s)}" stroke-linejoin="round" opacity=".5" filter="url(#glow)"/>')
            out.append(f'<path d="{panel}" fill="{PAL["bezel"]}" stroke="{PAL["bezel"]}" stroke-width="{fmt(2 * (c + fp["bezel"]) * s)}" stroke-linejoin="round"/>')
            out.append(f'<path d="{panel}" fill="{fill}" stroke="{fill}" stroke-width="{fmt(2 * c * s)}" stroke-linejoin="round"/>')
            if st.get('panelPattern') == 'hatch':
                out.append(f'<path d="{panel}" fill="url(#hatch)" stroke="url(#hatch)" stroke-width="{fmt(2 * c * s)}" stroke-linejoin="round" opacity=".45"/>')
            out.append(f'<g opacity="{".08" if is_off else ".2"}"><path d="{band((zb + zt) / 2, zt - c, Rh + 0.12)}" fill="#fff" stroke="#fff" stroke-width="{fmt(2 * c * s)}" stroke-linejoin="round"/></g>')
            # The glyph, mapped onto the same cylinder.
            gu = half * 0.55
            gz, gh = (zb + zt) / 2, (zt - zb) / 2 * 0.62
            ink = PAL['inkOnOff'] if is_off else PAL['ink']
            gw = fmt(1.15 * s)
            for stroke in C['glyphs'][st['glyph']]:
                if 'dot' in stroke:
                    u, v = stroke['dot']
                    if facing(u * gu):
                        x, y = cam.p(T(cyl(u * gu, gz + v * gh, Rh + 0.15)))
                        out.append(f'<circle cx="{fmt(x)}" cy="{fmt(y)}" r="{fmt(0.9 * s)}" fill="{ink}"/>')
                    continue
                if 'circle' in stroke:
                    cx, cy, r = stroke['circle']
                    pts = [(cx + r * math.cos(t), cy + r * math.sin(t)) for t in frange(0, 2 * math.pi, 2 * math.pi / 48)]
                else:
                    pts = stroke['poly'] + ([stroke['poly'][0]] if stroke.get('closed') else [])
                runs, cur = [], []
                for u, v in densify(pts, 0.05):
                    if facing(u * gu):
                        cur.append(cam.p(T(cyl(u * gu, gz + v * gh, Rh + 0.15))))
                    elif cur:
                        runs.append(cur)
                        cur = []
                if cur:
                    runs.append(cur)
                for r_ in runs:
                    if len(r_) > 1:
                        out.append(f'<path d="{path(r_, False)}" fill="none" stroke="{ink}" stroke-width="{gw}" stroke-linecap="round" stroke-linejoin="round"/>')
    out.append('</g>')
    out.append(f'<path d="{outline}" fill="none" stroke="{PAL["shell"]["line"]}" stroke-width="{fmt(lw)}"/>')
    svg = ''.join(out)
    if ghost:
        svg = f'<g opacity=".42">{svg}</g>'
    sc.put(4, cam.depth(center) - 0.5, svg)


# ---------------------------------------------------------------- furniture
def box(cam, center, size, yaw, z0, z1, colors, line):
    """A box `size` (w, d) centered at `center` (x, y), rotated by `yaw`, from z0 to z1."""
    w, d = size[0] / 2, size[1] / 2

    def V(x, y, z):
        q = rot_z((x, y, 0), yaw)
        return (center[0] + q[0], center[1] + q[1], z)

    faces = [
        ((0, 0, 1), [V(-w, -d, z1), V(w, -d, z1), V(w, d, z1), V(-w, d, z1)], colors['top']),
        ((0, -1, 0), [V(-w, -d, z0), V(w, -d, z0), V(w, -d, z1), V(-w, -d, z1)], colors['front']),
        ((0, 1, 0), [V(-w, d, z0), V(w, d, z0), V(w, d, z1), V(-w, d, z1)], colors.get('back', colors['front'])),
        ((-1, 0, 0), [V(-w, -d, z0), V(-w, d, z0), V(-w, d, z1), V(-w, -d, z1)], colors['side']),
        ((1, 0, 0), [V(w, -d, z0), V(w, d, z0), V(w, d, z1), V(w, -d, z1)], colors['side']),
    ]
    out = []
    corners = []
    for n, quad, col in faces:
        corners += quad
        if dot(rot_z(n, yaw), cam.f) < -1e-6:
            out.append(f'<path d="{path([cam.p(q) for q in quad])}" fill="{col}" stroke="{line}" stroke-width=".8" stroke-linejoin="round"/>')
    return ''.join(out), corners


def desk_cell(cam, origin, state_id, role, lw=1.0, k=20, glow=True, selected=False, theme='light'):
    """One workstation: chair, mannequin, desk, keyboard, monitor. Returns (scene, hand tip, desk front point)."""
    sc = Scene(cam)
    ox, oy, _ = origin
    fur = dict(PAL['furniture'])
    fur.update({k_: v for k_, v in C['rooms'][theme].items() if k_.startswith('desk')})
    st = STATES[state_id]
    if selected:
        c = cam.p((ox, oy - 30, 0))
        sc.put(0, 0, f'<ellipse cx="{fmt(c[0])}" cy="{fmt(c[1])}" rx="{fmt(78 * cam.s)}" ry="{fmt(78 * cam.s * math.sin(math.radians(cam.elev)) + 1)}" fill="none" stroke="{PAL["selection"]}" stroke-width="3.5"/>')
    shadow = cam.p((ox, oy - 30, 0))
    sc.put(0, 1, f'<ellipse cx="{fmt(shadow[0])}" cy="{fmt(shadow[1])}" rx="{fmt(62 * cam.s)}" ry="{fmt(62 * cam.s * math.sin(math.radians(cam.elev)) + 1)}" fill="#000" opacity=".16"/>')
    body_svg, _ = box(cam, (ox, oy - 52), (86, 56), 0, 0, DESK_TOP - 3,
                      {'top': fur['deskSide'], 'front': fur['deskSide'], 'side': fur['deskSide']}, '#8C95A1')
    top_svg, desk_corners = box(cam, (ox, oy - 52), (90, 60), 0, DESK_TOP - 3, DESK_TOP,
                                {'top': fur['deskTop'], 'front': fur['deskFront'], 'side': fur['deskFront']}, '#8C95A1')
    desk_svg = body_svg + top_svg
    desk_corners = desk_corners + [(x, y, 0) for x, y, _ in desk_corners]
    sc.put(2, cam.depth((ox, oy - 52, 37)), desk_svg)
    clip = uid('od')
    ring = hull([cam.p(q) for q in desk_corners])
    if sum(a[0] * b[1] - b[0] * a[1] for a, b in zip(ring, ring[1:] + ring[:1])) > 0:
        ring = ring[::-1]  # wound against the outer rectangle, so the desk is a hole under either fill rule
    sc.put(-1, 0, f'<clipPath id="{clip}"><path clip-rule="evenodd" d="M-4000,-4000H6000V6000H-4000Z{path(ring)}"/></clipPath>')
    dark = {'top': fur['graphite'], 'front': fur['graphiteSide'], 'side': fur['graphiteSide']}
    kb, _ = box(cam, (ox, oy - 41), (32, 10), 0, DESK_TOP, DESK_TOP + 1.6, dark, '#14171B')
    sc.put(3, 0, kb)
    chair = {'top': '#4A515C', 'front': '#3A404A', 'side': '#30353E'}
    for center, size, z0, z1 in (((ox, oy + 19), (32, 3), 54, 90), ((ox, oy + 2), (38, 32), 42, 47), ((ox, oy + 2), (4, 4), 8, 42)):
        svg, _ = box(cam, center, size, 0, z0, z1, chair, '#1E2228')
        sc.put(4, cam.depth((center[0], center[1], (z0 + z1) / 2)), f'<g clip-path="url(#{clip})">{svg}</g>')
    hand = mannequin(sc, (ox, oy, 0), 0, st['pose'], state_id, role, lw, k, clip_below=clip, glow=glow)
    # A low monitor at the desk's near corner, its back to the camera, so the face stays visible.
    mx, my, myaw = ox + 27, oy - 64, 22
    lit = st['id'] in ('working', 'waiting-external')
    parts = [box(cam, (mx, my), (12, 8), myaw, DESK_TOP, DESK_TOP + 1, dark, '#14171B')[0],
             box(cam, (mx, my + 1), (3, 3), myaw, DESK_TOP + 1, DESK_TOP + 8, dark, '#14171B')[0],
             box(cam, (mx, my), (36, 2.4), myaw, DESK_TOP + 7, DESK_TOP + 29,
                 {'top': fur['screenLit'] if lit else fur['screenDark'], 'front': fur['graphite'], 'back': fur['screenLit'] if lit else fur['screenDark'], 'side': fur['graphiteSide']}, '#14171B')[0]]
    sc.put(5, 0, ''.join(parts))
    return sc, hand, (ox, oy - 88, 0)


# ---------------------------------------------------------------- 2D marks
def glyph2d(name, cx, cy, size, color, width):
    out = []
    for st in C['glyphs'][name]:
        if 'poly' in st:
            pts = st['poly'] + ([st['poly'][0]] if st.get('closed') else [])
            out.append(f'<path d="{path([(cx + u * size, cy - v * size) for u, v in pts], False)}" fill="none" stroke="{color}" '
                       f'stroke-width="{fmt(width)}" stroke-linecap="round" stroke-linejoin="round"/>')
        elif 'circle' in st:
            u, v, r = st['circle']
            out.append(f'<circle cx="{fmt(cx + u * size)}" cy="{fmt(cy - v * size)}" r="{fmt(r * size)}" fill="none" stroke="{color}" stroke-width="{fmt(width)}"/>')
        else:
            u, v = st['dot']
            out.append(f'<circle cx="{fmt(cx + u * size)}" cy="{fmt(cy - v * size)}" r="{fmt(width * 0.78)}" fill="{color}"/>')
    return ''.join(out)


def chip(cx, cy, r, state_id):
    st = STATES[state_id]
    off = st['light'] == 'off'
    return (f'<circle cx="{fmt(cx)}" cy="{fmt(cy)}" r="{fmt(r)}" fill="{light_of(st)}" stroke="#1B1D22" stroke-width="1.2"/>'
            + glyph2d(st['glyph'], cx, cy, r * 0.6, '#F0F3F6' if off else PAL['ink'], max(1.1, r * 0.19)))


def badge(x, y, kind):
    """The raised hand's badge: question or approval, glyph and word, never color alone."""
    w = 84 if kind == 'question' else 88
    return (f'<g><rect x="{fmt(x)}" y="{fmt(y)}" width="{w}" height="22" rx="7" fill="#fff" stroke="#F85149" stroke-width="1.6"/>'
            + glyph2d('question' if kind == 'question' else 'shield', x + 12, y + 11, 6.4, '#B42318', 1.8)
            + text(x + 23, y + 15.5, kind, 12, '#B42318', 600) + '</g>')


def plate(x, y, number, name, label, state_id, theme, extra=None, w=150, small=False):
    t = C['rooms'][theme]
    h = (31 if small else 36) if extra is None else 48
    f1, f2, r = (11, 10, 8.5) if small else (12, 11, 9.5)
    out = [f'<rect x="{fmt(x)}" y="{fmt(y)}" width="{w}" height="{h}" rx="6" fill="{t["plate"]}" fill-opacity=".93" stroke="#1B1D22" stroke-opacity=".18"/>',
           chip(x + 13, y + h / 2, r, state_id),
           text(x + 26, y + h / 2 - 3, f'{number}. {name}', f1, t['plateText'], 600),
           text(x + 26, y + h / 2 + 10, label, f2, t['plateMuted'])]
    if extra:
        out.append(text(x + 30, y + 43, extra, 10, t['plateMuted'], 400, 'start', 'font-style="italic"'))
    return ''.join(out)


def defs():
    sh, jt = PAL['shell'], PAL['joint']
    return ('<defs>'
            f'<linearGradient id="shell" x1=".1" y1="0" x2=".9" y2="1"><stop offset="0" stop-color="{sh["hi"]}"/><stop offset=".55" stop-color="{sh["mid"]}"/><stop offset="1" stop-color="{sh["lo"]}"/></linearGradient>'
            f'<linearGradient id="joint" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{jt["hi"]}"/><stop offset="1" stop-color="{jt["lo"]}"/></linearGradient>'
            f'<linearGradient id="headgrad" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#C9D0D8"/><stop offset=".3" stop-color="#FFFFFF"/><stop offset=".65" stop-color="{sh["mid"]}"/><stop offset="1" stop-color="#B4BDC8"/></linearGradient>'
            '<pattern id="hatch" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="2.2" height="5" fill="#7A120E"/></pattern>'
            '<filter id="glow" x="-60%" y="-60%" width="220%" height="220%"><feGaussianBlur stdDeviation="2.4"/></filter>'
            '<filter id="mono"><feColorMatrix type="saturate" values="0"/></filter>'
            '</defs>')


def doc(w, h, body, bg='#F6F7F9'):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}" font-family="{FONT}">'
            + defs() + f'<rect width="{w}" height="{h}" fill="{bg}"/>' + body + '</svg>')


def write(name, svg):
    os.makedirs(SHEETS, exist_ok=True)
    with open(os.path.join(SHEETS, name), 'w', encoding='utf-8') as f:
        f.write(svg)
    return len(svg)


# ---------------------------------------------------------------- sheets
def sheet_turnaround():
    W, H = 1960, 1070
    out = [text(40, 52, 'Office android · turnaround', 28, '#14171C', 700),
           text(40, 80, 'Canonical character v0.1 (design). White mannequin shell, slender rounded-cylinder head, status face panel '
                'and base ring. Office workers only; Museum avatars stay human. Panel shown: Working.', 14, '#3B4048')]
    ground = 900
    s = 2.85
    views = [(0, 'FRONT'), (45, '3/4 FRONT'), (90, 'SIDE · character right'), (135, '3/4 BACK'), (180, 'BACK')]
    for i in range(8):
        y = ground - i * 25 * s
        out.append(f'<line x1="40" x2="1290" y1="{fmt(y)}" y2="{fmt(y)}" stroke="#C7CDD5" stroke-width="1" stroke-dasharray="{"0" if i == 0 else "4 6"}"/>')
        out.append(text(44, y - 4, '0' if i == 0 else f'{i} H', 11, '#7A8390'))
    out.append(f'<line x1="40" x2="1290" y1="{fmt(ground - 180 * s)}" y2="{fmt(ground - 180 * s)}" stroke="#D97757" stroke-width="1.2"/>')
    out.append(text(44, ground - 180 * s - 6, '180 cm = 7.2 head-heights (H = 25 cm)', 11, '#B65C3F', 600))
    for i, (yaw, label) in enumerate(views):
        cx = 175 + i * 245
        sc = Scene(Cam(yaw, 0, s, cx, ground))
        mannequin(sc, (0, 0, 0), 0, 'stand', 'working', 'main', 1.1, 32)
        out.append(sc.svg())
        out.append(text(cx, ground + 34, label, 14, '#14171C', 700, 'middle'))
        out.append(text(cx, ground + 52, f'camera yaw {yaw}°', 11, '#7A8390', 400, 'middle'))
    # Head detail
    hx = 1340
    out.append(f'<rect x="{hx - 20}" y="110" width="620" height="700" rx="14" fill="#FFFFFF" stroke="#DCE1E7"/>')
    out.append(text(hx, 142, 'Head detail', 18, '#14171C', 700))
    head_views = [(0, 0, 'front'), (55, 6, '3/4'), (90, 0, 'side'), (0, 89.5, 'top (front at bottom)')]
    for i, (yaw, elev, label) in enumerate(head_views):
        cx, cy = hx + 140 + (i % 2) * 300, 290 + (i // 2) * 260
        sc = Scene(centered(yaw, elev, 8.2, (0, 0.5, 167.5), cx, cy))
        mannequin(sc, (0, 0, 0), 0, 'stand', 'working', 'main', 1.2, 48, head_only=True)
        out.append(sc.svg())
        out.append(text(cx, cy + 128, label, 12, '#3B4048', 600, 'middle'))
    notes = ['Head: rounded cylinder Ø15 × 25 cm, edge radius 4 (width : height 0.6)',
             'Face panel: wraps ±60°, 14.5 cm tall, corner r 2.2, dark bezel 0.7',
             'Panel = status light: fill in the status color, glyph in dark ink',
             'Base ring: same status color, readable from behind and above',
             'No eyes, mouth, hair, skin tone, clothing or gender cues']
    for i, n in enumerate(notes):
        out.append(text(hx, 700 + i * 22, '• ' + n, 13, '#2A2F36'))
    # Role accents
    out.append(f'<rect x="{hx - 20}" y="830" width="620" height="210" rx="14" fill="#FFFFFF" stroke="#DCE1E7"/>')
    out.append(text(hx, 858, 'Role accent: shoulder joints only (never a status color)', 15, '#14171C', 700))
    for i, role in enumerate(('main', 'subagent', 'peer')):
        cx = hx + 90 + i * 200
        sc = Scene(centered(25, 8, 2.0, (0, 0.5, 150), cx, 945))
        mannequin(sc, (0, 0, 0), 0, 'stand', 'idle', role, 0.9, 28, bust=True)
        out.append(sc.svg())
        out.append(text(cx, 1030, {'main': 'This conversation', 'subagent': 'Subagent / teammate', 'peer': 'Enrolled peer'}[role], 12, '#2A2F36', 600, 'middle'))
        out.append(f'<circle cx="{cx - 72}" cy="1026" r="6" fill="{PAL["role"][role]}"/>')
    return write('turnaround.svg', doc(W, H, ''.join(out)))


def state_cell_cam(rect):
    pts = []
    for name in ('seat_hand_up', 'seat_rest', 'seat_slump', 'seat_lean_back'):
        P = pose(name)
        pts += [tuple(P['hand_l']), add(tuple(P['head']), (0, 0, 13))]
    pts += [(x, y, z) for x in (-45, 45) for y in (-82, 22) for z in (0, DESK_TOP)]
    pts += [(-45, -82, DESK_TOP + 30), (0, 21, 97)]
    return Cam(35, 18).fitted(pts, rect)


def sheet_states():
    cols = STATE_ORDER
    cw, left, top = 232, 170, 120
    W = left + cw * len(cols) + 30
    rows = [('At the desk', 250), ('Face panel', 190), ('From behind', 170), ('Without color', 250), ('Text + icon', 120)]
    H = top + sum(h for _, h in rows) + 40
    out = [text(40, 50, 'Office android · state sheet', 28, '#14171C', 700),
           text(40, 78, 'Every state carries four cues: posture, face-panel glyph, written label and light color. Rows 4 and 5 show the '
                'meaning survives without color. Sample states for design, not observed native states.', 14, '#3B4048')]
    y = top
    for ri, (label, rh) in enumerate(rows):
        out.append(f'<rect x="20" y="{y}" width="{W - 40}" height="{rh - 8}" rx="10" fill="{"#FFFFFF" if ri % 2 == 0 else "#F0F2F5"}"/>')
        out.append(text(36, y + 26, label, 14, '#14171C', 700))
        for ci, sid in enumerate(cols):
            st = STATES[sid]
            x = left + ci * cw
            if label in ('At the desk', 'Without color'):
                cam = state_cell_cam((x + 22, y + 40, cw - 44, rh - 56))
                sc, hand, _ = desk_cell(cam, (0, 0, 0), sid, 'subagent', 0.9, 24)
                g = sc.svg()
                if st['hand']:
                    hx, hy = cam.p(hand)
                    g += badge(hx - 42, hy - 30, st['hand'])
                if label == 'Without color':
                    g = mono(g)
                out.append(g)
            elif label == 'Face panel':
                sc = Scene(centered(0, 4, 5.6, (0, 0.5, 167.5), x + cw / 2, y + rh / 2 - 2))
                mannequin(sc, (0, 0, 0), 0, 'stand', sid, 'subagent', 1.0, 40, head_only=True)
                out.append(f'<g clip-path="url(#rowclip{ri}_{ci})">{sc.svg()}</g>')
                out.append(f'<clipPath id="rowclip{ri}_{ci}"><rect x="{x}" y="{y + 4}" width="{cw}" height="{rh - 16}"/></clipPath>')
            elif label == 'From behind':
                sc = Scene(centered(205, 14, 2.6, (0, 0.5, 152), x + cw / 2, y + rh / 2 + 6))
                mannequin(sc, (0, 0, 0), 0, 'stand', sid, 'subagent', 1.0, 32, bust=True)
                out.append(f'<g clip-path="url(#rowclip{ri}_{ci})">{sc.svg()}</g>')
                out.append(f'<clipPath id="rowclip{ri}_{ci}"><rect x="{x}" y="{y + 4}" width="{cw}" height="{rh - 16}"/></clipPath>')
            else:
                out.append(mono(chip(x + 26, y + 30, 13, sid)))
                out.append(chip(x + 60, y + 30, 13, sid))
                out.append(text(x + 82, y + 26, st['label'] if len(st['label']) < 22 else st['label'].split(' · ')[0], 13, '#14171C', 700))
                out.append(text(x + 82, y + 43, f'{st["light"]} · {st["icon"]} · {st["glyph"]}', 11, '#4A515B'))
                out.append(text(x + 14, y + 70, f'pose: {st["pose"].replace("seat_", "")}', 11, '#4A515B'))
                if sid == 'unknown':
                    out.append(text(x + 14, y + 86, 'also "Held (reason not exposed)"', 11, '#4A515B'))
                if sid == 'disconnected':
                    out.append(text(x + 14, y + 86, 'ghosted 42 %, peer stopped refreshing', 11, '#4A515B'))
                if st['hand']:
                    out.append(text(x + 14, y + 86, f'hand up + "{st["hand"]}" badge', 11, '#B42318', 600))
                if sid == 'failed':
                    out.append(text(x + 14, y + 86, 'hatched panel, slumped', 11, '#4A515B'))
            if ri == 0:
                out.append(text(x + cw / 2, top - 8, st['label'].split(' · ')[0], 13, '#14171C', 700, 'middle'))
        y += rh
    return write('state-sheet.svg', doc(W, H, ''.join(out)))


SAMPLE = [
    # (key, group, name, state, role, extra)
    ('main', 'session', 'This conversation', 'working', 'main', None),
    ('a1', 'session', 'Docs scan', 'needs-user-question', 'subagent', None),
    ('a2', 'session', 'Test runner', 'needs-user-approval', 'subagent', None),
    ('a3', 'session', 'Release notes', 'waiting-external', 'subagent', None),
    ('a4', 'session', 'Lint fixer', 'failed', 'subagent', None),
    ('a5', 'session', 'Changelog', 'completed', 'subagent', None),
    ('a6', 'session', 'Spec reader', 'idle', 'subagent', None),
    ('a7', 'session', 'Indexer', 'unknown', 'subagent', None),
    ('a8', 'session', 'Summary', 'completed', 'subagent', 'kept · not listed'),
    ('p1', 'peers', 'peer-a · 1a2b3c4d', 'working', 'peer', None),
    ('p2', 'peers', 'peer-b · 5e6f7a8b', 'disconnected', 'peer', None),
]


ROOMY = [SAMPLE[0], SAMPLE[1], SAMPLE[2], SAMPLE[3], SAMPLE[9]]


def label_of(sid, extra):
    st = STATES[sid]
    if sid == 'unknown':
        return 'Held (reason not exposed)'
    return st['label'] if extra is None else f'{st["label"]} · not listed'


ROOM_W, ROOM_H = 960, 640


def room_cam():
    frame = [(x, y, 0) for x in (-90, 1000) for y in (-190, 700)] + [(0, 520, 160), (920, 520, 160)]
    return Cam(30, 30).fitted(frame, (16, 58, ROOM_W - 32, ROOM_H - 58 - 48))


def room_cam_roomy():
    frame = [(x, y, 0) for x in (-90, 1000) for y in (60, 460)] + [(0, 360, 175), (920, 360, 175)]
    return Cam(30, 30).fitted(frame, (16, 70, ROOM_W - 32, ROOM_H - 70 - 60))


def tag(cx, y, number, state_id, extra, theme):
    """A one-line desk tag for dense rooms: chip, number and short state; the name is in the numbered button."""
    t = C['rooms'][theme]
    word = STATES[state_id]['short'] + (' (kept)' if extra else '')
    w = 34 + 6.3 * len(f'{number} {word}')
    x = cx - w / 2
    return (f'<rect x="{fmt(x)}" y="{fmt(y)}" width="{fmt(w)}" height="20" rx="10" fill="{t["plate"]}" fill-opacity=".94" stroke="#1B1D22" stroke-opacity=".2"/>'
            + chip(x + 11, y + 10, 7.5, state_id) + text(x + 23, y + 14.5, f'{number}', 11, t['plateText'], 700)
            + text(x + 23 + 7 * len(str(number)) + 4, y + 14.5, word, 11, t['plateMuted']))


def room(theme, workers=SAMPLE, selected='a1', k=20, glow=True, caption=None, mark=True):
    t = C['rooms'][theme]
    Wd, Hd = ROOM_W, ROOM_H
    spots = {}
    si = pi = 0
    n_session = sum(1 for w in workers if w[1] == 'session')
    dense = n_session > 4
    for w in workers:
        if w[1] == 'session':
            spots[w[0]] = ((si % 3) * 220, (si // 3) * 260, 0) if dense else (si * 195, 260, 0)
            si += 1
        else:
            spots[w[0]] = (700 + (pi % 2) * 220, (pi // 2) * 260, 0) if dense else (720 + (pi % 2) * 220, 260 + (pi // 2) * 260, 0)
            pi += 1
    cam = room_cam() if dense else room_cam_roomy()
    out = [f'<rect width="{Wd}" height="{Hd}" fill="{t["bg"]}"/>']
    poly = lambda pts, fill, extra='': f'<path d="{path([cam.p(q) for q in pts])}" fill="{fill}" {extra}/>'
    out.append(poly([(-90, -190, 0), (1000, -190, 0), (1000, 700, 0), (-90, 700, 0)], t['floor']))
    out.append(poly([(-70, -170, 0), (530, -170, 0), (530, 680, 0), (-70, 680, 0)], t['carpetSession']))
    out.append(poly([(640, -170, 0), (980, -170, 0), (980, 680, 0), (640, 680, 0)], t['carpetPeers']))
    cells = []
    for key, group, name, sid, role, extra in workers:
        sc, hand, front = desk_cell(cam, spots[key], sid, role, 1.0 if k > 12 else 0.8, k, glow, key == selected, theme)
        cells.append((cam.depth(spots[key]), key, group, sc, hand, front))
    numbering = {w[0]: i + 1 for i, w in enumerate(workers)}
    byKey = {w[0]: w for w in workers}

    def label(key, front):
        _, _, name, sid, role, extra = byKey[key]
        fx, fy = cam.p(front)
        if dense:
            return tag(fx - 16, fy + 3, numbering[key], sid, extra, theme)
        return plate(fx - 70, fy + 6, numbering[key], name, label_of(sid, extra), sid, theme, w=140, small=True)

    peers = sorted([c for c in cells if c[2] == 'peers'], key=lambda c: -c[0])
    sess = sorted([c for c in cells if c[2] == 'session'], key=lambda c: -c[0])
    out += [c[3].svg() + label(c[1], c[5]) for c in peers]
    out.append(poly([(590, -190, 0), (590, 700, 0), (590, 700, 150), (590, -190, 150)], t['glass'],
                    f'fill-opacity=".14" stroke="{t["glass"]}" stroke-opacity=".55"'))
    out += [c[3].svg() + label(c[1], c[5]) for c in sess]
    # Hands go last so nothing hides them.
    for depth, key, group, sc, hand, front in sorted(cells, key=lambda c: -c[0]):
        sid = byKey[key][3]
        if STATES[sid]['hand']:
            hx, hy = cam.p(hand)
            out.append(badge(hx - 42, hy - 30, STATES[sid]['hand']))
    out.append(text(24, 34, 'This session: main + its agents', 14, t['title'], 600))
    out.append(text(Wd - 24, 34, 'Enrolled peer sessions', 14, t['title'], 600, 'end'))
    hands = sum(1 for w in workers if STATES[w[3]]['hand'])
    cap = caption or f'{len(workers)} workers · {hands} hands up · select a worker with the buttons below the picture'
    out.append(f'<rect x="12" y="{Hd - 40}" width="{Wd - 24}" height="28" rx="6" fill="#000" fill-opacity=".45"/>')
    out.append(text(24, Hd - 21, cap, 14, '#F3EEE4'))
    if mark:
        out.append(text(Wd - 24, 54, MARK, 10, t['muted'], 600, 'end'))
    body = ''.join(out)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {Wd} {Hd}" width="{Wd}" height="{Hd}" font-family="{FONT}">'
            + defs() + body + '</svg>')


def bust_portrait(x, y, w, h, sid, role):
    P = pose(STATES[sid]['pose'])
    cam = Cam(28, 6, 3.3, 0, 0)
    head_c = tuple(P['head'])
    hx, hy = cam.p(head_c)
    cam.ox, cam.oy = x + w / 2 - hx - 6, y + h * 0.38 - hy
    sc = Scene(cam)
    hand = mannequin(sc, (0, 0, 0), 0, STATES[sid]['pose'], sid, role, 1.0, 36)
    cid = uid('pc')
    g = (f'<clipPath id="{cid}"><rect x="{fmt(x)}" y="{fmt(y)}" width="{fmt(w)}" height="{fmt(h)}" rx="12"/></clipPath>'
         f'<rect x="{fmt(x)}" y="{fmt(y)}" width="{fmt(w)}" height="{fmt(h)}" rx="12" fill="#2A2F37"/>'
         f'<g clip-path="url(#{cid})">{sc.svg()}</g>')
    return g


def button(x, y, w, label, primary=False, dim=False, h=26):
    fill = '#2F6FEB' if primary else '#2A2D33'
    stroke = '#2F6FEB' if primary else '#4A4F57'
    color = '#FFFFFF' if primary else ('#8B929B' if dim else '#E8E6E3')
    return (f'<rect x="{fmt(x)}" y="{fmt(y)}" width="{fmt(w)}" height="{h}" rx="6" fill="{fill}" stroke="{stroke}"/>'
            + text(x + 10, y + h / 2 + 4.5, label, 12.5, color))


def pane(x0, y0, variant):
    """A mockup of the native Agent Office pane (host-drawn controls approximated)."""
    W = 620
    sel = 'a1' if variant == 'question' else 'a2'
    selw = next(w for w in SAMPLE if w[0] == sel)
    out = ['PANE_FRAME',
           f'<rect x="{x0}" y="{y0}" width="{W}" height="40" rx="12" fill="#232428"/>',
           text(x0 + 16, y0 + 26, 'Agent Office', 14, '#E8E6E3', 600),
           text(x0 + W - 18, y0 + 26, '×', 16, '#8B929B', 400, 'end'),
           text(x0 + 16, y0 + 64, '11 workers · 2 hands up', 13, '#C9CDD3')]
    room_svg = room('dark', selected=sel, mark=False)
    inner = room_svg[room_svg.index('>') + 1:room_svg.rindex('</svg>')]
    sc = (W - 24) / ROOM_W
    out.append(f'<g transform="translate({x0 + 12},{y0 + 76}) scale({fmt(sc)})">{inner}</g>')
    y = y0 + 76 + ROOM_H * sc + 18
    out.append(text(x0 + 16, y + 4, '✋ Hands up:', 13, '#F85149', 600))
    out.append(button(x0 + 110, y - 13, 230, 'Inspect Docs scan: question', sel == 'a1'))
    out.append(button(x0 + 350, y - 13, 250, 'Inspect Test runner: approval', sel == 'a2'))
    y += 30
    for i, (key, group, name, sid, role, extra) in enumerate(SAMPLE):
        st = STATES[sid]
        mark = '▶' if key == sel else ' '
        lab = f'{mark} {i + 1}. {st["icon"]} {name} · {label_of(sid, extra)}' + ('  ✋ hand up' if st['hand'] else '')
        out.append(button(x0 + 16, y, W - 32, lab, key == sel, sid in ('disconnected',), 24))
        y += 28
    y += 8
    inspector_top = y
    out.append('INSPECTOR_FRAME')
    out.append(bust_portrait(x0 + 24, y + 14, 150, 178, selw[3], 'subagent'))
    tx, ty = x0 + 190, y + 34
    out.append(text(tx, ty, f'2. {selw[2]}' if sel == 'a1' else f'3. {selw[2]}', 16, '#F2F0ED', 700))
    out.append(chip(tx + 8, ty + 22, 9, selw[3]))
    out.append(text(tx + 24, ty + 27, label_of(selw[3], None), 13, '#F85149', 600))
    out.append(text(tx, ty + 52, 'Subagent of this session · general-purpose', 12, '#AEB4BC'))
    out.append(text(tx, ty + 72, 'Exact identity: agent a0b1c2d3e4f5a6b7c (sample)', 12, '#C9CDD3', 400, 'start', 'font-family="ui-monospace, Menlo, monospace"'))
    if variant == 'question':
        lines = [('Question waiting (inert text):', '#F85149', 600),
                 ('“Which docs folder should I scan first: docs/ or design/?”', '#E8E6E3', 400),
                 ('Answer it in Claude’s own question dialog.', '#C9CDD3', 400),
                 ('The office shows the question; it never answers for you.', '#C9CDD3', 400)]
    else:
        lines = [('Approval waiting (inert text): Bash · npm test', '#F85149', 600),
                 ('Answer in Claude Code’s own permission prompt.', '#E8E6E3', 400),
                 ('The office draws no approve or deny control.', '#C9CDD3', 400),
                 ('Needs classic.PermissionRequest: unverified natively;', '#AEB4BC', 400),
                 ('not delivered in organization-managed setups.', '#AEB4BC', 400)]
    ly = ty + 104
    for s, c, wgt in lines:
        out.append(text(tx, ly, s, 12.5, c, wgt))
        ly += 20
    by = max(y + 214, ly + 14)
    out.append(text(x0 + 24, by, 'Its own conversation (supported read, inert):', 12, '#AEB4BC', 600))
    convo = (['user · Scan the docs and list stale pages.', 'assistant · Starting with the folder list…',
              'assistant · (asks a question — see above)'] if variant == 'question' else
             ['user · Run the test suite and report failures.', 'assistant · Running the tests…',
              'assistant · (Bash: npm test, waiting for approval)'])
    for i, s in enumerate(convo):
        out.append(text(x0 + 24, by + 22 + i * 19, s, 12, '#8B929B'))
    sy = by + 90
    out.append(f'<rect x="{x0 + 24}" y="{sy}" width="{W - 48}" height="96" rx="8" fill="#1B1C1F" stroke="#4A4F57" stroke-dasharray="5 4"/>')
    out.append(text(x0 + 38, sy + 24, 'Send to this worker: held', 13, '#E3B341', 700))
    out.append(text(x0 + 38, sy + 46, 'In auto mode a pane button cannot deliver (no classifier verdict', 12, '#C9CDD3'))
    out.append(text(x0 + 38, sy + 64, 'outside a model request). Route decision pending:', 12, '#C9CDD3'))
    out.append(text(x0 + 38, sy + 82, 'docs/SEND_ROUTE_REVIEW.md. Nothing is sent from this pane.', 12, '#C9CDD3'))
    bottom = sy + 96 + 14
    out[0] = f'<rect x="{x0}" y="{y0}" width="{W}" height="{bottom + 12 - y0}" rx="12" fill="#1B1C1F" stroke="#34373D"/>'
    out[out.index('INSPECTOR_FRAME')] = f'<rect x="{x0 + 12}" y="{inspector_top}" width="{W - 24}" height="{bottom - inspector_top}" rx="10" fill="#222428" stroke="#34373D"/>'
    return ''.join(out)


def sheet_panes():
    W, H = 1340, 1440
    out = [text(40, 50, 'Office android · native pane: question and approval', 26, '#14171C', 700),
           text(40, 76, 'Mockup of the Agent Office pane in the Desktop Code tab. Picture = one Svg leaf; selection = native Buttons; '
                'answering stays in Claude’s own dialogs. ' + MARK + '.', 13, '#3B4048')]
    out.append(text(40, 112, 'A. A question is waiting', 16, '#14171C', 700))
    out.append(pane(40, 124, 'question'))
    out.append(text(680, 112, 'B. An approval is waiting', 16, '#14171C', 700))
    out.append(pane(680, 124, 'approval'))
    return write('pane-hands.svg', doc(W, H, ''.join(out), '#ECEEF1'))


def sheet_legibility():
    s1 = room_cam().s
    scales = [('Inspector portrait', None), ('Desk 1.0 × (office picture at 960 px)', s1), ('Desk 0.6 × (narrow pane)', s1 * 0.6)]
    cols = [s for s in STATE_ORDER]
    cw, left, top = 170, 250, 110
    W = left + cw * len(cols) + 30
    H = top + 3 * 180 + 160
    out = [text(40, 50, 'Office android · legibility at native sizes', 26, '#14171C', 700),
           text(40, 76, 'At desk scale the panel color, posture and written plate carry the state; the panel glyph is fully readable '
                'only in the inspector. Sizes assume the 960 × 640 office picture drawn at its natural width.', 13, '#3B4048')]
    y = top
    for ri, (label, scale) in enumerate(scales):
        out.append(f'<rect x="20" y="{y}" width="{W - 40}" height="170" rx="10" fill="{"#FFFFFF" if ri % 2 == 0 else "#F0F2F5"}"/>')
        out.append(text(36, y + 28, label, 13, '#14171C', 700))
        for ci, sid in enumerate(cols):
            x = left + ci * cw
            if scale is None:
                out.append(bust_portrait(x + 20, y + 14, 130, 142, sid, 'subagent').replace('#2A2F37', '#DDE2E8'))
            else:
                cam = Cam(45, 30, scale, x + cw / 2, y + 140)
                sc, hand, _ = desk_cell(cam, (0, 0, 0), sid, 'subagent', 0.7, 16)
                g = sc.svg()
                if STATES[sid]['hand'] and scale > 0.5:
                    hx, hy = cam.p(hand)
                    g += badge(hx - 42, hy - 28, STATES[sid]['hand'])
                out.append(g)
            if ri == 0:
                out.append(text(x + cw / 2, top - 10, STATES[sid]['label'].split(' · ')[0], 12, '#14171C', 700, 'middle'))
        y += 180
    out.append(text(36, y + 26, 'Status chips (desk plate and worker buttons): 19 px and 13 px, color and grayscale', 13, '#14171C', 700))
    for ci, sid in enumerate(cols):
        x = left + ci * cw
        out.append(chip(x + 40, y + 70, 9.5, sid))
        out.append(chip(x + 70, y + 70, 6.5, sid))
        out.append(mono(chip(x + 100, y + 70, 9.5, sid) + chip(x + 130, y + 70, 6.5, sid)))
    return write('legibility.svg', doc(W, H, ''.join(out)))


# ---------------------------------------------------------------- lean native drawing
LEAN_SHELL, LEAN_FAR, LEAN_LINE, LEAN_JOINT = '#F2F4F7', '#D9DEE5', '#6F7A88', '#AEB7C2'


def lean_mannequin(cam, at, pose_name, state_id, role, layers):
    """The same character in the cheapest primitives: lines for limbs, circles for joints, short paths for the rest.
    No gradients, filters, clip paths or panel glyph (the glyph is the inspector's job)."""
    P = pose(pose_name)
    st = STATES[state_id]
    ghost = st.get('ghost', False)
    center_depth = cam.depth(add(at, tuple(P['chest_l'])))
    for mat, sph in body_parts(P):
        ws = [(add(c, at), r) for c, r in sph]
        depth = sum(cam.depth(c) for c, _ in ws) / len(ws)
        zmin = min(c[2] - r for c, r in ws)
        far = depth > center_depth + 4
        shell = LEAN_FAR if far else LEAN_SHELL
        if mat in ('joint', 'role') and len(ws) == 1:
            (c, r), = ws
            x, y = cam.p(c)
            col = PAL['role'][role] if mat == 'role' else LEAN_JOINT
            svg = f'<circle cx="{fmt(x)}" cy="{fmt(y)}" r="{fmt(r * cam.s)}" fill="{col}"/>'
        elif len(ws) == 2:
            (a, ra), (b, rb) = ws
            (x1, y1), (x2, y2) = cam.p(a), cam.p(b)
            w = (ra + rb) * cam.s
            col = LEAN_JOINT if mat == 'joint' else shell
            pts = f'x1="{fmt(x1)}" y1="{fmt(y1)}" x2="{fmt(x2)}" y2="{fmt(y2)}"'
            svg = (f'<g stroke-linecap="round"><line {pts} stroke="{LEAN_LINE}" stroke-width="{fmt(w + 1.4)}"/>'
                   f'<line {pts} stroke="{col}" stroke-width="{fmt(w)}"/></g>')
        else:
            d = path(circles_hull([(*cam.p(c), r * cam.s) for c, r in ws], 8))
            svg = f'<path d="{d}" fill="{shell}" stroke="{LEAN_LINE}"/>'
        if ghost:
            svg = f'<g opacity=".42">{svg}</g>'
        layers.append((1 if zmin < DESK_TOP - 0.3 else 3, depth + {'shell': 0, 'joint': 1.5, 'role': -1.0}[mat], svg))
    # Head: outline, base ring and face panel as three short paths, colored by state.
    hg, fp = GEO['head'], GEO['facePanel']
    Rh, H, e = hg['radius'], hg['height'], hg['edgeRound']
    turn = P['headTurn']
    center = add(at, tuple(P['head']))

    def T(q):
        return add(rot_z(rot_x(rot_y(q, turn[2]), turn[1]), turn[0]), center)

    pts = []
    for i in range(4):
        t = math.pi / 2 * i / 3
        rr = Rh - e + e * math.sin(t)
        for zz in (-H / 2 + e - e * math.cos(t), H / 2 - e + e * math.cos(t)):
            pts += [cam.p(T((rr * math.sin(a), -rr * math.cos(a), zz))) for a in frange(0, 2 * math.pi, 2 * math.pi / 12)]
    outline = path(hull(pts))
    color = PAL['panelOff'] if st['light'] == 'off' else light_of(st)
    ring = '#4A525C' if st['light'] == 'off' else light_of(st)
    zb, zt = -H / 2 + fp['zFromHeadBottom'][0], -H / 2 + fp['zFromHeadBottom'][1]

    def cyl(phi, z):
        a = math.radians(phi)
        return cam.p(T((Rh * math.sin(a), -Rh * math.cos(a), z)))

    vis = [ph for ph in frange(-fp['halfAngleDeg'], fp['halfAngleDeg'], 10)
           if dot(rot_z(rot_x(rot_y((math.sin(math.radians(ph)), -math.cos(math.radians(ph)), 0), turn[2]), turn[1]), turn[0]), cam.f) < -0.1]
    svg = f'<path d="{outline}" fill="{LEAN_SHELL}" stroke="{LEAN_LINE}"/>'
    zr = -H / 2 + GEO['statusRing']['zFromHeadBottom']
    front = [ph for ph in frange(-90, 90, 30)]
    svg += f'<path d="{path([cyl(ph, zr) for ph in front], False)}" fill="none" stroke="{ring}" stroke-width="{fmt(1.4 * cam.s + 0.6)}"/>'
    if len(vis) > 1:
        lo, hi = vis[0], vis[-1]
        band = [cyl(ph, zt) for ph in (lo, (lo + hi) / 2, hi)] + [cyl(ph, zb) for ph in (hi, (lo + hi) / 2, lo)]
        svg += f'<path d="{path(band)}" fill="{color}" stroke="{PAL["bezel"]}" stroke-width="{fmt(max(1, 1.2 * cam.s))}" stroke-linejoin="round"/>'
    if ghost:
        svg = f'<g opacity=".42">{svg}</g>'
    layers.append((3, cam.depth(center) - 0.5, svg))
    return add(at, tuple(P['hand_l']))


def lean_box(cam, center, size, z0, z1, colors):
    w, d = size[0] / 2, size[1] / 2
    cx, cy = center
    faces = [((0, 0, 1), [(cx - w, cy - d, z1), (cx + w, cy - d, z1), (cx + w, cy + d, z1), (cx - w, cy + d, z1)], colors[0]),
             ((0, -1, 0), [(cx - w, cy - d, z0), (cx + w, cy - d, z0), (cx + w, cy - d, z1), (cx - w, cy - d, z1)], colors[1]),
             ((0, 1, 0), [(cx - w, cy + d, z0), (cx + w, cy + d, z0), (cx + w, cy + d, z1), (cx - w, cy + d, z1)], colors[1]),
             ((-1, 0, 0), [(cx - w, cy - d, z0), (cx - w, cy + d, z0), (cx - w, cy + d, z1), (cx - w, cy - d, z1)], colors[2]),
             ((1, 0, 0), [(cx + w, cy - d, z0), (cx + w, cy + d, z0), (cx + w, cy + d, z1), (cx + w, cy - d, z1)], colors[2])]
    return ''.join(f'<path d="{path([cam.p(q) for q in quad])}" fill="{col}"/>' for n, quad, col in faces if dot(n, cam.f) < -1e-6)


def lean_room(theme, workers):
    """The office picture as the mod could draw it inside one Svg leaf (whole-pixel coordinates)."""
    t = C['rooms'][theme]
    cam = room_cam()
    spots = {}
    si = pi = 0
    for w in workers:
        if w[1] == 'session':
            spots[w[0]] = ((si % 3) * 220, (si // 3) * 260, 0)
            si += 1
        else:
            spots[w[0]] = (700 + (pi % 2) * 220, (pi // 2) * 260, 0)
            pi += 1
    desk = (t['deskTop'], t['deskFront'], t['deskSide'])
    chair = ('#4A515C', '#3A404A', '#30353E')
    dark = (PAL['furniture']['graphite'], PAL['furniture']['graphiteSide'], PAL['furniture']['graphiteSide'])
    out = [f'<rect width="{ROOM_W}" height="{ROOM_H}" fill="{t["bg"]}"/>']
    poly = lambda pts, fill, extra='': f'<path d="{path([cam.p(q) for q in pts])}" fill="{fill}" {extra}/>'
    out.append(poly([(-90, -190, 0), (1000, -190, 0), (1000, 700, 0), (-90, 700, 0)], t['floor']))
    out.append(poly([(-70, -170, 0), (530, -170, 0), (530, 680, 0), (-70, 680, 0)], t['carpetSession']))
    out.append(poly([(640, -170, 0), (980, -170, 0), (980, 680, 0), (640, 680, 0)], t['carpetPeers']))
    cells = []
    for key, group, name, sid, role, extra in workers:
        ox, oy, _ = spots[key]
        layers = [(0, 0, lean_box(cam, (ox, oy + 19), (32, 3), 54, 90, chair) + lean_box(cam, (ox, oy + 2), (38, 32), 42, 47, chair))]
        hand = lean_mannequin(cam, spots[key], STATES[sid]['pose'], sid, role, layers)
        layers.append((2, 0, lean_box(cam, (ox, oy - 52), (90, 60), 0, DESK_TOP, desk) + lean_box(cam, (ox, oy - 41), (32, 10), DESK_TOP, DESK_TOP + 1.6, dark)))
        lit = sid in ('working', 'waiting-external')
        layers.append((4, 0, lean_box(cam, (ox + 27, oy - 64), (34, 3), DESK_TOP + 7, DESK_TOP + 29,
                                          (PAL['furniture']['screenLit'] if lit else PAL['furniture']['screenDark'], dark[1], dark[2]))))
        fx, fy = cam.p((ox, oy - 88, 0))
        layers.append((9, 0, tag(fx - 16, fy + 3, len(cells) + 1, sid, extra, theme)))
        cells.append((cam.depth(spots[key]), key, group, ''.join(x[2] for x in sorted(layers, key=lambda x: (x[0], -x[1]))), hand))
    out += [c[3] for c in sorted(cells, key=lambda c: -c[0]) if c[2] == 'peers']
    out.append(poly([(590, -190, 0), (590, 700, 0), (590, 700, 150), (590, -190, 150)], t['glass'], f'fill-opacity=".14" stroke="{t["glass"]}"'))
    out += [c[3] for c in sorted(cells, key=lambda c: -c[0]) if c[2] == 'session']
    numbering = {w[0]: i + 1 for i, w in enumerate(workers)}
    for depth, key, group, svg, hand in sorted(cells, key=lambda c: -c[0]):
        w = next(x for x in workers if x[0] == key)
        if STATES[w[3]]['hand']:
            hx, hy = cam.p(hand)
            out.append(badge(hx - 42, hy - 30, STATES[w[3]]['hand']))
    out.append(text(24, 34, 'This session: main + its agents', 14, t['title'], 600))
    out.append(text(ROOM_W - 24, 34, 'Enrolled peer sessions', 14, t['title'], 600, 'end'))
    out.append(f'<rect x="12" y="{ROOM_H - 40}" width="{ROOM_W - 24}" height="28" rx="6" fill="#000" fill-opacity=".45"/>')
    hands = sum(1 for w in workers if STATES[w[3]]['hand'])
    out.append(text(24, ROOM_H - 21, f'{len(workers)} workers · {hands} hands up · select a worker with the buttons below the picture', 14, '#F3EEE4'))
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {ROOM_W} {ROOM_H}" width="{ROOM_W}" height="{ROOM_H}" font-family="{FONT}">'
            + ''.join(out) + '</svg>')


FULL15 = SAMPLE[:9] + [('p%d' % i, 'peers', 'peer-%s · 0000000%d' % ('abcdef'[i], i), ['working', 'idle', 'disconnected', 'needs-user-question', 'completed', 'unknown'][i], 'peer', None) for i in range(6)]


def budget():
    """How much of the native Svg budget (131,072 characters) an office of these characters takes."""
    rich = room('dark')
    PREC[0] = 0
    lean11 = lean_room('dark', SAMPLE)
    lean15 = lean_room('dark', FULL15)
    lean0 = lean_room('dark', [])
    write('office-room-native-lean.svg', lean15)
    PREC[0] = 1
    return {
        'limit': 131072,
        'sheetQualityRoom11Workers': len(rich),
        'leanRoomEmpty': len(lean0),
        'leanRoom11Workers': len(lean11),
        'leanRoom15DesksAllFull': len(lean15),
        'leanPerWorker': round((len(lean15) - len(lean0)) / 15),
        'leanHeadroomAt15': 131072 - len(lean15),
        'note': 'sheet quality = gradients, glow, clip paths, cylinder-mapped glyphs, 0.1 px (design only, over budget); '
                'lean = lines, circles, 8-point hulls, whole pixels, no clip/filter/gradient/glyph, the mod-drawable form',
    }


def contrast_table():
    rows = []
    for name, hexv in LIGHTS.items():
        ink = PAL['inkOnOff'] if name == 'off' else PAL['ink']
        panel = PAL['panelOff'] if name == 'off' else hexv
        rows.append({'light': name, 'panel': panel, 'glyph': ink, 'glyphOnPanel': round(contrast(panel, ink), 2),
                     'panelOnBezel': round(contrast(panel, PAL['bezel']), 2), 'bezelOnShell': round(contrast(PAL['bezel'], PAL['shell']['mid']), 2),
                     'chipOnWhitePlate': round(contrast(hexv, '#FFFFFF'), 2)})
    return rows


def main():
    sizes = {
        'turnaround.svg': sheet_turnaround(),
        'state-sheet.svg': sheet_states(),
        'legibility.svg': sheet_legibility(),
        'office-room-dark.svg': write('office-room-dark.svg', room('dark')),
        'office-room-light.svg': write('office-room-light.svg', room('light')),
        'office-room-roomy.svg': write('office-room-roomy.svg', room('dark', workers=ROOMY, selected='a1')),
        'pane-hands.svg': sheet_panes(),
    }
    report = {'sheets': sizes, 'budget': budget(), 'contrast': contrast_table()}
    with open(os.path.join(SHEETS, 'report.json'), 'w', encoding='utf-8') as f:
        json.dump(report, f, indent=2)
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
