"""Blender reference renders of the Office android, built from ../character.json.

Run headless (nothing is installed or saved into Blender's preferences):
  Blender -b --factory-startup -P blender_turnaround.py

Writes ../renders/blender-turnaround.png, ../renders/blender-states.png and one transparent PNG per view in
../renders/views/ (same orthographic scale in every view, so they overlay).
Reuses gen_sheets.py for the pose and body-part definitions, so the 3D
reference and the SVG sheets come from the same numbers. Design reference only.
"""
import math
import os
import sys

import bmesh
import bpy

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gen_sheets as G  # noqa: E402

OUT = os.path.join(G.ROOT, 'renders')
MATS = {}


def lin(hex_color):
    h = hex_color.lstrip('#')
    out = []
    for i in (0, 2, 4):
        c = int(h[i:i + 2], 16) / 255
        out.append(c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4)
    return (*out, 1.0)


def material(name, hex_color, rough=0.45, metal=0.0, emit=0.0, coat=0.0, alpha=1.0):
    name = name + ('-ghost' if alpha < 1 else '')
    if name in MATS:
        return MATS[name]
    m = bpy.data.materials.new(name)
    try:
        m.use_nodes = True
    except Exception:
        pass
    b = m.node_tree.nodes.get('Principled BSDF')
    # An emissive part shows exactly its status color: no lit base color added on top.
    b.inputs['Base Color'].default_value = lin('#050505') if emit else lin(hex_color)
    b.inputs['Roughness'].default_value = rough
    b.inputs['Metallic'].default_value = metal
    if emit:
        b.inputs['Emission Color'].default_value = lin(hex_color)
        b.inputs['Emission Strength'].default_value = emit
    if coat and 'Coat Weight' in b.inputs:
        b.inputs['Coat Weight'].default_value = coat
    if alpha < 1:
        b.inputs['Alpha'].default_value = alpha
    MATS[name] = m
    return m


def link(ob):
    bpy.context.scene.collection.objects.link(ob)
    return ob


def sphere_pts(c, r, nu=12, nv=24):
    pts = [(c[0], c[1], c[2] + r), (c[0], c[1], c[2] - r)]
    for i in range(1, nu):
        th = math.pi * i / nu
        for j in range(nv):
            ph = 2 * math.pi * j / nv
            pts.append((c[0] + r * math.sin(th) * math.cos(ph), c[1] + r * math.sin(th) * math.sin(ph), c[2] + r * math.cos(th)))
    return pts


def hull_obj(name, pts, mat):
    bm = bmesh.new()
    for p in pts:
        bm.verts.new(p)
    res = bmesh.ops.convex_hull(bm, input=bm.verts[:])
    drop = list({v for v in res['geom_interior'] + res['geom_unused'] if isinstance(v, bmesh.types.BMVert)})
    if drop:
        bmesh.ops.delete(bm, geom=drop, context='VERTS')
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me)
    bm.free()
    for poly in me.polygons:
        poly.use_smooth = True
    me.materials.append(mat)
    return link(bpy.data.objects.new(name, me))


def stroke(name, pts, width, mat, closed=False):
    cu = bpy.data.curves.new(name, 'CURVE')
    cu.dimensions = '3D'
    cu.bevel_depth = width / 2
    cu.bevel_resolution = 3
    cu.use_fill_caps = True
    sp = cu.splines.new('POLY')
    sp.points.add(len(pts) - 1)
    for p, q in zip(sp.points, pts):
        p.co = (*q, 1.0)
    sp.use_cyclic_u = closed
    cu.materials.append(mat)
    return link(bpy.data.objects.new(name, cu))


def label(txt, loc, size, mat, yaw=0.0):
    cu = bpy.data.curves.new('label', 'FONT')
    cu.body = txt
    cu.size = size
    cu.align_x = 'CENTER'
    cu.materials.append(mat)
    ob = link(bpy.data.objects.new('label', cu))
    ob.location = loc
    ob.rotation_euler = (math.pi / 2, 0, math.radians(yaw))
    return ob


def build(offset, char_yaw, pose_name, state_id, role, bust=False):
    """One character: pose from character.json, rotated by char_yaw about z, moved to offset."""
    P = G.pose(pose_name)
    st = G.STATES[state_id]
    off = st['light'] == 'off'
    color = G.PAL['panelOff'] if off else G.light_of(st)
    A = 0.38 if st.get('ghost') else 1.0
    base_material = globals()['material']

    def material(*args, **kw):
        return base_material(*args, alpha=A, **kw)

    def W(p):
        return G.add(G.rot_z(p, char_yaw), offset)

    shell = material('shell', '#F2F4F7', 0.32, 0.0, 0.0, 0.35)
    joint = material('joint', '#AEB7C2', 0.3, 0.35)
    role_m = material('role-' + role, G.PAL['role'][role], 0.35, 0.2)
    for i, (mat, sph) in enumerate(G.body_parts(P)):
        if bust and min(c[2] for c, _ in sph) < P['waist'][2] - 4:
            continue
        pts = []
        for c, r in sph:
            pts += sphere_pts(W(c), r)
        hull_obj(f'part{i}', pts, {'shell': shell, 'joint': joint, 'role': role_m}[mat])
    hg, fp, ring = G.GEO['head'], G.GEO['facePanel'], G.GEO['statusRing']
    Rh, H, e = hg['radius'], hg['height'], hg['edgeRound']
    yaw, nod, roll = P['headTurn']
    center = W(tuple(P['head']))

    def T(q):
        return G.add(G.rot_z(G.rot_x(G.rot_y(q, roll), nod), yaw + char_yaw), center)

    pts = []
    for i in range(13):
        t = math.pi / 2 * i / 12
        rr = Rh - e + e * math.sin(t)
        for zz in (-H / 2 + e - e * math.cos(t), H / 2 - e + e * math.cos(t)):
            pts += [T((rr * math.sin(a), -rr * math.cos(a), zz)) for a in (2 * math.pi * j / 64 for j in range(64))]
    hull_obj('head', pts, shell)
    # Status ring
    zr = -H / 2 + ring['zFromHeadBottom']
    d = e - ring['zFromHeadBottom']
    rr = Rh - e + math.sqrt(max(e * e - d * d, 0)) if d > 0 else Rh
    ring_m = material('ring-off', '#4A525C', 0.4) if off else material('ring-' + st['light'], color, 0.4, 0, 1.0)
    stroke('ring', [T(((rr + 0.1) * math.sin(a), -(rr + 0.1) * math.cos(a), zr)) for a in (2 * math.pi * j / 72 for j in range(72))],
           ring['width'], ring_m, True)
    # Bezel and panel: rounded rectangles wrapped on the cylinder.
    zb, zt = -H / 2 + fp['zFromHeadBottom'][0], -H / 2 + fp['zFromHeadBottom'][1]

    def patch(name, rad, grow, mat):
        smax = rad * math.radians(fp['halfAngleDeg']) + grow
        z0, z1, c = zb - grow, zt + grow, fp['cornerRadius'] + grow
        nu, nv = 160, 80
        us = [-smax + 2 * smax * i / nu for i in range(nu + 1)]
        vs = [z0 + (z1 - z0) * j / nv for j in range(nv + 1)]
        bm = bmesh.new()
        grid = {(i, j): bm.verts.new(T((rad * math.sin(u / rad), -rad * math.cos(u / rad), v))) for i, u in enumerate(us) for j, v in enumerate(vs)}
        for i in range(nu):
            for j in range(nv):
                cs, cz = (us[i] + us[i + 1]) / 2, (vs[j] + vs[j + 1]) / 2
                qx, qz = min(max(cs, -smax + c), smax - c), min(max(cz, z0 + c), z1 - c)
                if (cs - qx) ** 2 + (cz - qz) ** 2 <= c * c:
                    bm.faces.new((grid[i, j], grid[i + 1, j], grid[i + 1, j + 1], grid[i, j + 1]))
        loose = [v for v in bm.verts if not v.link_faces]
        bmesh.ops.delete(bm, geom=loose, context='VERTS')
        me = bpy.data.meshes.new(name)
        bm.to_mesh(me)
        bm.free()
        for poly in me.polygons:
            poly.use_smooth = True
        me.materials.append(mat)
        link(bpy.data.objects.new(name, me))

    patch('bezel', Rh + 0.06, fp['bezel'], material('bezel', G.PAL['bezel'], 0.25, 0.1))
    patch('panel', Rh + 0.12, 0, material('panel-off', G.PAL['panelOff'], 0.2) if off else material('panel-' + st['light'], color, 0.3, 0, 1.0))
    # Glyph
    ink = material('ink-off', G.PAL['inkOnOff'], 0.5) if off else material('ink', G.PAL['ink'], 0.45)
    gu = fp['halfAngleDeg'] * 0.55
    gz, gh = (zb + zt) / 2, (zt - zb) / 2 * 0.62

    def gp(u, v):
        a = math.radians(u * gu)
        return T(((Rh + 0.3) * math.sin(a), -(Rh + 0.3) * math.cos(a), gz + v * gh))

    for k, s in enumerate(G.C['glyphs'][st['glyph']]):
        if 'dot' in s:
            hull_obj(f'dot{k}', sphere_pts(gp(*s['dot']), 0.85, 6, 12), ink)
        elif 'circle' in s:
            cx, cy, r = s['circle']
            stroke(f'g{k}', [gp(cx + r * math.cos(t), cy + r * math.sin(t)) for t in (2 * math.pi * j / 48 for j in range(48))], 1.1, ink, True)
        else:
            pts2 = G.densify(s['poly'] + ([s['poly'][0]] if s.get('closed') else []), 0.08)
            stroke(f'g{k}', [gp(u, v) for u, v in pts2], 1.1, ink)


def stage(width, height, ortho, cam_loc, cam_rot_deg, floor=True):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    MATS.clear()
    sc = bpy.context.scene
    for engine in ('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE', 'CYCLES'):
        try:
            sc.render.engine = engine
            break
        except TypeError:
            continue
    if sc.render.engine == 'CYCLES':
        sc.cycles.samples = 48
    else:
        try:
            sc.eevee.taa_render_samples = 32
        except AttributeError:
            pass
    sc.render.resolution_x, sc.render.resolution_y = width, height
    sc.render.resolution_percentage = 100
    sc.view_settings.view_transform = 'Standard'
    world = bpy.data.worlds.new('world')
    sc.world = world
    try:
        world.use_nodes = True
    except Exception:
        pass
    bg = world.node_tree.nodes.get('Background')
    bg.inputs['Color'].default_value = lin('#E9EDF1')
    bg.inputs['Strength'].default_value = 0.9
    cam_data = bpy.data.cameras.new('cam')
    cam_data.type = 'ORTHO'
    cam_data.ortho_scale = ortho
    cam_data.clip_start, cam_data.clip_end = 1, 6000
    cam = link(bpy.data.objects.new('cam', cam_data))
    cam.location = cam_loc
    cam.rotation_euler = tuple(math.radians(a) for a in cam_rot_deg)
    sc.camera = cam
    for name, loc, energy, size in (('key', (-180, -260, 320), 900000, 220), ('fill', (260, -200, 160), 380000, 260),
                                    ('rim', (0, 260, 260), 420000, 200)):
        ld = bpy.data.lights.new(name, 'AREA')
        ld.energy = energy
        ld.size = size
        ob = link(bpy.data.objects.new(name, ld))
        ob.location = loc
        direction = [-c for c in loc]
        ob.rotation_euler = vector_to_euler(direction)
    if floor:
        me = bpy.data.meshes.new('floor')
        me.from_pydata([(-3000, -3000, 0), (3000, -3000, 0), (3000, 3000, 0), (-3000, 3000, 0)], [], [(0, 1, 2, 3)])
        me.materials.append(material('floor', '#E3E7EC', 0.8))
        link(bpy.data.objects.new('floor', me))
    return sc


def vector_to_euler(d):
    from mathutils import Vector
    return Vector(d).to_track_quat('-Z', 'Y').to_euler()


def render(sc, name):
    os.makedirs(OUT, exist_ok=True)
    sc.render.filepath = os.path.join(OUT, name)
    bpy.ops.render.render(write_still=True)
    print('wrote', sc.render.filepath, 'engine', sc.render.engine)


def turnaround():
    views = [(0, 'FRONT'), (45, '3/4 FRONT'), (90, 'SIDE · RIGHT'), (135, '3/4 BACK'), (180, 'BACK')]
    gap = 78
    width = gap * (len(views) - 1)
    sc = stage(2400, 1100, 520, (width / 2, -1500, 88), (90, 0, 0))
    ink = material('label', '#1B1D22', 0.6)
    for i, (yaw, name) in enumerate(views):
        # Turning the character by +yaw shows what a camera at yaw `yaw` sees in the SVG sheets.
        build((i * gap, 0, 0), yaw, 'stand', 'working', 'main')
        label(name, (i * gap, -40, -16), 7, ink)
    label('Office android v0.1 · Blender reference (design) · panel: Working', (width / 2, -40, 194), 6, ink)
    render(sc, 'blender-turnaround.png')


def states():
    ids = G.STATE_ORDER
    gap = 54
    width = gap * (len(ids) - 1)
    sc = stage(2600, 760, width + 50, (width / 2, -1500, 128 + 1500 * math.tan(math.radians(6))), (84, 0, 0), floor=False)
    ink = material('label', '#1B1D22', 0.6)
    for i, sid in enumerate(ids):
        build((i * gap, 0, 0), 28, 'stand', sid, 'subagent', bust=True)
        label(G.STATES[sid]['label'].split(' · ')[0], (i * gap, -30, 98), 3.0, ink)
    render(sc, 'blender-states.png')


def views():
    """Front, three-quarter, profile and back as separate transparent images at one shared scale."""
    version = G.C['version'].split('-')[0]
    for yaw, name in ((0, 'front'), (45, 'three-quarter'), (90, 'profile-right'), (180, 'back')):
        sc = stage(1000, 1400, 206, (0, -1500, 91), (90, 0, 0), floor=False)
        sc.render.film_transparent = True
        build((0, 0, 0), yaw, 'stand', 'working', 'main')
        render(sc, os.path.join('views', f'office-android-v{version}-{name}.png'))


if __name__ == '__main__':
    turnaround()
    states()
    views()
