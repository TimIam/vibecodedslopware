# Agent Office 3D

A Claude Code mod that turns your sessions into a walkable 3D office.

- **A looping hallway of rooms.** Room 1 is the Agent Arcade, room 2 your own office, room 3 the escape room; every
  project (a session's working folder) has a room the first time one of its sessions appears, and keeps its place.
  Walk past the last room and you are back at the first.
- **Every project is in the office.** A session joins the office when it starts, so its room, its desks and its agents
  appear in every office window on this machine. The small in-app pane (`/office`) has one button into the window and
  one that removes this project from the office, or adds it back; a removed project stays out until you add it.
- **Your conversation and its agents at desks.** Each session has a bay: its lead desk at the front, its subagents
  clustered behind, a divider between bays. Status lights and raised hands come only from real evidence (a hand means a
  real pending question or permission prompt, which you answer in Claude Code itself; the office never approves anything).
- **Sit down to talk.** Walk up to any desk, press `E`: its conversation opens and what you type goes to that agent, or
  to your own conversation as your own prompt.
- **The Agent Arcade.** Chess, tic-tac-toe, Connect Four, checkers and Bones (Knucklebones). Sit in a chair, play
  yourself or seat an agent (a model and an effort level) on either side; the rules are enforced in the mod, so an
  agent's illegal move is bounced back with the reason until it plays a legal one.
- **Your own office.** A desk of your own with a wide monitor: sit down and share a window (the browser's own picker)
  to see it on the monitor, live. The picture stays in the page; nothing is sent anywhere and no browser data is read.
- **The escape room.** Pick a themed room, inspect its objects, try its locks, and seat an AI teammate who is told only
  what you have found: the answers exist only as hashes, so it cannot know them.
- **The kanban wall.** Your project's `KANBAN.md`, `ROADMAP.md`, `TODO.md` or `TASKS.md` on the wall of its room;
  walk up, press `E`, and tick, move, add, edit or remove cards: every change is written back into the file, by line.
- **The world editor.** Press `G` (or `/3d design <words>`) and ask in words: flowers on my desk, a bigger desk for
  agent 2, a blue carpet in the arcade, make my room bigger. The model answers with validated data, never code; you see
  a translucent preview, then apply, undo or reset. The scene is saved with a known-good snapshot.

Commands: `/3d` (the window), `/3d close`, `/3d arcade …`, `/3d design …`, `/3d kanban …`, `/3d escape …`,
`/office` (the pane: enter | add | remove | status), `/museum` (the gallery of enrolled conversations).

Keys in the window: `W A S D` move, mouse look, `Shift` run, `Space` jump, `E` sit / stand / open what you face,
`T` message, `Tab` conversation, `1`–`9` walk to a room, `0` the entrance, `G` world editor, `F` fullscreen, `Esc` stand up.

Options (Claude Code's plugin settings): *Show the Agent Office pane when a session starts* (on) and *Put every project
in the office* (on; off means only `/museum enroll` joins).

## Requirements

- Claude Code with mods (the desktop app's engine, 2.1.299 or later).
- Node.js 22+ on your PATH (the window's local bridge is a Node script).
- Chrome or Edge (the window is a fullscreen app window with its own profile).

## Install

Copy this folder to `~/.claude/skills/agent-office-3d/` (the plugin loads from there in every session), or start a
session with `--plugin-dir <this folder>`. Then, in a new session, press the button in the Agent Office pane, or run `/3d`.

To remove it, delete that folder. The mod keeps nothing else on your machine except its own browser profile under
`~/.claude/agent-office-3d/`, and, in the engine's plugin store, each live session's office record (deleted when the
session ends or leaves), the marks of projects you removed from the office, and the world editor's scene
(`/3d design reset` empties it).

## What it talks to

Everything stays on your machine. A session in the office publishes a bounded summary of itself (its label, project
folder name, status, whether it waits on you, its agents' states, and a short inert snapshot of its own transcript) to
the engine's local plugin store, where other sessions on this machine with this mod read it; never its files, and never
anything off the machine. Remove a project from the pane and its sessions publish nothing. The window is served from
`127.0.0.1` by a process the mod starts for the session, reachable only with a per-launch token; it exchanges state and
commands with the mod through files, and closes with the window. Agents in the arcade, the escape-room teammate and the
world editor are model calls made through your own session's client, with no tools and no history: the position and
the legal moves, the clues you found, or the editing vocabulary and the scene, nothing else. The kanban wall reads and
writes one markdown file in this session's working folder.

## Development

`claude plugin validate .` and `claude plugin test .` from this folder, with the desktop app's engine (2.1.299+).
Feature docs: `docs/DESIGN.md` (the world editor), `docs/ESCAPE.md`, `docs/KANBAN.md`. The rules of each arcade game are
a module under `src/arcade/` written to `src/arcade/rules.ts`, with a board drawer under `game/boards/`; the chess
engine is verified against the standard perft counts.

## License

Apache-2.0. See `LICENSE`. `docs/PROVENANCE.md` records the two small pieces of placement math reused from the author's
own earlier project.
