// Enrollment records shared through the mod's machine-wide $.store, and the
// receipts a receiving loop keeps about museum messages.
//
// Each enrolled conversation writes only its own key, museum.v1.session.<id>,
// as the docs' "Save from more than one session" advises, so sessions never
// overwrite each other. Every record read back is untrusted: it is validated
// field by field and made inert again before anything draws it.

import type { MuseumAgent, MuseumLine, MuseumNeedsUser, MuseumReceipt, MuseumRecord, TurnReason } from '../types'
import { inert, oneLine } from './sanitize'

export const KEY_PREFIX = 'museum.v1.session.'
export const SNAPSHOT_LINES = 24
export const LINE_CHARS = 600
export const LABEL_CHARS = 60
export const NEEDS_USER_CHARS = 400
export const ANSWER_HEAD_CHARS = 160
export const MAX_RECEIPTS = 20
export const STALE_MS = 20_000
export const NONCE_PATTERN = /MUSEUM-NONCE-[0-9a-f]{12}/

const SESSION_ID = /^[A-Za-z0-9_-]{6,128}$/
const REASONS: readonly TurnReason[] = ['answer', 'aborted', 'refusal', 'error']

export const keyFor = (sessionId: string): string => KEY_PREFIX + sessionId

export const findNonce = (text: string): string | null => NONCE_PATTERN.exec(text)?.[0] ?? null

/** The fields of a transcript message the snapshot reads (SessionMessage's). */
export type MessageLike = { role: 'user' | 'assistant'; text: string; toolUses?: readonly unknown[] }

const finite = (value: unknown): number | null =>
  typeof value === 'number' && Number.isFinite(value) ? value : null

/** A receipt read back from untrusted data, or null. */
export function parseReceipt(item: unknown): MuseumReceipt | null {
  if (typeof item !== 'object' || item === null) return null
  const r = item as Record<string, unknown>
  const nonce = typeof r.nonce === 'string' ? findNonce(r.nonce) : null
  const arrivedAt = finite(r.arrivedAt)
  if (nonce === null || nonce !== r.nonce || arrivedAt === null) return null
  const reason = REASONS.find(x => x === r.turnReason) ?? null
  return {
    nonce,
    arrivedAt,
    originKind: oneLine(r.originKind, 40) || 'unknown',
    claimedPlugin: typeof r.claimedPlugin === 'string' ? oneLine(r.claimedPlugin, 64) : null,
    inConversationAt: finite(r.inConversationAt),
    turnStartedAt: finite(r.turnStartedAt),
    turnId: typeof r.turnId === 'string' ? oneLine(r.turnId, 80) : null,
    turnCarriesNonce: r.turnCarriesNonce === true,
    turnEndedAt: finite(r.turnEndedAt),
    turnReason: reason,
    turnAnswerHead: typeof r.turnAnswerHead === 'string' ? oneLine(r.turnAnswerHead, ANSWER_HEAD_CHARS) : null,
    acknowledged: r.acknowledged === true,
  }
}

function parseNeedsUser(value: unknown): MuseumNeedsUser {
  if (typeof value !== 'object' || value === null) return null
  const { kind, text } = value as Record<string, unknown>
  if (kind !== 'question' && kind !== 'approval') return null
  return { kind, text: inert(text, NEEDS_USER_CHARS) }
}

/** A record read back from the store, or null when it is not one. */
export function parseRecord(value: unknown): MuseumRecord | null {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return null
  const raw = value as Record<string, unknown>
  const sessionId = raw.sessionId
  const enrolledAt = finite(raw.enrolledAt)
  const heartbeatAt = finite(raw.heartbeatAt)
  if (raw.v !== 1 || typeof sessionId !== 'string' || !SESSION_ID.test(sessionId)) return null
  if (enrolledAt === null || heartbeatAt === null) return null
  const snapshot: MuseumLine[] = Array.isArray(raw.snapshot)
    ? raw.snapshot.slice(-SNAPSHOT_LINES).flatMap(line => {
        if (typeof line !== 'object' || line === null) return []
        const { role, text } = line as Record<string, unknown>
        if (role !== 'user' && role !== 'assistant') return []
        return [{ role, text: inert(text, LINE_CHARS) }]
      })
    : []
  const receipts = Array.isArray(raw.receipts)
    ? raw.receipts.slice(-MAX_RECEIPTS).flatMap(item => {
        const r = parseReceipt(item)
        return r === null ? [] : [r]
      })
    : []
  const label = oneLine(raw.label, LABEL_CHARS) || sessionId.slice(0, 8)
  return {
    v: 1,
    sessionId,
    label,
    // A record written before projects were published: the label's first part is the folder it was made from.
    project: oneLine(raw.project, PROJECT_CHARS) || label.split(' · ')[0] || 'project',
    enrolledAt,
    heartbeatAt,
    status: raw.status === 'busy' ? 'busy' : 'idle',
    needsUser: parseNeedsUser(raw.needsUser),
    messageCount: Math.max(0, Math.floor(finite(raw.messageCount) ?? 0)),
    snapshot,
    receipts,
    agents: parseAgents(raw.agents),
  }
}

export const PROJECT_CHARS = 60
export const MAX_AGENTS = 24
const LIGHTS: ReadonlySet<string> = new Set(['green', 'yellow', 'red', 'off'])

/** The agents a record lists, each bounded and inert; anything malformed is dropped, never guessed. */
export function parseAgents(value: unknown): MuseumAgent[] {
  if (!Array.isArray(value)) return []
  return value.slice(0, MAX_AGENTS).flatMap(item => {
    if (typeof item !== 'object' || item === null) return []
    const a = item as Record<string, unknown>
    const key = oneLine(a.key, 120)
    if (key === '') return []
    const light = typeof a.light === 'string' && LIGHTS.has(a.light) ? (a.light as MuseumAgent['light']) : 'off'
    const hand = a.hand === 'question' || a.hand === 'approval' ? a.hand : null
    return [{ key, name: oneLine(a.name, 60) || key, state: oneLine(a.state, 24) || 'unknown', stateLabel: oneLine(a.stateLabel, 40) || 'Unknown', light, hand }]
  })
}

/** The last lines of a conversation's own transcript, bounded and inert. */
export function buildSnapshot(messages: readonly MessageLike[]): MuseumLine[] {
  const lines: MuseumLine[] = []
  for (const message of messages) {
    const text = inert(message.text, LINE_CHARS).trim()
    const tools = message.toolUses?.length ?? 0
    if (text === '' && tools === 0) continue
    lines.push({ role: message.role, text: text === '' ? `[used ${tools} tool${tools === 1 ? '' : 's'}]` : text })
  }
  return lines.slice(-SNAPSHOT_LINES)
}

/** Adds the arrival of one museum message, once per nonce, newest kept. */
export function addReceipt(
  receipts: readonly MuseumReceipt[],
  arrival: { nonce: string; at: number; originKind: string; claimedPlugin: string | null },
): MuseumReceipt[] {
  if (receipts.some(r => r.nonce === arrival.nonce)) return [...receipts]
  const receipt: MuseumReceipt = {
    nonce: arrival.nonce,
    arrivedAt: arrival.at,
    originKind: oneLine(arrival.originKind, 40) || 'unknown',
    claimedPlugin: arrival.claimedPlugin === null ? null : oneLine(arrival.claimedPlugin, 64),
    inConversationAt: null,
    turnStartedAt: null,
    turnId: null,
    turnCarriesNonce: false,
    turnEndedAt: null,
    turnReason: null,
    turnAnswerHead: null,
    acknowledged: false,
  }
  return [...receipts, receipt].slice(-MAX_RECEIPTS)
}

/** The loop's next turn started: each arrived receipt not yet linked to a turn is linked to this one. */
export function noteTurnStart(receipts: readonly MuseumReceipt[], turn: { turnId: string; text: string; at: number }): MuseumReceipt[] {
  return receipts.map(r =>
    r.turnStartedAt !== null || r.arrivedAt > turn.at
      ? r
      : { ...r, turnStartedAt: turn.at, turnId: turn.turnId, turnCarriesNonce: turn.text.includes(r.nonce) },
  )
}

/** A turn of the loop ended: receipts linked to it record how, with the start of its final text. */
export function noteTurnEnd(
  receipts: readonly MuseumReceipt[],
  turn: { turnId: string; reason: TurnReason; answer: string; at: number },
): MuseumReceipt[] {
  return receipts.map(r =>
    r.turnId !== turn.turnId || r.turnEndedAt !== null
      ? r
      : {
          ...r,
          turnEndedAt: turn.at,
          turnReason: turn.reason,
          turnAnswerHead: oneLine(turn.answer, ANSWER_HEAD_CHARS),
          acknowledged: turn.answer.includes(`ACK ${r.nonce}`),
        },
  )
}

/** Marks receipts whose nonce a row of the loop's own transcript now carries. */
export function noteConversation(receipts: readonly MuseumReceipt[], messages: readonly MessageLike[], now: number): MuseumReceipt[] {
  return receipts.map(r =>
    r.inConversationAt !== null || !messages.some(m => m.text.includes(r.nonce)) ? r : { ...r, inConversationAt: now },
  )
}

/** True while a receipt still waits on something its loop has not shown yet. */
export const isOpenReceipt = (r: MuseumReceipt): boolean => r.turnEndedAt === null
