// A kanban board kept in a markdown file: pure parsing and serialising.
//
// Three file shapes are read, in order of preference:
//   1. `## <column>` headings, each followed by a task list (`- [ ] text`,
//      `- [x] text`), nested indented lines being part of the card's text;
//   2. headings with plain bullet lists under them (one column per heading,
//      every bullet a card that is not done);
//   3. task or bullet lists with no headings at all: one column, "Tasks".
// In every shape a card is a list item that is not nested under another:
// a task item or a plain bullet. Fenced code blocks are skipped entirely.
//
// Everything else in the file (prose, code blocks, headings of other
// levels, ordered lists) is left alone: `serialize` rewrites only the list
// lines it knows by line number, with the smallest span each change needs,
// and the rest of the file comes back byte for byte (line endings included).

export type KanbanCard = {
  /** A stable hash of the column name and the card's text. */
  id: string
  /** The card's text; a nested continuation keeps its lines, joined with `\n`. */
  text: string
  done: boolean
  /** The 1-based line of the card's first line in the file (0 for a card not yet written). */
  line: number
}
export type KanbanColumn = { name: string; cards: KanbanCard[] }
export type KanbanBoard = { title: string; columns: KanbanColumn[] }
/** Which file shape was read: task lists under headings, bullets under headings, lists with no headings, or nothing. */
export type KanbanShape = 'tasks' | 'bullets' | 'flat' | 'none'

type Item = {
  /** 0-based line indexes of the item's span, inclusive. */
  start: number
  end: number
  indent: string
  bullet: string
  isTask: boolean
  done: boolean
  text: string
}
type Section = {
  name: string
  /** 0-based line of the heading, or -1 for the headingless "Tasks" column. */
  headingLine: number
  items: Item[]
}
type Parsed = { title: string; sections: Section[]; hasTasks: boolean; shape: KanbanShape; lines: string[] }

const HEADING = /^(#{1,6})[ \t]+(.*?)[ \t]*#*[ \t]*$/
const ITEM = /^([ \t]*)([-*+])[ \t]+(?:\[([ xX])\][ \t]*)?(.*)$/
const FENCE = /^[ \t]{0,3}(```|~~~)/

const stripCr = (line: string): string => (line.endsWith('\r') ? line.slice(0, -1) : line)

/** FNV-1a (32-bit) of a string, as 8 hex digits. */
function fnv1a(text: string): string {
  let h = 0x811c9dc5
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i)
    h = Math.imul(h, 0x01000193) >>> 0
  }
  return h.toString(16).padStart(8, '0')
}

/** A card's id: a stable hash of its column's name and its text. Duplicates in one board get `-2`, `-3`… appended, in order. */
export const cardId = (column: string, text: string): string => fnv1a(`${column}\n${text}`)

function parseDetailed(text: string): Parsed {
  const lines = text.split('\n')
  const headings: { line: number; level: number; text: string }[] = []
  const items: Item[] = []
  let inFence: string | null = null
  let open: Item | null = null
  const close = () => {
    open = null
  }
  for (let i = 0; i < lines.length; i++) {
    const raw = stripCr(lines[i]!)
    const fence = FENCE.exec(raw)
    if (fence !== null) {
      if (inFence === null) inFence = fence[1]!
      else if (fence[1] === inFence) inFence = null
      close()
      continue
    }
    if (inFence !== null) continue
    if (raw.trim() === '') {
      close()
      continue
    }
    const h = HEADING.exec(raw)
    if (h !== null) {
      headings.push({ line: i, level: h[1]!.length, text: h[2]! })
      close()
      continue
    }
    const indentLen = raw.length - raw.trimStart().length
    if (open !== null && indentLen > open.indent.length) {
      // Nested under the open item: part of its text, its own extra indent kept.
      const current: Item = open
      current.end = i
      current.text += '\n' + (raw.startsWith(current.indent) ? raw.slice(current.indent.length) : raw.trimStart())
      continue
    }
    const m = ITEM.exec(raw)
    if (m !== null) {
      const item: Item = { start: i, end: i, indent: m[1]!, bullet: m[2]!, isTask: m[3] !== undefined, done: m[3] === 'x' || m[3] === 'X', text: m[4]! }
      items.push(item)
      open = item
      continue
    }
    close()
  }
  const level2 = headings.filter(h => h.level === 2)
  const level1 = headings.filter(h => h.level === 1)
  const columnLevel = level2.length > 0 ? 2 : level1.length > 1 ? 1 : 0
  const title = columnLevel === 1 ? '' : (level1[0]?.text ?? '')
  const columnHeadings = headings.filter(h => h.level === columnLevel)
  const sections: Section[] = []
  if (columnLevel === 0) {
    if (items.length > 0) sections.push({ name: 'Tasks', headingLine: -1, items })
  } else {
    const before = items.filter(it => it.start < columnHeadings[0]!.line)
    if (before.length > 0) sections.push({ name: 'Tasks', headingLine: -1, items: before })
    columnHeadings.forEach((h, k) => {
      const next = columnHeadings[k + 1]?.line ?? Infinity
      sections.push({ name: h.text, headingLine: h.line, items: items.filter(it => it.start > h.line && it.start < next) })
    })
  }
  const hasTasks = items.some(it => it.isTask)
  const shape: KanbanShape = sections.length === 0 ? 'none' : columnLevel === 0 ? 'flat' : hasTasks ? 'tasks' : 'bullets'
  return { title, sections, hasTasks, shape, lines }
}

/** Ids for every item, column by column, duplicates numbered in order. */
function assignIds(sections: Section[]): string[][] {
  const seen = new Map<string, number>()
  return sections.map(s =>
    s.items.map(it => {
      const base = cardId(s.name, it.text)
      const n = (seen.get(base) ?? 0) + 1
      seen.set(base, n)
      return n === 1 ? base : `${base}-${n}`
    }),
  )
}

function boardOf(p: Parsed): KanbanBoard {
  const ids = assignIds(p.sections)
  return {
    title: p.title,
    columns: p.sections.map((s, si) => ({
      name: s.name,
      cards: s.items.map((it, k) => ({ id: ids[si]![k]!, text: it.text, done: it.done, line: it.start + 1 })),
    })),
  }
}

/** The board a markdown file holds (no columns when it holds no list and no column heading). */
export function parse(text: string): KanbanBoard {
  return boardOf(parseDetailed(text))
}

/** Which file shape `parse` read. */
export function shapeOf(text: string): KanbanShape {
  return parseDetailed(text).shape
}

/** A card's lines as they are written: the item line, then its continuation lines under the same indent. */
function render(card: KanbanCard, indent: string, bullet: string, mark: '' | '[ ] ' | '[x] ', cr: string): string[] {
  const parts = card.text.split('\n')
  return [`${indent}${bullet} ${mark}${parts[0] ?? ''}${cr}`, ...parts.slice(1).map(l => `${indent}${l}${cr}`)]
}

type Op = { at: number; remove: number; insert: string[] }

/**
 * The file's text with `board`'s changes written into it: a card whose text
 * or done state changed is rewritten in place; a card moved between columns
 * leaves one list and is appended to the other; a new card is appended to
 * its column's list; a card gone from the board has its lines removed. Cards
 * are matched to the file by id, so `board` must come from `parse` of this
 * same text (or of an earlier text whose cards still exist). Every other
 * line is kept as it was. Throws on a column the file does not have.
 */
export function serialize(board: KanbanBoard, originalText: string): string {
  const p = parseDetailed(originalText)
  const lines = p.lines.slice()
  const cr = lines.some(l => l.endsWith('\r')) ? '\r' : ''
  const ids = assignIds(p.sections)
  const origCards = new Map<string, { section: number; item: Item }>()
  p.sections.forEach((s, si) => s.items.forEach((it, k) => origCards.set(ids[si]![k]!, { section: si, item: it })))
  const sectionIndex = (name: string): number => {
    const exact = p.sections.findIndex(s => s.name === name)
    return exact >= 0 ? exact : p.sections.findIndex(s => s.name.toLowerCase() === name.toLowerCase())
  }
  const ops: Op[] = []
  const appends = new Map<number, string[]>()
  const seen = new Set<string>()
  const markFor = (card: KanbanCard, wasTask: boolean | null): '' | '[ ] ' | '[x] ' => (card.done ? '[x] ' : (wasTask ?? p.hasTasks) ? '[ ] ' : '')
  for (const column of board.columns) {
    const si = sectionIndex(column.name)
    if (si < 0) {
      if (column.cards.length === 0) continue
      throw new Error(`The file has no column named "${column.name}".`)
    }
    const section = p.sections[si]!
    const last = section.items.at(-1)
    const indent = last?.indent ?? ''
    const bullet = last?.bullet ?? '-'
    for (const card of column.cards) {
      if (seen.has(card.id)) continue
      seen.add(card.id)
      const orig = origCards.get(card.id)
      if (orig !== undefined && orig.section === si) {
        const it = orig.item
        if (it.text !== card.text || it.done !== card.done) {
          ops.push({ at: it.start, remove: it.end - it.start + 1, insert: render(card, it.indent, it.bullet, markFor(card, it.isTask), cr) })
        }
        continue
      }
      if (orig !== undefined) ops.push({ at: orig.item.start, remove: orig.item.end - orig.item.start + 1, insert: [] })
      const list = appends.get(si) ?? []
      list.push(...render(card, indent, bullet, markFor(card, orig?.item.isTask ?? null), cr))
      appends.set(si, list)
    }
  }
  for (const [id, orig] of origCards) {
    if (!seen.has(id)) ops.push({ at: orig.item.start, remove: orig.item.end - orig.item.start + 1, insert: [] })
  }
  for (const [si, insert] of appends) {
    const section = p.sections[si]!
    const last = section.items.at(-1)
    let at: number
    if (last !== undefined) at = last.end + 1
    else if (section.headingLine >= 0) {
      at = section.headingLine + 1
      if (at < lines.length && stripCr(lines[at]!).trim() === '' && at + 1 < lines.length) at += 1
    } else at = lines.length > 0 && lines.at(-1) === '' ? lines.length - 1 : lines.length
    ops.push({ at, remove: 0, insert })
  }
  // Bottom up, so every op's line index is the original file's; at one index a removal goes before an insertion.
  ops.sort((a, b) => b.at - a.at || b.remove - a.remove)
  for (const op of ops) lines.splice(op.at, op.remove, ...op.insert)
  return lines.join('\n')
}

// ─── Board edits (pure; the hook checks the arguments first) ──────────────
const clone = (board: KanbanBoard): KanbanBoard => ({ title: board.title, columns: board.columns.map(c => ({ name: c.name, cards: c.cards.map(k => ({ ...k })) })) })

/** The column holding `id`, and the card, or null. */
export function findCard(board: KanbanBoard, id: string): { column: KanbanColumn; card: KanbanCard } | null {
  for (const column of board.columns) {
    const card = column.cards.find(c => c.id === id)
    if (card !== undefined) return { column, card }
  }
  return null
}

/** The column named `name` (exact, then case-insensitive), or null. */
export function findColumn(board: KanbanBoard, name: string): KanbanColumn | null {
  return board.columns.find(c => c.name === name) ?? board.columns.find(c => c.name.toLowerCase() === name.toLowerCase()) ?? null
}

export function toggleCard(board: KanbanBoard, id: string): KanbanBoard {
  const next = clone(board)
  const hit = findCard(next, id)
  if (hit === null) throw new Error('no such card')
  hit.card.done = !hit.card.done
  return next
}

export function editCard(board: KanbanBoard, id: string, text: string): KanbanBoard {
  const next = clone(board)
  const hit = findCard(next, id)
  if (hit === null) throw new Error('no such card')
  hit.card.text = text
  return next
}

export function removeCard(board: KanbanBoard, id: string): KanbanBoard {
  const next = clone(board)
  const hit = findCard(next, id)
  if (hit === null) throw new Error('no such card')
  hit.column.cards = hit.column.cards.filter(c => c.id !== id)
  return next
}

export function moveCard(board: KanbanBoard, id: string, column: string): KanbanBoard {
  const next = clone(board)
  const hit = findCard(next, id)
  const to = findColumn(next, column)
  if (hit === null) throw new Error('no such card')
  if (to === null) throw new Error('no such column')
  if (to === hit.column) return next
  hit.column.cards = hit.column.cards.filter(c => c.id !== id)
  to.cards.push({ ...hit.card, line: 0 })
  return next
}

export function addCard(board: KanbanBoard, column: string, text: string): KanbanBoard {
  const next = clone(board)
  const to = findColumn(next, column)
  if (to === null) throw new Error('no such column')
  to.cards.push({ id: cardId(to.name, text), text, done: false, line: 0 })
  return next
}
