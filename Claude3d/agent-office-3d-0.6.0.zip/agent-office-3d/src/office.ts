// The agent office: which workers exist and what state each is in, derived
// only from supported evidence. A worker is an actual identity: this
// conversation's own loop, an agent `$.agent.list()` lists, or a peer session
// that explicitly enrolled. Nothing here invents a worker or an activity.
//
// Evidence → state (docs/OFFICE.md has the full table):
//   needs user        an AskUserQuestion call of that loop is in flight, or a
//                     permission dialog was shown for one of its calls
//                     (classic.PermissionRequest), or an enrolled peer published
//                     the same from its own hooks
//   failed            $.agent.list() status `failed`/`killed`; this conversation's
//                     last turn ended in `error`/`refusal`
//   waiting external  a turn is running and that loop has a call in flight to an
//                     external service (WebFetch, WebSearch, an MCP tool)
//   working           $.agent.list() `running`; this conversation's turn running;
//                     a peer's own record says busy
//   completed         $.agent.list() `completed`
//   idle              $.agent.list() `idle`/`pending`; no turn running here; a
//                     peer's own record says idle
//   unknown           $.agent.list() `waiting` (held: the API does not say on what),
//                     a peer whose heartbeat stopped, anything else
//
// An agent the list stops carrying keeps a bounded desk ("· not listed") with
// its last listed status, because a completed general-purpose or custom
// subagent stays addressable (a message resumes it); Explore and Plan are
// one-shot and stopped agents refuse messages, so those get no Send.

import type { MuseumFrame, OfficeAgent, OfficePending, OfficeRetired, OfficeTurn, SendTarget } from '../types'
import { oneLine } from './sanitize'

export type OfficeState = 'working' | 'needs-user' | 'waiting-external' | 'failed' | 'completed' | 'idle' | 'unknown'
export type Light = 'green' | 'yellow' | 'red' | 'off'

/** Each state's light, icon and label: color never carries a state alone. */
export const STATE_STYLE: Record<OfficeState, { light: Light; icon: string; label: string }> = {
  working: { light: 'green', icon: '⚙', label: 'Working' },
  'needs-user': { light: 'red', icon: '✋', label: 'Needs you' },
  'waiting-external': { light: 'yellow', icon: '⏳', label: 'Waiting on external' },
  failed: { light: 'red', icon: '✕', label: 'Failed' },
  completed: { light: 'green', icon: '✓', label: 'Completed' },
  idle: { light: 'yellow', icon: '◌', label: 'Idle' },
  unknown: { light: 'off', icon: '?', label: 'Unknown' },
}

export type WorkerKind = 'main' | 'subagent' | 'teammate' | 'peer'

export type OfficeWorker = {
  /** `main`, `agent:<id>` or `peer:<sessionId>`. */
  key: string
  kind: WorkerKind
  group: 'session' | 'peers'
  name: string
  detail: string
  state: OfficeState
  /** The state's label, or a more exact one (Stopped, Held, Disconnected, Not started). */
  stateLabel: string
  light: Light
  icon: string
  /** Where the state came from, in words. */
  evidence: string
  hand: { kind: 'question' | 'approval'; text: string } | null
  /** Where an explicit instruction would go; null when the office offers no Send for it. */
  target: SendTarget | null
  /** Why there is no Send, when `target` is null. */
  noSendReason: string | null
  /** False for an agent $.agent.list() no longer carries (kept because it stays addressable). */
  isListed: boolean
}

/**
 * The built-in Explore and Plan agents are one-shot: the docs say they cannot
 * be resumed, so a message cannot continue them. General-purpose and custom
 * subagents resume from their transcript; one the person stopped refuses it.
 */
export const ONE_SHOT_TYPES: ReadonlySet<string> = new Set(['Explore', 'Plan'])

export function agentSendBlock(agent: Pick<OfficeAgent, 'type' | 'status'>): string | null {
  if (ONE_SHOT_TYPES.has(agent.type)) return `${agent.type} agents are one-shot: the docs say they cannot be resumed, so the office offers no Send.`
  if (agent.status === 'killed') return 'Stopped: a message to a subagent its person stopped is refused, so the office offers no Send.'
  return null
}

export const EXTERNAL_TOOL = (tool: string): boolean => tool === 'WebFetch' || tool === 'WebSearch' || tool.startsWith('mcp__')

export const identityOf = (agentId: string | undefined): string => (agentId === undefined ? 'main' : `agent:${agentId}`)

type Derived = Pick<OfficeWorker, 'state' | 'stateLabel' | 'evidence' | 'hand'>

function withStyle(base: Omit<OfficeWorker, 'light' | 'icon'>): OfficeWorker {
  const style = STATE_STYLE[base.state]
  return { ...base, light: style.light, icon: style.icon }
}

function handOf(pending: readonly OfficePending[]): OfficeWorker['hand'] {
  const ask = pending.find(p => p.kind === 'question') ?? pending.find(p => p.kind === 'approval')
  return ask === undefined || ask.kind === 'external' ? null : { kind: ask.kind, text: ask.text }
}

function needsUser(hand: NonNullable<OfficeWorker['hand']>, pending: readonly OfficePending[]): Derived {
  const tool = pending.find(p => p.kind === hand.kind)?.tool ?? ''
  return {
    state: 'needs-user',
    stateLabel: hand.kind === 'question' ? 'Needs you: question' : 'Needs you: approval',
    evidence:
      hand.kind === 'question'
        ? 'an AskUserQuestion call is in flight (tool.call hook)'
        : `a permission dialog was shown for ${tool || 'a tool call'} (classic.PermissionRequest)`,
    hand,
  }
}

function running(pending: readonly OfficePending[], what: string): Derived {
  const external = pending.find(p => p.kind === 'external')
  return external === undefined
    ? { state: 'working', stateLabel: 'Working', evidence: what, hand: null }
    : { state: 'waiting-external', stateLabel: `Waiting on ${oneLine(external.tool, 40)}`, evidence: `${what}; a ${oneLine(external.tool, 40)} call is in flight`, hand: null }
}

function mainState(turn: OfficeTurn | undefined, pending: readonly OfficePending[]): Derived {
  const hand = handOf(pending)
  if (hand !== null) return needsUser(hand, pending)
  if (turn?.isRunning) return running(pending, 'a turn is running (turn.start without turn.complete)')
  if (turn?.lastReason === 'error' || turn?.lastReason === 'refusal') {
    return { state: 'failed', stateLabel: `Failed (${turn.lastReason})`, evidence: `the last turn ended with reason "${turn.lastReason}" (turn.complete)`, hand: null }
  }
  if (turn === undefined) return { state: 'unknown', stateLabel: 'Unknown', evidence: 'no turn seen since the office loaded', hand: null }
  return { state: 'idle', stateLabel: 'Idle', evidence: 'no turn running (turn.complete)', hand: null }
}

function agentState(agent: OfficeAgent, pending: readonly OfficePending[]): Derived {
  const listed = `$.agent.list() says "${agent.status}"`
  const hand = handOf(pending)
  if (hand !== null && (agent.status === 'running' || agent.status === 'waiting')) return needsUser(hand, pending)
  switch (agent.status) {
    case 'running':
      return running(pending, listed)
    case 'failed':
      return { state: 'failed', stateLabel: 'Failed', evidence: listed, hand: null }
    case 'killed':
      return { state: 'failed', stateLabel: 'Stopped', evidence: listed, hand: null }
    case 'completed':
      return { state: 'completed', stateLabel: 'Completed', evidence: listed, hand: null }
    case 'idle':
      return { state: 'idle', stateLabel: 'Idle', evidence: listed, hand: null }
    case 'pending':
      return { state: 'idle', stateLabel: 'Not started', evidence: listed, hand: null }
    case 'waiting':
      return {
        state: 'unknown',
        stateLabel: 'Held (reason not exposed)',
        evidence: `${listed}: held on background work, a plan's approval or an Agent call; the API does not say which`,
        hand: null,
      }
  }
}

function peerState(peer: MuseumFrame, now: number): Derived {
  if (peer.isStale) {
    return {
      state: 'unknown',
      stateLabel: 'Disconnected',
      evidence: `its own record has not been refreshed for ${Math.round((now - peer.heartbeatAt) / 1000)} s`,
      hand: null,
    }
  }
  if (peer.needsUser !== null) {
    return {
      state: 'needs-user',
      stateLabel: peer.needsUser.kind === 'question' ? 'Needs its person: question' : 'Needs its person: approval',
      evidence: 'as that session published from its own hooks',
      hand: peer.needsUser,
    }
  }
  return peer.status === 'busy'
    ? { state: 'working', stateLabel: 'Working', evidence: 'its own record says a turn is running', hand: null }
    : { state: 'idle', stateLabel: 'Idle', evidence: 'its own record says no turn is running', hand: null }
}

function retiredState(agent: OfficeRetired): Derived {
  const last = `$.agent.list() no longer lists it (last seen "${agent.status}")`
  const how = agentSendBlock(agent) === null ? '; a message resumes it from its transcript (docs)' : ''
  switch (agent.status) {
    case 'completed':
      return { state: 'completed', stateLabel: 'Completed · not listed', evidence: `${last}${how}`, hand: null }
    case 'failed':
      return { state: 'failed', stateLabel: 'Failed · not listed', evidence: `${last}${how}`, hand: null }
    case 'killed':
      return { state: 'failed', stateLabel: 'Stopped · not listed', evidence: last, hand: null }
    default:
      return { state: 'unknown', stateLabel: `Not listed (last seen ${agent.status})`, evidence: `${last}${how}`, hand: null }
  }
}

export type OfficeInput = {
  now: number
  turns: readonly OfficeTurn[]
  agents: readonly OfficeAgent[]
  retired?: readonly OfficeRetired[]
  pending: readonly OfficePending[]
  peers: readonly MuseumFrame[]
}

/** Every worker of the office: this conversation, its agents, then enrolled peers. */
export function deriveWorkers(input: OfficeInput): OfficeWorker[] {
  const pendingOf = (identity: string) => input.pending.filter(p => p.identity === identity)
  const main = withStyle({
    key: 'main',
    kind: 'main',
    group: 'session',
    name: 'This conversation',
    detail: 'the main loop of this session',
    ...mainState(input.turns.find(t => t.identity === 'main'), pendingOf('main')),
    // A send here is a prompt of the person's own, queued for this session ($.prompt.submit): it starts a turn once the session is idle.
    target: { kind: 'main' },
    noSendReason: null,
    isListed: true,
  })
  const agents = input.agents.map(agent =>
    withStyle({
      key: `agent:${agent.id}`,
      kind: agent.isTeammate ? 'teammate' : 'subagent',
      group: 'session',
      name: oneLine(agent.name ?? agent.description, 40) || agent.id.slice(0, 8),
      detail: oneLine(`${agent.isTeammate ? 'teammate' : 'subagent'} · ${agent.type}${agent.name ? ` · ${agent.description}` : ''}`, 80),
      ...agentState(agent, pendingOf(`agent:${agent.id}`)),
      target: agentSendBlock(agent) === null ? { kind: 'agent', agentId: agent.id } : null,
      noSendReason: agentSendBlock(agent),
      isListed: true,
    }),
  )
  const listed = new Set(input.agents.map(a => a.id))
  const retired = (input.retired ?? [])
    .filter(agent => !listed.has(agent.id))
    .map(agent =>
      withStyle({
        key: `agent:${agent.id}`,
        kind: agent.isTeammate ? 'teammate' : 'subagent',
        group: 'session',
        name: oneLine(agent.name ?? agent.description, 40) || agent.id.slice(0, 8),
        detail: oneLine(`${agent.isTeammate ? 'teammate' : 'subagent'} · ${agent.type}${agent.name ? ` · ${agent.description}` : ''} · no longer listed`, 90),
        ...retiredState(agent),
        target: agentSendBlock(agent) === null ? { kind: 'agent', agentId: agent.id } : null,
        noSendReason: agentSendBlock(agent),
        isListed: false,
      }),
    )
  const peers = input.peers.map(peer =>
    withStyle({
      key: `peer:${peer.sessionId}`,
      kind: 'peer',
      group: 'peers',
      name: oneLine(peer.label, 40),
      detail: `enrolled peer session · ${peer.sessionId.slice(0, 8)}`,
      ...peerState(peer, input.now),
      target: { kind: 'peer', sessionId: peer.sessionId },
      noSendReason: null,
      isListed: true,
    }),
  )
  return [main, ...agents, ...retired, ...peers]
}

/** The text of a pending question as AskUserQuestion's input carries it, inert and bounded. */
export function questionText(input: unknown): string {
  const questions = (input as { questions?: unknown })?.questions
  if (!Array.isArray(questions)) return 'a question (its text was not readable)'
  const texts = questions.flatMap(q => {
    const text = (q as { question?: unknown })?.question
    return typeof text === 'string' ? [oneLine(text, 200)] : []
  })
  return texts.length === 0 ? 'a question (its text was not readable)' : texts.join(' / ')
}

/** A one-line summary of the call a permission dialog is about. */
export function approvalText(tool: string, input: unknown): string {
  const fields = typeof input === 'object' && input !== null ? (input as Record<string, unknown>) : {}
  const main = fields.command ?? fields.file_path ?? fields.url ?? fields.pattern ?? fields.path
  return oneLine(typeof main === 'string' ? `${tool}: ${main}` : tool, 200)
}
