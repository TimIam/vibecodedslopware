// Checkers (English draughts), pure: twelve men a side on the dark squares of
// an 8×8 board named as in chess (a1 is dark). Black (side `a`) starts on
// ranks 6–8 and moves down the board first; Red (side `b`) starts on ranks
// 1–3 and moves up. Men move one square diagonally forward and capture by
// jumping; captures are mandatory and a jump goes on while the same piece
// can jump again (any complete sequence may be chosen, not only the longest);
// a man reaching the far rank is crowned and its move ends; kings move and
// capture in all four directions, one square at a time. No move left loses;
// fifty consecutive moves without a capture or a crowning is a draw.
//
// A move is the squares of the piece's path joined by `-` (a simple move,
// `b6-a5`) or `x` (a capture sequence, `d4xf6xh8`). Nothing but a move in
// `legalMoves(state)` is ever played, whoever proposes it.

import type { GameRules, GameStatus, Side } from './rules'

/** Lowercase a man, uppercase a king; `a` Black, `b` Red. */
export type Piece = 'a' | 'b' | 'A' | 'B'

export type CheckersState = {
  /** Sixty-four cells, a1 = 0, h1 = 7, a8 = 56; light squares stay null. */
  cells: (Piece | null)[]
  turn: Side
  /** The moves so far, as the strings `legalMoves` lists. */
  moves: string[]
  /** Consecutive moves without a capture or a crowning. */
  quiet: number
}

export const FILES = 'abcdefgh'
/** Quiet moves (by either side, counted singly) that draw the game. */
export const QUIET_LIMIT = 50

export const squareName = (sq: number): string => `${FILES[sq % 8]}${Math.floor(sq / 8) + 1}`
export const squareIndex = (name: string): number => {
  const file = FILES.indexOf(name[0] ?? '')
  const rank = Number(name[1]) - 1
  return name.length !== 2 || file < 0 || !(rank >= 0 && rank <= 7) ? -1 : rank * 8 + file
}
export const isDark = (sq: number): boolean => ((sq % 8) + Math.floor(sq / 8)) % 2 === 0

/** The standard number of a dark square, 1 (b8) to 32 (g1), or -1 for a light square. */
export const squareNumber = (sq: number): number => (sq >= 0 && sq < 64 && isDark(sq) ? 4 * (7 - Math.floor(sq / 8)) + Math.floor((sq % 8) / 2) + 1 : -1)
/** The dark square numbered `n` (1–32), or -1. */
export const numberedSquare = (n: number): number => {
  if (!Number.isInteger(n) || n < 1 || n > 32) return -1
  const rank = 7 - Math.floor((n - 1) / 4)
  const file = 2 * ((n - 1) % 4) + (rank % 2 === 0 ? 0 : 1)
  return rank * 8 + file
}

export const sideOf = (p: Piece): Side => p.toLowerCase() as Side
export const isKing = (p: Piece): boolean => p === 'A' || p === 'B'
export const other = (side: Side): Side => (side === 'a' ? 'b' : 'a')
/** The rank index (0–7) a man of `side` is crowned on. */
const farRank = (side: Side): number => (side === 'a' ? 0 : 7)
const forward = (side: Side): number => (side === 'a' ? -1 : 1)

/** A position from a spec: Black's squares, a slash, Red's squares; `K` before a square makes a king (`"b6 Kd8 / a3 c3"`). */
export function position(spec: string, turn: Side = 'a', quiet = 0): CheckersState {
  const cells: (Piece | null)[] = new Array(64).fill(null)
  const [black = '', red = ''] = spec.split('/')
  const put = (part: string, side: Side) => {
    for (const token of part.trim().split(/\s+/).filter(Boolean)) {
      const king = token.startsWith('K')
      const sq = squareIndex(king ? token.slice(1) : token)
      if (sq < 0 || !isDark(sq)) throw new Error(`position: ${token} is not a dark square`)
      cells[sq] = (king ? side.toUpperCase() : side) as Piece
    }
  }
  put(black, 'a')
  put(red, 'b')
  return { cells, turn, moves: [], quiet }
}

export function initial(): CheckersState {
  const cells: (Piece | null)[] = new Array(64).fill(null)
  for (let sq = 0; sq < 64; sq++) {
    if (!isDark(sq)) continue
    const rank = Math.floor(sq / 8)
    if (rank <= 2) cells[sq] = 'b'
    else if (rank >= 5) cells[sq] = 'a'
  }
  return { cells, turn: 'a', moves: [], quiet: 0 }
}

// ─── Moves ─────────────────────────────────────────────────────────────────
const step = (sq: number, df: number, dr: number): number => {
  const f = (sq % 8) + df
  const r = Math.floor(sq / 8) + dr
  return f < 0 || f > 7 || r < 0 || r > 7 ? -1 : r * 8 + f
}
const DIAGONALS: [number, number][] = [[-1, -1], [1, -1], [-1, 1], [1, 1]]
const directions = (p: Piece): [number, number][] => (isKing(p) ? DIAGONALS : DIAGONALS.filter(([, dr]) => dr === forward(sideOf(p))))

/** The jumps `piece` on `sq` can make: the square jumped over and the one landed on. */
function jumps(cells: readonly (Piece | null)[], sq: number, piece: Piece, taken: ReadonlySet<number>): { over: number; to: number }[] {
  const side = sideOf(piece)
  const found: { over: number; to: number }[] = []
  for (const [df, dr] of directions(piece)) {
    const over = step(sq, df, dr)
    const to = step(sq, 2 * df, 2 * dr)
    if (over < 0 || to < 0) continue
    const enemy = cells[over]
    if (enemy === null || enemy === undefined || sideOf(enemy) === side || taken.has(over)) continue
    if (cells[to] !== null) continue
    found.push({ over, to })
  }
  return found
}

/** Every complete capture path from `sq`: it goes on while a further jump exists and ends at once on crowning. */
function capturePaths(cells: readonly (Piece | null)[], sq: number, piece: Piece): number[][] {
  const out: number[][] = []
  const lifted = cells.slice()
  lifted[sq] = null // the piece is in the air: its own square may be landed on again
  const extend = (at: number, taken: Set<number>, path: number[]) => {
    const crowned = !isKing(piece) && Math.floor(at / 8) === farRank(sideOf(piece))
    const next = crowned ? [] : jumps(lifted, at, piece, taken)
    if (next.length === 0) {
      if (path.length > 1) out.push(path)
      return
    }
    for (const j of next) extend(j.to, new Set([...taken, j.over]), [...path, j.to])
  }
  extend(sq, new Set(), [sq])
  return out
}

const moveString = (path: readonly number[], capture: boolean): string => path.map(squareName).join(capture ? 'x' : '-')

/** The moves of the side to move, captures only when any exists, whatever the game's status. */
function movesFor(s: CheckersState): string[] {
  const captures: string[] = []
  const simple: string[] = []
  for (let sq = 0; sq < 64; sq++) {
    const p = s.cells[sq]
    if (p === null || p === undefined || sideOf(p) !== s.turn) continue
    for (const path of capturePaths(s.cells, sq, p)) captures.push(moveString(path, true))
    if (captures.length > 0) continue
    for (const [df, dr] of directions(p)) {
      const to = step(sq, df, dr)
      if (to >= 0 && s.cells[to] === null) simple.push(moveString([sq, to], false))
    }
  }
  return captures.length > 0 ? captures : simple
}

export function status(s: CheckersState): GameStatus {
  if (movesFor(s).length === 0) return { over: true, winner: other(s.turn), result: 'no moves' }
  if (s.quiet >= QUIET_LIMIT) return { over: true, winner: null, result: 'fifty-move' }
  return { over: false }
}

export const legalMoves = (s: CheckersState): string[] => (status(s).over ? [] : movesFor(s))
export const mustCapture = (s: CheckersState): boolean => !status(s).over && movesFor(s).some(m => m.includes('x'))

export function play(s: CheckersState, move: string): CheckersState {
  if (!legalMoves(s).includes(move)) throw new Error(`not a legal move: ${move}`)
  const capture = move.includes('x')
  const path = move.split(/[-x]/).map(squareIndex)
  const cells = s.cells.slice()
  const from = path[0]!
  const to = path[path.length - 1]!
  const piece = cells[from]!
  cells[from] = null
  if (capture) for (let i = 1; i < path.length; i++) cells[(path[i - 1]! + path[i]!) / 2] = null
  const crowned = !isKing(piece) && Math.floor(to / 8) === farRank(sideOf(piece))
  cells[to] = crowned ? (piece.toUpperCase() as Piece) : piece
  return { cells, turn: other(s.turn), moves: [...s.moves, move], quiet: capture || crowned ? 0 : s.quiet + 1 }
}

/**
 * The legal move `text` names, read forgivingly: any case, spaces, `:` or
 * `×` for `x`, `-` or `x` either way round, squares run together (`b6a5`),
 * the standard 1–32 numbering (`11-15`, `22x15x8`), trailing punctuation or
 * words. Only a move in `legalMoves(s)` can come back.
 */
export function parse(s: CheckersState, text: string): string | null {
  const t = text.toLowerCase().replace(/[×:]/g, 'x').replace(/[–—]/g, '-').replace(/\s+/g, '').replace(/^[`'"(\[]+/, '')
  let path: number[] | null = null
  const squares = /^[a-h][1-8](?:[-x]?[a-h][1-8])+/.exec(t)
  const numbers = /^\d{1,2}(?:[-x]\d{1,2})+/.exec(t)
  if (squares) path = (squares[0].match(/[a-h][1-8]/g) ?? []).map(squareIndex)
  else if (numbers) path = numbers[0].split(/[-x]/).map(n => numberedSquare(Number(n)))
  if (path === null || path.some(sq => sq < 0)) return null
  const wanted = path.map(squareName).join(' ')
  return legalMoves(s).find(m => m.split(/[-x]/).join(' ') === wanted) ?? null
}

export function replay(moves: readonly string[]): CheckersState {
  let s = initial()
  for (const text of moves) {
    const m = parse(s, text)
    if (m === null) break
    s = play(s, m)
  }
  return s
}

// ─── Text ──────────────────────────────────────────────────────────────────
const GLYPH: Record<Piece, string> = { a: 'b', b: 'r', A: 'B', B: 'R' }

/** The board, rank 8 first: `b`/`r` men, `B`/`R` kings, `.` an empty dark square, a space a light one. */
export function ascii(s: CheckersState): string {
  const rows: string[] = []
  for (let rank = 7; rank >= 0; rank--) {
    let row = `${rank + 1} `
    for (let file = 0; file < 8; file++) {
      const sq = rank * 8 + file
      const p = s.cells[sq]
      row += ` ${p ? GLYPH[p] : isDark(sq) ? '.' : ' '}`
    }
    rows.push(row)
  }
  rows.push('   a b c d e f g h')
  return rows.join('\n')
}

const SIDE_LETTER: Record<Side, string> = { a: 'B', b: 'R' }
export const history = (s: CheckersState): string[] => s.moves.map((m, i) => `${SIDE_LETTER[i % 2 === 0 ? 'a' : 'b']} ${m}`)

const SYSTEM = [
  'You are playing checkers (English draughts) on an 8×8 board whose squares are named as in chess: files a–h, ranks 1–8; only the dark squares (a1, c1, b2, …) are used.',
  'Black (b, kings B) starts on ranks 6–8 and moves down the board toward rank 1; Red (r, kings R) starts on ranks 1–3 and moves up toward rank 8. Black moves first.',
  'A man moves one square diagonally forward onto an empty square, and captures by jumping diagonally forward over an adjacent enemy piece onto the empty square beyond it.',
  'Capturing is mandatory: when any capture is available, only captures are legal. A capturing piece must go on jumping while a further jump is available from where it lands, all in the same move; any complete sequence may be chosen, not only the longest.',
  'A man that reaches the far rank becomes a king and its move ends there, even if a further jump would exist. Kings move and capture diagonally in all four directions, one square at a time (no flying kings).',
  'A side with no legal move loses, whether it has no pieces or all of them are blocked. Fifty consecutive moves without a capture or a crowning is a draw.',
  "A move is written as the squares of the piece's path joined by - for a simple move (b6-a5) or by x for a capture sequence (d4xf6xh8), listing every square the piece lands on.",
  'Answer with the move alone on the first line, exactly as it appears in the legal-move list. You may add one short line of reasoning after it. Nothing else: no headings, no alternatives, no commentary.',
].join('\n')

export function prompt(s: CheckersState, side: Side, lastProblem: string | null): { system: string; prompt: string } {
  const names = { a: 'Black', b: 'Red' }
  const legal = legalMoves(s)
  const lines = [
    `You are ${names[side]} (${SIDE_LETTER[side].toLowerCase()}, kings ${SIDE_LETTER[side]}).`,
    '',
    'Board (rank 8 at the top; Black moves toward rank 1, Red toward rank 8):',
    ascii(s),
    '',
    `Moves so far: ${s.moves.length === 0 ? '(none)' : history(s).join(', ')}`,
    `It is ${names[s.turn]}'s turn${s.turn === side ? ' (yours)' : ''}.`,
  ]
  if (mustCapture(s)) lines.push('A capture is available, so capturing is mandatory: only the capture sequences below are legal.')
  lines.push('', `Legal moves (${legal.length}): ${legal.join(', ')}`)
  if (lastProblem) lines.push('', `Your previous answer was refused: ${lastProblem} Choose from the legal moves above.`)
  lines.push('', 'Your move:')
  return { system: SYSTEM, prompt: lines.join('\n') }
}

export function out(s: CheckersState): { cells: (Piece | null)[]; lastMove: string | null; mustCapture: boolean } {
  return { cells: s.cells.slice(), lastMove: s.moves[s.moves.length - 1] ?? null, mustCapture: mustCapture(s) }
}

export const GAME: GameRules<CheckersState> = {
  kind: 'checkers',
  title: 'Checkers',
  sides: { a: 'Black', b: 'Red' },
  initial,
  replay,
  legal: legalMoves,
  parse,
  play,
  turn: s => s.turn,
  status,
  history,
  ascii,
  prompt,
  out,
}
