// What a game in the Agent Arcade is to the mod: pure rules over a state the
// game defines, replayed from a move list the arcade stores. The arcade never
// plays a move that `legal` does not list, whoever proposes it; an agent's
// answer is read with `parse`, and the model is asked with `prompt`, which
// names every legal move. Each game is one module exporting a `GameRules`.

export type Side = 'a' | 'b'

export type GameStatus = { over: false } | { over: true; winner: Side | null; result: string }

export type GameRules<S> = {
  /** The arcade's key for the game: letters and digits (`connect4`), fixed for its life. */
  kind: string
  /** The name the window shows. */
  title: string
  /** What the two seats are called (`{ a: 'White', b: 'Black' }`); side `a` moves first. */
  sides: { a: string; b: string }
  initial(): S
  /** The position after `moves` from the start; stops at the first move it cannot apply. */
  replay(moves: readonly string[]): S
  /** Every legal move, as the strings the arcade stores and the model answers with (short, unambiguous: `e2e4`, `c4`, `12-16`). */
  legal(s: S): string[]
  /** The legal move `text` names, read forgivingly (case, spaces, decorations), else null. Never a move `legal` leaves out. */
  parse(s: S, text: string): string | null
  play(s: S, move: string): S
  turn(s: S): Side
  status(s: S): GameStatus
  /** The moves so far in the game's own notation, for display. */
  history(s: S): string[]
  /** The position as plain text, for the model: a labelled grid. */
  ascii(s: S): string
  /**
   * The request for a move from the model playing `side`: a `system` text
   * with the rules and the exact answer format (the move alone on the first
   * line, one short reason line allowed), and a `prompt` with the position,
   * the moves so far, whose turn, the full legal-move list, and `lastProblem`
   * when the previous answer was refused.
   */
  prompt(s: S, side: Side, lastProblem: string | null): { system: string; prompt: string }
  /** The position for the window to draw: JSON-plain data (cells, sizes, the last move); no functions. */
  out(s: S): Record<string, unknown>
  /**
   * For a game of chance: the arcade stores this as the game's first move
   * when a game starts, and `replay` reads it as the seed every later roll
   * comes from (so a game replays the same way). A move string too, never
   * something a player chooses: `seed:<digits>`. Absent for games without chance.
   */
  seedMove?: () => string
}
