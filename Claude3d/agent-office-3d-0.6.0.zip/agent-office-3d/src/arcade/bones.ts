// Bones (Knucklebones), pure: each side has its own grid of three columns,
// a, b and c, holding up to three dice each. Player 1 (side a) moves first. A
// turn rolls one die and places it in one of the mover's columns with a free
// slot; a column scores the sum of its dice, except that equal dice in a
// column multiply (each counts as many times as the column holds that value);
// placing a die removes every die of the same value from the opponent's
// column of the same letter. The game ends when either grid is full; the
// higher total wins, equal totals draw.
//
// Chance: the arcade stores `seed:<digits>` as the game's first move and
// every roll comes from a mulberry32 stream seeded by it, advanced once per
// placement, so the same move list always replays to the same game. Stored
// moves after the seed are the column letter alone.

import type { GameRules, GameStatus, Side } from './rules'

export type Column = 'a' | 'b' | 'c'
export const COLUMNS: readonly Column[] = ['a', 'b', 'c']
export const SLOTS = 3
export const DIE_FACES = 6

export type Placement = { side: Side; column: Column; die: number }
export type Removal = { column: Column; values: number[] }

export type BonesState = {
  /** The 32-bit seed every roll derives from, or null before the seed move. */
  seed: number | null
  /** Each side's three columns, each up to three die values, bottom (first placed) first. */
  grids: Record<Side, number[][]>
  turn: Side
  /** The die rolled for the side to move: null before the seed and once the game is over. */
  roll: number | null
  /** The placements so far, in order. */
  plays: Placement[]
  /** The opponent dice the last placement knocked out, or null. */
  removed: Removal | null
  /** The moves as the arcade stores them: the seed move, then column letters. `replay(moves)` gives this state back. */
  moves: string[]
}

export const LABEL: Record<Side, string> = { a: 'P1', b: 'P2' }
const NAMES: Record<Side, string> = { a: 'Player 1', b: 'Player 2' }
const other = (side: Side): Side => (side === 'a' ? 'b' : 'a')
const SEED_MOVE = /^seed:(\d+)$/

// ─── Chance ────────────────────────────────────────────────────────────────
/** mulberry32: a small, well-mixed 32-bit generator; each call yields the next number in [0, 1). */
export function mulberry32(seed: number): () => number {
  let a = seed >>> 0
  return () => {
    a = (a + 0x6d2b79f5) >>> 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

/** The first `count` rolls (1–6) of the stream a seed gives; roll `n` is the die for the (n+1)th placement. */
export function rolls(seed: number, count: number): number[] {
  const next = mulberry32(seed)
  const out: number[] = []
  for (let i = 0; i < count; i++) out.push(Math.floor(next() * DIE_FACES) + 1)
  return out
}

/** The die for placement `n` (0-based) under `seed`. */
export const rollAt = (seed: number, n: number): number => rolls(seed, n + 1)[n]!

/** A fresh seed move from a random 32-bit integer: `seed:<digits>`. */
export const seedMove = (): string => `seed:${Math.floor(Math.random() * 4294967296) >>> 0}`

/** The seed a `seed:<digits>` move names (reduced to 32 bits), or null for anything else. */
export function parseSeed(move: string): number | null {
  const m = SEED_MOVE.exec(move.trim())
  return m ? Number(m[1]) >>> 0 : null
}

// ─── Scoring ───────────────────────────────────────────────────────────────
/** A column's score: each die's value times how many dice of that value the column holds. */
export function columnScore(dice: readonly number[]): number {
  let total = 0
  for (const d of dice) total += d * dice.filter(x => x === d).length
  return total
}

export const columnScores = (grid: readonly number[][]): number[] => COLUMNS.map((_, i) => columnScore(grid[i] ?? []))
export const gridScore = (grid: readonly number[][]): number => columnScores(grid).reduce((a, b) => a + b, 0)
export const diceCount = (grid: readonly number[][]): number => grid.reduce((n, col) => n + col.length, 0)
export const gridFull = (grid: readonly number[][]): boolean => diceCount(grid) >= COLUMNS.length * SLOTS

// ─── The game ──────────────────────────────────────────────────────────────
export const initial = (): BonesState => ({
  seed: null,
  grids: { a: [[], [], []], b: [[], [], []] },
  turn: 'a',
  roll: null,
  plays: [],
  removed: null,
  moves: [],
})

export function status(s: BonesState): GameStatus {
  if (!gridFull(s.grids.a) && !gridFull(s.grids.b)) return { over: false }
  const a = gridScore(s.grids.a)
  const b = gridScore(s.grids.b)
  if (a === b) return { over: true, winner: null, result: 'draw' }
  return { over: true, winner: a > b ? 'a' : 'b', result: 'full board' }
}

/** The side to move's columns with a free slot; nothing before the seed or after the end. */
export const legal = (s: BonesState): string[] =>
  s.seed === null || status(s).over ? [] : COLUMNS.filter((_, i) => s.grids[s.turn][i]!.length < SLOTS)

/**
 * The legal column `text` names, read forgivingly on its first non-empty
 * line: `b`, `B`, `col b`, `column b`, `b.`, `"b"`, or the column's number
 * `2` (a is 1). Never a column `legal` leaves out, and never the seed move.
 */
export function parse(s: BonesState, text: string): string | null {
  const line = text.split('\n').map(l => l.trim()).find(l => l !== '') ?? ''
  const t = line
    .toLowerCase()
    .replace(/^[["'`(*_]+/, '')
    .replace(/[.,;:!?)\]"'`*_]+$/, '')
    .replace(/^(?:column|col)\b[\s:.#-]*/, '')
    .trim()
  const col = /^[1-3]$/.test(t) ? COLUMNS[Number(t) - 1]! : /^[abc]$/.test(t) ? t : null
  return col !== null && legal(s).includes(col) ? col : null
}

/** Applies the seed move to a game that has none yet: records it and rolls the first die. */
function seedGame(s: BonesState, move: string, seed: number): BonesState {
  if (s.seed !== null) throw new Error('the game already has a seed')
  return { ...s, seed, roll: rollAt(seed, 0), moves: [...s.moves, move] }
}

/**
 * Plays a stored move: the seed move on an unseeded game, else a legal column
 * for the side to move, placing the current roll there and knocking matching
 * dice out of the opponent's column of the same letter.
 */
export function play(s: BonesState, move: string): BonesState {
  const seed = parseSeed(move)
  if (seed !== null) return seedGame(s, move, seed)
  if (!legal(s).includes(move) || s.roll === null) throw new Error(`not a legal move: ${move}`)
  const column = move as Column
  const i = COLUMNS.indexOf(column)
  const die = s.roll
  const mine = s.grids[s.turn].map(c => c.slice())
  const theirs = s.grids[other(s.turn)].map(c => c.slice())
  mine[i]!.push(die)
  const knocked = theirs[i]!.filter(d => d === die)
  theirs[i] = theirs[i]!.filter(d => d !== die)
  const grids = s.turn === 'a' ? { a: mine, b: theirs } : { a: theirs, b: mine }
  const plays = [...s.plays, { side: s.turn, column, die }]
  const next: BonesState = {
    seed: s.seed,
    grids,
    turn: other(s.turn),
    roll: null,
    plays,
    removed: knocked.length > 0 ? { column, values: knocked } : null,
    moves: [...s.moves, move],
  }
  if (!status(next).over) next.roll = rollAt(s.seed!, plays.length)
  return next
}

/** The position after `moves` from the start, stopping at the first move that cannot be applied. */
export function replay(moves: readonly string[]): BonesState {
  let s = initial()
  for (const m of moves) {
    if (s.seed === null) {
      if (parseSeed(m) === null) break
      s = play(s, m)
      continue
    }
    const move = parse(s, m)
    if (move === null) break
    s = play(s, move)
  }
  return s
}

/** The turns so far as `P1 b:4`: the side, the column and the die placed. */
export const history = (s: BonesState): string[] => s.plays.map(p => `${LABEL[p.side]} ${p.column}:${p.die}`)

/** One grid as text: three slots top-down (bottom slot last), the column letters, then each column's score. */
function gridText(side: Side, grid: readonly number[][]): string[] {
  const cell = (col: number, slot: number) => String(grid[col]?.[slot] ?? '.')
  const lines = [`${NAMES[side]} (${LABEL[side]}) — total ${gridScore(grid)}`]
  for (let slot = SLOTS - 1; slot >= 0; slot--) lines.push(`      ${COLUMNS.map((_, col) => cell(col, slot)).join('  ')}`)
  lines.push(`      ${COLUMNS.join('  ')}`)
  lines.push(`score ${columnScores(grid).map(n => String(n).padStart(2)).join(' ')}`)
  return lines
}

/** What the die and the turn are, in a sentence. */
function situation(s: BonesState): string {
  const st = status(s)
  if (st.over) return st.winner === null ? `Game over: a draw, ${gridScore(s.grids.a)} to ${gridScore(s.grids.b)}.` : `Game over: ${NAMES[st.winner]} wins, ${gridScore(s.grids.a)} to ${gridScore(s.grids.b)}.`
  if (s.roll === null) return 'No die rolled yet.'
  return `${NAMES[s.turn]} (${LABEL[s.turn]}) to move, rolled a ${s.roll}.`
}

/** Both grids with their dice, column scores and totals, and what was rolled for the side to move. */
export function ascii(s: BonesState): string {
  return [...gridText('a', s.grids.a), '', ...gridText('b', s.grids.b), '', situation(s)].join('\n')
}

const SYSTEM = `You are playing Bones (Knucklebones), a two-player dice game. Each player has their own grid of three columns, a, b and c, and each column holds up to three dice. Player 1 moves first, then the players alternate. On your turn one six-sided die is rolled for you (the prompt tells you the roll) and you place it in one of your own columns that still has a free slot; dice fill a column from the bottom. A column scores the sum of its dice, except that dice of equal value in the same column multiply: each die's value counts once for every die of that value the column holds (two 4s score 4×2 each, 16 together; three 4s score 4×3 each, 36 together). Placing a die removes every die of the same value from your opponent's column of the same letter, lowering their score; their placements can knock out your dice the same way. The game ends as soon as either grid is full (nine dice). The higher total score wins; equal totals are a draw.

Answer format: the column letter alone on the first line (for example: b). You may add one short line of reasoning after it. Nothing else: no other words on the first line, no quotes, no markdown. Choose only from the legal columns listed in the prompt.`

export function prompt(s: BonesState, side: Side, lastProblem: string | null): { system: string; prompt: string } {
  const moves = history(s)
  const lines = [
    `You are ${NAMES[side]} (${LABEL[side]}).`,
    '',
    'Your grid and your opponent\'s (dice listed top slot first, so the bottom row is the first die placed):',
    ...gridText('a', s.grids.a),
    '',
    ...gridText('b', s.grids.b),
    '',
    `Moves so far: ${moves.length === 0 ? '(none)' : moves.join(', ')}`,
    `It is ${NAMES[s.turn]}'s turn${s.turn === side ? ' (yours)' : ''}.`,
  ]
  if (s.roll !== null) lines.push(`The die rolled for this turn: ${s.roll}.`)
  lines.push(`Legal columns: ${legal(s).join(', ')}`)
  if (lastProblem !== null) lines.push('', `Your previous answer was refused: ${lastProblem} Choose from the legal columns above.`)
  lines.push('', 'Your move:')
  return { system: SYSTEM, prompt: lines.join('\n') }
}

export type BonesView = {
  grids: { a: number[][]; b: number[][] }
  scores: { a: number; b: number }
  columnScores: { a: number[]; b: number[] }
  roll: number | null
  lastMove: Placement | null
  removed: Removal | null
}

/** The position for the window: both grids bottom-first, the scores, the current roll, the last placement and what it knocked out. */
export function out(s: BonesState): BonesView {
  return {
    grids: { a: s.grids.a.map(c => c.slice()), b: s.grids.b.map(c => c.slice()) },
    scores: { a: gridScore(s.grids.a), b: gridScore(s.grids.b) },
    columnScores: { a: columnScores(s.grids.a), b: columnScores(s.grids.b) },
    roll: s.roll,
    lastMove: s.plays.length === 0 ? null : { ...s.plays[s.plays.length - 1]! },
    removed: s.removed === null ? null : { column: s.removed.column, values: s.removed.values.slice() },
  }
}

export const GAME: GameRules<BonesState> = {
  kind: 'bones',
  title: 'Bones',
  sides: { a: 'Player 1', b: 'Player 2' },
  initial,
  replay,
  legal,
  parse,
  play,
  turn: s => s.turn,
  status,
  history,
  ascii,
  prompt,
  out,
  seedMove,
}
