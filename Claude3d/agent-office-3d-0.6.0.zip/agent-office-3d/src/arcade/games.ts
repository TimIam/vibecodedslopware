// The games the arcade offers, each a `GameRules` module (rules.ts). Chess and
// tic-tac-toe are adapted here from their engines; the rest export `GAME`
// themselves. To add a game: write its module, and list it in GAMES.

import * as C from './chess'
import type { ChessState } from './chess'
import { GAME as BONES } from './bones'
import { GAME as CHECKERS } from './checkers'
import { GAME as CONNECT4 } from './connect4'
import type { GameRules, Side } from './rules'
import * as T from './tictactoe'
import type { TttState } from './tictactoe'

const refusal = (lastProblem: string | null, what: string) => (lastProblem ? `Your previous answer was refused: ${lastProblem} Choose from the ${what} above.\n` : '')

export const CHESS: GameRules<ChessState> = {
  kind: 'chess',
  title: 'Chess',
  sides: { a: 'White', b: 'Black' },
  initial: () => C.initialState(),
  replay(moves) {
    let s = C.initialState()
    for (const text of moves) {
      const m = C.parseMove(s, text)
      if (m === null) break
      s = C.play(s, m)
    }
    return s
  },
  legal: s => C.legalMoves(s).map(C.toUci),
  parse(s, text) {
    const m = C.parseMove(s, text)
    return m === null ? null : C.toUci(m)
  },
  play(s, move) {
    const m = C.parseMove(s, move)
    if (m === null) throw new Error(`not a legal move: ${move}`)
    return C.play(s, m)
  },
  turn: s => (s.turn === 'w' ? 'a' : 'b'),
  status(s) {
    const st = C.status(s)
    if (!st.over) return { over: false }
    return { over: true, winner: st.winner === null ? null : st.winner === 'w' ? 'a' : 'b', result: st.result }
  },
  history: s => s.history,
  ascii: s => C.asciiBoard(s),
  prompt(s, side, lastProblem) {
    const colour = side === 'a' ? 'White' : 'Black'
    const st = C.status(s)
    const numbered = s.history.map((san, i) => (i % 2 === 0 ? `${i / 2 + 1}. ${san}` : san)).join(' ')
    return {
      system:
        `You are playing a casual game of chess as ${colour}. Standard rules (FIDE): castling, en passant and promotion as usual; ` +
        'a move that leaves your own king in check is illegal. You must play one of the legal moves given. ' +
        'Answer with the move alone on the first line, in UCI: the from-square then the to-square, with the promotion piece appended for a promotion (e7e8q). ' +
        'You may add one short line after it saying why. Nothing else.',
      prompt:
        `Position (FEN): ${C.toFen(s)}\n` +
        `Board (rank 8 at the top; uppercase is White):\n${C.asciiBoard(s)}\n` +
        `Moves so far: ${numbered || '(none)'}\n` +
        `You are ${colour}, to move.${!st.over && st.inCheck ? ' You are in check.' : ''}\n` +
        `Legal moves (UCI): ${C.legalMoves(s).map(C.toUci).join(' ')}\n` +
        refusal(lastProblem, 'legal moves') +
        'Your move:',
    }
  },
  out(s) {
    const st = C.status(s)
    return { fen: C.toFen(s), board: s.board, inCheck: !st.over && st.inCheck }
  },
}

export const TICTACTOE: GameRules<TttState> = {
  kind: 'tictactoe',
  title: 'Tic-tac-toe',
  sides: { a: 'X', b: 'O' },
  initial: () => T.tttInitial(),
  // Moves are kept as square names (a1–c3), which is also what a person types and the model answers.
  replay(moves) {
    let s = T.tttInitial()
    for (const text of moves) {
      const i = T.tttParseMove(s, text)
      if (i < 0) break
      s = T.tttPlay(s, i)
    }
    return s
  },
  legal: s => T.tttLegalMoves(s).map(T.tttCellName),
  parse(s, text) {
    const i = T.tttParseMove(s, text)
    return i < 0 ? null : T.tttCellName(i)
  },
  play(s, move) {
    const i = T.tttParseMove(s, move)
    if (i < 0) throw new Error(`not a legal move: ${move}`)
    return T.tttPlay(s, i)
  },
  turn: s => (s.turn === 'x' ? 'a' : 'b'),
  status(s) {
    const st = T.tttStatus(s)
    if (!st.over) return { over: false }
    return { over: true, winner: st.winner === null ? null : st.winner === 'x' ? 'a' : 'b', result: st.winner === null ? 'draw' : 'win' }
  },
  history: s => s.history,
  ascii: s => T.tttAscii(s),
  prompt(s, side, lastProblem) {
    const mark = side === 'a' ? 'X' : 'O'
    return {
      system:
        `You are playing tic-tac-toe as ${mark} on a 3 x 3 board. Three in a row, column or diagonal wins. ` +
        'You must take one of the free squares given. Answer with the square alone on the first line (a1 to c3: the column letter then the row number, row 3 at the top). ' +
        'You may add one short line after it saying why. Nothing else.',
      prompt:
        `Board (row 3 at the top):\n${T.tttAscii(s)}\n` +
        `Moves so far: ${s.history.join(' ') || '(none)'}\n` +
        `You are ${mark}, to move.\n` +
        `Free squares: ${T.tttLegalMoves(s).map(T.tttCellName).join(' ')}\n` +
        refusal(lastProblem, 'free squares') +
        'Your square:',
    }
  },
  out: s => ({ cells: s.cells }),
}

/** Every game, by its kind. */
export const GAMES: Record<string, GameRules<unknown>> = Object.fromEntries(
  [CHESS, TICTACTOE, CONNECT4, CHECKERS, BONES].map(g => [g.kind, g as GameRules<unknown>]),
)

export const gameOf = (kind: string): GameRules<unknown> | undefined => GAMES[kind]
export const sideName = (kind: string, side: Side): string => GAMES[kind]?.sides[side] ?? side
