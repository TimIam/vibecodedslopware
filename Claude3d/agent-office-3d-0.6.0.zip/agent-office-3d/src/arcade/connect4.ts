// Connect Four, pure: seven columns a–g, six rows; Red (side a) drops first.
// A move is the column letter alone; the disc falls to the lowest free row.
// Four in a row, column or diagonal wins; a full board with no four is a
// draw. Nothing but a column with room on a live board is a legal move.

import type { GameRules, GameStatus, Side } from './rules'

export const COLS = 7
export const ROWS = 6
export const COLUMNS = 'abcdefg'

export type Connect4State = {
  /** Forty-two cells, bottom row first, left to right: index = row * 7 + column. */
  cells: (Side | null)[]
  turn: Side
  /** The column letters played so far. */
  moves: string[]
}

const LETTER: Record<Side, string> = { a: 'R', b: 'Y' }
const other = (side: Side): Side => (side === 'a' ? 'b' : 'a')
const index = (row: number, col: number): number => row * COLS + col

export const initial = (): Connect4State => ({ cells: new Array(ROWS * COLS).fill(null), turn: 'a', moves: [] })

/** The four cell indices of a win, lowest first, or null; the first found scanning from the bottom-left. */
export function winningLine(cells: readonly (Side | null)[]): number[] | null {
  const steps: [number, number][] = [[0, 1], [1, 0], [1, 1], [1, -1]] // along the row, up the column, the two diagonals
  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      const side = cells[index(row, col)]
      if (side === null) continue
      for (const [dr, dc] of steps) {
        const endRow = row + 3 * dr
        const endCol = col + 3 * dc
        if (endRow >= ROWS || endCol < 0 || endCol >= COLS) continue
        const line = [0, 1, 2, 3].map(k => index(row + k * dr, col + k * dc))
        if (line.every(i => cells[i] === side)) return line.sort((x, y) => x - y)
      }
    }
  }
  return null
}

export function status(s: Connect4State): GameStatus {
  const line = winningLine(s.cells)
  if (line) return { over: true, winner: s.cells[line[0]!]!, result: 'four in a row' }
  return s.cells.every(c => c !== null) ? { over: true, winner: null, result: 'draw' } : { over: false }
}

/** The lowest free row of a column, or -1 when it is full. */
export const dropRow = (s: Connect4State, col: number): number => {
  for (let row = 0; row < ROWS; row++) if (s.cells[index(row, col)] === null) return row
  return -1
}

export const legal = (s: Connect4State): string[] =>
  status(s).over ? [] : [...COLUMNS].filter((_, col) => dropRow(s, col) >= 0)

/**
 * The legal column `text` names, read forgivingly: `c`, `C`, `col c`,
 * `column c`, `c.`, or the column's number `3` (a is 1), on the first
 * non-empty line of the text. Never a column `legal` leaves out.
 */
export function parse(s: Connect4State, text: string): string | null {
  const line = text.split('\n').map(l => l.trim()).find(l => l !== '') ?? ''
  const t = line
    .toLowerCase()
    .replace(/^[["'`(]+/, '')
    .replace(/[.,;:!?)\]"'`]+$/, '')
    .replace(/^(?:column|col)\b[\s:.#-]*/, '')
    .trim()
  const col = /^[1-7]$/.test(t) ? COLUMNS[Number(t) - 1]! : /^[a-g]$/.test(t) ? t : null
  return col !== null && legal(s).includes(col) ? col : null
}

export function play(s: Connect4State, move: string): Connect4State {
  if (!legal(s).includes(move)) throw new Error(`not a legal move: ${move}`)
  const col = COLUMNS.indexOf(move)
  const cells = s.cells.slice()
  cells[index(dropRow(s, col), col)] = s.turn
  return { cells, turn: other(s.turn), moves: [...s.moves, move] }
}

export function replay(moves: readonly string[]): Connect4State {
  let s = initial()
  for (const m of moves) {
    const move = parse(s, m)
    if (move === null) break
    s = play(s, move)
  }
  return s
}

/** The moves so far as `Rc` / `Yd`: the side's letter and the column. */
export const history = (s: Connect4State): string[] => s.moves.map((m, i) => `${LETTER[i % 2 === 0 ? 'a' : 'b']}${m}`)

/** The grid as text, row 6 at the top and row 1 at the bottom, `R`, `Y` and `.`, the column letters under it. */
export function ascii(s: Connect4State): string {
  const rows: string[] = []
  for (let row = ROWS - 1; row >= 0; row--) {
    rows.push(`${row + 1}  ${[...COLUMNS].map((_, col) => { const c = s.cells[index(row, col)]; return c === null ? '.' : LETTER[c] }).join(' ')}`)
  }
  rows.push(`   ${[...COLUMNS].join(' ')}`)
  return rows.join('\n')
}

const SYSTEM = `You are playing Connect Four. The board has seven columns, a to g from left to right, and six rows, 1 at the bottom to 6 at the top. Red (R) moves first, then Yellow (Y), taking turns. A move names a column; your disc drops to the lowest empty row of that column. A full column cannot be played. The first player with four discs in a line (along a row, up a column, or on a diagonal) wins. A full board with no four in a line is a draw.

Answer format: the column letter alone on the first line (for example: d). You may add one short line of reasoning after it. Nothing else: no other words on the first line, no quotes, no markdown. Choose only from the legal columns listed in the prompt.`

export function prompt(s: Connect4State, side: Side, lastProblem: string | null): { system: string; prompt: string } {
  const moves = history(s)
  const lines = [
    `You are ${GAME.sides[side]} (${LETTER[side]}).`,
    '',
    'Board (row 6 at the top, row 1 at the bottom):',
    ascii(s),
    '',
    `Moves so far: ${moves.length === 0 ? '(none)' : moves.join(' ')}`,
    `It is ${GAME.sides[s.turn]}'s turn${s.turn === side ? ' (yours)' : ''}.`,
    `Legal columns: ${legal(s).join(', ')}`,
  ]
  if (lastProblem !== null) lines.push('', `Your previous answer was refused: ${lastProblem} Choose from the legal columns above.`)
  lines.push('', 'Your move:')
  return { system: SYSTEM, prompt: lines.join('\n') }
}

/** The position for the window: the cells bottom row first, the last column played, and the winning four. */
export const out = (s: Connect4State): Record<string, unknown> => ({
  cols: COLS,
  rows: ROWS,
  cells: s.cells.slice(),
  lastMove: s.moves.length === 0 ? null : s.moves[s.moves.length - 1]!,
  winningLine: winningLine(s.cells),
})

export const GAME: GameRules<Connect4State> = {
  kind: 'connect4',
  title: 'Connect Four',
  sides: { a: 'Red', b: 'Yellow' },
  initial,
  replay,
  legal,
  parse,
  play,
  turn: s => s.turn,
  status,
  history,
  ascii,
  prompt,
  out,
}
