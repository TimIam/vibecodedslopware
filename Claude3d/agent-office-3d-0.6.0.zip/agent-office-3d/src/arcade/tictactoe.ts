// Tic-tac-toe, pure: X moves first; a move names a square (a1–c3, or 1–9 read
// left to right, top row first). Nothing but an empty square on a live board
// is a legal move.

export type Mark = 'x' | 'o'
export type TttState = {
  /** Nine cells, top-left first, row by row. */
  cells: (Mark | null)[]
  turn: Mark
  history: string[]
}
export type TttStatus = { over: false } | { over: true; winner: Mark | null }

const LINES = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6],
]
const NAMES = ['a3', 'b3', 'c3', 'a2', 'b2', 'c2', 'a1', 'b1', 'c1']

export const tttInitial = (): TttState => ({ cells: new Array(9).fill(null), turn: 'x', history: [] })

export function tttStatus(s: TttState): TttStatus {
  for (const [a, b, c] of LINES) if (s.cells[a!] !== null && s.cells[a!] === s.cells[b!] && s.cells[a!] === s.cells[c!]) return { over: true, winner: s.cells[a!]! }
  return s.cells.every(c => c !== null) ? { over: true, winner: null } : { over: false }
}

export const tttLegalMoves = (s: TttState): number[] => (tttStatus(s).over ? [] : s.cells.flatMap((c, i) => (c === null ? [i] : [])))

export const tttCellName = (i: number): string => NAMES[i] ?? '?'

/** The legal cell `text` names (a1–c3, or 1–9), or -1. */
export function tttParseMove(s: TttState, text: string): number {
  const t = text.trim().toLowerCase()
  const i = /^[1-9]$/.test(t) ? Number(t) - 1 : NAMES.indexOf(t)
  return i >= 0 && tttLegalMoves(s).includes(i) ? i : -1
}

export function tttPlay(s: TttState, cell: number): TttState {
  if (!tttLegalMoves(s).includes(cell)) throw new Error(`not a legal move: ${cell}`)
  const cells = s.cells.slice()
  cells[cell] = s.turn
  return { cells, turn: s.turn === 'x' ? 'o' : 'x', history: [...s.history, `${s.turn.toUpperCase()}${tttCellName(cell)}`] }
}

export function tttAscii(s: TttState): string {
  const rows: string[] = []
  for (let r = 0; r < 3; r++) rows.push(`${3 - r}  ${[0, 1, 2].map(c => (s.cells[r * 3 + c] ?? '.').toUpperCase()).join(' ')}`)
  rows.push('   a b c')
  return rows.join('\n')
}
