// Chess, complete and pure: legal move generation (castling, en passant,
// promotion, check), SAN and UCI, FEN, and the game's result (checkmate,
// stalemate, the fifty-move rule, threefold repetition, insufficient material).
// The arcade holds a game as a ChessState and lets nothing through that is not
// in `legalMoves(state)`, whoever proposes it.

export type Color = 'w' | 'b'
export type PieceType = 'p' | 'n' | 'b' | 'r' | 'q' | 'k'
/** Uppercase white, lowercase black, as in FEN. */
export type Piece = 'P' | 'N' | 'B' | 'R' | 'Q' | 'K' | 'p' | 'n' | 'b' | 'r' | 'q' | 'k'

export type Move = {
  /** Squares 0–63, a1 = 0, h1 = 7, a8 = 56. */
  from: number
  to: number
  piece: Piece
  captured: Piece | null
  promotion: 'q' | 'r' | 'b' | 'n' | null
  isCastle: boolean
  isEnPassant: boolean
}

export type ChessState = {
  board: (Piece | null)[]
  turn: Color
  castling: { K: boolean; Q: boolean; k: boolean; q: boolean }
  /** The en passant target square, or -1. */
  ep: number
  halfmove: number
  fullmove: number
  /** The moves so far, in SAN. */
  history: string[]
  /** Position keys seen, for repetition: board, side, castling and en passant. */
  seen: string[]
}

export type ChessStatus =
  | { over: false; inCheck: boolean }
  | { over: true; result: 'checkmate'; winner: Color }
  | { over: true; result: 'stalemate' | 'fifty-move' | 'repetition' | 'material'; winner: null }

export const FILES = 'abcdefgh'
export const START_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'

export const squareName = (sq: number): string => `${FILES[sq % 8]}${Math.floor(sq / 8) + 1}`
export const squareIndex = (name: string): number => {
  const file = FILES.indexOf(name[0]!)
  const rank = Number(name[1]) - 1
  return file < 0 || rank < 0 || rank > 7 || name.length !== 2 ? -1 : rank * 8 + file
}
const colorOf = (p: Piece): Color => (p === p.toUpperCase() ? 'w' : 'b')
const typeOf = (p: Piece): PieceType => p.toLowerCase() as PieceType
const other = (c: Color): Color => (c === 'w' ? 'b' : 'w')

export function parseFen(fen: string): ChessState {
  const [placement, turn, castling, ep, half, full] = fen.trim().split(/\s+/)
  const board: (Piece | null)[] = new Array(64).fill(null)
  const ranks = (placement ?? '').split('/')
  if (ranks.length !== 8) throw new Error('FEN: eight ranks expected')
  ranks.forEach((row, i) => {
    let file = 0
    for (const ch of row) {
      if (/[1-8]/.test(ch)) file += Number(ch)
      else if (/[pnbrqkPNBRQK]/.test(ch)) board[(7 - i) * 8 + file++] = ch as Piece
      else throw new Error(`FEN: bad piece ${ch}`)
    }
    if (file !== 8) throw new Error('FEN: a rank is not eight squares')
  })
  const state: ChessState = {
    board,
    turn: turn === 'b' ? 'b' : 'w',
    castling: { K: (castling ?? '').includes('K'), Q: (castling ?? '').includes('Q'), k: (castling ?? '').includes('k'), q: (castling ?? '').includes('q') },
    ep: ep && ep !== '-' ? squareIndex(ep) : -1,
    halfmove: Number(half ?? 0) || 0,
    fullmove: Number(full ?? 1) || 1,
    history: [],
    seen: [],
  }
  state.seen.push(positionKey(state))
  return state
}

export function toFen(s: ChessState): string {
  const rows: string[] = []
  for (let rank = 7; rank >= 0; rank--) {
    let row = ''
    let empty = 0
    for (let file = 0; file < 8; file++) {
      const p = s.board[rank * 8 + file]
      if (p === null) empty += 1
      else {
        if (empty > 0) row += String(empty)
        empty = 0
        row += p
      }
    }
    if (empty > 0) row += String(empty)
    rows.push(row)
  }
  const c = `${s.castling.K ? 'K' : ''}${s.castling.Q ? 'Q' : ''}${s.castling.k ? 'k' : ''}${s.castling.q ? 'q' : ''}` || '-'
  return `${rows.join('/')} ${s.turn} ${c} ${s.ep >= 0 ? squareName(s.ep) : '-'} ${s.halfmove} ${s.fullmove}`
}

export const initialState = (): ChessState => parseFen(START_FEN)

function positionKey(s: ChessState): string {
  return toFen(s).split(' ').slice(0, 4).join(' ')
}

// ─── Attacks ───────────────────────────────────────────────────────────────
const KNIGHT = [
  [1, 2], [2, 1], [2, -1], [1, -2], [-1, -2], [-2, -1], [-2, 1], [-1, 2],
]
const KING = [
  [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1],
]
const BISHOP_RAYS = [[1, 1], [1, -1], [-1, 1], [-1, -1]]
const ROOK_RAYS = [[1, 0], [-1, 0], [0, 1], [0, -1]]

const onBoard = (f: number, r: number): boolean => f >= 0 && f < 8 && r >= 0 && r < 8

/** Whether `by` attacks square `sq` on `board`. */
export function isAttacked(board: readonly (Piece | null)[], sq: number, by: Color): boolean {
  const f = sq % 8
  const r = Math.floor(sq / 8)
  const enemy = (p: Piece | null, t: PieceType): boolean => p !== null && colorOf(p) === by && typeOf(p) === t
  // Pawns: a white pawn attacks upward, so a square is attacked by white from one rank below.
  const pr = by === 'w' ? r - 1 : r + 1
  for (const df of [-1, 1]) if (onBoard(f + df, pr) && enemy(board[pr * 8 + f + df]!, 'p')) return true
  for (const [df, dr] of KNIGHT) if (onBoard(f + df!, r + dr!) && enemy(board[(r + dr!) * 8 + f + df!]!, 'n')) return true
  for (const [df, dr] of KING) if (onBoard(f + df!, r + dr!) && enemy(board[(r + dr!) * 8 + f + df!]!, 'k')) return true
  for (const [rays, types] of [
    [BISHOP_RAYS, ['b', 'q']],
    [ROOK_RAYS, ['r', 'q']],
  ] as const) {
    for (const [df, dr] of rays) {
      let nf = f + df!
      let nr = r + dr!
      while (onBoard(nf, nr)) {
        const p = board[nr * 8 + nf]!
        if (p !== null) {
          if (colorOf(p) === by && (types as readonly string[]).includes(typeOf(p))) return true
          break
        }
        nf += df!
        nr += dr!
      }
    }
  }
  return false
}

function kingSquare(board: readonly (Piece | null)[], color: Color): number {
  const k = color === 'w' ? 'K' : 'k'
  return board.indexOf(k)
}

export const isInCheck = (s: ChessState, color: Color = s.turn): boolean => {
  const k = kingSquare(s.board, color)
  return k >= 0 && isAttacked(s.board, k, other(color))
}

// ─── Moves ─────────────────────────────────────────────────────────────────
function pseudoMoves(s: ChessState): Move[] {
  const moves: Move[] = []
  const us = s.turn
  const them = other(us)
  const add = (from: number, to: number, piece: Piece, extra: Partial<Move> = {}) => {
    const captured = extra.isEnPassant ? (them === 'w' ? 'P' : 'p') : s.board[to]
    moves.push({ from, to, piece, captured, promotion: null, isCastle: false, isEnPassant: false, ...extra })
  }
  for (let from = 0; from < 64; from++) {
    const piece = s.board[from]
    if (piece === null || colorOf(piece) !== us) continue
    const f = from % 8
    const r = Math.floor(from / 8)
    const t = typeOf(piece)
    if (t === 'p') {
      const dir = us === 'w' ? 1 : -1
      const startRank = us === 'w' ? 1 : 6
      const lastRank = us === 'w' ? 7 : 0
      const one = (r + dir) * 8 + f
      const pushes: number[] = []
      if (onBoard(f, r + dir) && s.board[one] === null) {
        pushes.push(one)
        const two = (r + 2 * dir) * 8 + f
        if (r === startRank && s.board[two] === null) pushes.push(two)
      }
      const targets: { to: number; ep: boolean }[] = pushes.map(to => ({ to, ep: false }))
      for (const df of [-1, 1]) {
        if (!onBoard(f + df, r + dir)) continue
        const to = (r + dir) * 8 + f + df
        const p = s.board[to]
        if (p !== null && colorOf(p) === them) targets.push({ to, ep: false })
        else if (to === s.ep && p === null) targets.push({ to, ep: true })
      }
      for (const { to, ep } of targets) {
        if (Math.floor(to / 8) === lastRank) for (const promotion of ['q', 'r', 'b', 'n'] as const) add(from, to, piece, { promotion })
        else add(from, to, piece, { isEnPassant: ep })
      }
    } else if (t === 'n' || t === 'k') {
      for (const [df, dr] of t === 'n' ? KNIGHT : KING) {
        if (!onBoard(f + df!, r + dr!)) continue
        const to = (r + dr!) * 8 + f + df!
        const p = s.board[to]
        if (p === null || colorOf(p) === them) add(from, to, piece)
      }
      if (t === 'k') {
        const home = us === 'w' ? 4 : 60
        const rights = us === 'w' ? [s.castling.K, s.castling.Q] : [s.castling.k, s.castling.q]
        if (from === home && !isAttacked(s.board, home, them)) {
          // King side: f and g empty, neither attacked; queen side: b, c, d empty, c and d not attacked.
          if (rights[0] && s.board[home + 1] === null && s.board[home + 2] === null && s.board[home + 3] === (us === 'w' ? 'R' : 'r'))
            if (!isAttacked(s.board, home + 1, them) && !isAttacked(s.board, home + 2, them)) add(from, home + 2, piece, { isCastle: true })
          if (rights[1] && s.board[home - 1] === null && s.board[home - 2] === null && s.board[home - 3] === null && s.board[home - 4] === (us === 'w' ? 'R' : 'r'))
            if (!isAttacked(s.board, home - 1, them) && !isAttacked(s.board, home - 2, them)) add(from, home - 2, piece, { isCastle: true })
        }
      }
    } else {
      const rays = t === 'b' ? BISHOP_RAYS : t === 'r' ? ROOK_RAYS : [...BISHOP_RAYS, ...ROOK_RAYS]
      for (const [df, dr] of rays) {
        let nf = f + df!
        let nr = r + dr!
        while (onBoard(nf, nr)) {
          const to = nr * 8 + nf
          const p = s.board[to]
          if (p === null) add(from, to, piece)
          else {
            if (colorOf(p) === them) add(from, to, piece)
            break
          }
          nf += df!
          nr += dr!
        }
      }
    }
  }
  return moves
}

/** The position after `move`, with the clocks, rights, en passant square and history moved on. */
export function applyMove(s: ChessState, move: Move): ChessState {
  const board = s.board.slice()
  const us = s.turn
  board[move.from] = null
  if (move.isEnPassant) board[move.to + (us === 'w' ? -8 : 8)] = null
  board[move.to] = move.promotion ? ((us === 'w' ? move.promotion.toUpperCase() : move.promotion) as Piece) : move.piece
  if (move.isCastle) {
    const rank = Math.floor(move.from / 8) * 8
    if (move.to > move.from) {
      board[rank + 5] = board[rank + 7]
      board[rank + 7] = null
    } else {
      board[rank + 3] = board[rank]
      board[rank] = null
    }
  }
  const castling = { ...s.castling }
  if (move.piece === 'K') castling.K = castling.Q = false
  if (move.piece === 'k') castling.k = castling.q = false
  for (const sq of [move.from, move.to]) {
    if (sq === 0) castling.Q = false
    if (sq === 7) castling.K = false
    if (sq === 56) castling.q = false
    if (sq === 63) castling.k = false
  }
  const isPawn = typeOf(move.piece) === 'p'
  const next: ChessState = {
    board,
    turn: other(us),
    castling,
    ep: isPawn && Math.abs(move.to - move.from) === 16 ? (move.from + move.to) / 2 : -1,
    halfmove: isPawn || move.captured !== null ? 0 : s.halfmove + 1,
    fullmove: us === 'b' ? s.fullmove + 1 : s.fullmove,
    history: [...s.history, ''],
    seen: [...s.seen],
  }
  next.seen.push(positionKey(next))
  return next
}

/** Every legal move for the side to move. */
export function legalMoves(s: ChessState): Move[] {
  return pseudoMoves(s).filter(m => {
    const after = applyMove(s, m)
    return !isInCheck(after, s.turn)
  })
}

/** Plays `move`, recording its SAN (with its check or mate suffix) in the history. */
export function play(s: ChessState, move: Move): ChessState {
  const san = toSan(s, move)
  const next = applyMove(s, move)
  const st = status(next)
  next.history[next.history.length - 1] = san + (st.over && st.result === 'checkmate' ? '#' : !st.over && st.inCheck ? '+' : '')
  return next
}

export function status(s: ChessState): ChessStatus {
  const moves = legalMoves(s)
  const inCheck = isInCheck(s)
  if (moves.length === 0) return inCheck ? { over: true, result: 'checkmate', winner: other(s.turn) } : { over: true, result: 'stalemate', winner: null }
  if (s.halfmove >= 100) return { over: true, result: 'fifty-move', winner: null }
  const key = positionKey(s)
  if (s.seen.filter(k => k === key).length >= 3) return { over: true, result: 'repetition', winner: null }
  if (isInsufficient(s.board)) return { over: true, result: 'material', winner: null }
  return { over: false, inCheck }
}

/** King against king, or king and one minor piece against king. */
function isInsufficient(board: readonly (Piece | null)[]): boolean {
  const pieces = board.filter((p): p is Piece => p !== null && typeOf(p) !== 'k')
  if (pieces.length === 0) return true
  if (pieces.length === 1) return typeOf(pieces[0]!) === 'b' || typeOf(pieces[0]!) === 'n'
  return false
}

// ─── Notation ──────────────────────────────────────────────────────────────
/** Standard algebraic notation for `move` in position `s`, without the check suffix (`play` adds it). */
export function toSan(s: ChessState, move: Move): string {
  if (move.isCastle) return move.to > move.from ? 'O-O' : 'O-O-O'
  const t = typeOf(move.piece)
  const dest = squareName(move.to)
  const promo = move.promotion ? `=${move.promotion.toUpperCase()}` : ''
  if (t === 'p') return (move.captured !== null ? `${FILES[move.from % 8]}x` : '') + dest + promo
  // Disambiguate among other legal moves of the same piece type to the same square.
  const others = legalMoves(s).filter(m => m.to === move.to && m.from !== move.from && typeOf(m.piece) === t)
  let dis = ''
  if (others.length > 0) {
    const sameFile = others.some(m => m.from % 8 === move.from % 8)
    const sameRank = others.some(m => Math.floor(m.from / 8) === Math.floor(move.from / 8))
    if (!sameFile) dis = FILES[move.from % 8]!
    else if (!sameRank) dis = String(Math.floor(move.from / 8) + 1)
    else dis = squareName(move.from)
  }
  return `${t.toUpperCase()}${dis}${move.captured !== null ? 'x' : ''}${dest}`
}

export const toUci = (move: Move): string => `${squareName(move.from)}${squareName(move.to)}${move.promotion ?? ''}`

/**
 * The legal move `text` names, in UCI (e2e4, e7e8q) or SAN (Nf3, exd5, O-O,
 * e8=Q, with or without +, #, !, ?), or null. Only moves in `legalMoves(s)`
 * can come back: an illegal move is simply not found.
 */
export function parseMove(s: ChessState, text: string): Move | null {
  const raw = text.trim().replace(/[+#!?]+$/g, '').replace(/^0-0-0$/i, 'O-O-O').replace(/^0-0$/i, 'O-O')
  if (raw === '') return null
  const moves = legalMoves(s)
  const uci = raw.toLowerCase().replace(/[-=]/g, '')
  if (/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(uci)) {
    const found = moves.find(m => toUci(m) === uci)
    if (found) return found
    // A promotion given without its piece: the queen.
    if (uci.length === 4) return moves.find(m => toUci(m) === `${uci}q`) ?? null
    return null
  }
  const wanted = raw.replace(/e\.p\./i, '').replace(/\s+/g, '')
  const byCastle = /^o-o(-o)?$/i.test(wanted) ? wanted.toUpperCase() : wanted
  return moves.find(m => toSan(s, m) === byCastle) ?? moves.find(m => toSan(s, m).replace(/=.$/, '') === byCastle && m.promotion === 'q') ?? null
}

/** The board as eight rows of text, rank 8 first, `.` for an empty square, for a model's eyes. */
export function asciiBoard(s: ChessState): string {
  const rows: string[] = []
  for (let rank = 7; rank >= 0; rank--) {
    let row = `${rank + 1} `
    for (let file = 0; file < 8; file++) row += ` ${s.board[rank * 8 + file] ?? '.'}`
    rows.push(row)
  }
  rows.push('   a b c d e f g h')
  return rows.join('\n')
}

/** The number of leaf positions `depth` plies down: the standard test of a move generator. */
export function perft(s: ChessState, depth: number): number {
  if (depth === 0) return 1
  const moves = legalMoves(s)
  if (depth === 1) return moves.length
  let n = 0
  for (const m of moves) n += perft(applyMove(s, m), depth - 1)
  return n
}
