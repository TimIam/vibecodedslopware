// The escape rooms: three themes, each a data object of what the person can
// see (objects), what inspecting an object reveals (its clue), and the locks
// (puzzles) that stand between the person and the exit.
//
// The answers are not here. Each puzzle holds only a salted SHA-256 of its
// answer, and `checkAnswer` compares a guess by hashing it the same way
// (lower case, whitespace folded). So nothing that reads this module, the
// state built from it, or a prompt built from it can read an answer off it:
// the teammate (hooks/escape.ts `teammateView`) is given names,
// descriptions, the clues already discovered and the lock prompts, and infers
// the rest exactly as the person must.

export type EscapeObject = {
  id: string
  name: string
  /** What you see before you touch it. */
  description: string
  /** What inspecting it reveals; some objects reveal nothing. */
  clue?: string
}

export type EscapePuzzle = {
  id: string
  /** What the lock asks. */
  prompt: string
  /** `hash(answer)`: a salted SHA-256, hex. The answer itself is nowhere in this module. */
  answerHash: string
  /** The objects whose clues bear on it (ids), for the room's own bookkeeping; never shown as such. */
  clueIds: string[]
  /** Shown once it is solved: what happens, and anything the opening reveals. */
  successText: string
}

export type EscapeRoom = {
  id: string
  title: string
  /** One line naming the theme, for signs and the room picker. */
  theme: string
  intro: string
  objects: EscapeObject[]
  /** In order; the exit puzzle stays locked until every other puzzle is solved. */
  puzzles: EscapePuzzle[]
  /** The puzzle whose solving opens the way out. */
  exit: string
}

// ─── A small SHA-256 (no dependency) ───────────────────────────────────────
const K = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
  0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
  0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
  0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
])

const rotr = (x: number, n: number): number => (x >>> n) | (x << (32 - n))

/** SHA-256 of a string (UTF-8), as 64 hex digits. */
export function sha256Hex(text: string): string {
  const bytes = new TextEncoder().encode(text)
  const bitLen = bytes.length * 8
  const padded = new Uint8Array(((bytes.length + 9 + 63) >> 6) << 6)
  padded.set(bytes)
  padded[bytes.length] = 0x80
  const view = new DataView(padded.buffer)
  view.setUint32(padded.length - 8, Math.floor(bitLen / 0x100000000))
  view.setUint32(padded.length - 4, bitLen >>> 0)
  const h = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19])
  const w = new Uint32Array(64)
  for (let off = 0; off < padded.length; off += 64) {
    for (let i = 0; i < 16; i++) w[i] = view.getUint32(off + i * 4)
    for (let i = 16; i < 64; i++) {
      const s0 = rotr(w[i - 15]!, 7) ^ rotr(w[i - 15]!, 18) ^ (w[i - 15]! >>> 3)
      const s1 = rotr(w[i - 2]!, 17) ^ rotr(w[i - 2]!, 19) ^ (w[i - 2]! >>> 10)
      w[i] = (w[i - 16]! + s0 + w[i - 7]! + s1) >>> 0
    }
    let [a, b, c, d, e, f, g, hh] = [h[0]!, h[1]!, h[2]!, h[3]!, h[4]!, h[5]!, h[6]!, h[7]!]
    for (let i = 0; i < 64; i++) {
      const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)
      const ch = (e & f) ^ (~e & g)
      const t1 = (hh + S1 + ch + K[i]! + w[i]!) >>> 0
      const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)
      const maj = (a & b) ^ (a & c) ^ (b & c)
      const t2 = (S0 + maj) >>> 0
      hh = g
      g = f
      f = e
      e = (d + t1) >>> 0
      d = c
      c = b
      b = a
      a = (t1 + t2) >>> 0
    }
    h[0] = (h[0]! + a) >>> 0
    h[1] = (h[1]! + b) >>> 0
    h[2] = (h[2]! + c) >>> 0
    h[3] = (h[3]! + d) >>> 0
    h[4] = (h[4]! + e) >>> 0
    h[5] = (h[5]! + f) >>> 0
    h[6] = (h[6]! + g) >>> 0
    h[7] = (h[7]! + hh) >>> 0
  }
  return Array.from(h, x => x.toString(16).padStart(8, '0')).join('')
}

// ─── Answers as hashes ─────────────────────────────────────────────────────
/** The fixed salt: it only keeps a stored hash from being looked up in a table of common words. */
const SALT = 'agent-office-3d/escape/v1'

/** A guess as the lock reads it: lower case, whitespace folded to single spaces, trimmed. */
export const normalise = (text: string): string => text.toLowerCase().replace(/\s+/g, ' ').trim()

/** The salted hash of an answer (or a guess), after normalising. */
export const hash = (text: string): string => sha256Hex(`${SALT}:${normalise(text)}`)

/** Whether `guess` opens `puzzle`. The comparison is hash to hash: the answer is never recovered. */
export const checkAnswer = (puzzle: EscapePuzzle, guess: string): boolean => normalise(guess) !== '' && hash(guess) === puzzle.answerHash

// ─── The rooms ─────────────────────────────────────────────────────────────
const MANSION: EscapeRoom = {
  id: 'mansion',
  title: 'Blackwood Manor',
  theme: 'a spooky mansion',
  intro:
    'The front door of Blackwood Manor slammed shut behind you and the bolt shot home. Dust, candle smoke, a storm against the shutters. ' +
    'Somewhere in the dark a clock is not ticking. The door out is locked from this side, and it wants more than a key.',
  objects: [
    {
      id: 'portrait',
      name: 'Portrait of Lady Blackwood',
      description: 'A stern woman in black, a closed fan in her lap. Her eyes seem to follow you round the room.',
      clue: "Behind the frame is a wall safe with a four-digit dial. On the back of the canvas, in faded ink: 'My heart stopped at the hour the clock keeps. Hour, then minute.'",
    },
    {
      id: 'clock',
      name: 'Grandfather clock',
      description: 'A tall case clock, its pendulum hanging dead still. The glass over the face is fogged.',
      clue: 'Wiping the glass: the hands stopped at a quarter past three. Scratched under the dial: "as the dial would show it, no more, no less".',
    },
    {
      id: 'bookshelf',
      name: 'Bookshelf',
      description: 'Leather-bound volumes, most of them rotted through. One spine is cleaner than the rest.',
      clue: "The clean book is a false front. Inside, a card: 'The door asks the raven's word. The mirror remembers it, the way mirrors do.'",
    },
    {
      id: 'mirror',
      name: 'Cracked mirror',
      description: 'A tall mirror, cracked corner to corner. Your reflection looks as tired as you feel.',
      clue: 'Someone wrote in the dust on the glass, nine capital letters, but they read as a mirror would show them: E R O M R E V E N.',
    },
    {
      id: 'candelabra',
      name: 'Candelabra',
      description: 'Five candles, three of them lit, dripping wax onto a side table beside a small music box.',
      clue: "Melted into the wax at the base: 'She danced the three-step dance of Vienna until the clock struck.'",
    },
  ],
  puzzles: [
    {
      id: 'safe',
      prompt: 'The wall safe behind the portrait: a dial that takes four digits.',
      answerHash: '5f21dee33efb680ca2c8b035eda79025f5edf265fc020f35eacc055158872378',
      clueIds: ['portrait', 'clock'],
      successText: "The safe swings open. Inside, a brass key on a ribbon and a card: 'Two keys, then the word, and the door will yield.'",
    },
    {
      id: 'musicbox',
      prompt: "The music box on the side table has a dial of letters and a plate: 'Name the dance she loved.'",
      answerHash: '0bbbfb0e5aa7a9e44ffd5191f902d9b4474096ba448affd53280a6aa506dcd32',
      clueIds: ['candelabra'],
      successText: 'The music box plays a slow three-four tune and a hidden drawer slides out, holding a silver key.',
    },
    {
      id: 'door',
      prompt: "The front door: two keyholes, brass and silver, and a dial of letters above them marked 'the raven's word'.",
      answerHash: '0d13ff4824e88699007c428adc3b91dd0c0f45728a75be5681a48d72e99645d8',
      clueIds: ['bookshelf', 'mirror'],
      successText: 'Both keys turn, the letters click into place, and the bolt draws back. Rain and night air pour in. You are out.',
    },
  ],
  exit: 'door',
}

const STATION: EscapeRoom = {
  id: 'station',
  title: 'Station Kepler-9',
  theme: 'a failing space station',
  intro:
    "Kepler-9's airlock sealed behind you. The lights are red, the recyclers hiss, and a calm voice is counting down to decompression. " +
    'The escape pod is docked at the far end of the module, behind a door that is in no hurry to open.',
  objects: [
    {
      id: 'console',
      name: 'Main console',
      description: 'A cracked screen scrolls diagnostics in pale green. Most of the keys are dead.',
      clue: "A sticky note on the bezel: 'Pod bay keypad: the tanks, then the deck, then the pods docked. Three digits, that order.'",
    },
    {
      id: 'tanks',
      name: 'Oxygen rack',
      description: 'A rack of grey cylinders bolted to the wall, most of their gauges reading empty.',
      clue: 'Seven tanks in the rack, counted twice. A stencil along the top rail reads DECK 6.',
    },
    {
      id: 'hatch',
      name: 'Maintenance hatch',
      description: 'A floor hatch with two of its four bolts missing.',
      clue: "Inside the hatch, a docking log: 'Pods docked this cycle: 3.' Nothing else but cable.",
    },
    {
      id: 'vent',
      name: 'Air vent',
      description: 'A grille rattling with the recycler’s breath, warm to the touch.',
      clue: 'Behind the grille, wedged in the duct: a fuse, still warm. Its casing is the colour of a clear sky.',
    },
    {
      id: 'locker',
      name: 'Crew locker',
      description: 'A dented locker, the name tag scratched off.',
      clue: "Inside, a crew badge: Cmdr. Ines Okafor. On the back, in pen: 'voice passphrase = my cat’s name, as his collar spells it'.",
    },
    {
      id: 'photo',
      name: 'Taped photograph',
      description: 'A photo taped above the locker: a grinning crew member holding an orange cat.',
      clue: 'The cat wears a collar tag, legible under the tape, one letter at a time: B · I · S · C · U · I · T.',
    },
  ],
  puzzles: [
    {
      id: 'keypad',
      prompt: 'The pod bay keypad asks for a three-digit code.',
      answerHash: '50d022235a6edf311dd90d7fcce07942ebc4bd78a938ca6926604b093bc15df3',
      clueIds: ['console', 'tanks', 'hatch'],
      successText: "The keypad chimes green. A fuse box beside the door lights up amber: 'FUSE MISSING'.",
    },
    {
      id: 'fuse',
      prompt: 'The fuse box by the pod door has five slots, four filled (red, green, yellow, white) and one empty. It asks for the colour of the missing fuse.',
      answerHash: '9b18def34cb6a45e1ea561b396b25a53cfdaebcd1474fc47f270a9721ea271d0',
      clueIds: ['vent'],
      successText: "The fuse seats with a click and the door motors hum. A panel lights: 'VOICE AUTH: commander’s passphrase.'",
    },
    {
      id: 'voice',
      prompt: "The voice panel: 'State the commander’s passphrase.'",
      answerHash: '3a01e298823bcb5297e0fe15aaefa1660f904c268c1112d7addef40ac0bc207a',
      clueIds: ['locker', 'photo'],
      successText: "'Voice accepted.' The pod bay door slides wide, the pod’s lights come on, and you strap in as the countdown stops.",
    },
  ],
  exit: 'voice',
}

const VAULT: EscapeRoom = {
  id: 'vault',
  title: 'The Meridian Vault',
  theme: 'a heist gone sideways',
  intro:
    "The Meridian Bank's vault door swung shut behind you and the wall timer started counting. Twenty minutes before the guards come back round. " +
    'The inner door, the one that leads out through the counting room, is locked from this side.',
  objects: [
    {
      id: 'ledger',
      name: 'Leather ledger',
      description: 'A bank ledger lying open on a lectern, columns of figures in a careful hand.',
      clue: "One row is circled in red: 'Box 19, property of A. Marchetti. Inner safe combination: her birth year.'",
    },
    {
      id: 'deposit',
      name: 'Wall of deposit boxes',
      description: 'Rows of small brass doors, numbered 1 to 60. One of them is not quite shut.',
      clue: 'Box 19 is the one ajar. Inside, a passport: Alessandra Marchetti, born the twelfth of May, nineteen seventy-four.',
    },
    {
      id: 'painting',
      name: 'Oil painting',
      description: 'A stormy harbour scene in a gilt frame, hung oddly low on the wall.',
      clue: "Behind it, a brass plate: 'The inner door answers to the ship’s name.' The ship’s hull carries the bank’s own name, then the word for what sailors steer by at night.",
    },
    {
      id: 'timer',
      name: 'Wall timer',
      description: 'Red digits counting down. 19:40. 19:39. Nothing to be done about it.',
    },
    {
      id: 'plans',
      name: 'Rolled plans',
      description: "The architect's drawings of the vault, rolled in a cardboard tube.",
      clue: "A pencilled note beside the inner door on the plan: 'Needs the safe’s key AND the word. Safe first.'",
    },
  ],
  puzzles: [
    {
      id: 'boxlock',
      prompt: 'The combination lock on the inner safe takes four digits.',
      answerHash: '005af83df6792c516a216f85d1c66b79ef3c046e003bbed995de27507121e5b8',
      clueIds: ['ledger', 'deposit'],
      successText: "The inner safe opens. Inside, a brass key tagged 'inner door' and a stack of someone else’s money.",
    },
    {
      id: 'door',
      prompt: "The inner door: a keyhole and a dial of letters. A plate reads 'Name the ship.'",
      answerHash: 'c26acfd21b9ae7d611a791e1ef587bbf437b5737063704ddade21ed3b241f96c',
      clueIds: ['painting', 'plans'],
      successText: 'The key turns, the letters lock in, and the inner door swings open onto the dark counting room. Four minutes to spare.',
    },
  ],
  exit: 'door',
}

/** The rooms in rotation order: `enter` with no room id takes the one after the current. */
export const ROOMS: readonly EscapeRoom[] = [MANSION, STATION, VAULT]

export const roomById = (id: string | null): EscapeRoom | undefined => (id === null ? undefined : ROOMS.find(r => r.id === id))

/** The room after `current` in rotation (the first when there is none, or it is unknown). */
export function nextRoom(current: string | null): EscapeRoom {
  const i = ROOMS.findIndex(r => r.id === current)
  return ROOMS[(i + 1) % ROOMS.length]!
}
