// Conversation text, labels and anything read back from the shared store are
// untrusted data. These helpers make them inert before they are drawn: plain
// text only, no terminal escapes, control or direction-override characters,
// no broken surrogate pairs, and a bounded length.

const ANSI = /\u001B(?:\[[0-?]*[ -/]*[@-~]|\][^\u0007\u001B]*(?:\u0007|\u001B\\)?|[@-Z\\-_])/g
const CONTROL = /[\u0000-\u0008\u000B-\u001F\u007F-\u009F]/g
const INVISIBLE = /[​-‏‪-‮⁠-⁩﻿]/g
const LONE_SURROGATE = /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g

/** Text safe to draw as a plain `Text` child, newlines kept, at most `max` characters. */
export function inert(value: unknown, max: number): string {
  if (typeof value !== 'string') return ''
  let text = value
    .replace(ANSI, '')
    .replace(/\r\n?/g, '\n')
    .replace(/\t/g, '  ')
    .replace(CONTROL, '')
    .replace(INVISIBLE, '')
  if (text.length > max) text = text.slice(0, Math.max(0, max - 1)) + '…'
  return text.replace(LONE_SURROGATE, '')
}

/** `inert`, folded onto one line. */
export function oneLine(value: unknown, max: number): string {
  return inert(inert(value, max * 4).replace(/\s+/g, ' ').trim(), max)
}

/** Escapes text for an SVG text node or attribute value. */
export function xml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}
