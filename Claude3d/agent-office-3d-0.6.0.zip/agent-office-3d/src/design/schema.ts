// The world editor's vocabulary and its gate. A scene edit is data: a prop
// made of a few primitives at an anchor, a desk size, a room's colours or
// size, or a theme of named colours. `validate` lets through exactly the
// shapes below, within the bounds below, and nothing else: no unknown fields,
// no colour that is not `#rrggbb`, no string that carries markup, a script,
// an event handler, a URL or a scheme, nothing outside its bounds, and no
// anchor that is not one of the allowed forms. `foldEdits` applies edits to a
// scene without touching the scene it was given.
//
// Nothing here can name a status light, a hand, an android or an arcade
// board: the vocabulary has no role for them.

import type {
  Anchor,
  DeskAnchor,
  DeskSize,
  DesignContext,
  Hex,
  Part,
  Prop,
  RoomStyle,
  SceneDoc,
  SceneEdit,
  Theme,
  Vec3,
} from '../../types'

export type { Anchor, DeskAnchor, DeskSize, DesignContext, Hex, Part, Prop, RoomStyle, SceneDoc, SceneEdit, Theme, Vec3 }

/** The bounds, in metres where they are sizes. Every number a request can carry is checked against one of these. */
export const BOUNDS = Object.freeze({
  /** Props in a scene. */
  maxProps: 40,
  /** Primitives in one prop. */
  maxParts: 12,
  /** Edits in one request. */
  maxEdits: 20,
  maxDesks: 64,
  maxRooms: 32,
  id: 32,
  name: 40,
  text: 40,
  key: 120,
  project: 80,
  session: 64,
  request: 400,
  explanation: 300,
  /** A box's sides, a cylinder's or cone's height. */
  size: { min: 0.02, max: 3 },
  radius: { min: 0.01, max: 1.5 },
  /** A label's height. */
  textSize: { min: 0.05, max: 0.5 },
  /** Where a part stands inside its prop. */
  partAt: { xz: 2, y: 3 },
  /** A prop's offset from its anchor, per anchor kind. The hallway's x runs along it from the entrance end. */
  offset: { desk: { xz: 3, y: 2.5 }, room: { xz: 7, y: 2.8 }, hallway: { xMin: 0, xMax: 60, z: 1.8, y: 2.8 } },
  yaw: 360,
  desk: { w: { min: 0.6, max: 2.4 }, d: { min: 0.4, max: 1.4 } },
  room: { width: { min: 10, max: 20 }, depth: { min: 10, max: 20 } },
  /** Applied scenes kept for undo. */
  history: 20,
})

const ID_RE = /^[a-z0-9][a-z0-9_-]{0,31}$/
const KEY_RE = /^[A-Za-z0-9_:.@-]{1,120}$/
const SESSION_RE = /^[A-Za-z0-9_:.-]{1,64}$/
const SEAT_RE = /^(lead|agent [1-9][0-9]?)$/
const HEX_RE = /^#[0-9a-fA-F]{6}$/

/** What no string may carry, whatever field it is in. */
const UNSAFE: readonly [RegExp, string][] = [
  [/[<>]/, 'angle brackets'],
  [/javascript:/i, 'a javascript: scheme'],
  [/vbscript:/i, 'a vbscript: scheme'],
  [/data:/i, 'a data: scheme'],
  [/file:/i, 'a file: scheme'],
  [/url\s*\(/i, 'url('],
  [/\bon\w+\s*=/i, 'an event handler'],
  [/[a-z][a-z0-9+.-]*:\/\//i, 'a URL'],
  [/&#|&[a-z]+;/i, 'an HTML entity'],
  [/[\u0000-\u001f\u007f-\u009f]/, 'control characters'],
  [/[\u200b-\u200f\u2028-\u202e\u2060-\u2069\ufeff]/, 'invisible characters'],
]

export class Refusal extends Error {}
const refuse = (what: string, why: string): never => {
  throw new Refusal(`${what}: ${why}`)
}

const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v)
/** A field name as it may appear in a reason (the name came from outside). */
const fieldName = (k: string): string => k.replace(/[^\w.-]/g, '?').slice(0, 30)

function fields(v: unknown, what: string, allowed: readonly string[]): Record<string, unknown> {
  if (!isRecord(v)) return refuse(what, 'must be an object')
  const extra = Object.keys(v).filter(k => !allowed.includes(k))
  if (extra.length > 0) refuse(what, `unknown field${extra.length > 1 ? 's' : ''} ${extra.map(fieldName).join(', ')}`)
  return v
}

function num(v: unknown, what: string, min: number, max: number): number {
  if (typeof v !== 'number' || !Number.isFinite(v)) return refuse(what, 'must be a number')
  if (v < min || v > max) refuse(what, `must be between ${min} and ${max}`)
  return v
}

function text(v: unknown, what: string, max: number, pattern?: RegExp): string {
  if (typeof v !== 'string') return refuse(what, 'must be a string')
  const t = v.trim()
  if (t === '') refuse(what, 'must not be empty')
  if (t.length > max) refuse(what, `must be at most ${max} characters`)
  for (const [re, why] of UNSAFE) if (re.test(t)) refuse(what, `contains ${why}`)
  if (pattern !== undefined && !pattern.test(t)) refuse(what, 'has characters that are not allowed there')
  return t
}

function hex(v: unknown, what: string): Hex {
  if (typeof v !== 'string' || !HEX_RE.test(v)) return refuse(what, 'must be a hex colour like #a0b0c0')
  return v.toLowerCase()
}

function unit(v: unknown, what: string): number | undefined {
  return v === undefined ? undefined : num(v, what, 0, 1)
}

function vec3(v: unknown, what: string, x: [number, number], y: [number, number], z: [number, number]): Vec3 {
  const o = fields(v, what, ['x', 'y', 'z'])
  return {
    x: num(o.x ?? 0, `${what}.x`, x[0], x[1]),
    y: num(o.y ?? 0, `${what}.y`, y[0], y[1]),
    z: num(o.z ?? 0, `${what}.z`, z[0], z[1]),
  }
}

/** A prop's offset checked against the bounds of its anchor kind (or, without one, the widest bounds). */
function offsetFor(anchor: Anchor | null, v: unknown, what: string): Vec3 {
  const b = BOUNDS.offset
  if (anchor === null) return vec3(v ?? {}, what, [-b.room.xz, b.hallway.xMax], [0, b.room.y], [-b.room.xz, b.room.xz])
  if (anchor.kind === 'desk') return vec3(v ?? {}, what, [-b.desk.xz, b.desk.xz], [0, b.desk.y], [-b.desk.xz, b.desk.xz])
  if (anchor.kind === 'room') return vec3(v ?? {}, what, [-b.room.xz, b.room.xz], [0, b.room.y], [-b.room.xz, b.room.xz])
  return vec3(v ?? {}, what, [b.hallway.xMin, b.hallway.xMax], [0, b.hallway.y], [-b.hallway.z, b.hallway.z])
}

function parseAnchor(v: unknown, what: string): Anchor {
  const a = fields(v, what, ['kind', 'key', 'session', 'seat', 'project'])
  switch (a.kind) {
    case 'desk': {
      if (a.project !== undefined) refuse(what, 'a desk anchor has no project')
      if (a.key !== undefined) {
        if (a.session !== undefined || a.seat !== undefined) refuse(what, 'a desk is named by key, or by session and seat, not both')
        return { kind: 'desk', key: text(a.key, `${what}.key`, BOUNDS.key, KEY_RE) }
      }
      if (a.session !== undefined && a.seat !== undefined) {
        const seat = text(a.seat, `${what}.seat`, 12).toLowerCase().replace(/\s+/g, ' ')
        if (!SEAT_RE.test(seat)) refuse(`${what}.seat`, 'must be lead, or agent 1, agent 2 …')
        return { kind: 'desk', session: text(a.session, `${what}.session`, BOUNDS.session, SESSION_RE), seat }
      }
      return refuse(what, 'a desk anchor needs a key, or a session and a seat (lead, agent 1 …)')
    }
    case 'room':
      if (a.key !== undefined || a.session !== undefined || a.seat !== undefined) refuse(what, 'a room anchor has only a project')
      return { kind: 'room', project: text(a.project, `${what}.project`, BOUNDS.project) }
    case 'hallway':
      if (Object.keys(a).length !== 1) refuse(what, 'the hallway anchor has no other field')
      return { kind: 'hallway' }
    default:
      return refuse(`${what}.kind`, 'must be desk, room or hallway')
  }
}

const PART_COMMON = ['shape', 'color', 'roughness', 'metalness', 'at'] as const
const PART_FIELDS: Record<Part['shape'], readonly string[]> = {
  box: [...PART_COMMON, 'w', 'h', 'd'],
  cylinder: [...PART_COMMON, 'r', 'h'],
  sphere: [...PART_COMMON, 'r'],
  cone: [...PART_COMMON, 'r', 'h'],
  text: [...PART_COMMON, 'text', 'size'],
}

function parsePart(v: unknown, what: string): Part {
  if (!isRecord(v)) return refuse(what, 'must be an object')
  const shape = v.shape
  if (typeof shape !== 'string' || !(shape in PART_FIELDS)) return refuse(`${what}.shape`, 'must be box, cylinder, sphere, cone or text')
  const p = fields(v, what, PART_FIELDS[shape as Part['shape']])
  const roughness = unit(p.roughness, `${what}.roughness`)
  const metalness = unit(p.metalness, `${what}.metalness`)
  const at = p.at === undefined ? undefined : vec3(p.at, `${what}.at`, [-BOUNDS.partAt.xz, BOUNDS.partAt.xz], [0, BOUNDS.partAt.y], [-BOUNDS.partAt.xz, BOUNDS.partAt.xz])
  const base = {
    color: hex(p.color, `${what}.color`),
    ...(roughness !== undefined && { roughness }),
    ...(metalness !== undefined && { metalness }),
    ...(at !== undefined && { at }),
  }
  const size = (k: string) => num(p[k], `${what}.${k}`, BOUNDS.size.min, BOUNDS.size.max)
  const radius = () => num(p.r, `${what}.r`, BOUNDS.radius.min, BOUNDS.radius.max)
  switch (shape) {
    case 'box':
      return { shape, w: size('w'), h: size('h'), d: size('d'), ...base }
    case 'cylinder':
      return { shape, r: radius(), h: size('h'), ...base }
    case 'sphere':
      return { shape, r: radius(), ...base }
    case 'cone':
      return { shape, r: radius(), h: size('h'), ...base }
    default:
      return { shape: 'text', text: text(p.text, `${what}.text`, BOUNDS.text), size: num(p.size, `${what}.size`, BOUNDS.textSize.min, BOUNDS.textSize.max), ...base }
  }
}

function parseProp(v: unknown, what: string): Prop {
  const p = fields(v, what, ['id', 'name', 'anchor', 'offset', 'yaw', 'parts'])
  const id = text(p.id, `${what}.id`, BOUNDS.id)
  if (!ID_RE.test(id)) refuse(`${what}.id`, 'must be lowercase letters, digits, - or _, starting with a letter or digit')
  const name = text(p.name, `${what}.name`, BOUNDS.name)
  const anchor = parseAnchor(p.anchor, `${what}.anchor`)
  const offset = offsetFor(anchor, p.offset, `${what}.offset`)
  const yaw = p.yaw === undefined ? 0 : num(p.yaw, `${what}.yaw`, -BOUNDS.yaw, BOUNDS.yaw)
  if (!Array.isArray(p.parts)) return refuse(`${what}.parts`, 'must be a list')
  if (p.parts.length === 0) refuse(`${what}.parts`, 'must hold at least one part')
  if (p.parts.length > BOUNDS.maxParts) refuse(`${what}.parts`, `may hold at most ${BOUNDS.maxParts} parts`)
  const parts = p.parts.map((part, i) => parsePart(part, `${what}.parts[${i}]`))
  return { id, name, anchor, offset, yaw, parts }
}

function parseDeskSize(w: unknown, d: unknown, what: string): DeskSize {
  return { w: num(w, `${what}.w`, BOUNDS.desk.w.min, BOUNDS.desk.w.max), d: num(d, `${what}.d`, BOUNDS.desk.d.min, BOUNDS.desk.d.max) }
}

function parseRoomStyle(v: Record<string, unknown>, what: string): RoomStyle {
  const carpet = v.carpet === undefined ? undefined : hex(v.carpet, `${what}.carpet`)
  const walls = v.walls === undefined ? undefined : hex(v.walls, `${what}.walls`)
  const width = v.width === undefined ? undefined : num(v.width, `${what}.width`, BOUNDS.room.width.min, BOUNDS.room.width.max)
  const depth = v.depth === undefined ? undefined : num(v.depth, `${what}.depth`, BOUNDS.room.depth.min, BOUNDS.room.depth.max)
  return { ...(carpet !== undefined && { carpet }), ...(walls !== undefined && { walls }), ...(width !== undefined && { width }), ...(depth !== undefined && { depth }) }
}

function parseTheme(v: unknown, what: string): Theme {
  const t = fields(v, what, ['carpet', 'walls', 'ceiling', 'deskWood'])
  const out: Theme = {}
  for (const role of ['carpet', 'walls', 'ceiling', 'deskWood'] as const) if (t[role] !== undefined) out[role] = hex(t[role], `${what}.${role}`)
  return out
}

function parseEdit(v: unknown): SceneEdit {
  if (!isRecord(v)) return refuse('edit', 'must be an object')
  switch (v.type) {
    case 'addProp': {
      fields(v, 'edit', ['type', 'prop'])
      return { type: 'addProp', prop: parseProp(v.prop, 'prop') }
    }
    case 'removeProp': {
      fields(v, 'edit', ['type', 'id'])
      const id = text(v.id, 'edit.id', BOUNDS.id)
      if (!ID_RE.test(id)) refuse('edit.id', 'is not a prop id')
      return { type: 'removeProp', id }
    }
    case 'moveProp': {
      const e = fields(v, 'edit', ['type', 'id', 'anchor', 'offset', 'yaw'])
      const id = text(e.id, 'edit.id', BOUNDS.id)
      if (!ID_RE.test(id)) refuse('edit.id', 'is not a prop id')
      if (e.anchor === undefined && e.offset === undefined && e.yaw === undefined) refuse('edit', 'a move needs an anchor, an offset or a yaw')
      const anchor = e.anchor === undefined ? undefined : parseAnchor(e.anchor, 'edit.anchor')
      const offset = e.offset === undefined ? undefined : offsetFor(anchor ?? null, e.offset, 'edit.offset')
      const yaw = e.yaw === undefined ? undefined : num(e.yaw, 'edit.yaw', -BOUNDS.yaw, BOUNDS.yaw)
      return { type: 'moveProp', id, ...(anchor !== undefined && { anchor }), ...(offset !== undefined && { offset }), ...(yaw !== undefined && { yaw }) }
    }
    case 'resizeDesk': {
      const e = fields(v, 'edit', ['type', 'desk', 'w', 'd'])
      const desk = parseAnchor(e.desk, 'edit.desk')
      if (desk.kind !== 'desk') return refuse('edit.desk', 'must be a desk anchor')
      return { type: 'resizeDesk', desk, ...parseDeskSize(e.w, e.d, 'edit') }
    }
    case 'room': {
      const e = fields(v, 'edit', ['type', 'project', 'carpet', 'walls', 'width', 'depth'])
      const project = text(e.project, 'edit.project', BOUNDS.project)
      const style = parseRoomStyle(e, 'edit')
      if (Object.keys(style).length === 0) refuse('edit', 'a room edit needs a carpet, walls, width or depth')
      return { type: 'room', project, ...style }
    }
    case 'theme': {
      const e = fields(v, 'edit', ['type', 'carpet', 'walls', 'ceiling', 'deskWood'])
      const { type: _type, ...roles } = e
      const theme = parseTheme(roles, 'edit')
      if (Object.keys(theme).length === 0) refuse('edit', 'a theme edit needs a carpet, walls, ceiling or deskWood colour')
      return { type: 'theme', ...theme }
    }
    default:
      return refuse('edit.type', 'must be addProp, removeProp, moveProp, resizeDesk, room or theme')
  }
}

const reasonOf = (err: unknown): string => (err instanceof Refusal ? err.message : 'not a valid edit')

/** One edit from outside (the model, the window, the command line): the same edit, checked and normalised, or why not. */
export function validate(edit: unknown): { ok: true; edit: SceneEdit } | { ok: false; reason: string } {
  try {
    return { ok: true, edit: parseEdit(edit) }
  } catch (err) {
    return { ok: false, reason: reasonOf(err) }
  }
}

/** A whole scene from outside (the store): checked field by field, or why not. */
export function validateDoc(doc: unknown): { ok: true; doc: SceneDoc } | { ok: false; reason: string } {
  try {
    const d = fields(doc, 'doc', ['v', 'props', 'desks', 'rooms', 'theme'])
    if (d.v !== 1) refuse('doc.v', 'must be 1')
    if (!Array.isArray(d.props)) return refuse('doc.props', 'must be a list')
    if (d.props.length > BOUNDS.maxProps) refuse('doc.props', `may hold at most ${BOUNDS.maxProps} props`)
    const props = d.props.map((p, i) => parseProp(p, `doc.props[${i}]`))
    const ids = new Set<string>()
    for (const p of props) {
      if (ids.has(p.id)) refuse('doc.props', `the id ${p.id} is used twice`)
      ids.add(p.id)
    }
    if (!isRecord(d.desks)) return refuse('doc.desks', 'must be an object')
    const deskKeys = Object.keys(d.desks)
    if (deskKeys.length > BOUNDS.maxDesks) refuse('doc.desks', `may hold at most ${BOUNDS.maxDesks} desks`)
    const desks: Record<string, DeskSize> = {}
    for (const k of deskKeys) {
      const key = text(k, 'doc.desks key', BOUNDS.key, KEY_RE)
      const s = fields(d.desks[k], `doc.desks.${fieldName(k)}`, ['w', 'd'])
      desks[key] = parseDeskSize(s.w, s.d, `doc.desks.${fieldName(k)}`)
    }
    if (!isRecord(d.rooms)) return refuse('doc.rooms', 'must be an object')
    const roomKeys = Object.keys(d.rooms)
    if (roomKeys.length > BOUNDS.maxRooms) refuse('doc.rooms', `may hold at most ${BOUNDS.maxRooms} rooms`)
    const rooms: Record<string, RoomStyle> = {}
    for (const k of roomKeys) {
      const project = text(k, 'doc.rooms key', BOUNDS.project)
      rooms[project] = parseRoomStyle(fields(d.rooms[k], `doc.rooms.${fieldName(k)}`, ['carpet', 'walls', 'width', 'depth']), `doc.rooms.${fieldName(k)}`)
    }
    return { ok: true, doc: { v: 1, props, desks, rooms, theme: parseTheme(d.theme ?? {}, 'doc.theme') } }
  } catch (err) {
    return { ok: false, reason: reasonOf(err) }
  }
}

export const emptyDoc = (): SceneDoc => ({ v: 1, props: [], desks: {}, rooms: {}, theme: {} })

// ─── Resolving anchors against the office ──────────────────────────────────
const deskKeyOf = (anchor: DeskAnchor, ctx: DesignContext): string | null => {
  if ('key' in anchor) return ctx.desks.some(d => d.key === anchor.key) ? anchor.key : null
  const wanted = anchor.seat
  const hit = ctx.desks.find(d => d.session === anchor.session && d.label.trim().toLowerCase() === wanted)
  return hit === undefined ? null : hit.key
}

/** Is `arcade`, or a project with a room now. */
const roomExists = (project: string, ctx: DesignContext): boolean => project === 'arcade' || ctx.rooms.some(r => r.project === project)

function resolveAnchor(anchor: Anchor, ctx: DesignContext): Anchor {
  if (anchor.kind === 'desk') {
    const key = deskKeyOf(anchor, ctx)
    if (key === null) refuse('anchor', 'key' in anchor ? `no desk has the key ${anchor.key}` : `session ${anchor.session} has no ${anchor.seat} desk`)
    return { kind: 'desk', key }
  }
  if (anchor.kind === 'room' && !roomExists(anchor.project, ctx)) refuse('anchor', `no room for the project ${anchor.project}`)
  return anchor
}

/**
 * A valid edit with its anchors resolved against the office now: a desk named
 * by session and seat becomes its worker key, and a desk or room that does
 * not exist refuses the edit.
 */
export function resolveEdit(edit: SceneEdit, ctx: DesignContext): { ok: true; edit: SceneEdit } | { ok: false; reason: string } {
  try {
    switch (edit.type) {
      case 'addProp':
        return { ok: true, edit: { ...edit, prop: { ...edit.prop, anchor: resolveAnchor(edit.prop.anchor, ctx) } } }
      case 'moveProp':
        return { ok: true, edit: edit.anchor === undefined ? edit : { ...edit, anchor: resolveAnchor(edit.anchor, ctx) } }
      case 'resizeDesk': {
        const desk = resolveAnchor(edit.desk, ctx)
        return desk.kind === 'desk' ? { ok: true, edit: { ...edit, desk } } : { ok: false, reason: 'edit.desk: must be a desk' }
      }
      case 'room':
        if (!roomExists(edit.project, ctx)) return { ok: false, reason: `edit.project: no room for the project ${edit.project}` }
        return { ok: true, edit }
      default:
        return { ok: true, edit }
    }
  } catch (err) {
    return { ok: false, reason: reasonOf(err) }
  }
}

// ─── Folding edits into a scene ────────────────────────────────────────────
function checkOffset(prop: Prop): string | null {
  try {
    offsetFor(prop.anchor, prop.offset, 'offset')
    return null
  } catch (err) {
    return reasonOf(err)
  }
}

/**
 * The scene with `edits` applied in order, and the edits that could not be:
 * a remove or move of an unknown prop, a prop past the cap, a move that
 * leaves the offset outside its new anchor's bounds, a desk still named by
 * session and seat. Pure: `doc` and `edits` are not changed.
 */
export function foldEdits(doc: SceneDoc, edits: readonly SceneEdit[]): { doc: SceneDoc; refused: { index: number; reason: string }[] } {
  let props = doc.props.slice()
  let desks = { ...doc.desks }
  let rooms = { ...doc.rooms }
  let theme = { ...doc.theme }
  const refused: { index: number; reason: string }[] = []
  edits.forEach((edit, index) => {
    switch (edit.type) {
      case 'addProp': {
        const at = props.findIndex(p => p.id === edit.prop.id)
        if (at >= 0) props = props.map((p, i) => (i === at ? edit.prop : p))
        else if (props.length >= BOUNDS.maxProps) refused.push({ index, reason: `the scene holds at most ${BOUNDS.maxProps} props` })
        else props = [...props, edit.prop]
        return
      }
      case 'removeProp': {
        if (!props.some(p => p.id === edit.id)) return void refused.push({ index, reason: `no prop has the id ${edit.id}` })
        props = props.filter(p => p.id !== edit.id)
        return
      }
      case 'moveProp': {
        const at = props.findIndex(p => p.id === edit.id)
        if (at < 0) return void refused.push({ index, reason: `no prop has the id ${edit.id}` })
        const moved: Prop = { ...props[at]!, ...(edit.anchor !== undefined && { anchor: edit.anchor }), ...(edit.offset !== undefined && { offset: edit.offset }), ...(edit.yaw !== undefined && { yaw: edit.yaw }) }
        const bad = checkOffset(moved)
        if (bad !== null) return void refused.push({ index, reason: bad })
        props = props.map((p, i) => (i === at ? moved : p))
        return
      }
      case 'resizeDesk': {
        if (!('key' in edit.desk)) return void refused.push({ index, reason: 'the desk was not resolved to a worker key' })
        if (!(edit.desk.key in desks) && Object.keys(desks).length >= BOUNDS.maxDesks) return void refused.push({ index, reason: `at most ${BOUNDS.maxDesks} desks can be resized` })
        desks = { ...desks, [edit.desk.key]: { w: edit.w, d: edit.d } }
        return
      }
      case 'room': {
        const { type: _type, project, ...style } = edit
        if (!(project in rooms) && Object.keys(rooms).length >= BOUNDS.maxRooms) return void refused.push({ index, reason: `at most ${BOUNDS.maxRooms} rooms can be styled` })
        rooms = { ...rooms, [project]: { ...rooms[project], ...style } }
        return
      }
      case 'theme': {
        const { type: _type, ...roles } = edit
        theme = { ...theme, ...roles }
        return
      }
    }
  })
  return { doc: { v: 1, props, desks, rooms, theme }, refused }
}

/** The scene with `edits` applied; what cannot be applied is left out. Pure. */
export const applyEdits = (doc: SceneDoc, edits: readonly SceneEdit[]): SceneDoc => foldEdits(doc, edits).doc

// ─── Words ─────────────────────────────────────────────────────────────────
const m = (n: number): string => `${Math.round(n * 100) / 100} m`

export function anchorWords(anchor: Anchor): string {
  if (anchor.kind === 'hallway') return 'the hallway'
  if (anchor.kind === 'room') return anchor.project === 'arcade' ? 'the arcade' : `the ${anchor.project} room`
  return 'key' in anchor ? `the desk of ${anchor.key}` : `the ${anchor.seat} desk of session ${anchor.session}`
}

const offsetWords = (o: Vec3): string => `(${m(o.x)}, ${m(o.y)}, ${m(o.z)})`

/** One edit in words, for the panel and the command line. */
export function describeEdit(edit: SceneEdit): string {
  switch (edit.type) {
    case 'addProp':
      return `add "${edit.prop.name}" (${edit.prop.id}: ${edit.prop.parts.length} part${edit.prop.parts.length === 1 ? '' : 's'}) at ${anchorWords(edit.prop.anchor)} + ${offsetWords(edit.prop.offset)}`
    case 'removeProp':
      return `remove the prop ${edit.id}`
    case 'moveProp':
      return `move the prop ${edit.id}${edit.anchor ? ` to ${anchorWords(edit.anchor)}` : ''}${edit.offset ? ` at ${offsetWords(edit.offset)}` : ''}${edit.yaw !== undefined ? ` turned ${edit.yaw}°` : ''}`
    case 'resizeDesk':
      return `resize ${anchorWords(edit.desk)} to ${m(edit.w)} by ${m(edit.d)}`
    case 'room': {
      const bits = [edit.carpet && `carpet ${edit.carpet}`, edit.walls && `walls ${edit.walls}`, edit.width && `width ${m(edit.width)}`, edit.depth && `depth ${m(edit.depth)}`].filter(Boolean)
      return `${anchorWords({ kind: 'room', project: edit.project })}: ${bits.join(', ')}`
    }
    case 'theme': {
      const bits = (['carpet', 'walls', 'ceiling', 'deskWood'] as const).filter(r => edit[r] !== undefined).map(r => `${r} ${edit[r]}`)
      return `theme: ${bits.join(', ')}`
    }
  }
}

/** The scene in a few lines, for the model and for `/3d design list`. */
export function summarizeDoc(doc: SceneDoc): string {
  const lines: string[] = []
  lines.push(doc.props.length === 0 ? 'Props: none yet.' : `Props (${doc.props.length} of ${BOUNDS.maxProps}):`)
  for (const p of doc.props) lines.push(`- ${p.id} "${p.name}": ${p.parts.length} part${p.parts.length === 1 ? '' : 's'} at ${anchorWords(p.anchor)} + ${offsetWords(p.offset)}${p.yaw ? `, yaw ${p.yaw}°` : ''}`)
  const desks = Object.entries(doc.desks)
  lines.push(desks.length === 0 ? 'Desks: all at the default 0.9 m by 0.6 m.' : `Desks resized: ${desks.map(([k, s]) => `${k} ${m(s.w)} by ${m(s.d)}`).join('; ')}`)
  const rooms = Object.entries(doc.rooms)
  lines.push(rooms.length === 0 ? 'Rooms: all default.' : `Rooms styled: ${rooms.map(([k, r]) => `${k} ${JSON.stringify(r)}`).join('; ')}`)
  const theme = Object.entries(doc.theme)
  lines.push(theme.length === 0 ? 'Theme: default.' : `Theme: ${theme.map(([k, v]) => `${k} ${v}`).join(', ')}`)
  return lines.join('\n')
}
