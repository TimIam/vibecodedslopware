// A send and the states it can be shown in. Each state is claimed only on its
// own evidence: `queued` from the sender's $.session.send result; the rest from
// the receipt the receiving loop's own hooks recorded. Nothing is inferred from
// elapsed time, and queued never means read.

import type { MuseumReceipt, MuseumSend, MuseumSendState } from '../types'

export const MAX_TEXT = 2000
export const MAX_SENDS = 20

/** A fresh `MUSEUM-NONCE-` followed by 12 hex digits. */
export function newNonce(): string {
  const bytes = new Uint8Array(6)
  crypto.getRandomValues(bytes)
  return 'MUSEUM-NONCE-' + Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('')
}

/** The text the target reads: the person's words, then the reference. */
export const compose = (text: string, nonce: string): string => `${text}\n\nmuseum-ref: ${nonce}`

const AFTER_QUEUED: readonly MuseumSendState[] = [
  'queued',
  'arrived',
  'in-conversation',
  'turn-started',
  'answered',
  'turn-failed',
  'unverified',
]

/** Still waiting on something the target has not shown yet. */
export const isOutstanding = (send: MuseumSend): boolean =>
  ['sending', 'queued', 'arrived', 'in-conversation', 'turn-started'].includes(send.state)

/** The state a receipt supports, from its strongest evidence. */
export function stateOf(receipt: MuseumReceipt): MuseumSendState {
  if (receipt.turnEndedAt !== null) return receipt.turnReason === 'answer' ? 'answered' : 'turn-failed'
  if (receipt.turnStartedAt !== null) return 'turn-started'
  if (receipt.inConversationAt !== null) return 'in-conversation'
  return 'arrived'
}

/**
 * The send moved on by what the target's loop recorded. `receipts` undefined
 * means nothing about the target is observable any more (a peer that left):
 * a queued send is then `unverified`.
 */
export function deriveSend(send: MuseumSend, receipts: readonly MuseumReceipt[] | undefined): MuseumSend {
  if (!AFTER_QUEUED.includes(send.state)) return send
  if (receipts === undefined) return send.receipt === null && send.state === 'queued' ? { ...send, state: 'unverified' } : send
  const receipt = receipts.find(r => r.nonce === send.nonce)
  if (receipt === undefined) return send.state === 'unverified' ? { ...send, state: 'queued' } : send
  return { ...send, state: stateOf(receipt), receipt }
}

/** One plain line saying what is known, and what is not. */
export function describeState(send: MuseumSend): string {
  const r = send.receipt
  const link = r !== null && !r.turnCarriesNonce ? " (that turn's start text does not carry this message's reference, so the link is not confirmed)" : ''
  switch (send.state) {
    case 'sending':
      return 'sending…'
    case 'failed':
      return `not sent: ${send.reason ?? 'unknown reason'}`
    case 'queued':
      return 'queued at the target; not yet seen by it'
    case 'arrived':
      return "arrived at the target's receive hook; no turn on it seen yet"
    case 'in-conversation':
      return "a row of the target's own transcript carries it; no turn on it seen yet"
    case 'turn-started':
      return `a turn started in the target after it arrived${link}`
    case 'answered':
      return r?.acknowledged
        ? "the target's turn ended with an answer carrying this message's ACK"
        : `the target's turn ended with an answer (no ACK in it)${link}`
    case 'turn-failed':
      return `the target's turn after it ended: ${r?.turnReason ?? 'unknown'}${r?.turnAnswerHead ? `: "${r.turnAnswerHead}"` : ''}${link}`
    case 'unverified':
      return 'queued, but the target is no longer observable: nothing past queued can be seen'
  }
}
