// The gallery: a small room with three wall-hung frames, one per enrolled
// conversation, projected in software and written as one SVG document.
// Mods have no Canvas, WebGL or DOM (docs/FEASIBILITY.md); the Desktop draws
// this SVG natively, as an image, inside the mod's pane.
//
// `wallToWorld` and `viewpointFor` are adapted from social-museum
// (src/layout.js and src/controls.js); see docs/PROVENANCE.md.

import type { MuseumCamera, MuseumFrame } from '../types'
import { oneLine, xml } from './sanitize'

type V3 = readonly [number, number, number]
type P2 = { x: number; y: number }

export type WallId = 'left' | 'back' | 'right'
type Wall = { origin: V3; along: V3; normal: V3; length: number }

export const ROOM = { halfWidth: 4, back: -6, front: 2, height: 3.2 } as const

// A wall runs from its left end (seen from inside the room) along `along`;
// `normal` faces into the room. Wall-local (u, v): metres along it, and up.
export const WALLS: Record<WallId, Wall> = {
  left: { origin: [-4, 0, 2], along: [0, 0, -1], normal: [1, 0, 0], length: 8 },
  back: { origin: [-4, 0, -6], along: [1, 0, 0], normal: [0, 0, 1], length: 8 },
  right: { origin: [4, 0, -6], along: [0, 0, 1], normal: [-1, 0, 0], length: 8 },
}

export const FRAME = { width: 1.8, height: 1.25, border: 0.09, offset: 0.03, viewDistance: 2.1 } as const
export const EYE_HEIGHT = 1.6
const PITCH_LIMIT = 0.6

/** Where each of the three frames hangs. */
export const SLOTS: readonly { wall: WallId; u: number; v: number }[] = [
  { wall: 'left', u: 5.4, v: 1.65 },
  { wall: 'back', u: 4, v: 1.65 },
  { wall: 'right', u: 2.6, v: 1.65 },
]

export const OVERVIEW: MuseumCamera = { x: 0, y: EYE_HEIGHT, z: 1.85, yaw: 0, pitch: -0.02 }

export const VIEW = { width: 960, height: 540, fovY: (62 * Math.PI) / 180, near: 0.05 } as const

const add = (a: V3, b: V3): V3 => [a[0] + b[0], a[1] + b[1], a[2] + b[2]]
const scale = (a: V3, k: number): V3 => [a[0] * k, a[1] * k, a[2] * k]
const UP: V3 = [0, 1, 0]

/**
 * World position of wall-local (u, v), `offset` metres out from the face.
 * Adapted from social-museum src/layout.js `wallToWorld`.
 */
export function wallToWorld(wallId: WallId, u: number, v: number, offset = 0): V3 {
  const w = WALLS[wallId]
  return [
    w.origin[0] + w.along[0] * u + w.normal[0] * offset,
    v,
    w.origin[2] + w.along[2] * u + w.normal[2] * offset,
  ]
}

const clamp = (v: number, lo: number, hi: number): number => (v < lo ? lo : v > hi ? hi : v)

/**
 * A camera standing `distance` metres out along a wall work's facing and
 * looking at it. `rotY` turns +Z to (sin, 0, cos); the camera's yaw θ looks
 * down (-sin θ, 0, -cos θ), as in social-museum. Adapted from social-museum
 * src/controls.js `viewpointFor`, with the walkable-area and collider clamps
 * replaced by a clamp inside this one empty room.
 */
export function viewpointFor(target: { x: number; y: number; z: number }, distance: number, rotY: number): MuseumCamera {
  const nx = Math.sin(rotY)
  const nz = Math.cos(rotY)
  const x = clamp(target.x + nx * distance, -ROOM.halfWidth + 0.3, ROOM.halfWidth - 0.3)
  const z = clamp(target.z + nz * distance, ROOM.back + 0.3, ROOM.front - 0.3)
  const dx = target.x - x
  const dz = target.z - z
  const flat = Math.hypot(dx, dz)
  const pitch = clamp(Math.atan2(target.y - EYE_HEIGHT, Math.max(flat, 1e-3)), -PITCH_LIMIT, PITCH_LIMIT)
  return { x, y: EYE_HEIGHT, z, yaw: Math.atan2(-dx, -dz), pitch }
}

/** The centre of slot `i`'s canvas, in the world. */
export function slotCenter(i: number): V3 {
  const slot = SLOTS[i] ?? SLOTS[1]!
  return wallToWorld(slot.wall, slot.u, slot.v, FRAME.offset)
}

/** The camera that looks at slot `i` straight on. */
export function cameraForSlot(i: number): MuseumCamera {
  const slot = SLOTS[i] ?? SLOTS[1]!
  const n = WALLS[slot.wall].normal
  const c = slotCenter(i)
  return viewpointFor({ x: c[0], y: c[1], z: c[2] }, FRAME.viewDistance, Math.atan2(n[0], n[2]))
}

const ease = (t: number): number => t * t * (3 - 2 * t)

/** The camera `t` of the way (0..1, eased) from `a` to `b`, turning the short way. */
export function tweenCamera(a: MuseumCamera, b: MuseumCamera, t: number): MuseumCamera {
  const k = ease(clamp(t, 0, 1))
  if (k >= 1) return { ...b }
  let dYaw = b.yaw - a.yaw
  while (dYaw > Math.PI) dYaw -= 2 * Math.PI
  while (dYaw < -Math.PI) dYaw += 2 * Math.PI
  return {
    x: a.x + (b.x - a.x) * k,
    y: a.y + (b.y - a.y) * k,
    z: a.z + (b.z - a.z) * k,
    yaw: a.yaw + dYaw * k,
    pitch: a.pitch + (b.pitch - a.pitch) * k,
  }
}

/** World → view space (camera at the origin looking down -Z), and view → SVG pixels. */
export function makeProjector(cam: MuseumCamera) {
  const cy = Math.cos(cam.yaw)
  const sy = Math.sin(cam.yaw)
  const cp = Math.cos(cam.pitch)
  const sp = Math.sin(cam.pitch)
  const focal = VIEW.height / 2 / Math.tan(VIEW.fovY / 2)
  const view = (p: V3): V3 => {
    const dx = p[0] - cam.x
    const dy = p[1] - cam.y
    const dz = p[2] - cam.z
    const x1 = dx * cy - dz * sy
    const z1 = dx * sy + dz * cy
    return [x1, dy * cp + z1 * sp, -dy * sp + z1 * cp]
  }
  const project = (v: V3): P2 => {
    const depth = -v[2]
    return {
      x: clamp(VIEW.width / 2 + (focal * v[0]) / depth, -1e5, 1e5),
      y: clamp(VIEW.height / 2 - (focal * v[1]) / depth, -1e5, 1e5),
    }
  }
  return { view, project, focal }
}

const isFront = (v: V3): boolean => v[2] <= -VIEW.near

/** Sutherland–Hodgman against the near plane, in view space. */
export function clipNear(poly: readonly V3[]): V3[] {
  const out: V3[] = []
  for (let i = 0; i < poly.length; i++) {
    const a = poly[i]!
    const b = poly[(i + 1) % poly.length]!
    if (isFront(a)) out.push(a)
    if (isFront(a) !== isFront(b)) {
      const t = (-VIEW.near - a[2]) / (b[2] - a[2])
      out.push([a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, -VIEW.near])
    }
  }
  return out
}

const n1 = (v: number): string => (Math.round(v * 10) / 10).toString()

type Projector = ReturnType<typeof makeProjector>

function polygon(pr: Projector, world: readonly V3[], attrs: string): string {
  const clipped = clipNear(world.map(pr.view))
  if (clipped.length < 3) return ''
  const pts = clipped.map(v => pr.project(v))
  return `<path d="M${pts.map(p => `${n1(p.x)} ${n1(p.y)}`).join('L')}Z" ${attrs}/>`
}

function segment(pr: Projector, a: V3, b: V3, attrs: string): string {
  let va = pr.view(a)
  let vb = pr.view(b)
  if (!isFront(va) && !isFront(vb)) return ''
  if (!isFront(va) || !isFront(vb)) {
    const t = (-VIEW.near - va[2]) / (vb[2] - va[2])
    const cut: V3 = [va[0] + (vb[0] - va[0]) * t, va[1] + (vb[1] - va[1]) * t, -VIEW.near]
    if (isFront(va)) vb = cut
    else va = cut
  }
  const p = pr.project(va)
  const q = pr.project(vb)
  return `<line x1="${n1(p.x)}" y1="${n1(p.y)}" x2="${n1(q.x)}" y2="${n1(q.y)}" ${attrs}/>`
}

const H = ROOM.height
const W = ROOM.halfWidth
const ROOM_FACES: readonly { pts: V3[]; fill: string }[] = [
  { pts: [[-W, 0, ROOM.front], [W, 0, ROOM.front], [W, 0, ROOM.back], [-W, 0, ROOM.back]], fill: '#5d4835' },
  { pts: [[-W, H, ROOM.front], [-W, H, ROOM.back], [W, H, ROOM.back], [W, H, ROOM.front]], fill: '#f2eee6' },
  { pts: [[-W, 0, ROOM.front], [-W, 0, ROOM.back], [-W, H, ROOM.back], [-W, H, ROOM.front]], fill: '#e2d9ca' },
  { pts: [[W, 0, ROOM.back], [W, 0, ROOM.front], [W, H, ROOM.front], [W, H, ROOM.back]], fill: '#e2d9ca' },
  { pts: [[-W, 0, ROOM.back], [W, 0, ROOM.back], [W, H, ROOM.back], [-W, H, ROOM.back]], fill: '#ece5d8' },
  { pts: [[W, 0, ROOM.front], [-W, 0, ROOM.front], [-W, H, ROOM.front], [W, H, ROOM.front]], fill: '#d9cfbe' },
]

const STATUS_COLOR = { idle: '#4caf50', busy: '#f0a020', stale: '#9e9e9e', empty: '#6b6b6b' } as const

/** What the gallery draws: up to three frames, which is selected, and the camera. */
export type GalleryInput = {
  frames: readonly MuseumFrame[]
  selectedId: string | null
  camera: MuseumCamera
  caption: string
}

/** The SVG text of the gallery as the camera sees it. Every text in it is escaped. */
export function renderGallerySvg(input: GalleryInput): string {
  const pr = makeProjector(input.camera)
  const out: string[] = []
  out.push(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${VIEW.width} ${VIEW.height}" width="${VIEW.width}" height="${VIEW.height}" font-family="-apple-system, system-ui, sans-serif">`,
    `<rect width="${VIEW.width}" height="${VIEW.height}" fill="#1b1d22"/>`,
  )
  for (const face of ROOM_FACES) out.push(polygon(pr, face.pts, `fill="${face.fill}"`))
  for (let x = -W + 1; x < W; x += 1) {
    out.push(segment(pr, [x, 0.001, ROOM.front], [x, 0.001, ROOM.back], 'stroke="#4a3929" stroke-width="1"'))
  }
  for (const wall of ['left', 'back', 'right'] as const) {
    const w = WALLS[wall]
    out.push(segment(pr, wallToWorld(wall, 0, 0.12, 0.002), wallToWorld(wall, w.length, 0.12, 0.002), 'stroke="#b9ad99" stroke-width="2"'))
  }
  const order = SLOTS.map((_, i) => i).sort((a, b) => pr.view(slotCenter(a))[2] - pr.view(slotCenter(b))[2])
  for (const i of order) out.push(drawFrame(pr, i, input.frames[i], input.frames[i]?.sessionId === input.selectedId))
  out.push(
    `<rect x="12" y="${VIEW.height - 40}" width="${VIEW.width - 24}" height="28" rx="6" fill="#000" fill-opacity="0.45"/>`,
    `<text x="24" y="${VIEW.height - 21}" font-size="15" fill="#f3eee4">${xml(oneLine(input.caption, 110))}</text>`,
    '</svg>',
  )
  return out.join('')
}

function drawFrame(pr: Projector, i: number, frame: MuseumFrame | undefined, isSelected: boolean): string {
  const slot = SLOTS[i]!
  const wall = WALLS[slot.wall]
  const c = slotCenter(i)
  const hw = FRAME.width / 2
  const hh = FRAME.height / 2
  const at = (du: number, dv: number, out = 0): V3 => add(add(add(c, scale(wall.along, du)), scale(UP, dv)), scale(wall.normal, out))
  const quad = (w: number, h: number, out = 0, du = 0, dv = 0): V3[] => [
    at(du - w, dv + h, out),
    at(du + w, dv + h, out),
    at(du + w, dv - h, out),
    at(du - w, dv - h, out),
  ]
  const parts: string[] = []
  if (isSelected) {
    const apex = add(add(c, scale(wall.normal, 1.1)), [0, H - 0.02 - c[1], 0])
    const o = quad(hw + FRAME.border, hh + FRAME.border)
    parts.push(polygon(pr, [apex, o[0]!, o[3]!, o[2]!, o[1]!], 'fill="#fff1c9" fill-opacity="0.22"'))
  }
  parts.push(polygon(pr, quad(hw + FRAME.border, hh + FRAME.border, -0.01, 0.04, -0.05), 'fill="#000" fill-opacity="0.25"'))
  parts.push(
    polygon(
      pr,
      quad(hw + FRAME.border, hh + FRAME.border),
      isSelected ? 'fill="#b08d57" stroke="#d97757" stroke-width="4"' : 'fill="#b08d57" stroke="#6b5530" stroke-width="1.5"',
    ),
  )
  parts.push(polygon(pr, quad(hw, hh, 0.005), `fill="${frame ? '#20242c' : '#3a3d44'}"`))
  const status = frame === undefined ? 'empty' : frame.isStale ? 'stale' : frame.status
  parts.push(polygon(pr, quad(0.06, 0.06, -0.02, 0, -hh - FRAME.border - 0.12), `fill="${STATUS_COLOR[status]}"`))
  parts.push(canvasText(pr, c, wall, frame, i, status))
  return parts.join('')
}

// The canvas's local text space, LW × LH units, laid on the projected canvas
// by the projection's first-order (affine) map at the canvas centre.
const LW = 360
const LH = 250

function canvasText(pr: Projector, c: V3, wall: Wall, frame: MuseumFrame | undefined, i: number, status: string): string {
  const hw = FRAME.width / 2
  const hh = FRAME.height / 2
  const lift = scale(wall.normal, 0.006)
  const views = [c, add(c, scale(wall.along, hw)), add(c, scale(wall.along, -hw)), add(c, scale(UP, hh)), add(c, scale(UP, -hh))]
    .map(p => pr.view(add(p, lift)))
  if (!views.every(isFront)) return ''
  const [center, right, left, top, bottom] = views.map(pr.project) as [P2, P2, P2, P2, P2]
  const a = (right.x - left.x) / LW
  const b = (right.y - left.y) / LW
  const cc = (bottom.x - top.x) / LH
  const d = (bottom.y - top.y) / LH
  if (Math.abs(a * d - b * cc) < 1e-4) return ''
  const e = center.x - a * (LW / 2) - cc * (LH / 2)
  const f = center.y - b * (LW / 2) - d * (LH / 2)
  const rows: string[] = []
  const text = (x: number, y: number, size: number, fill: string, body: string, weight = 400) =>
    rows.push(`<text x="${x}" y="${y}" font-size="${size}" font-weight="${weight}" fill="${fill}">${xml(body)}</text>`)
  if (frame === undefined) {
    text(20, 40, 24, '#c9c3b8', `Frame ${i + 1}: empty`, 600)
    text(20, 76, 16, '#a39d93', 'Run /museum enroll in a conversation')
    text(20, 100, 16, '#a39d93', 'to hang it here.')
  } else {
    text(20, 38, 24, '#f3eee4', oneLine(frame.label, 26), 600)
    text(20, 64, 15, '#b9b2a6', `${i + 1} · ${status} · ${frame.messageCount} messages`)
    const lines = frame.snapshot.slice(-5)
    lines.forEach((line, k) => {
      text(20, 100 + k * 30, 16, line.role === 'user' ? '#9fc3ff' : '#d8d2c6', `${line.role === 'user' ? 'you' : 'claude'}: ${oneLine(line.text, 32)}`)
    })
    if (lines.length === 0) text(20, 100, 16, '#a39d93', '(no messages yet)')
  }
  // Text never spills past the canvas, however the frame is turned.
  const clip = `museum-canvas-${i + 1}`
  return (
    `<g transform="matrix(${[a, b, cc, d, e, f].map(v => (Math.round(v * 1e4) / 1e4).toString()).join(' ')})">` +
    `<clipPath id="${clip}"><rect x="0" y="0" width="${LW}" height="${LH}"/></clipPath>` +
    `<g clip-path="url(#${clip})">${rows.join('')}</g></g>`
  )
}

/** What a reader who cannot see the SVG is told it shows. */
export function gallerySummary(frames: readonly MuseumFrame[], selectedId: string | null): string {
  const parts = SLOTS.map((_, i) => {
    const f = frames[i]
    if (f === undefined) return `frame ${i + 1} empty`
    return `frame ${i + 1}: ${oneLine(f.label, 40)} (${f.isStale ? 'stale' : f.status}${f.sessionId === selectedId ? ', selected' : ''})`
  })
  return `Session Museum gallery, ${parts.join('; ')}.`
}
